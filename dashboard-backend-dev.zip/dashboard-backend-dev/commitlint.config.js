const { RuleConfigSeverity } = require('@commitlint/types');

const Configuration = {
  extends: ['@commitlint/config-conventional'],

  rules: {
    'header-max-length': [2, 'always', 75],
    'scope-min-length': [2, 'always', 2],
    'body-max-line-length': [RuleConfigSeverity.Disabled],
    /*'scope-empty': [2, 'never', false], Optional for now **/
    'type-enum': [2, 'always', ['feat', 'fix', 'docs', 'refactor', 'test', 'revert', 'wip', 'chore', 'lint']],
    'scope-enum': [
      2,
      'always',
      [
        'app',
        'auth',
        'layout',
        'profile',
        'inv',
        'stocks',
        'funds',
        'portfolio',
        'favorites',
        'store',
        'kyc',
        'pages',
        'a11y',
        'i18n',
        'analytics',
        'pension',
        'recommendations',
        'houston',
        'formally',
      ],
    ],
  },

  /*
   * Custom URL to show upon failure
   */
  helpUrl: 'https://github.com/conventional-changelog/commitlint/#what-is-commitlint',
  /*
   * Custom prompt configs
   */
  prompt: {
    messages: {},
    questions: {
      type: {
        description: 'please input type:',
      },
    },
  },

  parserPreset: {
    parserOpts: {
      issuePrefixes: ['FINK-'],
    },
  },

  ignores: [
    (message) => {
      const ignores = ['Squashed', 'Merge branch', 'WIP'];

      return ignores.some((ignore) => message.includes(ignore));
    },
  ],
};

module.exports = Configuration;
