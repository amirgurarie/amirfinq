import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Client api server is running.<br/>open /api for the swagger page.';
  }
}
