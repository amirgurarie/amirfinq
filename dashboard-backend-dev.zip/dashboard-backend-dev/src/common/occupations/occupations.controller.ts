import { AbstractController } from '../../shared/controller';
import { ConfigService } from '@nestjs/config';
import { Controller, Get, UseInterceptors } from '@nestjs/common';
import { ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { OccupationSubject } from './subjects/occupation.subject';
import { ApiDataArrayResponse } from '../../shared/decorators/dataResponse.decorator';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { OccupationsService } from './occupations.service';

@ApiTags('Common')
@Controller('v1/occupations')
@ApiExtraModels(OccupationSubject)
export class OccupationsController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    private readonly occupationsService: OccupationsService,
  ) {
    super(configService);
  }

  @Get()
  @ApiOperation({ summary: 'Get all occupations' })
  @ApiDataArrayResponse(OccupationSubject, 'All occupations')
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getOccupations() {
    const res = await this.occupationsService.findAll({ cache: true });

    return this.transformToArray(res, OccupationSubject);
  }
}
