import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class OccupationSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  descriptionHe: string;

  @Expose()
  @ApiProperty()
  descriptionEn: string;
}
