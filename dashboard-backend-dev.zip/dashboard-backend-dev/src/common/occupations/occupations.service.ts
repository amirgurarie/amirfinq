import { ServiceHelper } from '../../shared/modules/service.helper';
import { RefUserOccupations } from '../../entities/RefUserOccupations';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';

@Injectable()
export class OccupationsService extends ServiceHelper<RefUserOccupations> {
  constructor(
    @InjectRepository(RefUserOccupations)
    private readonly refUserOccupationsRepository: Repository<RefUserOccupations>,
  ) {
    super(refUserOccupationsRepository);
  }
}
