import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RefUserOccupations } from '../../entities/RefUserOccupations';
import { OccupationsService } from './occupations.service';
import { OccupationsController } from './occupations.controller';

@Module({
  imports: [TypeOrmModule.forFeature([RefUserOccupations])],
  providers: [OccupationsService],
  controllers: [OccupationsController],
  exports: [OccupationsService],
})
export class OccupationsModule {}
