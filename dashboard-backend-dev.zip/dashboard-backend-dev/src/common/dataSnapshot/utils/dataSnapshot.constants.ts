import { PayActionStatus } from '../../../payments/types/payment.enum';
import { ProductTempTypes } from '../../productTemp/types/productTemp.types';

export const EXCLUDED_EMAILS: string[] = [
  '%finqai.com',
  '%finqai.co.il',
  '%finqfinance.com',
  '%tamfish%',
  '%iditkatz%',
  '%eldadtamir%',
  '%mailosaur%',
  '%action-item%',
];

export const ALL_PAYMENT_STATUSES: PayActionStatus[] = [
  'FREE_PLAN_SUBSCRIPTION',
  'PAID_SUCCESSFUL_SUBSCRIPTION',
  'COMPLETED_SUBSCRIPTION',
];

export const PAID_PAYMENT_STATUSES: PayActionStatus[] = ['PAID_SUCCESSFUL_SUBSCRIPTION', 'COMPLETED_SUBSCRIPTION'];

export const INCLUDED_PLANS: ProductTempTypes.PeriodTypeEnum[] = [
  ProductTempTypes.PeriodTypeEnum.FREE,
  ProductTempTypes.PeriodTypeEnum.MONTHLY,
  ProductTempTypes.PeriodTypeEnum.ANNUAL,
];

export const HISTORY_START_DATE = '2024-07-01';
