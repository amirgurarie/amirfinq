import { HttpModule, Module } from '@nestjs/common';
import { LoggerModule } from '../../shared/middlewares/logger/logger.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EnvironmentManager } from 'src/env/envManager.service';
import { CombinedUserProduct } from '../../entities/CombinedUserProduct';
import { DataSnapshotController } from './dataSnapshot.controller';
import { DataSnapshotService } from './dataSnapshot.service';
import { DataSnapshot } from '../../entities/DataSnapshot';
import { UserBankAccountsBalance, UserDocuments, Users } from '../../entities';
import { BigQueryModule } from '../../shared/modules/bigQuery/bigQuery.module';
import { HubSpotModule } from '../../shared/modules/hubSpot/hubSpot.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([DataSnapshot, CombinedUserProduct, Users, UserDocuments, UserBankAccountsBalance]),
    LoggerModule,
    HttpModule,
    BigQueryModule,
    HubSpotModule,
  ],
  controllers: [DataSnapshotController],
  providers: [DataSnapshotService, EnvironmentManager],
  exports: [DataSnapshotService],
})
export class DataSnapshotModule {}
