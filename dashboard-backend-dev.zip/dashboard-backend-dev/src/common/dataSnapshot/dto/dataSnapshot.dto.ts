import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class DataSnapshotDto {
  @IsString()
  @IsOptional()
  @ApiProperty()
  date?: string;
}
