import { Body, Controller, Get, Post, UseFilters, UseGuards, UseInterceptors } from '@nestjs/common';
import { CommonApiQueries } from 'src/shared/decorators/combinedDecorators.decorator';
import { ApiBearerAuth, ApiBody, ApiExtraModels, ApiTags } from '@nestjs/swagger';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { NotFoundExceptionFilter } from 'src/shared/filters/notFoundException.filter';
import { BadRequestExceptionFilter } from 'src/shared/filters/badRequestException.filter';
import { AnonymousLocalJwtAuthGuard } from 'src/shared/guards/anonymousLocalJwtAuth.guard';
import { DataSnapshotService } from './dataSnapshot.service';
import { DataSnapshotDto } from './dto/dataSnapshot.dto';

@ApiTags('DataSnapshots')
@Controller('v1/data-snapshot')
@ApiExtraModels()
@UseFilters(NotFoundExceptionFilter, BadRequestExceptionFilter)
export class DataSnapshotController {
  constructor(private readonly dataSnapshotService: DataSnapshotService) {}

  @Post()
  @CommonApiQueries({ summary: 'Create data snapshot' })
  @ApiBody({ type: DataSnapshotDto })
  @ApiBearerAuth()
  @UseGuards(AnonymousLocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  async createDataSnapshot(@Body() body: DataSnapshotDto) {
    this.dataSnapshotService.reportCurrencyConversionRate();
    this.dataSnapshotService.reportPortfoliosAssetsUnderManagement();
    const res = await this.dataSnapshotService.createDataSnapshot(body);

    return res;
  }

  @Post('/createhistory')
  @CommonApiQueries({ summary: 'Create data snapshot history' })
  @ApiBearerAuth()
  @UseGuards(AnonymousLocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  async createDataSnapshotHistory(@Body() body: DataSnapshotDto) {
    const res = await this.dataSnapshotService.createDataSnapshotHistory(body);

    return res;
  }
}
