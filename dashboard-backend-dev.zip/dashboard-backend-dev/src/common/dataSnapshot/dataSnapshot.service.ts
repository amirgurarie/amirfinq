import { HttpService, Injectable } from '@nestjs/common';
import { LoggerService } from '../../shared/middlewares/logger/logger.service';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, Brackets, LessThanOrEqual, Raw, Repository } from 'typeorm';
import { DataSnapshot } from '../../entities/DataSnapshot';
import { DataSnapshotDto } from './dto/dataSnapshot.dto';
import { UserBankAccountsBalance, UserDocuments, Users } from '../../entities';
import dayjs from 'dayjs';
import { CombinedUserProduct } from '../../entities/CombinedUserProduct';
import { DataType, EmailConfirm, PaymentStatus } from './types/dataSnapshot.enum';
import {
  ALL_PAYMENT_STATUSES,
  EXCLUDED_EMAILS,
  HISTORY_START_DATE,
  INCLUDED_PLANS,
  PAID_PAYMENT_STATUSES,
} from './utils/dataSnapshot.constants';
import utc from 'dayjs/plugin/utc';
import timezone from 'dayjs/plugin/timezone';
import { ProductsEnum } from '../../shared/enums';
import { UserDocumentsTypes } from '../../users/agreements/enums';
import { BigQueryService } from '../../shared/modules/bigQuery/bigQuery.service';
import { EnvironmentManager } from 'src/env/envManager.service';
import { HubSpotManager } from '../../shared/modules/hubSpot/hubSpot.manager';

type DateObj = { startDate: Date; endDate: Date };

@Injectable()
export class DataSnapshotService extends ServiceHelper<DataSnapshot> {
  private currencyConversionApiKey: string;
  private currencyConversionSendRequest: boolean;
  constructor(
    protected readonly loggerService: LoggerService,
    protected readonly bigQueryService: BigQueryService,
    protected readonly httpService: HttpService,
    private readonly hubSpotManager: HubSpotManager,
    private readonly env: EnvironmentManager,

    // Repositories
    @InjectRepository(Users)
    private readonly usersRepository: Repository<Users>,
    @InjectRepository(CombinedUserProduct)
    private readonly combinedUserProductsRepository: Repository<CombinedUserProduct>,
    @InjectRepository(UserDocuments)
    private readonly userDocumentsRepository: Repository<UserDocuments>,
    @InjectRepository(UserBankAccountsBalance)
    private readonly userBankAccountsBalanceRepository: Repository<UserBankAccountsBalance>,
    @InjectRepository(DataSnapshot)
    private readonly dataSnapshotRepository: Repository<DataSnapshot>,
  ) {
    super(dataSnapshotRepository);
    dayjs.extend(utc);
    dayjs.extend(timezone);

    this.currencyConversionApiKey = this.env.get('CURRENCY_CONVERSION_API_KEY');
    this.currencyConversionSendRequest = this.env.get('CURRENCY_CONVERSION_SEND_REQUEST') === 'true';
  }

  public async reportCurrencyConversionRate() {
    if (this.currencyConversionSendRequest) {
      const { data } = await this.httpService
        .get(`https://api.currencyfreaks.com/v2.0/rates/latest?apikey=${this.currencyConversionApiKey}`)
        .toPromise();

      const conversionRateObj = {
        date: data.date.split(' ')[0],
        conversionRate: data.rates.ILS,
      };

      await this.bigQueryService.insertRowsToTable('currencies.usd_ils', [conversionRateObj]);
    }
  }

  public async reportPortfoliosAssetsUnderManagement() {
    if (this.env.isFINQIsrael) {
      const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

      const query = this.userBankAccountsBalanceRepository
        .createQueryBuilder('userBankAccountsBalance')
        .select('user.id as user_id')
        .innerJoin('userBankAccountsBalance.user', 'user')
        .where('user.missingUserInAuth0 is not true')
        .andWhere(mappedQueryStr, emailsList);

      const userIds = (await query.getRawMany()).map((el) => el.user_id);
      const usersWithData = await this.usersRepository.findByIds(userIds, { relations: ['userBankAccountsBalances'] });

      const objToRet = {};
      usersWithData.forEach((user: Users) => {
        const totalAssetsValue = user.userBankAccountsBalances.reduce(
          (totalValue: number, bankAccountsBalance: UserBankAccountsBalance) =>
            totalValue + bankAccountsBalance.balanceValue,
          0,
        );

        this.hubSpotManager.updateContact({
          user,
          properties: { inv_portfolio_aum: totalAssetsValue },
        });
      });

      return { userIds, objToRet };
    }
  }

  public async createDataSnapshotHistory(body?: DataSnapshotDto) {
    const startDate = dayjs(body?.date || HISTORY_START_DATE).tz('Asia/Jerusalem');
    const endDate = dayjs().tz('Asia/Jerusalem').startOf('day');

    await this.delete({ recordDate: LessThanOrEqual(endDate) });

    const res = [];
    for (let d = startDate; d.isBefore(endDate); d = d.add(1, 'day')) {
      const dateStr = d.format('YYYY-MM-DD');
      const dayRes = await this.createDataSnapshot({ date: dateStr });
      res.push(dayRes);
    }

    return res;
  }

  public async createDataSnapshot(body: DataSnapshotDto) {
    const relativeDate = body?.date
      ? dayjs(body.date).tz('Asia/Jerusalem')
      : dayjs().tz('Asia/Jerusalem').subtract(1, 'days');
    const startDate = relativeDate.startOf('day').toDate();
    const endDate = relativeDate.endOf('day').toDate();
    const dateObj: DateObj = { startDate, endDate };

    const existingDay = await this.findOneBy({ recordDate: endDate });
    if (existingDay) {
      return { record_date: endDate, status: 'existing' };
    }

    const [
      [newSignupsItems, newSignups],
      [aggSignupsItems, aggSignups],
      [newSignupsVerifiedItems, newSignupsVerified],
      [aggSignupsVerifiedItems, aggSignupsVerified],
      [newSubscriptionsItems, newSubscriptions],
      [aggSubscriptionsItems, aggSubscriptions],
      [newPaidSubscriptionsItems, newPaidSubscriptions],
      [aggPaidSubscriptionsItems, aggPaidSubscriptions],
      [newTrialSubscriptionsItems, newTrialSubscriptions],
      [aggTrialSubscriptionsItems, aggTrialSubscriptions],
      [newChurnsItems, newChurns],
      [aggChurnsItems, aggChurns],
      [newPaidChurnsItems, newPaidChurns],
      [aggPaidChurnsItems, aggPaidChurns],
      [newTrialChurnsItems, newTrialChurns],
      [aggTrialChurnsItems, aggTrialChurns],

      [newPensionSubscriptionsItems, newPensionSubscriptions],
      [aggPensionSubscriptionsItems, aggPensionSubscriptions],
      [newPensionPaidSubscriptionsItems, newPensionPaidSubscriptions],
      [aggPensionPaidSubscriptionsItems, aggPensionPaidSubscriptions],
      [newPensionTrialSubscriptionsItems, newPensionTrialSubscriptions],
      [aggPensionTrialSubscriptionsItems, aggPensionTrialSubscriptions],
      [newPensionChurnsItems, newPensionChurns],
      [aggPensionChurnsItems, aggPensionChurns],
      [newPensionPaidChurnsItems, newPensionPaidChurns],
      [aggPensionPaidChurnsItems, aggPensionPaidChurns],
      [newPensionTrialChurnsItems, newPensionTrialChurns],
      [aggPensionTrialChurnsItems, aggPensionTrialChurns],

      [newStocksSubscriptionsItems, newStocksSubscriptions],
      [aggStocksSubscriptionsItems, aggStocksSubscriptions],
      [newStocksPaidSubscriptionsItems, newStocksPaidSubscriptions],
      [aggStocksPaidSubscriptionsItems, aggStocksPaidSubscriptions],
      [newStocksTrialSubscriptionsItems, newStocksTrialSubscriptions],
      [aggStocksTrialSubscriptionsItems, aggStocksTrialSubscriptions],
      [newStocksChurnsItems, newStocksChurns],
      [aggStocksChurnsItems, aggStocksChurns],
      [newStocksPaidChurnsItems, newStocksPaidChurns],
      [aggStocksPaidChurnsItems, aggStocksPaidChurns],
      [newStocksTrialChurnsItems, newStocksTrialChurns],
      [aggStocksTrialChurnsItems, aggStocksTrialChurns],

      [newNetAgreementsSignedItems, newNetAgreementsSigned],
      [aggNetAgreementsSignedItems, aggNetAgreementsSigned],
      [aggManagedPortfoliosItems, aggManagedPortfolios],
      [aggNetManagedPortfoliosItems, aggNetManagedPortfolios],
      [{ total_balance_value: aggNetAssetsUnderManagement = 0 }],
    ] = await Promise.all([
      this.getSignups(dateObj, DataType.New, EmailConfirm.All),
      this.getSignups(dateObj, DataType.Aggregated, EmailConfirm.All),
      this.getSignups(dateObj, DataType.New, EmailConfirm.Confirmed),
      this.getSignups(dateObj, DataType.Aggregated, EmailConfirm.Confirmed),
      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.All),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.All),
      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.Paid),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.Paid),
      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.Trial),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.Trial),
      this.getChurns(dateObj, DataType.New, PaymentStatus.All),
      this.getChurns(dateObj, DataType.Aggregated, PaymentStatus.All),
      this.getChurns(dateObj, DataType.New, PaymentStatus.Paid),
      this.getChurns(dateObj, DataType.Aggregated, PaymentStatus.Paid),
      this.getTrialChurns(dateObj, DataType.New),
      this.getTrialChurns(dateObj, DataType.Aggregated),

      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.All, ProductsEnum.Pensions),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.All, ProductsEnum.Pensions),
      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.Paid, ProductsEnum.Pensions),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.Paid, ProductsEnum.Pensions),
      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.Trial, ProductsEnum.Pensions),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.Trial, ProductsEnum.Pensions),
      this.getChurns(dateObj, DataType.New, PaymentStatus.All, ProductsEnum.Pensions),
      this.getChurns(dateObj, DataType.Aggregated, PaymentStatus.All, ProductsEnum.Pensions),
      this.getChurns(dateObj, DataType.New, PaymentStatus.Paid, ProductsEnum.Pensions),
      this.getChurns(dateObj, DataType.Aggregated, PaymentStatus.Paid, ProductsEnum.Pensions),
      this.getTrialChurns(dateObj, DataType.New, ProductsEnum.Pensions),
      this.getTrialChurns(dateObj, DataType.Aggregated, ProductsEnum.Pensions),

      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.All, ProductsEnum.Stocks),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.All, ProductsEnum.Stocks),
      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.Paid, ProductsEnum.Stocks),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.Paid, ProductsEnum.Stocks),
      this.getSubscriptions(dateObj, DataType.New, PaymentStatus.Trial, ProductsEnum.Stocks),
      this.getSubscriptions(dateObj, DataType.Aggregated, PaymentStatus.Trial, ProductsEnum.Stocks),
      this.getChurns(dateObj, DataType.New, PaymentStatus.All, ProductsEnum.Stocks),
      this.getChurns(dateObj, DataType.Aggregated, PaymentStatus.All, ProductsEnum.Stocks),
      this.getChurns(dateObj, DataType.New, PaymentStatus.Paid, ProductsEnum.Stocks),
      this.getChurns(dateObj, DataType.Aggregated, PaymentStatus.Paid, ProductsEnum.Stocks),
      this.getTrialChurns(dateObj, DataType.New, ProductsEnum.Stocks),
      this.getTrialChurns(dateObj, DataType.Aggregated, ProductsEnum.Stocks),

      this.getAgreementsSigned(dateObj, DataType.New),
      this.getAgreementsSigned(dateObj, DataType.Aggregated),
      this.getAggManagedPortfolios(dateObj),
      this.getAggNetManagedPortfolios(),
      this.getAggNetAssetsUnderManagement(),
    ]);

    const newNetSubscriptions = newSubscriptions - newChurns;
    const newNetSubscriptionsItems = [...this.getIds(newSubscriptionsItems), ...this.getIds(newChurnsItems)];
    const aggNetSubscriptions = aggSubscriptions - aggChurns;
    const aggNetSubscriptionsItems = this.getNetIds(this.getIds(aggSubscriptionsItems), this.getIds(aggChurnsItems));
    const newNetPaidSubscriptions = newPaidSubscriptions - newPaidChurns;
    const newNetPaidSubscriptionsItems = [
      ...this.getIds(newPaidSubscriptionsItems),
      ...this.getIds(newPaidChurnsItems),
    ];
    const aggNetPaidSubscriptions = aggPaidSubscriptions - aggPaidChurns;
    const aggNetPaidSubscriptionsItems = this.getNetIds(
      this.getIds(aggPaidSubscriptionsItems),
      this.getIds(aggPaidChurnsItems),
    );
    const newNetTrialSubscriptions = newTrialSubscriptions - newTrialChurns;
    const newNetTrialSubscriptionsItems = [
      ...this.getIds(newTrialSubscriptionsItems),
      ...this.getIds(newTrialChurnsItems),
    ];
    const aggNetTrialSubscriptions = aggTrialSubscriptions - aggTrialChurns;
    const aggNetTrialSubscriptionsItems = this.getNetIds(
      this.getIds(aggTrialSubscriptionsItems),
      this.getIds(aggTrialChurnsItems),
    );

    const newPensionNetSubscriptions = newPensionSubscriptions - newPensionChurns;
    const newPensionNetSubscriptionsItems = [
      ...this.getIds(newPensionSubscriptionsItems),
      ...this.getIds(newPensionChurnsItems),
    ];
    const aggPensionNetSubscriptions = aggPensionSubscriptions - aggPensionChurns;
    const aggPensionNetSubscriptionsItems = this.getNetIds(
      this.getIds(aggPensionSubscriptionsItems),
      this.getIds(aggPensionChurnsItems),
    );
    const newPensionNetPaidSubscriptions = newPensionPaidSubscriptions - newPensionPaidChurns;
    const newPensionNetPaidSubscriptionsItems = [
      ...this.getIds(newPensionPaidSubscriptionsItems),
      ...this.getIds(newPensionPaidChurnsItems),
    ];
    const aggPensionNetPaidSubscriptions = aggPensionPaidSubscriptions - aggPensionPaidChurns;
    const aggPensionNetPaidSubscriptionsItems = this.getNetIds(
      this.getIds(aggPensionPaidSubscriptionsItems),
      this.getIds(aggPensionPaidChurnsItems),
    );
    const newPensionNetTrialSubscriptions = newPensionTrialSubscriptions - newPensionTrialChurns;
    const newPensionNetTrialSubscriptionsItems = [
      ...this.getIds(newPensionTrialSubscriptionsItems),
      ...this.getIds(newPensionTrialChurnsItems),
    ];
    const aggPensionNetTrialSubscriptions = aggPensionTrialSubscriptions - aggPensionTrialChurns;
    const aggPensionNetTrialSubscriptionsItems = this.getNetIds(
      this.getIds(aggPensionTrialSubscriptionsItems),
      this.getIds(aggPensionTrialChurnsItems),
    );

    const newStocksNetSubscriptions = newStocksSubscriptions - newStocksChurns;
    const newStocksNetSubscriptionsItems = [
      ...this.getIds(newStocksSubscriptionsItems),
      ...this.getIds(newStocksChurnsItems),
    ];
    const aggStocksNetSubscriptions = aggStocksSubscriptions - aggStocksChurns;
    const aggStocksNetSubscriptionsItems = this.getNetIds(
      this.getIds(aggStocksSubscriptionsItems),
      this.getIds(aggStocksChurnsItems),
    );
    const newStocksNetPaidSubscriptions = newStocksPaidSubscriptions - newStocksPaidChurns;
    const newStocksNetPaidSubscriptionsItems = [
      ...this.getIds(newStocksPaidSubscriptionsItems),
      ...this.getIds(newStocksPaidChurnsItems),
    ];
    const aggStocksNetPaidSubscriptions = aggStocksPaidSubscriptions - aggStocksPaidChurns;
    const aggStocksNetPaidSubscriptionsItems = this.getNetIds(
      this.getIds(aggStocksPaidSubscriptionsItems),
      this.getIds(aggStocksPaidChurnsItems),
    );
    const newStocksNetTrialSubscriptions = newStocksTrialSubscriptions - newStocksTrialChurns;
    const newStocksNetTrialSubscriptionsItems = [
      ...this.getIds(newStocksTrialSubscriptionsItems),
      ...this.getIds(newStocksTrialChurnsItems),
    ];
    const aggStocksNetTrialSubscriptions = aggStocksTrialSubscriptions - aggStocksTrialChurns;
    const aggStocksNetTrialSubscriptionsItems = this.getNetIds(
      this.getIds(aggStocksTrialSubscriptionsItems),
      this.getIds(aggStocksTrialChurnsItems),
    );

    await this.create({
      recordDate: endDate,
      newSignups,
      aggSignups,
      newSignupsVerified,
      aggSignupsVerified,
      newSubscriptions,
      newSubscriptionsItems: this.getIds(newSubscriptionsItems),
      aggSubscriptions,
      aggSubscriptionsItems: this.getIds(aggSubscriptionsItems),
      newPaidSubscriptions,
      newPaidSubscriptionsItems: this.getIds(newPaidSubscriptionsItems),
      aggPaidSubscriptions,
      aggPaidSubscriptionsItems: this.getIds(aggPaidSubscriptionsItems),
      newTrialSubscriptions,
      newTrialSubscriptionsItems: this.getIds(newTrialSubscriptionsItems),
      aggTrialSubscriptions,
      aggTrialSubscriptionsItems: this.getIds(aggTrialSubscriptionsItems),
      newChurns,
      newChurnsItems: this.getIds(newChurnsItems),
      aggChurns,
      aggChurnsItems: this.getIds(aggChurnsItems),
      newPaidChurns,
      newPaidChurnsItems: this.getIds(newPaidChurnsItems),
      aggPaidChurns,
      aggPaidChurnsItems: this.getIds(aggPaidChurnsItems),
      newTrialChurns,
      newTrialChurnsItems: this.getIds(newTrialChurnsItems),
      aggTrialChurns,
      aggTrialChurnsItems: this.getIds(aggTrialChurnsItems),
      newNetSubscriptions,
      newNetSubscriptionsItems,
      aggNetSubscriptions,
      aggNetSubscriptionsItems,
      newNetPaidSubscriptions,
      newNetPaidSubscriptionsItems,
      aggNetPaidSubscriptions,
      aggNetPaidSubscriptionsItems,
      newNetTrialSubscriptions,
      newNetTrialSubscriptionsItems,
      aggNetTrialSubscriptions,
      aggNetTrialSubscriptionsItems,

      newPensionSubscriptions,
      newPensionSubscriptionsItems: this.getIds(newPensionSubscriptionsItems),
      aggPensionSubscriptions,
      aggPensionSubscriptionsItems: this.getIds(aggPensionSubscriptionsItems),
      newPensionPaidSubscriptions,
      newPensionPaidSubscriptionsItems: this.getIds(newPensionPaidSubscriptionsItems),
      aggPensionPaidSubscriptions,
      aggPensionPaidSubscriptionsItems: this.getIds(aggPensionPaidSubscriptionsItems),
      newPensionTrialSubscriptions,
      newPensionTrialSubscriptionsItems: this.getIds(newPensionTrialSubscriptionsItems),
      aggPensionTrialSubscriptions,
      aggPensionTrialSubscriptionsItems: this.getIds(aggPensionTrialSubscriptionsItems),
      newPensionChurns,
      newPensionChurnsItems: this.getIds(newPensionChurnsItems),
      aggPensionChurns,
      aggPensionChurnsItems: this.getIds(aggPensionChurnsItems),
      newPensionPaidChurns,
      newPensionPaidChurnsItems: this.getIds(newPensionPaidChurnsItems),
      aggPensionPaidChurns,
      aggPensionPaidChurnsItems: this.getIds(aggPensionPaidChurnsItems),
      newPensionTrialChurns,
      newPensionTrialChurnsItems: this.getIds(newPensionTrialChurnsItems),
      aggPensionTrialChurns,
      aggPensionTrialChurnsItems: this.getIds(aggPensionTrialChurnsItems),
      newPensionNetSubscriptions,
      newPensionNetSubscriptionsItems,
      aggPensionNetSubscriptions,
      aggPensionNetSubscriptionsItems,
      newPensionNetPaidSubscriptions,
      newPensionNetPaidSubscriptionsItems,
      aggPensionNetPaidSubscriptions,
      aggPensionNetPaidSubscriptionsItems,
      newPensionNetTrialSubscriptions,
      newPensionNetTrialSubscriptionsItems,
      aggPensionNetTrialSubscriptions,
      aggPensionNetTrialSubscriptionsItems,

      newStocksSubscriptions,
      newStocksSubscriptionsItems: this.getIds(newStocksSubscriptionsItems),
      aggStocksSubscriptions,
      aggStocksSubscriptionsItems: this.getIds(aggStocksSubscriptionsItems),
      newStocksPaidSubscriptions,
      newStocksPaidSubscriptionsItems: this.getIds(newStocksPaidSubscriptionsItems),
      aggStocksPaidSubscriptions,
      aggStocksPaidSubscriptionsItems: this.getIds(aggStocksPaidSubscriptionsItems),
      newStocksTrialSubscriptions,
      newStocksTrialSubscriptionsItems: this.getIds(newStocksTrialSubscriptionsItems),
      aggStocksTrialSubscriptions,
      aggStocksTrialSubscriptionsItems: this.getIds(aggStocksTrialSubscriptionsItems),
      newStocksChurns,
      newStocksChurnsItems: this.getIds(newStocksChurnsItems),
      aggStocksChurns,
      aggStocksChurnsItems: this.getIds(aggStocksChurnsItems),
      newStocksPaidChurns,
      newStocksPaidChurnsItems: this.getIds(newStocksPaidChurnsItems),
      aggStocksPaidChurns,
      aggStocksPaidChurnsItems: this.getIds(aggStocksPaidChurnsItems),
      newStocksTrialChurns,
      newStocksTrialChurnsItems: this.getIds(newStocksTrialChurnsItems),
      aggStocksTrialChurns,
      aggStocksTrialChurnsItems: this.getIds(aggStocksTrialChurnsItems),
      newStocksNetSubscriptions,
      newStocksNetSubscriptionsItems,
      aggStocksNetSubscriptions,
      aggStocksNetSubscriptionsItems,
      newStocksNetPaidSubscriptions,
      newStocksNetPaidSubscriptionsItems,
      aggStocksNetPaidSubscriptions,
      aggStocksNetPaidSubscriptionsItems,
      newStocksNetTrialSubscriptions,
      newStocksNetTrialSubscriptionsItems,
      aggStocksNetTrialSubscriptions,
      aggStocksNetTrialSubscriptionsItems,

      newNetAgreementsSigned,
      aggNetAgreementsSigned,
      aggManagedPortfolios,
      aggNetManagedPortfolios,
      aggNetAssetsUnderManagement: aggNetAssetsUnderManagement || 0,
    });

    return { record_date: endDate, status: 'success' };
  }

  private async getSignups(dateObj: DateObj, dataType: DataType, emailConfirmed: EmailConfirm) {
    const { startDate, endDate } = dateObj;
    const updateDateFunction = dataType === DataType.New ? Between(startDate, endDate) : LessThanOrEqual(endDate);
    const emailConfirmedCondition = emailConfirmed === EmailConfirm.Confirmed ? { emailConfirmed: true } : {};
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"Users"."email"');

    return this.usersRepository.findAndCount({
      where: {
        updateDate: updateDateFunction,
        missingUserInAuth0: Raw((alias) => `${alias} is not true`),
        email: Raw(() => mappedQueryStr, emailsList),
        ...emailConfirmedCondition,
      },
    });
  }

  private async getSubscriptions(
    dateObj: DateObj,
    dataType: DataType,
    paymentStatus: PaymentStatus,
    productId?: ProductsEnum,
  ) {
    const { endDate } = dateObj;
    const paymentStatuses = paymentStatus === PaymentStatus.All ? ALL_PAYMENT_STATUSES : PAID_PAYMENT_STATUSES;
    const dateConditionOperator = dataType === DataType.New ? '=' : '<=';
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

    const query = this.combinedUserProductsRepository
      .createQueryBuilder('combinedUserProduct')
      .innerJoin(
        'combinedUserProduct.payments',
        'payments',
        `payments.statusCode in ('${paymentStatuses.join("','")}')`,
      )
      .innerJoin('combinedUserProduct.user', 'user')
      .where('combinedUserProduct.productPricingPlanType in (:...includedPlans)', {
        includedPlans: INCLUDED_PLANS,
      })
      .andWhere('user.missingUserInAuth0 is not true')
      .andWhere(mappedQueryStr, emailsList);

    if (productId) {
      query.andWhere('combinedUserProduct.productId = :productId', { productId });
    }

    if (paymentStatus !== PaymentStatus.Paid) {
      query.andWhere(`combinedUserProduct.startDate ${dateConditionOperator} :date`, { date: endDate });
    }

    if (paymentStatus === PaymentStatus.Trial) {
      query.andWhere('combinedUserProduct.trialEndDate is not null');
    }

    if (paymentStatus === PaymentStatus.Paid) {
      query.andWhere(
        new Brackets((qb) => {
          qb.where(
            new Brackets((qb2) => {
              qb2
                .where(`combinedUserProduct.startDate ${dateConditionOperator} :date`, { date: endDate })
                .andWhere('combinedUserProduct.trialEndDate is null');
            }),
          )
            .orWhere(
              new Brackets((qb2) => {
                qb2
                  .where(`combinedUserProduct.trialEndDate ${dateConditionOperator} :date`, { date: endDate })
                  .andWhere('combinedUserProduct.expiryDate is null');
              }),
            )
            .orWhere(
              new Brackets((qb2) => {
                qb2
                  .where(`combinedUserProduct.trialEndDate ${dateConditionOperator} :date`, { date: endDate })
                  .andWhere('combinedUserProduct.expiryDate is not null')
                  .andWhere('combinedUserProduct.trialEndDate < combinedUserProduct.expiryDate');
              }),
            );
        }),
      );
    }

    return query.getManyAndCount();
  }

  private async getChurns(
    dateObj: DateObj,
    dataType: DataType,
    paymentStatus: PaymentStatus,
    productId?: ProductsEnum,
  ) {
    const { endDate } = dateObj;
    const paymentStatuses = paymentStatus === PaymentStatus.All ? ALL_PAYMENT_STATUSES : PAID_PAYMENT_STATUSES;
    const dateConditionOperator = dataType === DataType.New ? '=' : '<=';
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

    const query = this.combinedUserProductsRepository
      .createQueryBuilder('combinedUserProduct')
      .innerJoin(
        'combinedUserProduct.payments',
        'payments',
        `payments.statusCode in ('${paymentStatuses.join("','")}')`,
      )
      .innerJoin('combinedUserProduct.user', 'user')
      .where('combinedUserProduct.expiryDate is not null')
      .andWhere(
        new Brackets((qb) => {
          qb.where(
            new Brackets((qb) => {
              qb.where(`combinedUserProduct.expiryDate ${dateConditionOperator} :date`, {
                date: endDate,
              })
                .andWhere('combinedUserProduct.trialEndDate is null')
                .andWhere('combinedUserProduct.startDate <= combinedUserProduct.expiryDate');
            }),
          )
            .orWhere(
              new Brackets((qb) => {
                qb.where(`combinedUserProduct.startDate ${dateConditionOperator} :date`, {
                  date: endDate,
                }).andWhere('combinedUserProduct.startDate > combinedUserProduct.expiryDate');
              }),
            )
            .orWhere(
              new Brackets((qb) => {
                qb.where(`combinedUserProduct.expiryDate ${dateConditionOperator} :date`, {
                  date: endDate,
                })
                  .andWhere('combinedUserProduct.trialEndDate is not null')
                  .andWhere('combinedUserProduct.trialEndDate < combinedUserProduct.expiryDate');
              }),
            );
        }),
      )
      .andWhere('combinedUserProduct.productPricingPlanType in (:...includedPlans)', {
        includedPlans: INCLUDED_PLANS,
      })
      .andWhere('user.missingUserInAuth0 is not true')
      .andWhere(mappedQueryStr, emailsList);

    if (productId) {
      query.andWhere('combinedUserProduct.productId = :productId', { productId });
    }

    return query.getManyAndCount();
  }

  private async getTrialChurns(dateObj: DateObj, dataType: DataType, productId?: ProductsEnum) {
    const { endDate } = dateObj;
    const dateConditionOperator = dataType === DataType.New ? '=' : '<=';
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

    const query = this.combinedUserProductsRepository
      .createQueryBuilder('combinedUserProduct')
      .innerJoin(
        'combinedUserProduct.payments',
        'payments',
        `payments.statusCode in ('${PAID_PAYMENT_STATUSES.join("','")}')`,
      )
      .innerJoin('combinedUserProduct.user', 'user')
      .where('combinedUserProduct.trialEndDate is not null')
      .andWhere(`combinedUserProduct.trialEndDate ${dateConditionOperator} :date`, {
        date: endDate,
      })
      .andWhere('combinedUserProduct.productPricingPlanType in (:...includedPlans)', {
        includedPlans: INCLUDED_PLANS,
      })
      .andWhere('user.missingUserInAuth0 is not true')
      .andWhere(mappedQueryStr, emailsList);

    if (productId) {
      query.andWhere('combinedUserProduct.productId = :productId', { productId });
    }

    return query.getManyAndCount();
  }

  private getAgreementsSigned(dateObj: DateObj, dataType: DataType) {
    const { endDate } = dateObj;
    const dateConditionOperator = dataType === DataType.New ? '=' : '<=';
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

    const query = this.userDocumentsRepository
      .createQueryBuilder('userDocument')
      .innerJoin('userDocument.user', 'user')
      .andWhere(`userDocument.updateDate ${dateConditionOperator} :date`, {
        date: endDate,
      })
      .andWhere('userDocument.approved is true')
      .andWhere('userDocument.documentType = :documentType', { documentType: UserDocumentsTypes.Contract })
      .andWhere('user.missingUserInAuth0 is not true')
      .andWhere(mappedQueryStr, emailsList);

    return query.getManyAndCount();
  }

  private getAggManagedPortfolios(dateObj: DateObj) {
    const { endDate } = dateObj;
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

    const query = this.usersRepository
      .createQueryBuilder('user')
      .innerJoin('user.userBankAccountsTransactions', 'userBankAccountsTransactions')
      .where(`userBankAccountsTransactions.creationDate <= :date`, { date: endDate })
      .where('user.missingUserInAuth0 is not true')
      .andWhere(mappedQueryStr, emailsList);

    return query.getManyAndCount();
  }

  private getAggNetManagedPortfolios() {
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

    const query = this.usersRepository
      .createQueryBuilder('user')
      .innerJoin('user.userBankAccountsBalances', 'userBankAccountsBalances')
      .where('user.missingUserInAuth0 is not true')
      .andWhere(mappedQueryStr, emailsList);

    return query.getManyAndCount();
  }

  private getAggNetAssetsUnderManagement() {
    const { mappedQueryStr, emailsList } = this.getExcludedEmailsRaw('"user"."email"');

    const query = this.userBankAccountsBalanceRepository
      .createQueryBuilder('userBankAccountsBalance')
      .select('sum(userBankAccountsBalance.balance_value) as total_balance_value')
      .innerJoin('userBankAccountsBalance.user', 'user')
      .where('user.missingUserInAuth0 is not true')
      .andWhere(mappedQueryStr, emailsList);

    return query.getRawMany();
  }

  private getExcludedEmailsRaw(alias = 'email') {
    const emailsList = {};
    const mappedQueryArr = [];
    EXCLUDED_EMAILS.forEach((email, index) => {
      mappedQueryArr.push(`${alias} NOT LIKE :email${index}`);
      emailsList[`email${index}`] = email;
    });
    const mappedQueryStr = mappedQueryArr.join(' AND ');

    return { mappedQueryStr, emailsList };
  }

  private getIds(entities: Record<string, any>[]): number[] {
    return entities.map((entity) => {
      return entity.id;
    });
  }

  private getNetIds(subscriptions: number[], churns: number[]) {
    return subscriptions.filter((id) => !churns.includes(id));
  }
}
