export enum DataType {
  New = 'New',
  Aggregated = 'Aggregated',
}

export enum EmailConfirm {
  All = 'All',
  Confirmed = 'Confirmed',
}

export enum PaymentStatus {
  All = 'All',
  Paid = 'Paid',
  Trial = 'Trial',
}
