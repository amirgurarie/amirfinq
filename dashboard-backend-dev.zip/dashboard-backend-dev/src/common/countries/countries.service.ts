import { ServiceHelper } from '../../shared/modules/service.helper';
import { RefCountries } from '../../entities/RefCountries';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';

@Injectable()
export class CountriesService extends ServiceHelper<RefCountries> {
  constructor(
    @InjectRepository(RefCountries)
    private readonly refCountriesRepository: Repository<RefCountries>,
  ) {
    super(refCountriesRepository);
  }
}
