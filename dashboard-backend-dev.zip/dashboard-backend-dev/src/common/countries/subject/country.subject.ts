import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class CountrySubject {
  @ApiProperty()
  @Expose()
  id: string;

  @ApiProperty()
  @Expose()
  descriptionHe: string;

  @ApiProperty()
  @Expose()
  descriptionEn: string;

  @ApiProperty({ name: 'code' })
  @Expose({ name: 'code', toPlainOnly: true })
  countryCode: string;
}
