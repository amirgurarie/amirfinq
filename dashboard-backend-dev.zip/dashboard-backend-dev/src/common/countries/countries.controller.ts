import { AbstractController } from '../../shared/controller';
import { ConfigService } from '@nestjs/config';
import { CountriesService } from './countries.service';
import { Controller, Get, UseInterceptors } from '@nestjs/common';
import { ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { CountrySubject } from './subject/country.subject';
import { ApiDataArrayResponse } from '../../shared/decorators/dataResponse.decorator';

@ApiTags('Common')
@Controller('v1/countries')
@ApiExtraModels(CountrySubject)
export class CountriesController extends AbstractController {
  constructor(protected readonly configService: ConfigService, private readonly countriesService: CountriesService) {
    super(configService);
  }

  @Get()
  @ApiDataArrayResponse(CountrySubject, 'Get all countries')
  @ApiOperation({ summary: 'All countries' })
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getCountries() {
    const res = await this.countriesService.findAll({ cache: true });

    return this.transformToArray(res, CountrySubject);
  }
}
