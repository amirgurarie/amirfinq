import { AbstractController } from '../../shared/controller';
import { ConfigService } from '@nestjs/config';
import { Controller, Get, Query, UseInterceptors } from '@nestjs/common';
import { ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { ApiDataArrayResponse } from '../../shared/decorators/dataResponse.decorator';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { DocumentTypesService } from './documentTypes.service';
import { DocumentTypeSubject } from './subject/documentType.subject';
import { DocumentTypesQueryDto } from './dto/documentTypesQuery.dto';

@ApiTags('Documents & Agreements')
@Controller('v1/documents')
@ApiExtraModels(DocumentTypeSubject)
export class DocumentTypesController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    private readonly documentTypesService: DocumentTypesService,
  ) {
    super(configService);
  }

  @Get()
  @ApiOperation({ summary: 'Get all document types' })
  @ApiDataArrayResponse(DocumentTypeSubject, 'All document types')
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getDocumentTypes(@Query() documentTypesQuery: DocumentTypesQueryDto) {
    const res = await this.documentTypesService.getDocuments(documentTypesQuery);

    return this.transformToArray(res, DocumentTypeSubject);
  }
}
