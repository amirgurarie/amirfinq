import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RefDocumentsTypes } from '../../entities/RefDocumentsTypes';
import { DocumentTypesController } from './documentTypes.controller';
import { DocumentTypesService } from './documentTypes.service';

@Module({
  imports: [TypeOrmModule.forFeature([RefDocumentsTypes])],
  providers: [DocumentTypesService],
  controllers: [DocumentTypesController],
  exports: [DocumentTypesService],
})
export class DocumentTypesModule {}
