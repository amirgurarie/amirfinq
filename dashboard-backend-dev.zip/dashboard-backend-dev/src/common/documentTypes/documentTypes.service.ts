import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceHelper } from '../../shared/modules/service.helper';
import { RefDocumentsTypes } from '../../entities/RefDocumentsTypes';
import { IDocumentTypesQuery } from './dto/documentTypesQuery.dto';

@Injectable()
export class DocumentTypesService extends ServiceHelper<RefDocumentsTypes> {
  constructor(
    @InjectRepository(RefDocumentsTypes)
    private readonly refDocumentsTypesRepository: Repository<RefDocumentsTypes>,
  ) {
    super(refDocumentsTypesRepository);
  }

  public async getDocuments(data: IDocumentTypesQuery): Promise<RefDocumentsTypes[]> {
    const query = this.refDocumentsTypesRepository.createQueryBuilder();

    if (data.group) {
      query.andWhere('LOWER(document_group) = LOWER(:group)', {
        group: data.group,
      });
    }

    if (data.subGroup) {
      query.andWhere('LOWER(document_sub_group) = LOWER(:subGroup)', {
        subGroup: data.subGroup,
      });
    }

    return await query.orderBy('document_sub_group_order', 'ASC', 'NULLS LAST').getMany();
  }
}
