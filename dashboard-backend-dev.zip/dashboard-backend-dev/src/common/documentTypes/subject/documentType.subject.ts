import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class DocumentTypeSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  descriptionHe: string;

  @Expose()
  @ApiProperty()
  descriptionEn: string;

  @Expose({ name: 'group', toPlainOnly: true })
  @ApiProperty({ name: 'group' })
  documentGroup: string;

  @Expose({ name: 'subGroup', toPlainOnly: true })
  @ApiProperty({ name: 'subGroup' })
  documentSubGroup: string;
}
