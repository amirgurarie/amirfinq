import { ApiProperty } from '@nestjs/swagger';
import { Allow } from 'class-validator';

export class DocumentTypesQueryDto {
  @ApiProperty({ required: false })
  @Allow()
  public readonly group?: string | null;

  @ApiProperty({ required: false })
  @Allow()
  public readonly subGroup?: string | null;
}

export type IDocumentTypesQuery = DocumentTypesQueryDto;
