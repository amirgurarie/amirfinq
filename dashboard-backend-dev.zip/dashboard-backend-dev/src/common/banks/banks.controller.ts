import { AbstractController } from '../../shared/controller';
import { Controller, Get, Param, UseFilters, UseInterceptors } from '@nestjs/common';
import { ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { BankSubject } from './subject/bank.subject';
import { ConfigService } from '@nestjs/config';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { ApiDataArrayResponse } from '../../shared/decorators/dataResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { BranchSubject } from './subject/branch.subject';
import { BanksService } from './banks.service';
import { NotFoundExceptionFilter } from '../../shared/filters/notFoundException.filter';
import { ApiNotFoundHttpResponse } from '../../shared/decorators/apiNotFoundHttpResponse.decorator';

@ApiTags('Common')
@Controller('v1/banks')
@ApiExtraModels(BankSubject, BranchSubject)
@UseFilters(NotFoundExceptionFilter)
export class BanksController extends AbstractController {
  constructor(private readonly banksService: BanksService, protected readonly configService: ConfigService) {
    super(configService);
  }

  @Get()
  @ApiOperation({ summary: 'Get all banks' })
  @ApiDataArrayResponse(BankSubject, 'All banks')
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getBanks() {
    const banks = await this.banksService.getBanks();

    return this.transformToArray(banks, BankSubject);
  }

  @Get(':bankId/branches')
  @ApiOperation({ summary: 'Get all banks branches' })
  @ApiDataArrayResponse(BranchSubject, 'All banks branches')
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getBranches(@Param('bankId') bankId: string) {
    const res = await this.banksService.getBanksBranches(bankId);

    return this.transformToArray(res, BranchSubject);
  }
}
