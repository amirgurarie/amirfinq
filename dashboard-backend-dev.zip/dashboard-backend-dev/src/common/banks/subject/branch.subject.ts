import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class BranchSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  branchNumber: string;

  @Expose({ name: 'name', toPlainOnly: true })
  @ApiProperty({ name: 'name' })
  branchName: string;

  @Expose({ name: 'nameEn', toPlainOnly: true })
  @ApiProperty({ name: 'nameEn' })
  branchNameEn: string;

  @Expose({ name: 'bankId', toPlainOnly: true })
  @ApiProperty({ name: 'bankId' })
  bankNumber: string;
}
