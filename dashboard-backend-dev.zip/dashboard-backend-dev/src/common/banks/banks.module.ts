import { Module } from '@nestjs/common';
import { BanksController } from './banks.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RefBanks } from '../../entities/RefBanks';
import { RefBankBranches } from '../../entities/RefBankBranches';
import { BanksService } from './banks.service';
import { LoggerModule } from '../../shared/middlewares/logger/logger.module';

@Module({
  imports: [TypeOrmModule.forFeature([RefBanks, RefBankBranches]), LoggerModule],
  providers: [BanksService],
  controllers: [BanksController],
  exports: [BanksService],
})
export class BanksModule {}
