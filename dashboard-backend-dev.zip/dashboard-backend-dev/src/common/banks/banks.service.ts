import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FindOneOptions, Repository } from 'typeorm';
import { RefBanks } from '../../entities/RefBanks';
import { RefBankBranches } from '../../entities/RefBankBranches';
import { LanguagesEnum } from '../../shared/languages.enum';
import { EntityNotFoundError } from 'typeorm/error/EntityNotFoundError';
import { NotFoundError } from '../../shared/errors/notFound.error';

@Injectable()
export class BanksService {
  constructor(
    @InjectRepository(RefBanks)
    private readonly refBanksRepository: Repository<RefBanks>,
    @InjectRepository(RefBankBranches)
    private readonly refBankBranchesRepository: Repository<RefBankBranches>,
  ) {}

  public async getBank(id: string): Promise<RefBanks> {
    return this.refBanksRepository.findOne(id);
  }

  public async getBankBranch(options: FindOneOptions<RefBankBranches>): Promise<RefBankBranches> {
    return this.refBankBranchesRepository.findOne(options);
  }

  public async getBanks() {
    return await this.refBanksRepository.find({
      order: {
        uiSort: 'ASC',
      },
      cache: true,
    });
  }

  public async getBanksBranches(bankId: string) {
    try {
      const bank = await this.refBanksRepository.findOneOrFail(bankId);

      return await this.refBankBranchesRepository.find({
        where: {
          bankNumber: bank,
        },
        loadRelationIds: {
          relations: ['bankNumber'],
        },
      });
    } catch (e) {
      if (e instanceof EntityNotFoundError) {
        throw new NotFoundError(e, e.message || 'Resource not found');
      } else {
        throw e;
      }
    }
  }
}
