import { Module } from '@nestjs/common';
import { BanksModule } from './banks/banks.module';
import { CountriesModule } from './countries/countries.module';
import { OccupationsModule } from './occupations/occupations.module';
import { PublicRolesModule } from './publicRoles/publicRoles.module';
import { DocumentTypesModule } from './documentTypes/documentTypes.module';
import { SendGridModule } from './sendgrid/sendgrid.module';
import { ProductsModule } from './products/products.module';
import { ProductTempModule } from './productTemp/productTemp.module';
import { DataSnapshotModule } from './dataSnapshot/dataSnapshot.module';
import { HRConfContactsModule } from './hr-conf-contacts/hr-conf-contacts.module';

@Module({
  imports: [
    BanksModule,
    CountriesModule,
    OccupationsModule,
    PublicRolesModule,
    DocumentTypesModule,
    SendGridModule,
    ProductsModule,
    ProductTempModule,
    DataSnapshotModule,
    HRConfContactsModule,
  ],
})
export class CommonModule {}
