import { HttpModule, Module } from '@nestjs/common';
import { LoggerModule } from '../../shared/middlewares/logger/logger.module';
import { RabbitModule } from '../../shared/modules/rabbitMQ/rabbitMQ.module';
import { ConfigModule } from '@nestjs/config';
import { SendGridController } from './sendgrid.controller';
import { SendGridService } from './sendgrid.service';
import { MakeModule } from 'src/shared/modules/make/make.module';
import { EnvironmentManager } from 'src/env/envManager.service';
import { LiquidManager } from 'src/shared/injectables/liquidManager.service';
import { AnalyticsModule } from '../../shared/modules/analytics/analytics.module';

@Module({
  imports: [LoggerModule, RabbitModule, ConfigModule, MakeModule, AnalyticsModule, HttpModule],
  providers: [SendGridService, EnvironmentManager, LiquidManager],
  controllers: [SendGridController],
  exports: [SendGridService],
})
export class SendGridModule {}
