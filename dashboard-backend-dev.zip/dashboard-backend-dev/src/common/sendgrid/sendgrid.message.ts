export class CustomerSupportRequestMessage {
  constructor(private readonly userEmail: string, private readonly subject: string, private readonly body?: string) {}

  public getMessage(): string {
    return `A user ${this.userEmail} reports this issue: [Subject]: ${this.subject}, [Body]: ${this.body}`;
  }
}
