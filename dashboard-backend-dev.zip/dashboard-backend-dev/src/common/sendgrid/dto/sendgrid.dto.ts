import { ApiProperty, getSchemaPath } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { Allow, IsEmail, MinLength, MaxLength, IsString, ValidateNested, IsEnum, Validate } from 'class-validator';
import { FINQ_HELLO_EMAIL, FINQ_PARTNER_EMAIL } from 'src/constants';
import { IsCaseSensitive } from 'src/shared/validators/isCaseSensitive';

export const SendGridEvent = {
  contactUs: 'contact-us',
  b2bContact: 'b2b-contact',
} as const;

export const SendGridEmailMap = {
  [SendGridEvent.contactUs]: {
    subject: 'New customer support mail',
    to: FINQ_HELLO_EMAIL,
    apiExample: {
      summary: 'Submit a customer support request',
      value: {
        event: 'contact-us',
        properties: {
          from: 'John Doe',
          subject: 'Hello World',
          body: 'Hello, I have a question.',
        },
      } as DiscriminatedSendGridDto,
    },
  },

  [SendGridEvent.b2bContact]: {
    subject: 'New B2B contact mail',
    to: FINQ_PARTNER_EMAIL,
    apiExample: {
      summary: 'Submit a B2B Partner request',
      value: {
        event: 'b2b-contact',
        properties: {
          companyName: 'Random Company',
          companyWebsite: 'www.randomcompany.com',
          fullName: 'John Doe',
          messageContent: 'Hello, I have a question.',
          phoneNumber: '+1234567890',
          workEmail: 'john.doe@example.com',
        },
      } as DiscriminatedSendGridDto,
    },
  },
};

export class CustomerSupportRequestDto {
  @ApiProperty()
  @IsString()
  public readonly subject: string;

  @ApiProperty()
  @IsString()
  public readonly body?: string | null;

  @ApiProperty()
  @Allow()
  @IsEmail()
  public readonly from: string;
}

export class PartnersSupportRequestDto {
  @ApiProperty()
  @IsString()
  public readonly fullName: string;

  @ApiProperty()
  @IsEmail()
  public readonly workEmail: string;

  @ApiProperty()
  @IsString()
  public readonly phoneNumber: string;

  @ApiProperty()
  @IsString()
  public readonly companyName: string;

  @ApiProperty()
  @IsString()
  public readonly companyWebsite: string;

  @ApiProperty()
  @IsString()
  @MinLength(20)
  @MaxLength(5000)
  public readonly messageContent: string;
}

export type SendGridEvent = typeof SendGridEvent[keyof typeof SendGridEvent];

export class SendGridDto {
  @IsCaseSensitive(Object.values(SendGridEvent))
  @ApiProperty({
    required: true,
    enum: SendGridEvent,
    description: `One of: ${Object.values(SendGridEvent)}`,
  })
  public readonly event: SendGridEvent;

  @ApiProperty({
    description: 'Properties of the request, varies based on the event type',
  })
  @ValidateNested()
  @Type(({ object }) => {
    switch (object.event) {
      case SendGridEvent.contactUs:
        return CustomerSupportRequestDto;

      case SendGridEvent.b2bContact:
        return PartnersSupportRequestDto;

      default:
        return CustomerSupportRequestDto || PartnersSupportRequestDto;
    }
  })
  public readonly properties: CustomerSupportRequestDto | PartnersSupportRequestDto;
}

export type DiscriminatedSendGridDto =
  | { event: 'contact-us'; properties: CustomerSupportRequestDto }
  | { event: 'b2b-contact'; properties: PartnersSupportRequestDto };
