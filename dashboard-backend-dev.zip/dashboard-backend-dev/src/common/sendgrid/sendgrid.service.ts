import { Liquid } from 'liquidjs';
import { Injectable, InternalServerErrorException } from '@nestjs/common';
import { LoggerService } from '../../shared/middlewares/logger/logger.service';
import { SENDGRID_VERIFIED_SENDER } from 'src/constants';
import { DiscriminatedSendGridDto, SendGridDto, SendGridEmailMap } from './dto/sendgrid.dto';
import { startCase } from 'lodash';
import SendGrid from '@sendgrid/mail';
import i18n, { i18nLiquidPlugin } from 'src/i18n';
import { EnvironmentManager } from 'src/env/envManager.service';
import { LiquidManager } from 'src/shared/injectables/liquidManager.service';

interface Attachment {
  content: string;
  filename: string;
  type: string;
  disposition?: string;
  contentId?: string;
}

type TemplatesParams =
  | { name: 'code_verification'; data: { otp: string } }
  | { name: 'finq_agreement'; data: { user_name: string; email: string } };

@Injectable()
export class SendGridService {
  constructor(
    protected readonly loggerService: LoggerService,
    protected readonly env: EnvironmentManager,
    protected readonly liquid: LiquidManager,
  ) {
    SendGrid.setApiKey(this.env.get('SENDGRID_API_KEY'));
  }

  public async send(...args: Parameters<typeof SendGrid.send>) {
    const res = await SendGrid.send(...args);
    this.loggerService.log(res, 'Sent SendGrid email, response');

    return res;
  }

  public async sendWithTemplate({ name, data, to, lang }: TemplatesParams & { lang?: string; to: string }) {
    const file = await this.liquid.renderFile(name, { ...data, lang });

    return this.send({
      to,
      from: `${this.env.getAppName()} <${SENDGRID_VERIFIED_SENDER}>`,
      subject: i18n.t(`email_templates.${name}.subject` as 'email_templates.code_verification.subject', { lng: lang }),
      content: [{ type: 'text/html', value: file }],
    });
  }

  public async sendWithTemplateId({
    templateId,
    dynamicTemplateData,
    to,
    attachments,
  }: {
    templateId: string;
    dynamicTemplateData: any;
    to: string | string[];
    attachments?: Attachment[];
  }) {
    const msg: SendGrid.MailDataRequired = {
      to,
      from: `${this.env.getAppName()} <${SENDGRID_VERIFIED_SENDER}>`,
      templateId,
      dynamicTemplateData,
      attachments,
    };

    try {
      return this.send(msg);
    } catch (error) {
      this.loggerService.error(`Failed to send email to ${to} with template ${templateId}`, error);
      throw error;
    }
  }

  public async sendGridRequest(data: SendGridDto) {
    const { event, properties } = data as unknown as DiscriminatedSendGridDto;

    this.loggerService.log(data, 'SendGrid email data');

    const coreDomain = this.env.get('CORE_DOMAIN');
    const mailDomain = coreDomain?.includes('finqai') ? `finqai${coreDomain.split('finqai')[1]}` : 'finqai.com';
    const toEmail = SendGridEmailMap[event].to.replace('{domain}', mailDomain);

    try {
      const res = await this.send({
        to: toEmail,
        from: `${this.env.getAppName()} <${SENDGRID_VERIFIED_SENDER}>`,
        subject: SendGridEmailMap[event].subject,

        content: [
          {
            type: 'text/html',
            value: Object.entries(properties)
              .map(([key, value]) => `<b>${startCase(key)}</b>: ${value}`)
              .join('<br>'),
          },
        ],
      });

      return res;
    } catch (error) {
      if (error as SendGrid.ResponseError) {
        this.loggerService.error(error, 'SendGrid error');

        throw new InternalServerErrorException('SendGrid error');
      }
    }
  }
}
