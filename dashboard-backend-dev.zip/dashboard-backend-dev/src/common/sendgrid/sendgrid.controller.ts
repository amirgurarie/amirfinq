import { MakeService } from 'src/shared/modules/make/make.service';
import { Body, Controller, HttpCode, Post, Req, UseGuards, UseInterceptors } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AbstractController } from '../../shared/controller';
import { SendGridService } from './sendgrid.service';
import { ApiBody, ApiOperation, ApiTags } from '@nestjs/swagger';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { DiscriminatedSendGridDto, SendGridDto, SendGridEmailMap, SendGridEvent } from './dto/sendgrid.dto';
import { Request } from 'express';
import { RecaptchaGuard } from 'src/shared/guards/recaptcha.guard';
import { ApiRecaptchaHeaders } from 'src/shared/decorators/apiRecaptchaHeaders.decorator';
import { CurrentAuthUser } from '../../auth/currentAuthUser.decorator';
import { AuthenticatedUser } from '../../shared/types/authenticatedUser.interface';
import { AnalyticsService } from '../../shared/modules/analytics/analytics.service';
import { AnonymousLocalJwtAuthGuard } from 'src/shared/guards/anonymousLocalJwtAuth.guard';

@ApiTags('Customer Communication & Support')
@Controller('v1')
export class SendGridController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    protected readonly sendGridService: SendGridService,
    protected readonly makeService: MakeService,
    protected readonly analyticsService: AnalyticsService,
  ) {
    super(configService);
  }

  @Post('/customersupport')
  @HttpCode(200)
  @ApiOperation({ summary: 'Send a request to the customer support by type' })
  @ApiFailedHttpResponse()
  @ApiBody({
    type: SendGridDto,
    examples: {
      'Customer support / Contact us': SendGridEmailMap[SendGridEvent.contactUs].apiExample,
      'B2B Partner form': SendGridEmailMap[SendGridEvent.b2bContact].apiExample,
    },
  })
  @ApiRecaptchaHeaders()
  @UseGuards(AnonymousLocalJwtAuthGuard, RecaptchaGuard)
  @UseInterceptors(TransformInterceptor)
  public async customSupportRequest(
    @Req() req: Request,
    @Body() supportRequestDto: SendGridDto,
    @CurrentAuthUser() authUserPayload: AuthenticatedUser,
  ) {
    // Send the email
    await this.sendGridService.sendGridRequest(supportRequestDto);

    this.analyticsService.reportEvent(req, authUserPayload?.user, {
      eventName: 'form_submit',
      eventType: 'contact-us',
      eventSource: 'server',
      eventParams: {
        element: {
          elementType: supportRequestDto.event,
          elementLabel: supportRequestDto.properties['from'] || supportRequestDto.properties['workEmail'],
        },
      },
    });

    return {};
  }
}
