import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RefUserPublicRole } from '../../entities/RefUserPublicRole';
import { PublicRolesService } from './publicRoles.service';
import { PublicRolesController } from './publicRoles.controller';

@Module({
  imports: [TypeOrmModule.forFeature([RefUserPublicRole])],
  providers: [PublicRolesService],
  controllers: [PublicRolesController],
  exports: [PublicRolesService],
})
export class PublicRolesModule {}
