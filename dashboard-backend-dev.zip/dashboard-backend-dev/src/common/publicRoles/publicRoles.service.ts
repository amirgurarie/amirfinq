import { ServiceHelper } from '../../shared/modules/service.helper';
import { RefUserPublicRole } from '../../entities/RefUserPublicRole';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';

@Injectable()
export class PublicRolesService extends ServiceHelper<RefUserPublicRole> {
  constructor(
    @InjectRepository(RefUserPublicRole)
    private readonly refPublicRoleRepository: Repository<RefUserPublicRole>,
  ) {
    super(refPublicRoleRepository);
  }

  public async getAllPublicRoles() {
    return await this.refPublicRoleRepository.find({
      order: {
        id: 'ASC',
      },
    });
  }
}
