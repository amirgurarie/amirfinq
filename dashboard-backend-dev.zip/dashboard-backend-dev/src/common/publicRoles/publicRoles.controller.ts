import { AbstractController } from '../../shared/controller';
import { ConfigService } from '@nestjs/config';
import { Controller, Get, UseInterceptors } from '@nestjs/common';
import { ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { PublicRoleSubject } from './subjects/publicRoles.subject';
import { ApiDataArrayResponse } from '../../shared/decorators/dataResponse.decorator';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { PublicRolesService } from './publicRoles.service';

@ApiTags('Common')
@Controller('v1/publicroles')
@ApiExtraModels(PublicRoleSubject)
export class PublicRolesController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    private readonly publicRolesService: PublicRolesService,
  ) {
    super(configService);
  }

  @Get()
  @ApiOperation({ summary: 'Get all public roles' })
  @ApiDataArrayResponse(PublicRoleSubject, 'All public roles')
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getPublicRoles() {
    const res = await this.publicRolesService.getAllPublicRoles();

    return this.transformToArray(res, PublicRoleSubject);
  }
}
