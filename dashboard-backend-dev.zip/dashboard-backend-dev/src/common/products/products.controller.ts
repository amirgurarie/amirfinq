import { AbstractController } from '../../shared/controller';
import { ConfigService } from '@nestjs/config';
import { Controller, Get, Param, Query, UseGuards, UseInterceptors } from '@nestjs/common';
import { ApiBearerAuth, ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { ProductsSubject } from './subjects/products.subject';
import { ApiDataArrayResponse } from '../../shared/decorators/dataResponse.decorator';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { ProductsService } from './products.service';
import { ProductsExtendedSubject } from './subjects/products-extended.subject';
import { ProductsManager } from './products.manager';
import { AnonymousLocalJwtAuthGuard } from 'src/shared/guards/anonymousLocalJwtAuth.guard';
import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';
import { CurrentAuthUser } from 'src/auth/currentAuthUser.decorator';
import { ProductsPresaleApiQuery, ProductsPresaleDto } from './dto/products-presale.dto';

@ApiTags('Common')
@Controller('v1/products')
@ApiExtraModels(ProductsSubject, ProductsExtendedSubject)
export class ProductsController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    private readonly productsService: ProductsService,
    private readonly productsManager: ProductsManager,
  ) {
    super(configService);
  }

  @Get()
  @ApiOperation({
    summary: 'Get all active products, including kyc paths and stocks',
  })
  @ApiDataArrayResponse(ProductsSubject, 'All products')
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getProducts() {
    const res = await this.productsService.getAllProducts();

    return this.transformToArray(res, ProductsSubject);
  }

  @Get(':productId/presale')
  @ApiOperation({
    summary: 'Get presale products data for a given product id, returns all necessary data for the presale page',
  })
  @ApiFailedHttpResponse()
  @ApiBearerAuth()
  @ProductsPresaleApiQuery()
  @ApiDataArrayResponse(ProductsExtendedSubject, 'All products')
  @UseGuards(AnonymousLocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  public async getProductPreSale(
    @CurrentAuthUser() authUserPayload: AuthenticatedUser,
    @Param('productId') id: string,
    @Query() dto: ProductsPresaleDto,
  ) {
    const products = await this.productsManager.generatePreSale(authUserPayload?.user, id, dto);

    return this.transformToArray(products, ProductsExtendedSubject);
  }
}
