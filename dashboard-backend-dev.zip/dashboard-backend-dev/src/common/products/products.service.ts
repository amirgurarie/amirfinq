import { ParametersHelper } from './../../finance/parameters.helper';
import { ServiceHelper } from '../../shared/modules/service.helper';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { UserProducts } from 'src/entities/UserProducts';
import { RefProductConflicts } from 'src/entities/RefProductConflicts';
import { RefPaymentMethod } from 'src/entities/RefPaymentMethod';
import { RefUserProductStatus } from 'src/entities/RefUserProductStatus';
import { ProductSaleType, ProductsPresaleDto } from './dto/products-presale.dto';
import { RefProducts } from 'src/entities';
import { RefProductSubscriptionMethods } from 'src/entities/RefProductSubscriptionMethods';
import { SubscriptionMethod } from 'src/payments/types/subscriptionMethod.interface';

@Injectable()
export class ProductsService extends ServiceHelper<RefProducts> {
  constructor(
    @InjectRepository(RefProducts)
    public readonly refProductRepository: Repository<RefProducts>,
    @InjectRepository(UserProducts)
    public readonly refUserProductsRepository: Repository<UserProducts>,
    @InjectRepository(RefProductConflicts)
    private readonly refProductConflictsRepository: Repository<RefProductConflicts>,

    @InjectRepository(RefPaymentMethod)
    private readonly refPaymentMethodRepository: Repository<RefPaymentMethod>,
    @InjectRepository(RefUserProductStatus)
    private readonly refUserProductStatusRepository: Repository<RefUserProductStatus>,
    @InjectRepository(RefProductSubscriptionMethods)
    private readonly refProductSubscriptionMethodsRepository: Repository<RefProductSubscriptionMethods>,
  ) {
    super(refProductRepository);
  }

  public async getAllProducts() {
    return await this.refProductRepository.find({
      where: { isActive: true },
      order: { displayOrder: 'ASC' },
    });
  }

  public getUserProducts(userId: string): Promise<[UserProducts[], number]> {
    if (!userId) return Promise.resolve([[], 0]);

    return this.refUserProductsRepository.findAndCount({ where: { userId } });
  }

  public findProductsByIds(ids: string | string[], idField: keyof RefProducts = 'id'): Promise<RefProducts[]> {
    if (!ids?.length) return Promise.resolve([]);
    else if (typeof ids === 'string') ids = ParametersHelper.getArrayParams(ids);

    return this.refProductRepository.find({ where: { [idField]: In(ids) }, relations: ['subscriptionMethod'] });
  }

  public getActiveProducts(filters?: ProductsPresaleDto): Promise<RefProducts[]> {
    const query = this.refProductRepository
      .createQueryBuilder('products')
      .where('products.isActive = true')
      .orderBy('products.display_order', 'ASC');

    if (filters?.type) {
      query.andWhere('products.type = :type OR products.type = :toolsType', {
        type: filters.type,
        toolsType: ProductSaleType.Tools,
      });
    }

    return query.getMany();
  }

  public async asyncCheckConflicts(productId: string, conflictWithProductId: string): Promise<boolean> {
    const rows = await this.refProductConflictsRepository.findOne({
      where: { productId, conflictWithProductId },
    });

    return !!rows;
  }

  public getAllConflicts() {
    return this.refProductConflictsRepository.find();
  }

  public getAllPaymentMethods() {
    return this.refPaymentMethodRepository.find();
  }

  public getAllUserProductStatuses() {
    return this.refUserProductStatusRepository.find();
  }

  public splitPlanCode(planCode: SubscriptionMethod) {
    const [market, productId, frequency] = planCode.split('-');

    return { market, productId, frequency };
  }

  public async findProductsWithSubscriptionMethodByIds(ids: SubscriptionMethod[]): Promise<RefProducts[]> {
    const conditions = ids.map(this.splitPlanCode);

    return this.refProductRepository
      .createQueryBuilder('products')
      .leftJoinAndMapOne(
        'products.subscriptionMethod',
        'ref_product_subscription_methods',
        'psm',
        'psm.product_id = products.id',
      )
      .where('products.isActive = true')
      .andWhere(
        conditions
          .map(
            (c, index) =>
              `(psm.market = :market${index} AND psm.productId = :productId${index} AND psm.frequency = :frequency${index})`,
          )
          .join(' OR '),
        conditions.reduce(
          (params, c, index) => ({
            ...params,
            [`market${index}`]: c.market,
            [`productId${index}`]: c.productId,
            [`frequency${index}`]: c.frequency,
          }),
          {},
        ),
      )
      .getMany();
  }

  public async findExtendedProductByStripeCode(id: RefProductSubscriptionMethods['stripePriceId']) {
    return this.refProductSubscriptionMethodsRepository
      .createQueryBuilder('psm')
      .leftJoinAndMapOne('psm.product', 'ref_products', 'products', 'products.id = psm.product_id')
      .where('psm.stripe_price_id = :id', { id })
      .getOne();
  }
}
