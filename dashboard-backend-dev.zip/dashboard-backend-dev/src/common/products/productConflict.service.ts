import { RefProductConflicts } from './../../entities';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Injectable } from '@nestjs/common';

@Injectable()
export class ProductConflictService {
  constructor(
    @InjectRepository(RefProductConflicts)
    private readonly refProductConflictsRepository: Repository<RefProductConflicts>,
  ) {}

  public async checkConflicts(productId: number, conflictId: number) {
    const conflict = await this.refProductConflictsRepository.findOne({
      where: {
        productId: In([productId, conflictId]),
        conflictId: In([productId, conflictId]),
      },
    });

    return Boolean(conflict);
  }
}
