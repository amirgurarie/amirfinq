import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductsService } from './products.service';
import { ProductsController } from './products.controller';
import { UserProducts } from 'src/entities/UserProducts';
import { RefUserProductStatus } from 'src/entities/RefUserProductStatus';
import { RefProductConflicts } from 'src/entities/RefProductConflicts';
import { ProductsManager } from './products.manager';
import { RefPaymentMethod } from 'src/entities/RefPaymentMethod';
import { RefProducts } from 'src/entities';
import { RefProductSubscriptionMethods } from 'src/entities/RefProductSubscriptionMethods';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      RefProducts,
      UserProducts,
      RefUserProductStatus,
      RefProductConflicts,
      RefPaymentMethod,
      RefUserProductStatus,
      RefProductSubscriptionMethods,
    ]),
  ],
  providers: [ProductsService, ProductsManager],
  controllers: [ProductsController],
  exports: [ProductsService, ProductsManager],
})
export class ProductsModule {}
