import { applyDecorators } from '@nestjs/common';
import { ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';

export enum ProductSaleType {
  Paid = 'PAID',
  Tools = 'TOOLS',
  Managed = 'MANAGED',
}

export class ProductsPresaleDto {
  @IsString()
  @IsOptional()
  @IsEnum(ProductSaleType)
  public readonly type: typeof ProductSaleType;
}

export function ProductsPresaleApiQuery() {
  return applyDecorators(
    ApiQuery({
      name: 'type',
      enum: ProductSaleType,
      description: `Product sale type, One of: ${Object.values(ProductSaleType)}`,
      required: false,
    }),
  );
}
