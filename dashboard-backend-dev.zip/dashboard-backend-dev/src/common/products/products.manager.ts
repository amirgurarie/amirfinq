import { Injectable, NotFoundException } from '@nestjs/common';
import { Users } from 'src/entities';
import { RefProductConflicts } from 'src/entities/RefProductConflicts';
import { ProductsPresaleDto } from './dto/products-presale.dto';
import { ProductsService } from './products.service';

@Injectable()
export class ProductsManager {
  constructor(private readonly productsService: ProductsService) {}

  public checkForConflicts(allConflicts: RefProductConflicts[], userProductsIds: string[], productId: string) {
    return allConflicts.find((conflict) => {
      return userProductsIds.find((userProductId) => {
        return conflict.productId === userProductId && conflict.conflictWithProductId === productId;
      });
    });
  }

  public async generatePreSale(user: Users, requestProduct: string, filters: ProductsPresaleDto) {
    const [[userProducts], allConflicts, products] = await Promise.all([
      this.productsService.getUserProducts(user?.id),
      this.productsService.getAllConflicts(),
      this.productsService.getActiveProducts(filters),
    ]);

    const userProductIds = userProducts.map((product) => product.productId);
    const foundRequestProduct = products.find((product) => product.id === requestProduct);
    if (!foundRequestProduct) throw new NotFoundException('Product not found');

    const mappedProducts = products.map((product) => {
      const ownedByUser = userProducts.find((userProduct) => userProduct.productId === product.id) || null;
      const conflictsWith = this.checkForConflicts(allConflicts, userProductIds, product.id)?.productId || null;
      const isRequestedProduct = requestProduct === product.id;

      return {
        ...product,
        ownedByUser,
        conflictsWith,
        isRequestedProduct,
      };
    });

    return mappedProducts;
  }
}
