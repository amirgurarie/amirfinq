import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { TransformToBoolean } from 'src/shared/decorators/subjects';

export class ProductsSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  descriptionHe: string;

  @Expose()
  @ApiProperty()
  descriptionEn: string;

  @Expose()
  @ApiProperty()
  productId: string;

  @Expose()
  @ApiProperty()
  imageHe: string;

  @Expose()
  @ApiProperty()
  imageEn: string;

  @Expose()
  @ApiProperty()
  screenPath: string;

  @Expose()
  @ApiProperty()
  @TransformToBoolean()
  isTools: boolean;

  @Expose()
  @ApiProperty()
  logo: string;

  @Expose()
  @ApiProperty()
  textHe: string;

  @Expose()
  @ApiProperty()
  textEn: string;

  @Expose()
  @ApiProperty()
  initialPricingPlan: string;
}
