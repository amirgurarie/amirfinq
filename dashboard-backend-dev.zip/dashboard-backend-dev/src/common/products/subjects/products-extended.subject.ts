import { Expose, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { TransformToBoolean } from 'src/shared/decorators/subjects/transformToBoolean.decorator';
import { ProductsSubject } from './products.subject';
import { DateToEpochTransform } from 'src/shared/decorators/subjects';
import { BaseRefSubject } from 'src/shared/subjects/baseRef.subject';

export class ProductOwnedByUserSubject {
  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  activationDate: number;

  @Expose()
  @ApiProperty()
  @TransformToBoolean()
  mainProduct: boolean;

  @Expose()
  @ApiProperty({ type: () => BaseRefSubject })
  @Type(() => BaseRefSubject)
  productStatus: BaseRefSubject;

  productStatusId: string;
}

export class ProductsExtendedSubject extends ProductsSubject {
  @Expose()
  @ApiProperty({ type: ProductOwnedByUserSubject, isArray: true })
  @Type(() => ProductOwnedByUserSubject)
  ownedByUser: ProductOwnedByUserSubject[];

  @Expose()
  @ApiProperty()
  @TransformToBoolean()
  isRequestedProduct: boolean;

  @Expose()
  @ApiProperty()
  conflictsWith: string;
}
