export const enum UserProductStatusEnum {
  Active = 'ACTIVE',
  NotActive = 'NOT_ACTIVE',
  PendingPayment = 'PENDING_PAYMENT',
  PendingAgreement = 'PENDING_AGREEMENT',
}
