import { Controller, Get, Param, Query, UseGuards, UseInterceptors } from '@nestjs/common';
// import { ProductStamps } from './productStamps.service';
import { ApiBearerAuth, ApiExtraModels, ApiTags } from '@nestjs/swagger';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { AbstractController } from 'src/shared';
import { ConfigService } from '@nestjs/config';
import { PlansCategoriesSubject } from './subject/plansCategories.subject';
import { ProductTempService } from './productTemp.service';
import { ApiDataArrayResponse } from 'src/shared/decorators/dataResponse.decorator';
import { ProductPlansSubject } from './subject/productPlans.subject';
import { PlanPricingSubject } from './subject/pricingPlan.subject';
import { AnonymousLocalJwtAuthGuard } from 'src/shared/guards/anonymousLocalJwtAuth.guard';
import { UserHasPlansTransformerInterceptor } from './transformers/userHasPlans.transformer';
import { ProductsDto, ProductsQueryFilter } from './dto/products.dto';

@ApiTags('Common')
@Controller('v1/products-temp')
@ApiExtraModels(PlansCategoriesSubject, ProductPlansSubject, PlanPricingSubject)
export class ProductTempController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    private readonly productTempService: ProductTempService,
  ) {
    super(configService);
  }

  @Get()
  @ApiDataArrayResponse(PlansCategoriesSubject, 'Product categories')
  @UseGuards(AnonymousLocalJwtAuthGuard)
  @ApiBearerAuth()
  @ProductsQueryFilter()
  @UseInterceptors(UserHasPlansTransformerInterceptor, TransformInterceptor)
  async getCategories(@Query() query: ProductsDto) {
    const res = await this.productTempService.getProducts(query);

    return this.transformToArray(res, PlansCategoriesSubject);
  }
}
