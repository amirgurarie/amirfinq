import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CombinedUserProduct } from 'src/entities/CombinedUserProduct';
import { ProductPlan } from 'src/entities/ProductPlan';
import { Product } from 'src/entities/Products';
import { Repository } from 'typeorm';
import { ProductsDto } from './dto/products.dto';
import {
  CreateFreeSubscriptionDto,
  CreateSubscriptionDto,
} from 'src/payments/PayMe/integration/dto/createSubscription.dto';
import { ProductPlanExclusivity } from '../../entities/ProductPlanExclusivity';

@Injectable()
export class ProductTempService {
  constructor(
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @InjectRepository(ProductPlan)
    private readonly planRepository: Repository<ProductPlan>,
    @InjectRepository(CombinedUserProduct)
    private readonly combinedUserProductRepository: Repository<CombinedUserProduct>,
    @InjectRepository(ProductPlanExclusivity)
    private readonly productPlanExclusivityRepository: Repository<ProductPlanExclusivity>,
  ) {}

  // Get product categories from the database without managed
  public getProducts(query?: ProductsDto) {
    const queryBuilder = this.productRepository
      .createQueryBuilder('product')
      .innerJoinAndSelect('product.plans', 'plans')
      .leftJoinAndSelect('plans.pricing', 'pricing')
      .leftJoinAndSelect('plans.higherProductPlans', 'higherProductPlans')
      .leftJoinAndSelect('plans.lowerProductPlans', 'lowerProductPlans')
      .where('product.isVisible = true')
      .andWhere('plans.status IN (:...statuses)', { statuses: ['ACTIVE', 'UPCOMING'] });

    if (query.productId) {
      queryBuilder.andWhere('product.id = :productId', { productId: query.productId });
    }

    return queryBuilder.orderBy('product.displayOrder', 'ASC').addOrderBy('plans.displayOrder', 'ASC').getMany();
  }

  // Get plans by product id from the database without "managed" productId
  public getPlansByProductId(productId: string) {
    return this.planRepository
      .createQueryBuilder('plan')
      .innerJoinAndSelect('plan.product', 'product')
      .leftJoinAndSelect('plan.pricing', 'pricing')
      .where('product.id = :productId', { productId })
      .getMany();
  }

  //
  public getActiveSubscriptionsByUserId(userId: string) {
    return this.combinedUserProductRepository
      .createQueryBuilder('combinedUserProduct')
      .innerJoinAndSelect('combinedUserProduct.product', 'product')
      .innerJoinAndMapOne('combinedUserProduct.productPlan', 'combinedUserProduct.productPlan', 'productPlan')
      .innerJoinAndMapOne(
        'combinedUserProduct.productPricingPlan',
        'combinedUserProduct.productPricingPlan',
        'productPricingPlan',
      )
      .where('combinedUserProduct.userId = :userId', { userId })
      .getMany();
  }

  public getProductByFilter(data: CreateSubscriptionDto | CreateFreeSubscriptionDto) {
    return this.productRepository
      .createQueryBuilder('product')
      .innerJoinAndSelect('product.plans', 'plans')
      .innerJoinAndSelect('plans.pricing', 'pricing')
      .leftJoinAndSelect('plans.higherProductPlans', 'higherProductPlans')
      .where('product.id = :id', { id: data.productId })
      .andWhere('plans.code = :code', { code: data.productPlanCode })
      .andWhere('pricing.type = :type', { type: data.productPlanPricingType })
      .getOne();
  }

  public getLowerProductPlans(productPlanId: number) {
    return this.productPlanExclusivityRepository
      .createQueryBuilder('productPlanExclusivity')
      .where('productPlanExclusivity.highProductPlanId = :highProductPlanId', { highProductPlanId: productPlanId })
      .getOne();
  }
}
