export namespace ProductTempTypes {
  export const CurrencyEnum = {
    ILS: 'ILS',
    USD: 'USD',
  } as const;

  export type CurrencyEnum = (typeof CurrencyEnum)[keyof typeof CurrencyEnum];

  export const ProductPlanTypesEnum = {
    DIY: 'DIY',
    MANAGED: 'MANAGED',
    DIY_AGENTS: 'DIY_AGENTS',
    DIY_LIGHT: 'DIY_LIGHT',
    DIY_PRO: 'DIY_PRO',
  } as const;

  export type ProductPlanTypesEnum = (typeof ProductPlanTypesEnum)[keyof typeof ProductPlanTypesEnum];

  export const PlanStatus = {
    ACTIVE: 'ACTIVE',
    INACTIVE: 'INACTIVE',
    UPCOMING: 'UPCOMING',
  } as const;

  export type PlanStatus = (typeof PlanStatus)[keyof typeof PlanStatus];

  export const PeriodTypeEnum = {
    ANNUAL: 'ANNUAL',
    MONTHLY: 'MONTHLY',
    FEES: 'FEES',
    ONCE: 'ONCE',
    FREE: 'FREE',
    NONE: 'NONE',
  } as const;

  export type PeriodTypeEnum = (typeof PeriodTypeEnum)[keyof typeof PeriodTypeEnum];

  export const SubscriptionStatusEnum = {
    SUBSCRIBED: 'SUBSCRIBED',
    NONE: 'NONE',
    WAITING_LIST: 'WAITING_LIST',
    UPGRADEABLE: 'UPGRADEABLE',
    DOWNGRADEABLE: 'DOWNGRADEABLE',
  } as const;

  export type SubscriptionStatusEnum = (typeof SubscriptionStatusEnum)[keyof typeof SubscriptionStatusEnum];

  export const ProductsEnum = {
    Stocks: 'PRODUCT_STOCK',
    Funds: 'PRODUCT_FUND',
    Pensions: 'PRODUCT_PENSION',
  } as const;
  export type ProductsEnum = (typeof ProductsEnum)[keyof typeof ProductsEnum];
}
