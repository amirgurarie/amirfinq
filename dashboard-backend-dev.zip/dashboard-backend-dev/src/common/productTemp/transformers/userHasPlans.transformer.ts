import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { map } from 'rxjs/operators';
import { CombinedUserProductsService } from 'src/users/combinedUserProducts/combinedUserProducts.service';
import { CombinedUserProduct } from 'src/entities/CombinedUserProduct';
import { PlanPricingSubject } from '../subject/pricingPlan.subject';
import { PlansCategoriesSubject } from '../subject/plansCategories.subject';
import { ProductPlansWaitingList } from 'src/entities/ProductPlansWaitingList';
import { ProductTempTypes } from '../types/productTemp.types';
import { ProductPlan } from '../../../entities/ProductPlan';
import { ExtendedProductPlansSubject } from '../subject/productPlans.subject';

@Injectable()
export class UserHasPlansTransformerInterceptor implements NestInterceptor {
  constructor(public readonly combinedUserProductsService: CombinedUserProductsService) {}

  async intercept(context: ExecutionContext, next: CallHandler) {
    const request = context.switchToHttp().getRequest();
    const userProducts = await this.combinedUserProductsService.getActiveSubscriptionsByUserId(request?.user?.user?.id);
    const productPlansWaitingList = await this.combinedUserProductsService.getProductPlansWaitingList(
      request?.user?.user?.email,
    );

    return next.handle().pipe(
      map((responseData: { data: PlansCategoriesSubject[] }) => {
        for (let product of responseData.data) {
          for (let plan of product.plans) {
            for (let pricing of plan.pricing) {
              const subscriptionData = this.isSubscribed(pricing, userProducts, productPlansWaitingList);
              Object.keys(subscriptionData).forEach((key) => {
                pricing[key] = subscriptionData[key];
              });
            }
          }

          for (let plan of product.plans) {
            const hasSubscriptionToPlan = this.isSubscribedToPlan(plan);
            if (hasSubscriptionToPlan) {
              for (let { highProductPlanId } of plan.higherProductPlans) {
                const higherPlan = product.plans.find(
                  (productPlanToUpgrade) => productPlanToUpgrade.id === highProductPlanId,
                );
                for (let higherPlanPricing of higherPlan.pricing) {
                  higherPlanPricing.pricingPlanStatus = ProductTempTypes.SubscriptionStatusEnum.UPGRADEABLE;
                }
              }

              for (let { lowProductPlanId } of plan.lowerProductPlans) {
                const lowPlan = product.plans.find(
                  (productPlanToDowngrade) => productPlanToDowngrade.id === lowProductPlanId,
                );
                for (let lowerPlanPricing of lowPlan.pricing) {
                  lowerPlanPricing.pricingPlanStatus = ProductTempTypes.SubscriptionStatusEnum.DOWNGRADEABLE;
                }
              }
            }
          }
        }

        return responseData;
      }),
    );
  }

  private isSubscribedToPlan(plan: ExtendedProductPlansSubject) {
    return plan.pricing.some(
      (pricing) => pricing.pricingPlanStatus === ProductTempTypes.SubscriptionStatusEnum.SUBSCRIBED,
    );
  }

  private isSubscribed(
    pricing: PlanPricingSubject,
    subscriptions: CombinedUserProduct[],
    waitingList: ProductPlansWaitingList[],
  ) {
    let pricingPlanStatus: keyof typeof ProductTempTypes.SubscriptionStatusEnum =
      ProductTempTypes.SubscriptionStatusEnum.NONE;
    let expiryDate = null;
    let renewalDate = null;
    let trialEndDate = null;

    const isNotified = waitingList.some((res) => {
      return res.productPlanPricing.id === pricing.id;
    });

    if (isNotified) {
      pricingPlanStatus = ProductTempTypes.SubscriptionStatusEnum.WAITING_LIST;
    }

    const activeSubscription = subscriptions.find((subscription) => {
      return subscription.productPricingPlan.id === pricing.id;
    });

    if (activeSubscription) {
      pricingPlanStatus = ProductTempTypes.SubscriptionStatusEnum.SUBSCRIBED;
      expiryDate = activeSubscription.expiryDate;
      renewalDate = activeSubscription.renewalDate;
      trialEndDate = activeSubscription.trialEndDate;
    }

    return { pricingPlanStatus, expiryDate, renewalDate, trialEndDate };
  }
}
