import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { ProductTempTypes } from '../types/productTemp.types';

export class PlanPricingSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty({ enum: ProductTempTypes.PeriodTypeEnum, enumName: 'PeriodTypeEnum' })
  type: ProductTempTypes.PeriodTypeEnum;

  @Expose()
  @ApiProperty()
  price: number;

  @Expose()
  @ApiProperty({ enum: ProductTempTypes.CurrencyEnum, enumName: 'CurrencyEnum' })
  currency: ProductTempTypes.CurrencyEnum;

  @Expose()
  @ApiProperty()
  trialPeriod: string;

  @Expose()
  @ApiProperty({ enum: ProductTempTypes.CurrencyEnum })
  pricingPlanStatus: ProductTempTypes.SubscriptionStatusEnum;
}
