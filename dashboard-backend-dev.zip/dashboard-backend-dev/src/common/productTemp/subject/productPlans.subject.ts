import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { PlanPricingSubject } from './pricingPlan.subject';
import { TransformToProperty } from 'src/shared/decorators/subjects';
import { ProductPlansExclusivitySubject } from './productPlansExclusivity.subject';

export class BaseProductPlansSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  code: string;

  @Expose()
  @ApiProperty()
  displayOrder: number;

  @Expose()
  @ApiProperty()
  status: string;

  @Expose()
  @ApiProperty({ type: PlanPricingSubject, isArray: true })
  @Type(() => PlanPricingSubject)
  pricing: PlanPricingSubject[];
}

export class ProductPlansSubject extends BaseProductPlansSubject {
  @Expose()
  @ApiProperty()
  @TransformToProperty('product.id')
  product_id: string;
}

export class ExtendedProductPlansSubject extends BaseProductPlansSubject {
  @Expose()
  @ApiProperty({ type: ProductPlansExclusivitySubject, isArray: true })
  @Type(() => ProductPlansExclusivitySubject)
  higherProductPlans: ProductPlansExclusivitySubject[];

  @Expose()
  @ApiProperty({ type: ProductPlansExclusivitySubject, isArray: true })
  @Type(() => ProductPlansExclusivitySubject)
  lowerProductPlans: ProductPlansExclusivitySubject[];
}
