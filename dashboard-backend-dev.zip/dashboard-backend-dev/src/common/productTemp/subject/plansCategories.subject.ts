import { ApiProperty } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { BaseProductPlansSubject, ExtendedProductPlansSubject, ProductPlansSubject } from './productPlans.subject';

export class PlansCategoriesSubject {
  @Expose()
  @ApiProperty()
  id: string;

  @Expose()
  @ApiProperty({ type: ExtendedProductPlansSubject })
  @Type(() => ExtendedProductPlansSubject)
  plans: ExtendedProductPlansSubject[];
}
