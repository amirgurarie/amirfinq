import { Module } from '@nestjs/common';
import { ProductTempService } from './productTemp.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ProductTempController } from './productTemp.controller';
import { ProductPlan } from 'src/entities/ProductPlan';
import { ProductPlanPricing } from 'src/entities/ProductPlanPricing';
import { Product } from 'src/entities/Products';
import { CombinedUserProductsService } from 'src/users/combinedUserProducts/combinedUserProducts.service';
import { CombinedUserProduct } from 'src/entities/CombinedUserProduct';
import { ProductPlansWaitingList } from 'src/entities/ProductPlansWaitingList';
import { ProductPlanExclusivity } from '../../entities/ProductPlanExclusivity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ProductPlan,
      ProductPlanPricing,
      ProductPlanExclusivity,
      Product,
      CombinedUserProduct,
      ProductPlansWaitingList,
    ]),
  ],
  controllers: [ProductTempController],
  providers: [ProductTempService, CombinedUserProductsService],
})
export class ProductTempModule {}
