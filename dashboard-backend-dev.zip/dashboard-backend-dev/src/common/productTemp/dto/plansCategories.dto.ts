import { ApiProperty } from '@nestjs/swagger';

export class PlansCategoriesDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  name: string;

  @ApiProperty()
  displayOrder: number;

  @ApiProperty()
  isActive: boolean;
}
