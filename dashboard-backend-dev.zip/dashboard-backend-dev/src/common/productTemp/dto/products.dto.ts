import { applyDecorators } from '@nestjs/common';
import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsString } from 'class-validator';
import { ProductTempTypes } from '../types/productTemp.types';

export class ProductsDto {
  @ApiProperty()
  @IsString()
  productId = '';
}

export function ProductsQueryFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'productId',
      required: false,
      type: String,
      enum: ProductTempTypes.ProductsEnum,
      description: `One of: ${Object.values(ProductTempTypes.ProductsEnum)}`,
    }),
  );
}
