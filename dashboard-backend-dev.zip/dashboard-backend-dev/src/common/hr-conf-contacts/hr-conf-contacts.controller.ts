import { Controller, Post, Body, HttpCode, UseGuards, UseInterceptors, Req } from '@nestjs/common';
import { HRConfContactsService } from './hr-conf-contacts.service';
import { CreateHRConfContactDto } from './dto/create-hr-conf-contact.dto';
import { ApiBody, ApiOperation, ApiTags } from '@nestjs/swagger';
import { ApiFailedHttpResponse } from 'src/shared/decorators/apiFailedHttpResponse.decorator';
import { ApiRecaptchaHeaders } from 'src/shared/decorators/apiRecaptchaHeaders.decorator';
import { RecaptchaGuard } from 'src/shared/guards/recaptcha.guard';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';

@ApiTags('Customer Communication & Support')
@Controller('v1')
export class HRConfContactsController {
  constructor(private readonly hrConfContactsService: HRConfContactsService) {}

  @Post('/hr-conf-contact')
  @HttpCode(200)
  @ApiOperation({ summary: 'Send a request to the customer support by type' })
  @ApiFailedHttpResponse()
  @ApiBody({ type: CreateHRConfContactDto })
  @ApiRecaptchaHeaders()
  @UseGuards(RecaptchaGuard)
  @UseInterceptors(TransformInterceptor)
  public async createContact(@Body() dto: CreateHRConfContactDto) {
    await this.hrConfContactsService.save(dto);

    return {};
  }
}
