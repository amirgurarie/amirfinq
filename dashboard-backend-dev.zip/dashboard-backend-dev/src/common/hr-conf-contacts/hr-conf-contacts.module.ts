import { HttpModule, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HRConfContactsController } from 'src/common/hr-conf-contacts/hr-conf-contacts.controller';
import { HRConfContactsService } from 'src/common/hr-conf-contacts/hr-conf-contacts.service';
import { HRConfContacts } from 'src/entities/HRConfContacts';
import { LoggerModule } from 'src/shared/middlewares/logger/logger.module';

@Module({
  imports: [TypeOrmModule.forFeature([HRConfContacts]), HttpModule, LoggerModule],
  controllers: [HRConfContactsController],
  providers: [HRConfContactsService],
})
export class HRConfContactsModule {}
