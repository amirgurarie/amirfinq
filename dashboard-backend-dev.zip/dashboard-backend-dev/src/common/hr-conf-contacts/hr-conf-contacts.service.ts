import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { HRConfContacts } from 'src/entities/HRConfContacts';
import { ServiceHelper } from 'src/shared/modules/service.helper';

@Injectable()
export class HRConfContactsService extends ServiceHelper<HRConfContacts> {
  constructor(
    @InjectRepository(HRConfContacts)
    private readonly hrConfContactsRepository: Repository<HRConfContacts>,
  ) {
    super(hrConfContactsRepository);
  }
}
