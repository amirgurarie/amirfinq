import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsNumber, IsOptional, IsString, Length, MaxLength } from 'class-validator';
import { IsValidText } from 'src/shared/validators/isValidText';

export class CreateHRConfContactDto {
  @IsOptional()
  @IsString()
  @IsValidText({ message: 'Invalid first name. Only letters, numbers, spaces, and specific punctuation are allowed.' })
  @Length(1, 60)
  @ApiProperty()
  firstName: string;

  @IsOptional()
  @IsString()
  @IsValidText({ message: 'Invalid last name. Only letters, numbers, spaces, and specific punctuation are allowed.' })
  @Length(1, 60)
  @ApiProperty()
  lastName?: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  @IsEmail()
  email: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  company: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  position: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  employeeCount: string;

  @ApiProperty()
  @IsString()
  @MaxLength(20)
  phoneNumber: string;

  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  message: string;
}
