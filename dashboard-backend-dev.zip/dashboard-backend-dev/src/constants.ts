export const STRING_RANGE_SEPARATOR = ',';

export const RANGE_ELEMENTS_COUNT = 2;

export const STRING_ARRAY_SEPARATOR = ',';

export const REGULATORY_INTEREST_RATE = 4.0;

export const MANAGEMENT_FEE = 1.5;

export const RETIREMENT_AGE = 67;

export const FUND_SIZE_CORRECTION_COEFFICIENT = 1000000;

export const TIMESTAMP_IN_SECONDS_DIGITS_COUNT = 10;

export const TIMESTAMP_FROM_SECONDS_TO_MILLISECONDS_COEFFICIENT = 1000;

export const DEFAULT_MAX_ALLOWED_ONBOARDING_TIMES = 5;

export const DEFAULT_SECTOR_COMBINATION_EXTRACTION_START_POSITION = 1;

export const DEFAULT_SECTOR_COMBINATION_EXTRACTION_LENGTH = 8;

/**/
export const DEFAULT_PORTFOLIO_PROPOSAL_TYPE = 'U';

export const DEFAULT_PORTFOLIO_QUESTIONNAIRE_TYPE = 'INV';
/**/

export const ACTIVE_USER_PORTFOLIO_PREFIX = 'active-';

export const PORTFOLIO_SELECTION_PREFIX = 'selection-';

export const PENDING_USER_PORTFOLIO_PREFIX = 'pending-';

export const FAVORITE_USER_PORTFOLIO_PREFIX = 'favorite-';

export const USERS_ROOT_FOLDER = 'users';

export const USERS_DOCUMENT_FOLDER = 'documents';

export const USERS_PICTURE_FOLDER = 'picture';

export const FINQ_HELLO_EMAIL = 'hello@{domain}';

export const FINQ_PARTNER_EMAIL = 'lital@finqai.com';

export const SENDGRID_VERIFIED_SENDER = 'hello@finqai.com';

/**
  (?=.*[a-z]): Ensures at least one lowercase letter.
  (?=.*[A-Z]): Ensures at least one uppercase letter.
  (?=.*[0-9]): Ensures at least one digit.
  (?=.*[!@#$%^&?]): Ensures at least one special character (from the set !@#$%^&?).
  [!@#$%^&?A-Za-z\d]{8,}: Matches the entire password, which must be at least 8 characters long, including allowed special characters, letters, and digits.
*/
export const AUTH_VALID_PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&?])[!@#$%^&? A-Za-z\d]{8,}$/;

export const GENDER = {
  male: 'M',
  female: 'F',
} as const;

export enum KindOfPrefixes {
  ActivePortfolio = 'active',
  PortfolioSelections = 'selection',
  FavoriteAssets = 'favorite',
  PortfolioPendingRequest = 'pending',
}

export enum NoIdPrefixes {
  ActivePortfolio = 'active',
  PendingPortfolio = 'pending',
}

export const HEALTH_CHECK_ENDPOINT = '/health';

export const AZURE_PDF_AGREEMENT_CONTAINER_NAME = 'users';
