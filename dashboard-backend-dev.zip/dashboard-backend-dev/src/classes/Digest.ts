import { createHash } from 'crypto';

export type AdvancedDigestFilter = {
  localTrade: boolean | null;
  managementFee: number | string | null;
  fundHouse: string[] | null;
};

export class DigestUtils {
  static generateObj(localTrade, managementFee, fundHouse): AdvancedDigestFilter {
    return {
      localTrade: localTrade || null,
      managementFee: managementFee ? parseFloat(managementFee).toFixed(1) : null,
      fundHouse: fundHouse?.split(',') || null,
    };
  }

  static generateDbString(filters: AdvancedDigestFilter): string {
    const sort = (a, b) => (String(a) > String(b) ? 1 : -1);

    return Object.entries(filters)
      .map(([k, v]) => {
        const value = Array.isArray(v) ? v.sort(sort)?.join(',') : v;

        return `${k}=${value}`;
      })
      .join(' ');
  }

  static digestMessage(message): string {
    const msgUint8 = new TextEncoder().encode(message); // encode as (utf-8) Uint8Array
    const hashBuffer = createHash('sha1').update(msgUint8).digest('hex');

    return hashBuffer;
  }
}
