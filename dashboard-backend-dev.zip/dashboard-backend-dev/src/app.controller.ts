import { Controller, Get, Req } from '@nestjs/common';
import { AppService } from './app.service';
import { Request } from 'express';
import { HEALTH_CHECK_ENDPOINT } from 'src/constants';

@Controller('/')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  getHello(@Req() req: Request): string {
    // get the full request url

    const protocol = req.protocol;
    const host = req.get('Host');
    const originUrl = req.originalUrl;
    const fullUrl = protocol + '://' + host + originUrl;

    if (fullUrl.includes('localhost')) {
      return this.appService.getHello();
    } else {
      return 'Healthy';
    }
  }

  @Get(HEALTH_CHECK_ENDPOINT)
  getHealth(): string {
    return 'Healthy';
  }
}
