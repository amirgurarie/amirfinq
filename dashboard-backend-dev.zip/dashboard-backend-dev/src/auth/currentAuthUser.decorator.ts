import { createParamDecorator, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthTokenSubEnum } from './authTokenSub.enum';
import { AuthenticatedUser } from '../shared/types/authenticatedUser.interface';
import { Auth0IdHelper } from '../shared/helpers/auth0Id.helper';
import { DomainHelper } from '../shared/helpers/domain.helper';

// can be used for auth0 jwt, auth0 social jwt and marketing (local) jwt and for anonymous
export const CurrentAuthUser = createParamDecorator(
  (
    data: '' | AuthTokenSubEnum.Auth0 | AuthTokenSubEnum.Finq = '',
    context: ExecutionContext,
  ): AuthenticatedUser | null => {
    const request = context.switchToHttp().getRequest();

    if (request.user === 'anonymous') {
      return null;
    }

    const type = DomainHelper.getDomain(request) === request.user.iss ? AuthTokenSubEnum.Finq : AuthTokenSubEnum.Auth0;

    if (data.length > 0 && type !== data) {
      throw new UnauthorizedException('User is not authenticated');
    }

    return {
      ...request.user,
      type,
      authUserId: Auth0IdHelper.getUserIdFromTokenSub(request.user.sub),
      accessToken: request.headers.authorization.replace('Bearer ', '') || '',
    };
  },
);
