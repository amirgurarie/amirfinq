import { IAuth0UserObject, IUpdateAuth0UserIdentifier } from './../shared/types/auth0UserObject.interface';
import { AuthManagementService } from './authManagement.service';
import { ConfigService } from '@nestjs/config';
import {
  ConflictException,
  ForbiddenException,
  NotAcceptableException,
  HttpService,
  Injectable,
  BadRequestException,
  NotImplementedException,
  NotFoundException,
} from '@nestjs/common';
import { SignupDto } from './dto/signup.dto';
import { UsersService } from '../users/users.service';
import { ForgotDto } from './dto/forgot.dto';
import { RefreshTokenDto } from './dto/refreshToken.dto';
import { AuthenticationError } from '../shared/errors/auth.error';
import { AuthenticationTokensSubject } from './subject/authenticationTokens.subject';
import { UserStageService } from '../users/userStage.service';
import { UserStagesEnum } from '../users/userStages.enum';
import { Users } from '../entities/Users';
import { LoggerService } from '../shared/middlewares/logger/logger.service';
import { Auth0SocialUserInterface, AuthenticatedUser } from '../shared/types/authenticatedUser.interface';
import { ICreateOTPDto } from './dto/createOTP.dto';
import jwt from 'jsonwebtoken';
import { Auth0IdHelper } from '../shared/helpers/auth0Id.helper';
import { UserStatusEnum } from 'src/users/userStatus.enum';
import { HubSpotManager } from 'src/shared/modules/hubSpot/hubSpot.manager';
import { UtmDto } from 'src/auth/dto/utm.dto';
import { LoginDto } from 'src/auth/dto/login.dto';
import { Request } from 'express';
import { MakeEvent, MakeService } from 'src/shared/modules/make/make.service';
import { SendGridService } from 'src/common/sendgrid/sendgrid.service';
import { ResendVerifyDto, VerifyDto } from 'src/auth/dto/verify.dto';
import devIsrUsers from './auth0users/devIsr';
import devUsUsers from './auth0users/devUs';
import prodIsrUsers from './auth0users/prodIsr';
import prodUsUsers from './auth0users/prodUs';
import isrHubspotContacts from './hubspotContacts/isr';
import usHubspotContacts from './hubspotContacts/us';
import { JSONClean } from '../shared/helpers/utils';
import { UserEventsEnum } from 'src/shared/enums';
import { UserProfileService } from 'src/users/userProfile/user-profile.service';
import { getSessionId } from '../shared/helpers/cookies.helper';
import { AnalyticsService } from '../shared/modules/analytics/analytics.service';
import dayjs from 'dayjs';

@Injectable()
export class AuthService {
  constructor(
    private readonly configService: ConfigService,
    private readonly httpService: HttpService,
    private readonly usersService: UsersService,
    private readonly userStagesService: UserStageService,
    private readonly authManagementService: AuthManagementService,
    private readonly hubSpotManager: HubSpotManager,
    private readonly loggerService: LoggerService,
    private readonly makeService: MakeService,
    private readonly sendgridService: SendGridService,
    private readonly userProfileService: UserProfileService,
    private readonly analyticsService: AnalyticsService,
  ) {}

  public async login(
    req: Request,
    loginDto: LoginDto | VerifyDto,
    additionalUpdates: Partial<Users> = {},
  ): Promise<any> {
    const { utm, ...loginData } = loginDto;
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    // eslint-disable-next-line prefer-const
    let [oauthLogin, user, { access_token: mgmtAccessToken }] = await Promise.all([
      this.httpService
        .post(
          `https://${auth0Domain}/oauth/token`,
          {
            username: loginData.email,
            password: loginData.password,
            grant_type: 'password',
            audience: this.configService.get<string>('AUTH0_API_IDENTIFIER'),
            scope: 'profile openid read:current_user offline_access email update:users update:current_user_identities',
            client_id: this.configService.get<string>('AUTH0_CLIENT_ID'),
            client_secret: this.configService.get<string>('AUTH0_CLIENT_SECRET'),
          },
          {
            headers: {
              'auth0-forwarded-for': req.clientIp,
            },
          },
        )
        .toPromise()
        .then((res) => {
          this.loggerService.debug(res.data, 'Login Oauth token response');

          return res.data as AuthenticationTokensSubject & {
            id_token: string;
          };
        })
        .catch((err) => {
          this.loggerService.debug(err.response.data, 'Login Oauth token error');
          throw new AuthenticationError(err || 'Invalid credentials');
        }),
      this.usersService.findFirstByEmail(loginData.email),
      this.authManagementService.getManagementToken(),
    ]);

    if (!user) throw new BadRequestException('Authentication failed');

    const userUpdates: Partial<Users> = { lastSeen: new Date(), ...additionalUpdates };

    const existingAuth0Users: any[] = await this.getUsersWithSameVerifiedEmail({
      sub: user.linkToAuth0Id,
      email: loginData.email,
      accessToken: mgmtAccessToken,
    });

    if (existingAuth0Users?.length) {
      const primaryAuth0User = existingAuth0Users.find(({ user_id }) => user_id.includes(user.linkToAuth0Id));

      // Maybe the user has multiple accounts, but none of them has a matching linkToAuth0Id, so we skip linking accounts
      if (primaryAuth0User) {
        this.loggerService.debug({ existingAuth0Users, oauthLogin, user }, 'Login existingAuth0Users');

        // If the user verified his email / he does not have a waiting email to verify
        if (existingAuth0Users.every((authUser) => authUser.email_verified)) {
          const secondaryAuth0Users = existingAuth0Users.filter(({ user_id }) => !user_id.includes(user.linkToAuth0Id));
          let rootUserId = primaryAuth0User.user_id;
          // If primary auth user is jwt user, we need to link it differently
          if (!primaryAuth0User || (primaryAuth0User?.user_id.includes('auth0') && secondaryAuth0Users.length)) {
            rootUserId = secondaryAuth0Users[0].user_id;
          }

          if (rootUserId && secondaryAuth0Users?.length) {
            await this.linkAccounts(rootUserId, { link_with: oauthLogin.id_token }, mgmtAccessToken, {
              id: user.id,
              linkToAuth0Id: user.linkToAuth0Id,
            });
          }

          // Making sure to update the db that the user is confirmed his email
          if (!user.emailConfirmed) {
            userUpdates.emailConfirmed = true;
          }

          // If user status is not authenticated, we need to update it
          if ([UserStatusEnum.Marketing, UserStatusEnum.WaitingForAuthentication].includes(user.userStatus)) {
            userUpdates.userStatus = UserStatusEnum.Authenticated;
          }

          if (user.connectionType !== 'user-password') {
            userUpdates.connectionType = 'user-password';
          }

          // Trigger login form in hubspot
          await this.hubSpotManager.loginContact({ user, req });
        } else {
          await this.resendVerificationEmail(req, user);

          throw new NotAcceptableException('Authentication failed');
        }
      }
    }

    if (!user) {
      if (oauthLogin) {
        this.loggerService.debug('User does not exist but creating him in db', 'Auth Login');
        user = await this.usersService.create({
          ...loginData,
          connectionType: 'user-password',
          userDetails: { email: loginData.email },
        });

        await Promise.all([
          this.reportAuthEvent(req, user, 'signup_success', 'user-password'),
          this.hubSpotManager.createContact({ user, utm, req }),
        ]);
      } else {
        this.loggerService.debug('User does not exist', 'Auth Login');
      }
    }

    await this.usersService.updateWithoutSelect(user.id, userUpdates);

    if (userUpdates.emailConfirmed) {
      await this.reportAuthEvent(req, user, 'user_verified', 'user-password');
    }

    await this.reportAuthEvent(req, user, 'login_success', 'user-password');

    return {
      ...oauthLogin,
      ...user,
      ...userUpdates,
    };
  }

  public async signup(req: Request, signupData: SignupDto) {
    const { password, utm, ...userData } = signupData;
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');
    const emailConfirmedManually = signupData.email.endsWith('verified@finqai.com');

    let user = await this.usersService.findOneBy({ email: signupData.email }, ['userDetails']);

    if (!user) {
      const createInDbAndReportStartTime = new Date().getTime();
      user = await this.usersService.create({ ...userData, connectionType: 'user-password' });
      await this.userProfileService.updateUserProfile(
        { id: user.id, ...userData },
        user?.id,
        UserEventsEnum.SignUp,
        true,
      );
      this.loggerService.debug(user, '[Signup] Created new user');

      // Get the user with the userDetails
      user = await this.usersService.findOneBy({ id: user.id }, ['userDetails']);

      await this.reportAuthEvent(req, user, 'signup_success', 'user-password');
      const createInDbAndReportEndTime = new Date().getTime();
      this.loggerService.log(
        `Signup::authService.signup::${signupData.email}::create in DB + report: ${
          createInDbAndReportEndTime - createInDbAndReportStartTime
        }ms`,
      );
    } else {
      this.loggerService.debug(user, '[Signup] Existing user trying to signup');
    }

    let oauthLogin: IAuthSignup;

    try {
      const signupInAuth0StartTime = new Date().getTime();

      const auth0RequestStartTime = new Date().getTime();
      oauthLogin = (
        await this.httpService
          .post(`https://${auth0Domain}/dbconnections/signup`, {
            client_id: this.configService.get<string>('AUTH0_CLIENT_ID'),
            email: userData.email,
            password: password,
            given_name: userData.firstName,
            family_name: userData.lastName,
            connection: this.configService.get<string>('AUTH0_CONNECTION'),
            user_metadata: {
              marketingId: user.id,
              preferredLanguage: signupData.defaultLanguage,
            },
          })
          .toPromise()
      ).data;
      const auth0RequestEndTime = new Date().getTime();
      this.loggerService.log(
        `Signup::authService.signup::${signupData.email}::signup in auth0::auth0: ${
          auth0RequestEndTime - auth0RequestStartTime
        }ms`,
      );

      const hubspotStartTime = new Date().getTime();
      await this.hubSpotManager.createContact({ user, utm, req });
      const hubspotEndTime = new Date().getTime();
      this.loggerService.log(
        `Signup::authService.signup::${signupData.email}::signup in auth0::hubspot: ${
          hubspotEndTime - hubspotStartTime
        }ms`,
      );

      const signupInAuth0EndTime = new Date().getTime();
      this.loggerService.log(
        `Signup::authService.signup::${signupData.email}::signup in auth0: ${
          signupInAuth0EndTime - signupInAuth0StartTime
        }ms`,
      );
    } catch (e) {
      this.loggerService.debug(e, 'Signup error');
      // If users already exists in auth0, return conflict, else return global err
      const existingUsers = await this.validateEmailPasswordSignup(userData.email);

      if (existingUsers?.length) {
        if (existingUsers.some(({ email_verified }) => !email_verified)) {
          await this.resendVerificationEmail(req, user);
          throw new NotAcceptableException('Action required for account activation');
        }

        throw new ConflictException('Unable to proceed with the request');
      } else {
        throw new BadRequestException('Request cannot be processed at this time');
      }
    }

    this.loggerService.debug(oauthLogin, 'Signup response');

    const updates: Partial<Users> = <Partial<Users>>{
      linkToAuth0Id: oauthLogin._id,
      userStatus: UserStatusEnum.WaitingForAuthentication,
    };

    if (!user.emailConfirmed) {
      updates.emailConfirmed = oauthLogin.email_verified || emailConfirmedManually;
    }

    if (!user.picture) {
      updates.picture = oauthLogin.picture;
    }

    const updateUserInDbStartTime = new Date().getTime();
    const [updatedUser] = await Promise.all([
      this.usersService.update(user.id, updates),
      this.userStagesService.insert({ stage: UserStagesEnum.CompletedSignUp, user: user }),
    ]);
    const updateUserInDbEndTime = new Date().getTime();
    this.loggerService.log(
      `Signup::authService.signup::${signupData.email}::update user in db: ${
        updateUserInDbEndTime - updateUserInDbStartTime
      }ms`,
    );

    if (emailConfirmedManually) {
      await this.authManagementService.updateAuth0User({ email: signupData.email }, { email_verified: true });
    }

    if (updates.emailConfirmed) {
      await this.reportAuthEvent(req, user, 'user_verified', 'user-password');
    } else {
      const sendVerificationEmailStartTime = new Date().getTime();
      await this.resendVerificationEmail(req, user);
      const sendVerificationEmailEndTime = new Date().getTime();
      this.loggerService.log(
        `Signup::authService.signup::${signupData.email}::send verification email: ${
          sendVerificationEmailEndTime - sendVerificationEmailStartTime
        }ms`,
      );
    }

    return {
      ...oauthLogin,
      ...updatedUser,
    };
  }

  public async verifyUser(
    verifyData: VerifyDto,
    authUserPayload?: Auth0SocialUserInterface,
  ): Promise<{ verifyData: VerifyDto }> {
    const userEmail = authUserPayload?.user?.email ?? verifyData.email;
    const user = authUserPayload?.user ?? (await this.usersService.findOneBy({ email: userEmail.toLowerCase() }));

    // Validation
    if (!user || !user.verificationCode || user.verificationCode !== verifyData.code) {
      throw new BadRequestException('Verification unsuccessful');
    }

    let updateField: IUpdateAuth0UserIdentifier = { email: userEmail };

    const { access_token: mgmtAccessToken } = await this.authManagementService.getManagementToken();

    const existingAuth0Users = await this.getUsersWithSameVerifiedEmail({
      sub: authUserPayload?.sub || '',
      email: userEmail,
      accessToken: mgmtAccessToken,
    });

    const nonConfirmedAuth0User = existingAuth0Users.find((e) => !e.email_verified);

    if (nonConfirmedAuth0User) {
      updateField = { user_id: nonConfirmedAuth0User.user_id };
    }

    if (!nonConfirmedAuth0User && user.emailConfirmed) {
      throw new BadRequestException('Email already verified');
    }

    await Promise.all([
      this.authManagementService.updateAuth0User(updateField, { email_verified: true }),
      this.usersService.updateWithoutSelect(user.id, {
        emailConfirmed: true,
        verificationCode: null,
        userStatus: UserStatusEnum.Authenticated,
      }),
      this.hubSpotManager.updateContact({ user, properties: { email_authenticated: 'Yes' } }),
    ]);

    // TEMP: Delaying the response to make sure the user is verified in auth0
    await new Promise((resolve) => setTimeout(resolve, 2000));

    return { verifyData };
  }

  public async resendVerificationEmail(req: Request, { email }: ResendVerifyDto): Promise<void> {
    const user = await this.usersService.findOneBy({ email });

    if (!user) {
      throw new BadRequestException('Resending verification unsuccessful');
    }

    const expirationVerificationCodeDate = dayjs(user.verificationCodeDate).add(1, 'day');

    let verificationCode, verificationCodeDate;
    if (user.verificationCodeDate && dayjs().isBefore(expirationVerificationCodeDate)) {
      verificationCode = user.verificationCode ?? verificationCodeGenerator();
      verificationCodeDate = user.verificationCodeDate;
    } else {
      verificationCode = verificationCodeGenerator();
      verificationCodeDate = new Date();
    }

    await this.sendVerificationEmail({ ...user, verificationCode });

    await this.usersService.updateWithoutSelect(user.id, { verificationCode, verificationCodeDate });

    return;
  }

  private async validateEmailPasswordSignup(email) {
    const { access_token: accessToken } = await this.authManagementService.getManagementToken();

    const existingUsers = await this.getUsersWithSameVerifiedEmail({
      email,
      accessToken,
    });

    const hasExistingUser = existingUsers.some(({ identities }) =>
      identities?.length
        ? identities.some((identity) => identity.connection === this.configService.get<string>('AUTH0_CONNECTION'))
        : false,
    );

    return hasExistingUser ? existingUsers : null;
  }

  public async createOrUpdateSocialUser({
    userInfo,
    auth0User,
    utm,
    req,
  }: {
    userInfo: IAuth0UserInfo;
    auth0User: Auth0User | Auth0SocialUserInterface;
    utm: UtmDto;
    req: Request;
  }) {
    if (!userInfo.email) {
      throw new ForbiddenException('Required scopes are missing from the request');
    }

    let user: Users = await this.usersService.findOneBy(
      {
        email: userInfo.email,
      },
      ['userDetails'],
    );

    const [linkedAccount] = await this.handleAccountSocialLink(userInfo, user);
    const updatedConnectionType = userInfo.sub?.split('|')[0] as MakeEvent.SignupMethods;

    if (user) {
      const updates: Partial<Users> = <Partial<Users>>{
        linkToAuth0Id: auth0User.authUserId,
      };

      if (linkedAccount && Object.keys(linkedAccount)?.length) {
        updates.linkToAuth0Id = linkedAccount[0]?.user_id;
      }

      if (!user.emailConfirmed) {
        updates.emailConfirmed = userInfo.email_verified;
      }

      if (!user.picture) {
        updates.picture = userInfo.picture_large ?? userInfo.picture;
      }

      if (updatedConnectionType && user.connectionType !== updatedConnectionType) {
        updates.connectionType = updatedConnectionType;
      }

      // if user status is Marketing / Waiting For Authentication
      if ([UserStatusEnum.Marketing, UserStatusEnum.WaitingForAuthentication].includes(user.userStatus)) {
        updates.userStatus = UserStatusEnum.Authenticated;
      }

      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const userUpdated = await this.usersService.update(user.id, updates, { relations: ['userDetails'] });
      user = userUpdated;

      if (updates.emailConfirmed) {
        await this.reportAuthEvent(req, user, 'user_verified', updatedConnectionType);
      }

      // Trigger login form in hubspot
      await this.hubSpotManager.loginContact({ user, req });
    } else {
      // if user does not exist
      user = await this.usersService.create({
        email: userInfo.email,
        linkToAuth0Id: auth0User.authUserId,
        emailConfirmed: userInfo.email_verified,
        userStatus: UserStatusEnum.Authenticated,
        connectionType: updatedConnectionType,
      });

      user.userDetails = await this.userProfileService.createUserProfile(
        {
          id: user.id,
          email: userInfo.email,
          firstName: userInfo.given_name,
          lastName: userInfo.family_name,
          picture: userInfo.picture_large ?? userInfo.picture,
        },
        user?.id,
      );

      await this.reportAuthEvent(req, user, 'signup_success', updatedConnectionType);

      if (userInfo.email_verified) {
        await this.reportAuthEvent(req, user, 'user_verified', updatedConnectionType);
      }

      // Trigger signup contact in hubspot
      await this.hubSpotManager.createContact({ user, utm, req });

      await this.userStagesService.insert({
        stage: UserStagesEnum.CompletedSocialSignUp,
        user: user,
      });
    }

    await this.reportAuthEvent(req, user, 'login_success', updatedConnectionType);

    return {
      ...userInfo,
      ...user,
      ...{ access_token: auth0User.accessToken, expires_in: auth0User.exp },
    };
  }

  public async getUserInfo(accessToken): Promise<IAuth0UserInfo> {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    try {
      return await this.httpService
        .get(`https://${auth0Domain}/userinfo`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        })
        .toPromise()
        .then((res) => {
          this.loggerService.debug(res.data, 'UserInfo response');

          return res.data as IAuth0UserInfo;
        });
    } catch (e) {
      this.loggerService.debug(e, 'UserInfo error');
      throw new AuthenticationError(e);
    }
  }

  public async forgotPassword(forgotData: ForgotDto): Promise<any> {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    try {
      return await this.httpService
        .post(`https://${auth0Domain}/dbconnections/change_password`, {
          client_id: this.configService.get<string>('AUTH0_CLIENT_ID'),
          email: forgotData.email,
          connection: this.configService.get<string>('AUTH0_CONNECTION'),
        })
        .toPromise();
    } catch (e) {
      throw new AuthenticationError(e);
    }
  }

  public async refreshToken(ip: string, refreshToken: RefreshTokenDto): Promise<IAuthLogin | void> {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    return await this.httpService
      .post(
        `https://${auth0Domain}/oauth/token`,
        {
          refresh_token: refreshToken.refreshToken,
          grant_type: 'refresh_token',
          client_id: this.configService.get<string>('AUTH0_CLIENT_ID'),
          client_secret: this.configService.get<string>('AUTH0_CLIENT_SECRET'),
        },
        {
          headers: {
            'auth0-forwarded-for': ip,
          },
        },
      )
      .toPromise()
      .then((res) => {
        this.loggerService.debug(res.data, 'Refresh oauth token response');

        return res.data as IAuthLogin;
      })
      .catch((err) => {
        this.loggerService.debug(err, 'Refresh oauth token error');
        throw new AuthenticationError(err);
      });
  }

  public async logout(req: Request, accessToken: string): Promise<Record<string, unknown>> {
    const sessionId = getSessionId(req, this.configService);
    if (sessionId) {
      await this.analyticsService.revokeSession(sessionId);
    }

    //in the future update stage on analytics server
    return {};
  }

  public async initiateOtp(ip, email: string): Promise<IOtpLogin> {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    return await this.httpService
      .post(
        `https://${auth0Domain}/passwordless/start`,
        {
          connection: 'email',
          email: email?.toLowerCase(),
          send: 'code',
          client_id: this.configService.get<string>('AUTH0_CLIENT_ID'),
          client_secret: this.configService.get<string>('AUTH0_CLIENT_SECRET'),
        },
        {
          headers: {
            'auth0-forwarded-for': ip,
          },
        },
      )
      .toPromise()
      .then((res) => {
        this.loggerService.debug(res.data, 'Initiate otp login response');

        return res.data as IOtpLogin;
      })
      .catch((err) => {
        this.loggerService.debug(err, 'Initiate otp login error');
        throw new AuthenticationError(err);
      });
  }

  public async createOrUpdateOTPUser(data: ICreateOTPDto): Promise<IAuthOtpLogin & Users> {
    let user = await this.usersService.findOneBy({
      email: data.email.toLowerCase(),
    });

    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    let oauthData: IAuthOtpLogin;
    try {
      oauthData = (
        await this.httpService
          .post(`https://${auth0Domain}/oauth/token`, {
            grant_type: 'http://auth0.com/oauth/grant-type/passwordless/otp',
            client_id: this.configService.get<string>('AUTH0_CLIENT_ID'),
            client_secret: this.configService.get<string>('AUTH0_CLIENT_SECRET'),
            username: data.email,
            otp: data.code,
            realm: 'email',
            audience: this.configService.get<string>('AUTH0_API_IDENTIFIER'),
            scope: 'openid profile email offline_access update:current_user_identities',
          })
          .toPromise()
      ).data;
    } catch (e) {
      this.loggerService.debug(e, 'Create otp user error');
      throw new AuthenticationError(e);
    }

    this.loggerService.debug(oauthData, 'Create otp user response');

    const userProfile = jwt.decode(oauthData.id_token) as IAuthIdTokenInfo;

    const [linkedAccount] = await this.handleAccountSocialLink(userProfile, user);

    let auth0Sub = userProfile.sub;
    if (linkedAccount && Object.keys(linkedAccount)?.length) {
      auth0Sub = linkedAccount[0].user_id;
    }

    const dataToUpdate: Partial<Users> = {
      lastSeen: new Date(),
      linkToAuth0Id: Auth0IdHelper.getUserIdFromTokenSub(auth0Sub),
    };

    if (!user) {
      user = await this.usersService.create({
        ...dataToUpdate,
        email: data.email,
      });

      await this.userProfileService.updateUserProfile(
        {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
        },
        user?.id,
        UserEventsEnum.SignUp,
        true,
      );

      await this.userStagesService.insert({
        stage: UserStagesEnum.CompletedSignUp,
        user: user,
      });
    } else {
      await this.usersService.update(user.id, dataToUpdate);
    }

    return {
      ...oauthData,
      ...user,
    };
  }

  public async handleAccountSocialLink(userInfo: IAuth0UserInfo, user: Users) {
    const { access_token: mgmtAccessToken } = await this.authManagementService.getManagementToken();

    const existingAuth0Users: any[] = await this.getUsersWithSameVerifiedEmail({
      sub: userInfo.sub,
      email: userInfo.email,
      accessToken: mgmtAccessToken,
    });

    if (existingAuth0Users?.length) {
      // Checking for un verified accounts
      const noneVerifiedAuth0User = existingAuth0Users.find((authUser) => !authUser.email_verified);
      if (noneVerifiedAuth0User) {
        // // Uncomment if you want to lock the user out of the app whenever a new email-password account is created with the same email
        // if (user.emailConfirmed) {
        //   await this.usersService.update(user.id, { emailConfirmed: false });
        // }

        // // Sending a verification email to the user and alerting the client
        // await this.resendVerificationEmail({} as Request, user);

        // throw new NotAcceptableException('Email not verified');
        return [];
      } else {
        const [newAuth0Provider, newAuth0UserId] = userInfo.sub.split('|');

        return this.linkAccounts(
          existingAuth0Users[0].user_id,
          { provider: newAuth0Provider, user_id: newAuth0UserId },
          mgmtAccessToken,
        );
      }
    } else {
      return [];
    }
  }

  private async linkAccounts(
    rootUserId: string,
    targetUserIdToken: object,
    accessToken: string,
    user?: { id: string; linkToAuth0Id: string },
  ) {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    const requests: any[] = [
      await this.httpService
        .post(`https://${auth0Domain}/api/v2/users/${rootUserId}/identities`, targetUserIdToken, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        })
        .toPromise()
        .then((res) => {
          this.loggerService.debug(
            res.data,
            `linkAccounts post({rootUserId: ${rootUserId}, targetUserIdToken: ${targetUserIdToken}}) response`,
          );

          return res.data as IAuth0UserObject[];
        }),
    ];

    if (!!user && !rootUserId.includes(user?.linkToAuth0Id)) {
      const updates: Partial<Users> = <Partial<Users>>{
        linkToAuth0Id: rootUserId,
      };

      requests.push(await this.usersService.update(user.id, updates));
    }

    return await Promise.all(requests);
  }

  private getUsersWithSameVerifiedEmail({ sub = '', email, accessToken }): Promise<IAuth0UserObject[]> {
    this.loggerService.log(`searching matching users with email ${email} , ${sub} ...`);

    try {
      return this.authManagementService.getAuth0Users(
        {
          q: `email:"${email?.toLowerCase()}" ${sub ? `-user_id:"${sub}"` : ''}`,
        },
        accessToken,
      );
    } catch (e) {
      this.loggerService.debug(e, 'getUsersWithSameVerifiedEmail get() error');
      throw new AuthenticationError(e);
    }
  }

  private async reportAuthEvent(req: Request, user: Users, eventName: string, connectionType: string) {
    return this.analyticsService.reportEvent(req, user, {
      eventName,
      eventType: 'authentication',
      eventSource: 'server',
      eventParams: {
        user: {
          id: user.id,
          firstName: user.userDetails.firstName,
          lastName: user.userDetails.lastName,
          email: user.email,
          connectionType,
        },
      },
    });
  }

  public async sendAuth0VerificationEmail({ accessToken, userId }) {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    return await this.httpService
      .post(
        `https://${auth0Domain}/api/v2/jobs/verification-email`,
        { user_id: userId },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      )
      .toPromise()
      .then((res) => {
        this.loggerService.debug(res.data, `send verification email response`);

        return res.data as IAuth0UserObject[];
      });
  }

  public sendVerificationEmail({
    verificationCode,
    email,
    defaultLanguage,
  }: Pick<Users, 'verificationCode' | 'email' | 'defaultLanguage'>) {
    return this.sendgridService.sendWithTemplate({
      name: 'code_verification',
      data: { otp: verificationCode },
      to: email,
      lang: defaultLanguage,
    });
  }

  public async prepareForAlignment() {
    const db = this.configService.get<string>('POSTGRES_DATABASE');

    const dbUsers = await this.usersService.findAll();
    const auth0users = db.includes('dev')
      ? db.includes('isr')
        ? devIsrUsers
        : devUsUsers
      : db.includes('isr')
      ? prodIsrUsers
      : prodUsUsers;

    const results = {
      notExistInAuth0: [],
      notExistInDb: [],
      auth0LinkWrong: [],
      goodUsers: [],
      count: {
        notExistInAuth0: 0,
        notExistInDb: 0,
        auth0LinkWrong: 0,
        goodUsers: 0,
      },
    };
    const auth0usersObj = {};
    auth0users.forEach((auth0User) => {
      if (!auth0usersObj[auth0User.Email]) {
        auth0usersObj[auth0User.Email] = auth0User;
      }
    });

    const dbUsersObj = {};
    dbUsers.forEach((dbUser) => {
      if (!dbUsersObj[dbUser.email]) {
        dbUsersObj[dbUser.email] = dbUser;
      }
    });

    auth0users.forEach((auth0User) => {
      if (!dbUsersObj[auth0User.Email]) {
        results.notExistInDb.push(auth0User);
        results.count.notExistInDb++;
      }
    });

    dbUsers.forEach((dbUser) => {
      if (auth0usersObj[dbUser.email]) {
        if (auth0usersObj[dbUser.email].Id.split('|')[1] === dbUser.linkToAuth0Id) {
          results.goodUsers.push(dbUser);
          results.count.goodUsers++;
        } else {
          results.auth0LinkWrong.push(dbUser);
          results.count.auth0LinkWrong++;
        }
      } else {
        results.notExistInAuth0.push(dbUser);
        results.count.notExistInAuth0++;
      }
    });

    for (let i = 0; i < results.notExistInAuth0.length; i++) {
      const notExistedUser = results.notExistInAuth0[i];
      const hubspotData = await this.getUserDataFromHubspot(notExistedUser);

      const updates: Partial<Users> = JSONClean({
        missingUserInAuth0: true,
        ...hubspotData,
      });
      await this.usersService.getRepository().update({ id: notExistedUser.id }, updates);
    }

    for (let i = 0; i < results.goodUsers.length; i++) {
      const existedUser = results.goodUsers[i];
      const hubspotData = await this.getUserDataFromHubspot(existedUser);

      const updates: Partial<Users> = JSONClean({
        missingUserInAuth0: false,
        ...hubspotData,
      });
      await this.usersService.getRepository().update({ id: existedUser.id }, updates);
    }

    return { done: true, count: results.count };
  }

  private async getUserDataFromHubspot(user) {
    const db = this.configService.get<string>('POSTGRES_DATABASE');
    const hubspotContacts = db.includes('isr') ? isrHubspotContacts : usHubspotContacts;
    const hubspotContact = hubspotContacts.find((el) => el.Email === user.email);

    let existingHubspotContactInOurDB;
    try {
      existingHubspotContactInOurDB = await this.hubSpotManager.hubSpotService.findOneBy({ email: user.email });
    } catch (e) {}

    const updates: Partial<Users> = JSONClean({
      missingContactInHubspot: !hubspotContact,
      realHubspotContactId: hubspotContact?.Record_ID ? String(hubspotContact?.Record_ID) : undefined,
      mismatchHubspotContactId: String(existingHubspotContactInOurDB?.contactId) != String(hubspotContact?.Record_ID),
    });

    return updates;
  }
}

function verificationCodeGenerator(length = 6): string {
  // Generate a random number between 100000 and 999999
  const randomNum = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;

  // Convert the number to a string and pad with leading zeros if necessary
  return randomNum.toString().padStart(length, '0');
}
