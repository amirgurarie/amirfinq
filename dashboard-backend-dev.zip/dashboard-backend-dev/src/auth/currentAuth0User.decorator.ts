import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { Auth0IdHelper } from '../shared/helpers/auth0Id.helper';
import { Auth0JwtUser } from '../shared/types/authenticatedUser.interface';

//can be used only for auth0 jwt
export const CurrentAuth0User = createParamDecorator((data: unknown, context: ExecutionContext): Auth0JwtUser => {
  const request = context.switchToHttp().getRequest();

  return {
    ...request.user,
    auth0UserId: Auth0IdHelper.getUserIdFromTokenSub(request.user.sub),
    accessToken: request.headers.authorization.replace('Bearer ', '') || '',
  };
});
