export const enum AuthScopes {
  Marketing = 'marketing',
}
