export enum AuthTokenSubEnum {
  Auth0 = 'auth0',
  Auth0Email = 'email',
  Facebook = 'facebook',
  Google = 'google-oauth2',
  Finq = 'finq',
}
