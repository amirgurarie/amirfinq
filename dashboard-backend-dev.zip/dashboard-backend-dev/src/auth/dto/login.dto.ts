import { Allow, IsEmail, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { UtmObjectDto } from 'src/auth/dto/utm.dto';

export class LoginDto extends UtmObjectDto {
  @IsEmail()
  @ApiProperty({ name: 'email', type: String, required: true })
  public readonly email: string;

  @Allow()
  @IsString()
  @ApiProperty({ name: 'password', type: String, required: true })
  public readonly password: string;
}
