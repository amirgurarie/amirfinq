import { IsEmail } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';

export class ForgotDto {
  @IsEmail()
  @ApiProperty({
    name: 'email',
    required: true,
    type: String,
  })
  @Transform(({ value }) => value.toLowerCase())
  public readonly email: string;
}
