import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { Allow, IsOptional, IsString } from 'class-validator';

export class UtmDto {
  @IsString()
  @IsOptional()
  @ApiProperty()
  public readonly ref: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  public readonly adId: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  public readonly lastClickRef: string;
}

export class UtmObjectDto {
  @Allow()
  @Type(() => UtmDto)
  @ApiProperty({ name: 'utm', required: false, type: UtmDto })
  public readonly utm?: UtmDto;
}
