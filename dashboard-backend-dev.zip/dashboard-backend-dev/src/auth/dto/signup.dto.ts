import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { Allow, IsEmail, IsNotEmpty } from 'class-validator';
import { UtmObjectDto } from 'src/auth/dto/utm.dto';
import { IsValidPassword } from 'src/shared/validators/isValidPassword';
import { UserStatusEnum } from 'src/users/userStatus.enum';
import { IsValidText } from '../../shared/validators/isValidText';

export class InputSignupDto extends UtmObjectDto {
  @IsEmail()
  @ApiProperty({ name: 'email', required: true, type: String })
  @Transform(({ value }) => value.toLowerCase())
  public readonly email: string;

  @Allow()
  @ApiProperty({ name: 'password', required: true, type: String })
  @IsValidPassword()
  public readonly password: string;

  @Allow()
  @ApiProperty({ name: 'firstName', required: false, type: String })
  @IsNotEmpty()
  @IsValidText({
    message: 'Invalid first name. Only letters, numbers, spaces, and specific punctuation are allowed.',
  })
  public readonly firstName?: string;

  @Allow()
  @ApiProperty({ name: 'lastName', required: false, type: String })
  @Transform(({ value }) => (value == null ? undefined : value))
  @IsValidText({
    message: 'Invalid last name. Only letters, numbers, spaces, and specific punctuation are allowed.',
  })
  public readonly lastName?: string;
}

export class SignupDto extends InputSignupDto {
  @Allow()
  public defaultLanguage?: string;

  @Allow()
  public userStatus?: UserStatusEnum;
}
