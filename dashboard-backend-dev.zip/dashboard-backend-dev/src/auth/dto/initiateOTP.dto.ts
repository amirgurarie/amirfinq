import { Allow, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';

export class InitiateOTPDto {
  @ApiProperty({
    name: 'email',
    required: true,
    type: String,
  })
  @Allow()
  @IsNotEmpty()
  @Transform(({ value }) => value.toLowerCase())
  public readonly email: string;
}
