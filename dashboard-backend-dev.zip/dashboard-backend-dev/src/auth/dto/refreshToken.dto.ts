import { ApiProperty } from '@nestjs/swagger';
import { Allow } from 'class-validator';

export class RefreshTokenDto {
  @ApiProperty({
    name: 'refreshToken',
    required: true,
    type: String,
  })
  @Allow()
  public readonly refreshToken: string;
}
