import { Allow, IsEmail, IsNotEmpty } from 'class-validator';
import { ApiProperty, PartialType } from '@nestjs/swagger';
import { LoginDto } from 'src/auth/dto/login.dto';

export class VerifyDto extends PartialType(LoginDto) {
  @Allow()
  @ApiProperty()
  @IsNotEmpty()
  public readonly code: string;
}

export class ResendVerifyDto {
  @IsEmail()
  @ApiProperty({ name: 'email', type: String, required: true })
  public readonly email: string;
}
