import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class AuthenticationTokensSubject {
  @Expose({ name: 'accessToken', toPlainOnly: true })
  @ApiProperty({
    name: 'accessToken',
  })
  access_token: string;

  @Expose({ name: 'refreshToken', toPlainOnly: true })
  @ApiProperty({
    required: false,
    name: 'refreshToken',
  })
  refresh_token?: string | null;

  @Expose({ name: 'expiresIn', toPlainOnly: true })
  @ApiProperty({
    name: 'expiresIn',
  })
  expires_in: number;
}
