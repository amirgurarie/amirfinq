import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { UserSubject } from '../../users/subject/user.subject';

export class AuthenticatedUserSubject extends UserSubject {
  @Expose()
  @ApiProperty()
  emailConfirmed: boolean;

  @Expose()
  @ApiProperty()
  auth0Id: string;

  @Expose({ name: 'accessToken', toPlainOnly: true })
  @ApiProperty({ name: 'accessToken' })
  access_token: string;

  @Expose({ name: 'refreshToken', toPlainOnly: true })
  @ApiProperty({
    required: false,
    name: 'refreshToken',
  })
  refresh_token?: string | null;

  @Expose({ name: 'expiresIn', toPlainOnly: true })
  @ApiProperty({
    required: false,
    name: 'expiresIn',
  })
  expires_in?: number | null;
}
