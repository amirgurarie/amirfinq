import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { Strategy } from 'passport-http-bearer';
import { JwtService } from '@nestjs/jwt';
import { AuthScopes } from './authScopes.enum';
import { AuthTokenSubEnum } from './authTokenSub.enum';
import { UsersService } from '../users/users.service';
import { Users } from '../entities/Users';
import { Auth0IdHelper } from '../shared/helpers/auth0Id.helper';

@Injectable()
export class MarketingStrategy extends PassportStrategy(Strategy) {
  constructor(
    protected readonly configService: ConfigService,
    private readonly jwtService: JwtService,
    private readonly userService: UsersService,
  ) {
    super();
  }

  async validate(payload: any): Promise<MarketingUser & { user: Users }> {
    let tokenDecoded;
    try {
      tokenDecoded = <MarketingUser>this.jwtService.verify(payload);
    } catch (err) {
      return null;
    }
    if (tokenDecoded.scope !== AuthScopes.Marketing) {
      return null;
    }
    const subArray = Auth0IdHelper.getTokenSubArray(tokenDecoded.sub);

    if (subArray[0] !== AuthTokenSubEnum.Finq) {
      return null;
    }

    const user = await this.userService.findOne(Auth0IdHelper.getUserIdFromTokenSub(tokenDecoded.sub));
    if (!user) {
      return null;
    }

    return { ...tokenDecoded, ...{ user: user } };
  }
}
