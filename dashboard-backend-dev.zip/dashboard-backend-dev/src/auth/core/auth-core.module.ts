import { forwardRef, Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { PassportModule } from '@nestjs/passport';
import { UsersModule } from 'src/users/users.module';
import { HubSpotModule } from 'src/shared/modules/hubSpot/hubSpot.module';
import { MakeModule } from 'src/shared/modules/make/make.module';
import { AnalyticsModule } from 'src/shared/modules/analytics/analytics.module';
import { SendGridModule } from 'src/common/sendgrid/sendgrid.module';
import { UserProfileModule } from 'src/users/userProfile/user-profile.module';
import { LoggerModule } from 'src/shared/middlewares/logger/logger.module';
import { jwtModuleFactory } from 'src/shared/helpers/jwtModule.factory';
import { AuthService } from '../auth.service';
import { JwtStrategy } from '../jwt.strategy';
import { MarketingStrategy } from '../marketing.strategy';
import { SocialJwtStrategy } from '../socialJwt.strategy';
import { AuthManagementService } from '../authManagement.service';
import { EnvironmentManager } from 'src/env/envManager.service';
import { AnonymousStrategy } from '../anonymous.strategy';

@Module({
  imports: [
    HttpModule,
    LoggerModule,
    PassportModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: jwtModuleFactory,
      inject: [ConfigService],
    }),
    forwardRef(() => UsersModule),
    HubSpotModule,
    MakeModule,
    AnalyticsModule,
    SendGridModule,
    UserProfileModule,
  ],
  providers: [
    AuthService,
    JwtStrategy,
    MarketingStrategy,
    SocialJwtStrategy,
    AuthManagementService,
    AnonymousStrategy,
    EnvironmentManager,
  ],
  exports: [
    LoggerModule,
    PassportModule,
    JwtModule,
    AuthService,
    AuthManagementService,
    JwtStrategy,
    MarketingStrategy,
    SocialJwtStrategy,
    AnonymousStrategy,
    HubSpotModule,
    MakeModule,
    AnalyticsModule,
    SendGridModule,
    UserProfileModule,
    EnvironmentManager,
  ],
})
export class AuthCoreModule {}
