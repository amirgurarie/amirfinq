import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { passportJwtSecret } from 'jwks-rsa';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { FindConditions } from 'typeorm';
import { Users } from '../entities/Users';
import { Auth0IdHelper } from '../shared/helpers/auth0Id.helper';
import { UsersService } from '../users/users.service';

@Injectable()
export class SocialJwtStrategy extends PassportStrategy(Strategy, 'socialJwt') {
  constructor(protected readonly configService: ConfigService, private readonly userService: UsersService) {
    super({
      secretOrKeyProvider: passportJwtSecret({
        cache: true,
        rateLimit: true,
        jwksRequestsPerMinute: 5,
        jwksUri: `https://${configService.get<string>('AUTH0_DOMAIN')}/.well-known/jwks.json`,
      }),
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      audience: `${configService.get<string>('AUTH0_API_IDENTIFIER')}`,
      issuer: `${configService.get<string>('AUTH0_ISSUER_URL')}`,
      algorithms: ['RS256'],
    });
  }

  async validate(payload: IAuth0Payload): Promise<IAuth0Payload & { user?: Users; type: string }> {
    const subArray = Auth0IdHelper.getTokenSubArray(payload.sub);
    const auth0userId = Auth0IdHelper.getUserIdFromTokenSub(payload.sub);
    // finds the field in the payload that contains the email
    const emailField = Object.keys(payload).find((key) => key.endsWith('/email'));
    const email = payload[emailField] || payload['https://finqfinance.com/email']; // we have a rule in auth0 that adds the email to the access token - https://manage.auth0.com/dashboard/eu/dev-pulfkw2v/rules/rul_C0G1Tus8eJJtRX66

    const where: FindConditions<Users> = email ? { email } : { linkToAuth0Id: auth0userId };
    const user = await this.userService.findCurrentAuthUser(where);

    return user ? { ...payload, ...{ user: user, type: subArray[0] } } : { ...payload, ...{ type: subArray[0] } };
  }
}
