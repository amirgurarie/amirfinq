import { Strategy } from 'passport';

export class AnonymousPassportStrategy extends Strategy {
  name = 'anonymous';

  authenticate() {
    return this.success('anonymous');
  }
}
