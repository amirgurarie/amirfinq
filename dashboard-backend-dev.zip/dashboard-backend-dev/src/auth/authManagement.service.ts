import { ConfigService } from '@nestjs/config';
import { HttpService, Injectable } from '@nestjs/common';
import { AuthenticationError } from '../shared/errors/auth.error';
import { LoggerService } from '../shared/middlewares/logger/logger.service';
import { IAuthenticatedManagementApi } from '../shared/types/authenticatedApi.interface';
import { IAuth0UserObject, IUpdateAuth0UserIdentifier } from '../shared/types/auth0UserObject.interface';
import { BadRequestError } from '../shared/errors/badRequest.error';
import { RxjsHelper } from 'src/shared/helpers/rxjs.helper';
//todo finish this if it's needed
@Injectable()
export class AuthManagementService {
  constructor(
    private readonly configService: ConfigService,
    private readonly httpService: HttpService,
    protected readonly loggerService: LoggerService,
  ) {}

  public getManagementToken(): Promise<IAuthenticatedManagementApi> {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    try {
      return this.httpService
        .post(`https://${auth0Domain}/oauth/token`, {
          grant_type: 'client_credentials',
          audience: `https://${auth0Domain}/api/v2/`,
          client_id: this.configService.get<string>('AUTH0_CLIENT_ID'),
          client_secret: this.configService.get<string>('AUTH0_CLIENT_SECRET'),
          scope: 'update:users',
        })
        .toPromise()
        .then((res) => {
          this.loggerService.debug(res.data, 'Login Oauth token response');

          return res.data as IAuthenticatedManagementApi;
        });
    } catch (err) {
      this.loggerService.debug(err.response ?? err, 'Login auth0 management token error');
      throw new AuthenticationError(err.response?.data ?? err);
    }
  }

  public async getAuth0Users(
    params: Object = {},
    accessToken?: string,
    failIfEmpty = false,
  ): Promise<IAuth0UserObject[]> {
    this.loggerService.log(`searching auth0 users using the query: ${JSON.stringify(params)}`);

    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');

    try {
      const access_token = accessToken || (await this.getManagementToken()).access_token;

      let observable = this.httpService.get(`https://${auth0Domain}/api/v2/users`, {
        headers: {
          Authorization: `Bearer ${access_token}`,
        },
        params: { search_engine: 'v3', ...params },
      });

      if (failIfEmpty) {
        observable = observable.pipe(
          RxjsHelper.throwErrorIf(({ data }) => data?.length === 0, 'No results found'),
          RxjsHelper.retryWithDelay(600, 5),
        );
      }

      return observable.toPromise().then((res) => {
        this.loggerService.debug(res.data, `Get users with fulfill query: ${JSON.stringify(params)}`);

        return res.data as IAuth0UserObject[];
      });
    } catch (e) {
      this.loggerService.debug(e, 'getAuth0Users get() error');
      throw new AuthenticationError(e);
    }
  }

  public async updateAuth0User(
    auth0UserIdentifier: IUpdateAuth0UserIdentifier,
    userData: IAuth0UserObject,
  ): Promise<any> {
    const auth0Domain = this.configService.get<string>('AUTH0_DOMAIN');
    const { access_token: accessToken } = await this.getManagementToken();

    try {
      let auth0UserId = auth0UserIdentifier?.user_id;
      if (!auth0UserId) {
        const authUsersData = await this.getAuth0Users(
          { q: `email:"${auth0UserIdentifier.email?.toLowerCase()}"` },
          accessToken,
          true,
        );

        const [auth0User] = authUsersData;
        if (auth0User?.user_id === undefined) throw new BadRequestError('Auth0 user not found');
        auth0UserId = auth0User.user_id;
      }

      return this.httpService
        .patch(`https://${auth0Domain}/api/v2/users/${auth0UserId}`, userData, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        })
        .toPromise();
    } catch (e) {
      this.loggerService.debug(e, `Failed to update user with identifier: ${JSON.stringify(auth0UserIdentifier)}`);
      throw new BadRequestError(e);
    }
  }
}
