import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { AnonymousPassportStrategy } from './anonymousPassport.strategy';

@Injectable()
export class AnonymousStrategy extends PassportStrategy(AnonymousPassportStrategy, 'anonymous') {
  constructor() {
    super();
  }

  async validate(): Promise<any> {
    return this.success({});
  }
}
