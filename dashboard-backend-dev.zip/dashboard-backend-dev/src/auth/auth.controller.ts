import { Body, Controller, Get, HttpCode, Post, Req, UseFilters, UseGuards, UseInterceptors } from '@nestjs/common';
import { LoginDto } from './dto/login.dto';
import { AuthService } from './auth.service';
import { InputSignupDto } from './dto/signup.dto';
import { ForgotDto } from './dto/forgot.dto';
import { RefreshTokenDto } from './dto/refreshToken.dto';
import { Request } from 'express';
import { AbstractController } from '../shared/controller';
import { ConfigService } from '@nestjs/config';
import { AuthenticatedUserSubject } from './subject/authenticatedUser.subject';
import { AuthenticationTokensSubject } from './subject/authenticationTokens.subject';
import { TransformInterceptor } from '../shared/interceptors/transform.interceptor';
import { Auth0ExceptionFilter } from '../shared/filters/auth0Exception.filter';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiExtraModels, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { ApiFailedHttpResponse } from '../shared/decorators/apiFailedHttpResponse.decorator';
import { ApiDataObjectResponse } from '../shared/decorators/dataResponse.decorator';
import { errorSchemaResponse } from '../shared/decorators/errorSchemaResponse';
import { CurrentAuthUser } from './currentAuthUser.decorator';
import { AuthTokenSubEnum } from './authTokenSub.enum';
import { Auth0SocialUserInterface } from '../shared/types/authenticatedUser.interface';
import { ApiHeaderAcceptedLanguage } from '../shared/decorators/apiHeaderAcceptedLanguage.decorator';
import { InitiateOTPDto } from './dto/initiateOTP.dto';
import { CreateOTPDto } from './dto/createOTP.dto';
import { AcceptedLanguage } from 'src/shared';
import { UsersService } from 'src/users/users.service';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { UtmObjectDto } from 'src/auth/dto/utm.dto';
import { ResendVerifyDto, VerifyDto } from 'src/auth/dto/verify.dto';
import { CommonApiQueries } from 'src/shared/decorators/combinedDecorators.decorator';
import { FinqAdminGuard } from 'src/shared/guards/finqAdmin.guard';
import { RecaptchaGuard } from 'src/shared/guards/recaptcha.guard';
import { ApiRecaptchaHeaders } from 'src/shared/decorators/apiRecaptchaHeaders.decorator';
import { CookiesInterceptor } from '../shared/interceptors/cookies.interceptor';
import { SESSION_COOKIE_NAME } from '../shared/modules/analytics/analytics.constants';
import { getSessionId } from '../shared/helpers/cookies.helper';
import { AnalyticsService } from '../shared/modules/analytics/analytics.service';
import { AnonymousLocalJwtAuthGuard } from 'src/shared/guards/anonymousLocalJwtAuth.guard';
import { Users } from 'src/entities/Users';

@ApiTags('Auth')
@Controller('v1/auth')
@UseFilters(Auth0ExceptionFilter)
@ApiExtraModels(AuthenticatedUserSubject)
export class AuthController extends AbstractController {
  constructor(
    private readonly authService: AuthService,
    protected readonly configService: ConfigService,
    private readonly usersService: UsersService,
    private readonly analyticsService: AnalyticsService,
    private readonly loggerService: LoggerService,
  ) {
    super(configService);
  }

  @Post('login')
  @HttpCode(200)
  @ApiOperation({ summary: 'Authorize user by email & password credentials' })
  @ApiRecaptchaHeaders()
  @ApiDataObjectResponse(
    AuthenticatedUserSubject,
    'Authenticated User data including access token, refresh token and expiration',
  )
  @ApiResponse({ status: 403, description: 'Forbidden.', schema: errorSchemaResponse })
  @UseGuards(RecaptchaGuard)
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  public async login(@Body() loginDto: LoginDto, @Req() req: Request) {
    const { userSession, setCookies } = await this.analyticsService.configureSession(req);

    const data = await this.authService.login(req, loginDto);
    const resUser = await this.usersService.getFullUserDetails(data);

    await this.analyticsService.updateSessionWithUser(userSession.sessionId, resUser.id);

    return { ...this.transformToObject(resUser, AuthenticatedUserSubject), setCookies };
  }

  @Post('signup')
  @HttpCode(200)
  @ApiOperation({ summary: 'Signup a user with email & password' })
  @ApiRecaptchaHeaders()
  @ApiResponse({ status: 403, description: 'Forbidden.', schema: errorSchemaResponse })
  @ApiResponse({ status: 409, description: 'User already exists in the db', schema: errorSchemaResponse })
  @ApiHeaderAcceptedLanguage()
  @UseGuards(RecaptchaGuard)
  @UseInterceptors(TransformInterceptor, CookiesInterceptor)
  @ApiFailedHttpResponse()
  public async signup(
    @Body() signupDto: InputSignupDto,
    @Req() req: Request,
    @AcceptedLanguage() defaultLanguage: string,
  ) {
    const sessionConfigurationStartTime = new Date().getTime();
    const { userSession, setCookies } = await this.analyticsService.configureSession(req);
    const sessionConfigurationEndTime = new Date().getTime();
    this.loggerService.log(
      `Signup::Configure Session(${signupDto.email}): ${sessionConfigurationEndTime - sessionConfigurationStartTime}ms`,
    );

    const authServiceStartTime = new Date().getTime();
    const data = await this.authService.signup(req, { ...signupDto, defaultLanguage });
    const authServiceEndTime = new Date().getTime();
    this.loggerService.log(
      `Signup::authService.signup(${signupDto.email}): ${authServiceEndTime - authServiceStartTime}ms`,
    );

    const updateSessionWithUserStartTime = new Date().getTime();
    await this.analyticsService.updateSessionWithUser(userSession.sessionId, data.id);
    const updateSessionWithUserEndTime = new Date().getTime();
    this.loggerService.log(
      `Signup::updateSessionWithUser(${signupDto.email}): ${
        updateSessionWithUserEndTime - updateSessionWithUserStartTime
      }ms`,
    );

    return { id: data.id, setCookies };
  }

  @Post('verify')
  @HttpCode(200)
  @CommonApiQueries({ summary: 'Verify user after signup via code' })
  @ApiRecaptchaHeaders()
  @ApiDataObjectResponse(
    AuthenticatedUserSubject,
    'Authenticated User data including access token, refresh token and expiration',
  )
  @ApiHeaderAcceptedLanguage()
  @UseGuards(RecaptchaGuard, AnonymousLocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  public async validateVerificationCode(
    @CurrentAuthUser(AuthTokenSubEnum.Auth0) authUserPayload: Auth0SocialUserInterface,
    @Body() verifyDto: VerifyDto,
    @Req() req: Request,
  ) {
    const { verifyData } = await this.authService.verifyUser(verifyDto, authUserPayload);

    let loggedInUser: Users = null;
    let sessionSetCookies: any = null;

    if (verifyData.password) {
      loggedInUser = await this.authService.login(req, verifyData);
    } else if (authUserPayload.user) {
      const { userSession, setCookies } = await this.analyticsService.configureSession(req, authUserPayload);
      const auth0UserInfo = await this.authService.getUserInfo(authUserPayload.accessToken);

      loggedInUser = await this.authService.createOrUpdateSocialUser({
        userInfo: auth0UserInfo,
        auth0User: authUserPayload,
        utm: {} as any,
        req,
      });

      await this.analyticsService.updateSessionWithUser(userSession.sessionId, loggedInUser.id);

      sessionSetCookies = setCookies;
    }

    const resUser = await this.usersService.getFullUserDetails(loggedInUser);

    return { ...this.transformToObject(resUser, AuthenticatedUserSubject), setCookies: sessionSetCookies };
  }

  // Resend verification code
  @Post('resend-verification')
  @HttpCode(200)
  @CommonApiQueries({ summary: 'Resend verification code to the user' })
  @ApiDataObjectResponse(
    AuthenticatedUserSubject,
    'Authenticated User data including access token, refresh token and expiration',
  )
  @ApiRecaptchaHeaders()
  @ApiHeaderAcceptedLanguage()
  @UseGuards(RecaptchaGuard)
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  public async resendVerificationCode(
    @Body() verifyDto: ResendVerifyDto,
    @Req() req: Request,
    @AcceptedLanguage() defaultLanguage: string,
  ) {
    return this.authService.resendVerificationEmail(req, verifyDto);
  }

  @Post('otp')
  @HttpCode(200)
  @ApiOperation({ summary: 'Initiate passwordless login via email and code' })
  @ApiResponse({ status: 200, description: 'Email with code should have been sent to the email' })
  @ApiResponse({ status: 409, description: 'User already exists in the db', schema: errorSchemaResponse })
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  public async initiatePasswordlessLogin(@Body() initiateOTPDto: InitiateOTPDto, @Req() req: Request) {
    await this.authService.initiateOtp(req.ip, initiateOTPDto.email);

    return {};
  }

  @Post('otp/token')
  @HttpCode(200)
  @ApiOperation({ summary: 'Create or retrieve user via passwordless login' })
  @ApiDataObjectResponse(
    AuthenticatedUserSubject,
    'Authenticated User data including access token, refresh token and expiration',
  )
  @ApiResponse({ status: 403, description: 'Forbidden.', schema: errorSchemaResponse })
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  public async signUpOrLoginByToken(@Body() createOTPDto: CreateOTPDto) {
    const data = await this.authService.createOrUpdateOTPUser(createOTPDto);

    const resUser = await this.usersService.getFullUserDetails(data);

    return this.transformToObject(resUser, AuthenticatedUserSubject);
  }

  @Post('forgotpassword')
  @HttpCode(200)
  @ApiRecaptchaHeaders()
  @ApiOperation({ summary: 'Sends a reset password via email' })
  @ApiResponse({ status: 200, schema: { properties: { data: { type: 'object' } } } })
  @UseGuards(RecaptchaGuard)
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  public async forgotPassword(@Body() forgotDto: ForgotDto) {
    await this.authService.forgotPassword(forgotDto);

    return {};
  }

  @Post('refreshtoken')
  @HttpCode(200)
  @ApiOperation({ summary: 'Refresh token' })
  @ApiDataObjectResponse(
    AuthenticatedUserSubject,
    'Authenticated User data including access token, refresh token and expiration',
  )
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  @ApiResponse({ status: 403, description: 'Unknown or invalid refresh token.', schema: errorSchemaResponse })
  public async refreshToken(@Body() refreshToken: RefreshTokenDto, @Req() req: Request) {
    const res = await this.authService.refreshToken(req.ip, refreshToken);
    if (res && !res.refresh_token) {
      res.refresh_token = refreshToken.refreshToken;
    }

    return this.transformToObject(res, AuthenticationTokensSubject);
  }

  @Post('social')
  @HttpCode(200)
  @ApiOperation({ summary: 'Social login/signup' })
  @ApiDataObjectResponse(
    AuthenticatedUserSubject,
    'Authenticated User data including access token, refresh token and expiration',
  )
  @ApiBearerAuth()
  @UseInterceptors(TransformInterceptor, CookiesInterceptor)
  @UseGuards(AuthGuard('socialJwt'))
  @ApiResponse({
    status: 403,
    description: 'Required scopes are missing from the request.',
    schema: errorSchemaResponse,
  })
  @ApiFailedHttpResponse()
  public async social(
    @Body() utmDto: UtmObjectDto,
    @CurrentAuthUser(AuthTokenSubEnum.Auth0) authUserPayload: Auth0SocialUserInterface,
    @Req() req: Request,
  ) {
    const { userSession, setCookies } = await this.analyticsService.configureSession(req, authUserPayload);

    const auth0UserInfo = await this.authService.getUserInfo(authUserPayload.accessToken);
    const data = await this.authService.createOrUpdateSocialUser({
      userInfo: auth0UserInfo,
      auth0User: authUserPayload,
      utm: utmDto.utm,
      req,
    });
    const resUser = await this.usersService.getFullUserDetails(data);

    await this.analyticsService.updateSessionWithUser(userSession.sessionId, resUser.id);

    return { ...this.transformToObject(resUser, AuthenticatedUserSubject), setCookies };
  }

  @Get('validate')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Validate access token' })
  @ApiResponse({ status: 200, schema: { properties: { data: { type: 'object' } } } })
  @ApiResponse({ status: 401, description: 'Invalid access token', schema: errorSchemaResponse })
  @UseGuards(AuthGuard(['jwt', 'socialJwt']))
  @UseInterceptors(TransformInterceptor)
  public async validate(): Promise<any> {
    return {};
  }

  @Post('logout')
  @HttpCode(200)
  @ApiOperation({ summary: 'Logout (no need to wait for response. but delete your access token locally)' })
  @ApiResponse({ status: 200 })
  @ApiResponse({ status: 401, description: 'Invalid access token', schema: errorSchemaResponse })
  @UseGuards(AuthGuard(['jwt', 'socialJwt']))
  @UseInterceptors(TransformInterceptor, CookiesInterceptor)
  public async logout(@Req() req: Request) {
    const response = await this.authService.logout(req, req.header('Authorization').replace('Bearer ', ''));

    return {
      ...response,
      clearCookies: [SESSION_COOKIE_NAME],
    };
  }

  @Post('prepare-for-alignment')
  @HttpCode(200)
  @ApiOperation({ summary: 'Get Auth0 Data' })
  @ApiResponse({ status: 200 })
  @ApiResponse({ status: 401, description: 'Invalid access token', schema: errorSchemaResponse })
  @UseGuards(AuthGuard(['jwt', 'socialJwt']), FinqAdminGuard)
  @UseInterceptors(TransformInterceptor)
  public async auth0data(@Req() req: Request) {
    return await this.authService.prepareForAlignment();
  }
}
