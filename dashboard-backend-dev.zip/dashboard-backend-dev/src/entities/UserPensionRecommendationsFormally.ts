import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';
import { Formally } from '../finance/pensions/modules/pensionFormally/types/formally.namespace';

@Index('user_pension_recommendations_formally_pk', ['id'], { unique: true })
@Entity('user_pension_recommendations_formally', { schema: 'public' })
export class UserPensionRecommendationsFormally {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @Column('enum', { name: 'status', nullable: true, enum: Formally.status })
  status: Formally.status | null;

  @Column('uuid', { name: 'process_guid', nullable: false })
  processGuid: string;

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: any;

  @Column('character varying', { name: 'link', nullable: true })
  link: string | null;

  @Column('character varying', { name: 'error_status', nullable: true })
  errorStatus: string | null;

  @Column('character varying', { name: 'error_description', nullable: true })
  errorDescription: string | null;

  @Column('timestamp', { name: 'created_at' })
  createdAt: Date;
}
