import { Column, Entity, Index, PrimaryColumn } from 'typeorm';

@Index('user_investment_risk_analytics_pk', ['userId', 'creationDate'], { unique: true })
@Entity('user_investment_risk_analytics', { schema: 'public' })
export class UserInvestmentRiskAnalytics {
  @PrimaryColumn('character varying', { name: 'user_id', primary: true })
  userId: string;

  @Column('timestamp with time zone', {
    name: 'creation_date',
    default: () => 'now()',
    primary: true,
  })
  creationDate: Date;

  @Column('character varying', { name: 'investments_background', nullable: true })
  investmentsBackground: string;

  @Column('float', { name: 'investments_background_score', nullable: true })
  investmentsBackgroundScore: number;

  @Column('float', { name: 'investments_background_weight', nullable: true })
  investmentsBackgroundWeight: number;

  @Column('float', { name: 'investments_background_weighted_score', nullable: true })
  investmentsBackgroundWeightedScore: number;

  @Column('integer', { name: 'investments_period', nullable: true })
  investmentsPeriod: number;

  @Column('float', { name: 'investments_period_score', nullable: true })
  investmentsPeriodScore: number;

  @Column('float', { name: 'investments_period_weight', nullable: true })
  investmentsPeriodWeight: number;

  @Column('float', { name: 'investments_period_weighted_score', nullable: true })
  investmentsPeriodWeightedScore: number;

  @Column('integer', { name: 'response_strategy', nullable: true })
  responseStrategy: number;

  @Column('float', { name: 'response_strategy_score', nullable: true })
  responseStrategyScore: number;

  @Column('float', { name: 'response_strategy_weight', nullable: true })
  responseStrategyWeight: number;

  @Column('float', { name: 'response_strategy_weighted_score', nullable: true })
  responseStrategyWeightedScore: number;

  @Column('integer', { name: 'risk_tolerance_scenario', nullable: true })
  riskToleranceScenario: number;

  @Column('float', { name: 'risk_tolerance_scenario_score', nullable: true })
  riskToleranceScenarioScore: number;

  @Column('float', { name: 'risk_tolerance_scenario_weight', nullable: true })
  riskToleranceScenarioWeight: number;

  @Column('float', { name: 'risk_tolerance_scenario_weighted_score', nullable: true })
  riskToleranceScenarioWeightedScore: number;

  @Column('float', { name: 'user_investment_risk', nullable: false })
  userInvestmentRisk: number;

  @Column('float', { name: 'user_investment_risk_level', nullable: false })
  userInvestmentRiskLevel: number;
}
