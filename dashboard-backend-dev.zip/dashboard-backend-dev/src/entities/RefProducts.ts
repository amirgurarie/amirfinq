import { Column, Entity, Index, OneToMany } from 'typeorm';
import { RefProductSubscriptionMethods } from 'src/entities/RefProductSubscriptionMethods';

@Index('ref_products_pk', ['id'], { unique: true })
@Entity('ref_products', { schema: 'public' })
export class RefProducts {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string;

  @Column('character varying', { name: 'image_he', nullable: true })
  imageHe: string;

  @Column('character varying', { name: 'image_en', nullable: true })
  imageEn: string;

  @Column('character varying', { name: 'screen_path', nullable: true })
  screenPath: string;

  @Column('smallint', { name: 'display_order', nullable: true })
  displayOrder: number;

  @Column('boolean', { name: 'is_active', nullable: true })
  isActive: boolean;

  @Column('boolean', { name: 'is_tools', nullable: true })
  isTools: boolean;

  @Column('character varying', { name: 'text_he', nullable: true })
  textHe: string;

  @Column('character varying', { name: 'text_en', nullable: true })
  textEn: string;

  @Column('character varying', { name: 'payme_company_code', nullable: true })
  paymeCompanyCode: string;

  @Column('character varying', { name: 'logo', nullable: true })
  logo: string;

  @Column('character varying', { name: 'initial_pricing_plan', nullable: true })
  initialPricingPlan: string;

  @Column('character varying', { name: 'type', nullable: true })
  type: string;

  @Column('character varying', { name: 'stripe_price_id', nullable: true })
  stripePriceId: string;

  @OneToMany(() => RefProductSubscriptionMethods, (type) => type.productId)
  subscriptionMethod: RefProductSubscriptionMethods;
}
