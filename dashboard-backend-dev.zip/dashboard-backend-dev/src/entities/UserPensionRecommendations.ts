import { PensionPortfolio } from 'src/finance/pensions/modules/portfolio/portfolio.namespace';
import { Column, Entity, Index, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionRecommendationBenefits } from './UserPensionRecommendationsBenefits';
import { UserPensionRecommendationTransactions } from './UserPensionRecommendationsTransactions';

@Index('user_pension_recommendations_pk', ['id'], { unique: true })
@Entity('user_pension_recommendations', { schema: 'public' })
export class UserPensionRecommendations {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @Column('uuid', { name: 'request_id', nullable: false })
  requestId: string;

  @Column('character varying', { name: 'title', nullable: true })
  title: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'reason', nullable: true })
  reason: string | null;

  @Column('character varying', { name: 'category', nullable: true })
  category: PensionPortfolio.Categories | null;

  @Column('boolean', { name: 'is_selected', nullable: true })
  isSelected: boolean;

  @Column('timestamp', { name: 'created_at' })
  createdAt: Date;

  @Column('timestamp', { name: 'expired_at' })
  expiredAt: Date;

  @OneToMany(() => UserPensionRecommendationTransactions, (transaction) => transaction.recommendation, {
    cascade: true,
  })
  transactions: UserPensionRecommendationTransactions[];

  @OneToMany(() => UserPensionRecommendationBenefits, (benefit) => benefit.recommendation, {
    cascade: true,
  })
  benefits: UserPensionRecommendationBenefits[];
}
