import { Column, Entity, Index, ManyToOne, OneToMany } from 'typeorm';
import { RefNotificationsTypes } from './RefNotificationsTypes';

@Index('ref_notification_group_pk', ['id'], { unique: true })
@Entity('ref_notification_group', { schema: 'public' })
export class RefNotificationGroup {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @OneToMany(() => RefNotificationsTypes, (type) => type.notificationGroup)
  notification: RefNotificationsTypes;
}
