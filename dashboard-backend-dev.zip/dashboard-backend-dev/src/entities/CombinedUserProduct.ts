import { Column, Entity, ManyToOne, JoinColumn, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { ProductPlan } from './ProductPlan';
import { ProductPlanPricing } from './ProductPlanPricing';
import { Product } from './Products';
import { UserProductPayment } from './UserProductPayment';
import { Users } from 'src/entities';
import { UserPaymentToken } from './UserPaymentToken';

@Entity('combined_user_products', { schema: 'public' })
export class CombinedUserProduct {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('character varying', { name: 'user_id' })
  userId: string;

  @ManyToOne(() => Users, (users) => users.userHubSpotContact)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user?: Users;

  @Column('integer', { name: 'product_plan_id' })
  productPlanId: number;

  @ManyToOne(() => ProductPlan, (productPlan) => productPlan.combinedUserProducts)
  @JoinColumn({ name: 'product_plan_id', referencedColumnName: 'id' })
  productPlan: ProductPlan;

  @Column('integer', { name: 'product_pricing_plan_id' })
  productPricingPlanId: number;

  @ManyToOne(() => ProductPlanPricing, (pricing) => pricing.id)
  @JoinColumn({ name: 'product_pricing_plan_id', referencedColumnName: 'id' })
  productPricingPlan: ProductPlanPricing;

  @Column('character varying', { name: 'price' })
  price: string;

  @Column('character varying', { name: 'currency' })
  currency: string;

  @Column('character varying', { name: 'product_pricing_plan_type' })
  productPricingPlanType: string;

  @Column('character varying', { name: 'sub_external_id' })
  subExternalId: string;

  @Column('date', { name: 'start_date' })
  startDate: Date;

  @Column('date', { name: 'expiry_date' })
  expiryDate: Date;

  @Column('date', { name: 'renewal_date' })
  renewalDate: Date;

  @Column('date', { name: 'trial_end_date' })
  trialEndDate: Date;

  @Column('character varying', { name: 'product_id' })
  productId: string;

  @ManyToOne(() => Product, (product) => product.id)
  @JoinColumn({ name: 'product_id', referencedColumnName: 'id' })
  product: Product;

  @OneToMany((type) => UserProductPayment, (payment) => payment.userProduct)
  payments: UserProductPayment[];

  @ManyToOne(() => UserPaymentToken, (userPaymentToken) => userPaymentToken.combinedUserProducts)
  @JoinColumn({ name: 'user_payment_token_id', referencedColumnName: 'id' })
  userPaymentToken: UserPaymentToken;
}
