import { Column, Entity, ManyToOne, JoinColumn, PrimaryGeneratedColumn, Index } from 'typeorm';
import { ProductPlan } from './ProductPlan';
import { Product } from './Products';
import { ProductPlanPricing } from './ProductPlanPricing';

@Index('product_plans_waiting_list_pk', ['id'], { unique: true })
@Entity('product_plans_waiting_list', { schema: 'public' })
export class ProductPlansWaitingList {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => ProductPlan, (productPlan) => productPlan.productPlansWaitingLists)
  @JoinColumn({ name: 'product_plan_id', referencedColumnName: 'id' })
  productPlan: ProductPlan;

  @ManyToOne(() => Product, (product) => product.id)
  @JoinColumn({ name: 'product_id', referencedColumnName: 'id' })
  product: Product;

  @ManyToOne(() => ProductPlanPricing, (product) => product.id)
  @JoinColumn({ name: 'product_plan_pricing_id', referencedColumnName: 'id' })
  productPlanPricing: ProductPlanPricing;

  @Column('date', { name: 'notification_request_date' })
  notificationRequestDate: Date;

  @Column('character varying', { name: 'email' })
  email: string;
}
