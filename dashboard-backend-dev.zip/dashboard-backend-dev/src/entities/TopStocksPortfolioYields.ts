import { Column, Entity, Index, OneToMany } from 'typeorm';
import { TopStocksTransactions } from './TopStocksTransactions';

@Index('top_stocks_portfolio_yields_pk', ['portfolioId', 'yieldPeriod', 'yieldDate'], { unique: true })
@Entity('top_stocks_portfolio_yields', { schema: 'public' })
export class TopStocksPortfolioYields {
  @Column('character varying', { name: 'portfolio_id', primary: true })
  portfolioId: string;

  @Column('character varying', { name: 'yield_period', primary: true })
  yieldPeriod: string;

  @Column('double precision', { name: 'yield', nullable: true, precision: 53 })
  yield: number | null;

  @Column('double precision', { name: 'yield_date', nullable: true, primary: true })
  yieldDate: Date | null;

  @Column('double precision', { name: 'portfolio_value', nullable: true, precision: 53 })
  portfolioValue: number | null;

  @Column('double precision', { name: 'accumulated_yield', nullable: true, precision: 53 })
  accumulatedYield: number | null;

  @OneToMany(() => TopStocksTransactions, (type) => type.portfolioYield)
  portfolioTransactions: TopStocksTransactions[];
}
