import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Users } from './Users';

@Index('user_stage_pk', ['id'], { unique: true })
@Entity('user_stages', { schema: 'public' })
export class UserStages {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'stage', nullable: true })
  stage: string | null;

  @Column('timestamp with time zone', { name: 'created_date', nullable: true })
  createdDate: Date | null;

  @ManyToOne(() => Users, (users) => users.userStages)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
