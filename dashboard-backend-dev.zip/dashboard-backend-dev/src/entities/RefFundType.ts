import { Column, Entity, Index } from 'typeorm';

@Index('ref_fund_type_pk', ['id'], { unique: true })
@Entity('ref_fund_type', { schema: 'public' })
export class RefFundType {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('integer', { name: 'ui_order', nullable: true })
  uiOrder: number;

  @Column('character varying', { name: 'image_path', nullable: true })
  imagePath: string;

  @Column('character varying', { name: 'text_en', nullable: true })
  textEn: string | null;

  @Column('character varying', { name: 'text_he', nullable: true })
  textHe: string | null;
}
