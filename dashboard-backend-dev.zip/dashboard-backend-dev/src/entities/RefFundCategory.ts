import { Column, Entity } from 'typeorm';

@Entity('ref_fund_category', { schema: 'public' })
export class RefFundCategory {
  @Column('integer', { primary: true, name: 'id', nullable: true })
  id: number | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;
}
