import { Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { BaseEventEntity } from './BaseEventEntity';
import { UserSpouseDetails } from './UserSpouseDetails';

@Index('user_spouse_events_pk', ['id'], { unique: true })
@Entity('user_spouse_events', { schema: 'public' })
export class UserSpouseEvent extends BaseEventEntity {
  @ManyToOne(() => UserSpouseDetails, (user) => user.userSpouseEvents)
  @JoinColumn([{ name: 'spouse_id', referencedColumnName: 'id' }])
  spouseDetails?: UserSpouseDetails;
}
