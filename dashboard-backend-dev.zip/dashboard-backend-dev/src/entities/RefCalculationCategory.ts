import { Column, Entity } from 'typeorm';

@Entity('ref_calculation_category', { schema: 'public' })
export class RefCalculationCategory {
  @Column('character varying', { primary: true, name: 'code' })
  code: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;
}
