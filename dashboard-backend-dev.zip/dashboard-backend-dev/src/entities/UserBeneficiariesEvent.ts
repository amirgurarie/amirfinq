import { Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { BaseEventEntity } from './BaseEventEntity';
import { UserBeneficiariesDetails } from './UserBeneficiariesDetails';

@Index('user_beneficiaries_events_pk', ['id'], { unique: true })
@Entity('user_beneficiaries_events', { schema: 'public' })
export class UserBeneficiariesEvent extends BaseEventEntity {
  @ManyToOne(() => UserBeneficiariesDetails, (user) => user.userBeneficiariesEvents)
  @JoinColumn([{ name: 'beneficiaries_id', referencedColumnName: 'id' }])
  beneficiariesDetails?: UserBeneficiariesDetails;
}
