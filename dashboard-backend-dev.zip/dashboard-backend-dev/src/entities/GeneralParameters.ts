import { Column, Entity, Index, OneToMany } from 'typeorm';
import { StocksRanking } from './StocksRanking';
import { TopStocksTransactions } from './TopStocksTransactions';

@Index('ref_parameters_pk', ['id', 'stockRankingDate'], { unique: true })
@Entity('general_parameters', { schema: 'public' })
export class GeneralParameters {
  @Column('timestamp with time zone', { name: 'fund_batch_run_date', nullable: true })
  fundBatchRunDate: Date | null;

  @Column('smallint', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'currency', nullable: true })
  currency: string | null;

  @Column('boolean', { name: 'local_trade', nullable: true })
  localTrade: boolean | null;

  @Column('real', { name: 'profile_risk_decrease', nullable: true })
  profileRiskDecrease: number | null;

  @Column('double precision', { name: 'alerts_monthly_price', nullable: true, precision: 53 })
  alertsMonthlyPrice: number | null;

  @Column('double precision', { name: 'alerts_yearly_price', nullable: true, precision: 53 })
  alertsYearlyPrice: number | null;

  @Column('double precision', { name: 'full_management_price', nullable: true, precision: 53 })
  fullManagementPrice: number | null;

  @Column('double precision', { name: 'stock_portfolio_amount', nullable: true, precision: 53 })
  stockPortfolioAmount: number | null;

  @Column('date', { name: 'stock_ranking_date', nullable: true, primary: true })
  stockRankingDate: Date;

  @Column('timestamp with time zone', { name: 'stock_ranking_date_time', nullable: true })
  stockRankingDateTime: Date;

  @Column('date', { name: 'stock_ranking_yield_date', nullable: true })
  stockRankingYieldDate: Date;

  @Column('timestamp with time zone', { name: 'stock_ranking_yield_date_time', nullable: true })
  stockRankingYieldDateTime: Date;

  @Column('timestamp with time zone', { name: 'asset_realtime_update_time', nullable: true })
  assetRealtimeUpdateTime: Date;

  @Column('integer', { name: 'asset_realtime_interval', nullable: true })
  assetRealtimeInterval: number;

  @Column('character varying', { name: 'pension_holdings_quarter', nullable: true })
  pensionHoldingsQuarter?: string | null;

  @OneToMany(() => StocksRanking, (type) => type.generalParameters)
  stocksRanking: StocksRanking[];

  @OneToMany(() => TopStocksTransactions, (type) => type.generalParameters)
  topStocksTransactions: TopStocksTransactions[];
}
