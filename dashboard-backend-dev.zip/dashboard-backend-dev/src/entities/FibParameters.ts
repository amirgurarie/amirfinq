import { Column, Entity, Index } from 'typeorm';

@Index('fib_parameters_pk', ['id'], { unique: true })
@Entity('fib_parameters', { schema: 'public' })
export class FibParameters {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'calculation_method', nullable: true })
  calculationMethod: string | null;

  @Column('real', { name: 'fib_weight', nullable: true, precision: 24 })
  fibWeight: number | null;

  @Column('character varying', { name: 'fib_type', nullable: true })
  fibType: string | null;

  @Column('real', { name: 'min_range', nullable: true, precision: 24 })
  minRange: number | null;

  @Column('real', { name: 'max_range', nullable: true, precision: 24 })
  maxRange: number | null;

  @Column('boolean', { name: 'active', nullable: true })
  active: boolean | null;

  @Column('character varying', { name: 'general_param', nullable: true })
  generalParam: string | null;

  @Column('character varying', { name: 'purity_type', nullable: true })
  purityType: string | null;
}
