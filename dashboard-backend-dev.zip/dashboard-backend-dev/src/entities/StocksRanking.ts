import { AssetsHistory } from './AssetsHistory';
import { GeneralParameters } from './GeneralParameters';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToOne, PrimaryColumn } from 'typeorm';
import { Assets } from './Assets';
import { RefStockRating } from './RefStockRating';

@Index('stocks_ranking_pk', ['assetId', 'rankDate'])
@Entity('stocks_ranking', { schema: 'public' })
export class StocksRanking {
  @PrimaryColumn('character varying', { name: 'asset_id', primary: true })
  assetId: string;

  @Column('date', { name: 'rank_date', primary: true })
  rankDate: Date;

  @Column('double precision', { name: 'asset_rank', nullable: true })
  assetRank: number | null;

  @Column('integer', { name: 'asset_order', nullable: true })
  assetOrder: number | null;

  @Column('double precision', { name: 'rank_professional', nullable: true })
  rankProfessional: number | null;

  @Column('double precision', { name: 'rank_crowed_wisdom', nullable: true })
  rankCrowedWisdom: number | null;

  @Column('double precision', { name: 'rank_fundamentals', nullable: true })
  rankFundamentals: number | null;

  @Column('double precision', { name: 'rank_professional_score', nullable: true })
  rankProfessionalScore: number | null;

  @Column('double precision', { name: 'rank_crowed_wisdom_score', nullable: true })
  rankCrowedWisdomScore: number | null;

  @Column('double precision', { name: 'rank_fundamentals_score', nullable: true })
  rankFundamentalsScore: number | null;

  @Column('boolean', { name: 'is_public', nullable: true })
  isPublic: boolean | null;

  @OneToOne(() => AssetsHistory, (assetsHistory) => assetsHistory.stocksRanking)
  assetsHistory: AssetsHistory | AssetsHistory[];

  @ManyToOne(() => Assets, (asset) => asset.stocksRanking)
  @JoinColumn([{ name: 'asset_id', referencedColumnName: 'id' }])
  assets: Assets;

  @ManyToOne(() => GeneralParameters, (type) => type.stocksRanking)
  @JoinColumn([{ name: 'rank_date', referencedColumnName: 'stockRankingDate' }])
  generalParameters: GeneralParameters;

  // Keep this here, used for leftJoinAndMapOne
  rating: RefStockRating;

  momentum: number;
}
