import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { RefDistributionGroup } from './RefDistributionGroup';
import { Funds } from './Funds';

@Index('fund_items_distribution_pk', ['id'], { unique: true })
@Entity('fund_items_distribution', { schema: 'public' })
export class FundItemsDistribution {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'item_code', nullable: true })
  itemCode: string | null;

  @Column('double precision', {
    name: 'item_percentage',
    nullable: true,
    precision: 53,
  })
  itemPercentage: number | null;

  @ManyToOne(() => RefDistributionGroup, (refDistributionGroup) => refDistributionGroup.fundItemsDistributions)
  @JoinColumn([{ name: 'distribution_group', referencedColumnName: 'id' }])
  distributionGroup: RefDistributionGroup;

  @ManyToOne(() => Funds, (funds) => funds.fundItemsDistributions)
  @JoinColumn([{ name: 'fund_id', referencedColumnName: 'id' }])
  fund: Funds;
}
