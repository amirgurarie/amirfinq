import { RefProducts } from 'src/entities/RefProducts';
import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';

@Index('ref_product_subscription_methods_pk', ['productId', 'frequency', 'market'], { unique: true })
@Entity('ref_product_subscription_methods', { schema: 'public' })
export class RefProductSubscriptionMethods {
  @Column('character varying', { primary: true, name: 'product_id' })
  productId: string;

  @Column('character varying', { primary: true, name: 'frequency' })
  frequency: string;

  @Column('character varying', { primary: true, name: 'market' })
  market: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('double precision', { name: 'price', nullable: true, precision: 53 })
  price: number | null;

  @Column('character varying', { name: 'stripe_price_id', nullable: true })
  stripePriceId: string | null;

  @Column('character varying', { name: 'payme_company_code', nullable: true })
  paymeCompanyCode: string | null;

  @ManyToOne(() => RefProducts, (type) => type.id)
  @JoinColumn([{ name: 'product_id', referencedColumnName: 'id' }])
  product: RefProducts;
}
