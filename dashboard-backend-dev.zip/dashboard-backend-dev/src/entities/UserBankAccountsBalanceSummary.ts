import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { Users } from './Users';

@Index('user_bank_accounts_balance_summary_pk', ['externalId'], {
  unique: true,
})
@Entity('user_bank_accounts_balance_summary', { schema: 'public' })
export class UserBankAccountBalanceSummary {
  @Column('integer', { primary: true, name: 'external_id', nullable: true })
  externalId: number | null;

  @Column('character varying', { name: 'status', nullable: true })
  status: string | null;

  @Column('double precision', { name: 'yield', nullable: true, precision: 53 })
  yield?: number | null;

  @Column('double precision', {
    name: 'yield_ytd',
    nullable: true,
    precision: 53,
  })
  yieldYtd?: number | null;

  @Column('double precision', { name: 'profit', nullable: true, precision: 53 })
  profit?: number | null;

  @Column('double precision', {
    name: 'profit_ytd',
    nullable: true,
    precision: 53,
  })
  profitYtd?: number | null;

  @ManyToOne(() => Users, (users) => users.userBankAccountsBalancesSummaries)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
