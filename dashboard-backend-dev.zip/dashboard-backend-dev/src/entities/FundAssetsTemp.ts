import { Column, Entity } from 'typeorm';

@Entity('fund_assets_temp', { schema: 'public' })
export class FundAssetsTemp {
  @Column('integer', { primary: true, name: 'id', nullable: true })
  id: number | null;

  @Column('character varying', { name: 'fund_id', nullable: true })
  fundId: string | null;

  @Column('character varying', { name: 'asset_id', nullable: true })
  assetId: string | null;

  @Column('double precision', {
    name: 'asset_percentage',
    nullable: true,
    precision: 53,
  })
  assetPercentage: number | null;

  @Column('double precision', {
    name: 'turnover',
    nullable: true,
    precision: 53,
  })
  turnover: number | null;
}
