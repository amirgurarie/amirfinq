import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { RefBanks } from './RefBanks';
import { RefBankBranches } from './RefBankBranches';
import { Users } from './Users';
import { UserBankAccountPartners } from './UserBankAccountPartners';
import { RefBankAccountTypes } from './RefBankAccountTypes';

@Index('user_bank_accounts_pk', ['id'], { unique: true })
@Entity('user_bank_accounts', { schema: 'public' })
export class UserBankAccounts {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'account', nullable: true })
  account: string | null;

  @Column('boolean', { name: 'power_of_attorney', nullable: true })
  powerOfAttorney: boolean | null;

  @OneToMany(() => UserBankAccountPartners, (userBankAccountPartners) => userBankAccountPartners.bankAccount)
  userBankAccountPartners: UserBankAccountPartners[];

  @ManyToOne(() => RefBankAccountTypes, (refBankAccountTypes) => refBankAccountTypes.userBankAccounts)
  @JoinColumn([{ name: 'account_type', referencedColumnName: 'id' }])
  accountType: RefBankAccountTypes;

  @ManyToOne(() => RefBanks, (refBanks) => refBanks.userBankAccounts)
  @JoinColumn([{ name: 'bank_number', referencedColumnName: 'id' }])
  bank: RefBanks;

  @ManyToOne(() => RefBankBranches, (refBankBranches) => refBankBranches.userBankAccounts)
  @JoinColumn([{ name: 'branch', referencedColumnName: 'id' }])
  branch: RefBankBranches;

  @ManyToOne(() => Users, (users) => users.userBankAccounts)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
