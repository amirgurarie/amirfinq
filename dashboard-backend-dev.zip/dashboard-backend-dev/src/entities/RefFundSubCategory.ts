import { Column, Entity, Index } from 'typeorm';

@Index('ref_fund_sub_category_pk', ['id'], { unique: true })
@Entity('ref_fund_sub_category', { schema: 'public' })
export class RefFundSubCategory {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;
}
