import { Column, Entity, Index } from 'typeorm';

@Index('ref_address_pk1', ['id'], { unique: true })
@Entity('ref_address', { schema: 'public' })
export class RefAddress {
  @Column('bigint', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'city_name', nullable: true })
  cityName: string | null;

  @Column('character varying', { name: 'city_name_en', nullable: true })
  cityNameEn: string | null;

  @Column('character varying', { name: 'street_name', nullable: true })
  streetName: string | null;

  @Column('character varying', { name: 'street_name_en', nullable: true })
  streetNameEn: string | null;

  @Column('bigint', { name: 'index_reference', nullable: true })
  indexReference: string | null;

  @Column('bigint', { name: 'city_num', nullable: true })
  cityNum: string | null;
}
