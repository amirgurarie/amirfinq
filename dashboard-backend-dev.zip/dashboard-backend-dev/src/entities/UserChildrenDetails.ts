import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { UserChildrenEvent } from './UserChildrenEvent';
import { UserDetails } from './UserDetails';

@Index('user_children_details_pk', ['userId', 'idNumber'], { unique: true })
@Entity('user_children_details', { schema: 'public' })
export class UserChildrenDetails {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('uuid', { name: 'user_id' })
  userId: string;

  @Column('character varying', { name: 'first_name' })
  firstName: string;

  @Column('character varying', { name: 'last_name' })
  lastName: string;

  @Column('character varying', { name: 'gender_by_identity_card', nullable: true })
  gender: string;

  @Column('date', { name: 'date_of_birth', nullable: true })
  dateOfBirth: Date | null;

  @Column('character varying', { name: 'id_card_number', unique: true, nullable: true })
  idNumber: string | null;

  @Column('bool', { name: 'disability' })
  disability: boolean;

  @Column('date', { name: 'disability_recognition_date' })
  disabilityRecognitionDate: Date | null;

  @ManyToOne(() => UserDetails, (user) => user.children)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails: UserDetails;

  @OneToMany(() => UserChildrenEvent, (userEvent) => userEvent.childrenDetails)
  childrenEvents: UserChildrenEvent[];
}
