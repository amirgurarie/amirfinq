import { Column, Entity, Index, JoinColumn, OneToMany, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserDetails } from './UserDetails';
import { UserBeneficiariesEvent } from './UserBeneficiariesEvent';

@Index('user_beneficiaries_details_pkey', ['userId', 'idNumber'], { unique: true })
@Entity('user_beneficiaries_details', { schema: 'public' })
export class UserBeneficiariesDetails {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('uuid', { name: 'user_id' })
  userId: string;

  @Column('character varying', { name: 'first_name' })
  firstName: string;

  @Column('character varying', { name: 'last_name' })
  lastName: string;

  @Column('character varying', { name: 'gender' })
  gender: string;

  @Column('character varying', { name: 'beneficiary_relation', nullable: true })
  beneficiaryRelation: string;

  @Column('date', { name: 'date_of_birth' })
  dateOfBirth: Date;

  @Column('character varying', { name: 'id_card_number' })
  idNumber: string;

  @Column('character varying', { name: 'phone_number', nullable: true, length: 20 })
  phoneNumber: string | null;

  @Column('character varying', { name: 'address', nullable: true })
  address: string | null;

  @Column('float', { name: 'beneficiary_percentage', nullable: true })
  beneficiaryPercentage: number | null;

  @Column('character varying', { name: 'phone_number_country_code', nullable: true, length: 20 })
  phoneNumberCountryCode: string | null;

  @OneToOne(() => UserDetails, (user) => user.spouse)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails?: UserDetails;

  @OneToMany(() => UserBeneficiariesEvent, (userBeneficiariesDetails) => userBeneficiariesDetails.beneficiariesDetails)
  userBeneficiariesEvents: UserBeneficiariesEvent[];
}
