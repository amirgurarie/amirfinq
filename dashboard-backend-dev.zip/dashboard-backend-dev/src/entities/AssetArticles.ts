import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { Assets } from './Assets';
import { AssetArticlesSiteLogo } from './AssetArticlesSiteLogo';

@Index('asset_articles_pk', ['url'], { unique: true })
@Entity('asset_articles', { schema: 'public' })
export class AssetArticles {
  @Column('character varying', { name: 'title', nullable: true })
  title: string;

  @Column('character varying', { primary: true, name: 'url' })
  url: string;

  @Column('character varying', { name: 'sentiment', nullable: true })
  sentiment: string;

  @Column('timestamp with time zone', { name: 'article_timestamp', nullable: true })
  articleTimestamp: string;

  @Column('character varying', { name: 'site_name', nullable: true })
  siteName: string;

  @ManyToOne(() => AssetArticlesSiteLogo, (assets) => assets.siteName)
  @JoinColumn([{ name: 'site_name', referencedColumnName: 'siteName' }])
  logo: AssetArticlesSiteLogo | string;

  @ManyToOne(() => Assets, (assets) => assets.symbol)
  @JoinColumn([{ name: 'symbol', referencedColumnName: 'symbol' }])
  asset: string;
}
