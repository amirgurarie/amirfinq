import { Column, Entity, Index, OneToMany, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
import { RefFlowStage } from './RefFlowStage';
import { FlowStage } from 'src/flow-stages/flowStage.namespace';

@Index('ref_flows_pk', ['flowKey'], { unique: true })
@Entity('ref_flows', { schema: 'public' })
export class RefFlow {
  @PrimaryColumn('enum', { name: 'flow_key', enum: FlowStage.FlowKey, unique: true })
  flowKey: string;

  @Column({ name: 'name', nullable: true })
  name: string;

  @Column({ default: true, name: 'is_active' })
  isActive: boolean;

  @Column({ name: 'created_at', type: 'timestamp with time zone', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;

  @Column({ name: 'updated_at', type: 'timestamp with time zone', default: () => 'CURRENT_TIMESTAMP' })
  updatedAt: Date;

  @OneToMany(() => RefFlowStage, (stage) => stage.flow)
  stages: RefFlowStage[];
}
