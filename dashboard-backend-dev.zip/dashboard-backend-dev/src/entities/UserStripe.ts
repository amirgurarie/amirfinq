import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Users } from './Users';

@Index('user_stripe_pk', ['id'], { unique: true })
@Entity('user_stripe', { schema: 'public' })
export class UserStripe {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('timestamp with time zone', { name: 'payment_date', nullable: true })
  paymentDate: string | Date;

  @Column('character varying', { name: 'payment_id' })
  paymentId: string;

  @Column('integer', { name: 'amount_received', nullable: true })
  amountReceived: number;

  @Column('character varying', { name: 'currency', nullable: true })
  currency: string;

  @Column('character varying', { name: 'customer', nullable: true })
  customer: string;

  @Column('character varying', { name: 'invoice', nullable: true })
  invoice: string;

  @Column('character varying', { name: 'payment_status', nullable: true })
  paymentStatus: string;

  @Column('character varying', { name: 'product_code', nullable: true })
  productCode: string;

  @Column('character varying', { name: 'error_text', nullable: false })
  errorText: string;

  @Column('character varying', { name: 'user_id', nullable: false })
  userId: string;

  @ManyToOne(() => Users, (users) => users.userStripe)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
