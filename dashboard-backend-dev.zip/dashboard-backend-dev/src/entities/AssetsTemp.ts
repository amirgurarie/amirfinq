import { Column, Entity } from 'typeorm';

@Entity('assets_temp', { schema: 'public' })
export class AssetsTemp {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'asset_type', nullable: true })
  assetType: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('double precision', {
    name: 'current_price',
    nullable: true,
    precision: 53,
  })
  currentPrice: number | null;

  @Column('double precision', { name: 'yield', nullable: true, precision: 53 })
  yield: number | null;

  @Column('integer', { name: 'currency', nullable: true })
  currency: number | null;

  @Column('character varying', { name: 'asset_linkage', nullable: true })
  assetLinkage: string | null;

  @Column('double precision', {
    name: 'duration',
    nullable: true,
    precision: 53,
  })
  duration: number | null;

  @Column('character varying', { name: 'sector', nullable: true })
  sector: string | null;

  @Column('character varying', { name: 'trade_location', nullable: true })
  tradeLocation: string | null;

  @Column('character varying', { name: 'asset_issuer', nullable: true })
  assetIssuer: string | null;

  @Column('double precision', { name: 'pe', nullable: true, precision: 53 })
  pe: number | null;

  @Column('double precision', { name: 'pb', nullable: true, precision: 53 })
  pb: number | null;

  @Column('double precision', { name: 'ps', nullable: true, precision: 53 })
  ps: number | null;

  @Column('double precision', {
    name: 'esg_score',
    nullable: true,
    precision: 53,
  })
  esgScore: number | null;

  @Column('double precision', {
    name: 'yield_month12',
    nullable: true,
    precision: 53,
  })
  yieldMonth12: number | null;

  @Column('character varying', { name: 'none_grade_bond', nullable: true })
  noneGradeBond: string | null;
}
