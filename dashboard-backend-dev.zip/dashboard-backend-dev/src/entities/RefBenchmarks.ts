import { Column, Entity, Index } from 'typeorm';

@Index('ref_benchmarks_pk', ['id'], { unique: true })
@Entity('ref_benchmarks', { schema: 'public' })
export class RefBenchmarks {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'sector', nullable: true })
  sector: string | null;

  @Column('character varying', { name: 'asset_type', nullable: true })
  assetType: string | null;

  @Column('character varying', { name: 'trade_location', nullable: true })
  tradeLocation: string | null;
}
