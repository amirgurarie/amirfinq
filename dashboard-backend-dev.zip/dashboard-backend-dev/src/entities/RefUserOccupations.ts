import { Column, Entity, Index, OneToMany } from 'typeorm';
import { Users } from './Users';

@Index('ref_user_occupations_pk', ['id'], { unique: true })
@Entity('ref_user_occupations', { schema: 'public' })
export class RefUserOccupations {
  @Column('bigint', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @OneToMany(() => Users, (users) => users.occupation)
  users: Users[];
}
