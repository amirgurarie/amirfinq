import { Column, Entity, Index } from 'typeorm';

@Index('fib_funds_statistics_parameters_pk', ['id'], { unique: true })
@Entity('fib_funds_statistics_parameters', { schema: 'public' })
export class FibFundsStatisticsParameters {
  @Column('smallint', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'statistics_type', nullable: true })
  statisticsType: string | null;

  @Column('character varying', { name: 'param', nullable: true })
  param: string | null;
}
