import { Column, Entity, Index, OneToMany } from 'typeorm';
import { Assets } from './Assets';
import { RefBizportalTradingPlace } from './RefBizportalTradingPlace';

@Index('ref_trade_locations_pk', ['id'], { unique: true })
@Entity('ref_trade_locations', { schema: 'public' })
export class RefTradeLocations {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @OneToMany(() => Assets, (assets) => assets.tradeLocation)
  assets: Assets[];

  @OneToMany(() => RefBizportalTradingPlace, (refBizportalTradingPlace) => refBizportalTradingPlace.tradingPlace)
  refBizportalTradingPlaces: RefBizportalTradingPlace[];
}
