import { Column, Entity, Index } from 'typeorm';

@Index('fib_calculation_mci_index_pk', ['entityCode'], { unique: true })
@Entity('fib_calculation_mci_index', { schema: 'public' })
export class FibCalculationMciIndex {
  @Column('character varying', { primary: true, name: 'entity_code' })
  entityCode: string;

  @Column('real', { name: 'entity_percent', nullable: true, precision: 24 })
  entityPercent: number | null;

  @Column('character varying', { name: 'entity_type', nullable: true })
  entityType: string | null;

  @Column('real', { name: 'entity_weight', nullable: true, precision: 24 })
  entityWeight: number | null;
}
