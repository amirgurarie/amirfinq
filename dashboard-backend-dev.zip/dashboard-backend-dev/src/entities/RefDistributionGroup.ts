import { Column, Entity, Index, OneToMany } from 'typeorm';
import { FundItemsDistribution } from './FundItemsDistribution';

@Index('ref_distribution_group_pk', ['id'], { unique: true })
@Entity('ref_distribution_group', { schema: 'public' })
export class RefDistributionGroup {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @OneToMany(() => FundItemsDistribution, (fundItemsDistribution) => fundItemsDistribution.distributionGroup)
  fundItemsDistributions: FundItemsDistribution[];
}
