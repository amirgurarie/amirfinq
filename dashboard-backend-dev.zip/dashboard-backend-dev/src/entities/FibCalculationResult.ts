import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('fib_calculation_result_pkey', ['id'], { unique: true })
@Entity('fib_calculation_result', { schema: 'public' })
export class FibCalculationResult {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('timestamp with time zone', {
    name: 'run_date',
    default: () => 'now()',
  })
  runDate: Date;

  @Column('character varying', { name: 'finq_category', nullable: true })
  finqCategory: string | null;

  @Column('double precision', {
    name: 'finq_risk_level',
    nullable: true,
    precision: 53,
  })
  finqRiskLevel: number | null;

  @Column('double precision', {
    name: 'finq_yield_level',
    nullable: true,
    precision: 53,
  })
  finkYieldLevel: number | null;

  @Column('character varying', { name: 'fund_id', nullable: true })
  fundId: string | null;

  @Column('integer', { name: 'param_id', nullable: true })
  paramId: number | null;

  @Column('character varying', { name: 'param_description', nullable: true })
  paramDescription: string | null;

  @Column('character varying', { name: 'calculation_method', nullable: true })
  calculationMethod: string | null;

  @Column('double precision', {
    name: 'min_range',
    nullable: true,
    precision: 53,
  })
  minRange: number | null;

  @Column('double precision', {
    name: 'max_range',
    nullable: true,
    precision: 53,
  })
  maxRange: number | null;

  @Column('double precision', {
    name: 'fib_weight',
    nullable: true,
    precision: 53,
  })
  fibWeight: number | null;

  @Column('character varying', { name: 'fib_type', nullable: true })
  fibType: string | null;

  @Column('character varying', { name: 'general_param', nullable: true })
  generalParam: string | null;

  @Column('double precision', { name: 'median', nullable: true, precision: 53 })
  median: number | null;

  @Column('double precision', {
    name: 'distance',
    nullable: true,
    precision: 53,
  })
  distance: number | null;

  @Column('double precision', { name: 'score', nullable: true, precision: 53 })
  score: number | null;
}
