import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { RefBanks } from './RefBanks';
import { UserBankAccounts } from './UserBankAccounts';

@Index('ref_bank_branches_pk', ['id'], { unique: true })
@Entity('ref_bank_branches', { schema: 'public' })
export class RefBankBranches {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('bigint', { name: 'branch_number', nullable: true })
  branchNumber: string | null;

  @Column('character varying', { name: 'branch_name', nullable: true })
  branchName: string | null;

  @Column('character varying', { name: 'branch_name_en', nullable: true })
  branchNameEn: string | null;

  @ManyToOne(() => RefBanks, (refBanks) => refBanks.refBankBranches)
  @JoinColumn([{ name: 'bank_number', referencedColumnName: 'id' }])
  bankNumber: RefBanks;

  @OneToMany(() => UserBankAccounts, (userBankAccounts) => userBankAccounts.branch)
  userBankAccounts: UserBankAccounts[];
}
