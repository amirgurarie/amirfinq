import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('hr_conf_contacts_pk', ['id'], { unique: true })
@Entity('hr_conf_contacts', { schema: 'public' })
export class HRConfContacts {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('timestamp with time zone', { name: 'created_at', nullable: false })
  createdAt: Date | null;

  @Column('character varying', { name: 'first_name', nullable: true })
  firstName: string | null;

  @Column('character varying', { name: 'last_name', nullable: true })
  lastName: string | null;

  @Column('character varying', { name: 'email', nullable: false, length: 255 })
  email: string | null;

  @Column('character varying', { name: 'phone_number', nullable: true, length: 20 })
  phoneNumber: string | null;

  @Column('character varying', { name: 'company', nullable: false })
  company: string | null;

  @Column('character varying', { name: 'employee_count', nullable: true })
  employeeCount: string | null;

  @Column('character varying', { name: 'position', nullable: true })
  position: string | null;

  @Column('character varying', { name: 'message', nullable: false })
  message: string | null;
}
