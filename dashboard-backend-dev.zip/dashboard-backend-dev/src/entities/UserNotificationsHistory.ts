import { Column, Entity, Index } from 'typeorm';

@Index('user_notifications_history_pk', ['id'], { unique: true })
@Entity('user_notifications_history', { schema: 'public' })
export class UserNotificationsHistory {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('uuid', { name: 'user_id', nullable: true })
  userId: string | null;

  @Column('character varying', { name: 'notification_id', nullable: true })
  notificationId: string | null;

  @Column('character varying', { name: 'template_params', nullable: true })
  templateParams: string | null;

  @Column('timestamp with time zone', {
    name: 'notification_date',
    nullable: true,
  })
  notificationDate: Date | null;
}
