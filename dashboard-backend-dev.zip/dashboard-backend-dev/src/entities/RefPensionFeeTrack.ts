import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('ref_pension_fee_tracks_pk', ['id'], { unique: true })
@Entity('ref_pension_fee_tracks', { schema: 'public' })
export class RefPensionFeeTrack {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column('character varying', { name: 'company_id', nullable: false })
  companyId: string; // יצרן

  @Column('character varying', { name: 'product_category', nullable: false })
  productCategory: string; // מוצר

  @Column('integer', { name: 'sub_specialization', nullable: true })
  subSpecialization: number | null; // תת התמחות

  @Column('numeric', { name: 'min_accumulation', nullable: true })
  minAccumulation: number | null; // צבירה מינימלית

  @Column('numeric', { name: 'max_accumulation', nullable: true })
  maxAccumulation: number | null; // צבירה מקסימלית

  @Column('numeric', { name: 'min_salary', nullable: true })
  minSalary: number | null; // משכורת מינימלית

  @Column('numeric', { name: 'max_salary', nullable: true })
  maxSalary: number | null; // משכורת מקסימלית

  @Column('numeric', { name: 'min_provision_self_employed', nullable: true })
  minProvisionSelfEmployeed: number | null; // עצמאי הפקדה מינימלית

  @Column('numeric', { name: 'max_provision_self_employed', nullable: true })
  maxProvisionSelfEmployeed: number | null; // עצמאי הפקדה מקסימלית

  @Column('numeric', { name: 'deposit_fee', nullable: true })
  depositFee: number; //דמי ניהול מהפקדה

  @Column('numeric', { name: 'accumulation_fee', nullable: true })
  accumulationFee: number; // דמי ניהול מצבירה

  @Column('enum', { name: 'operator_type', enumName: 'PensionFeeOperatorType', nullable: false })
  operatorType: PensionFeeOperatorType;
}

export const PensionFeeOperatorType = {
  OR: 'OR',
  AND: 'AND',
} as const;

export type PensionFeeOperatorType = (typeof PensionFeeOperatorType)[keyof typeof PensionFeeOperatorType];
