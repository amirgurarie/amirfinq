import { Column, Entity, Index } from 'typeorm';

@Index('afi_regulated_adjustment_pk', ['id'], { unique: true })
@Entity('afi_regulated_adjustment', { schema: 'public' })
export class AfiRegulatedAdjustment {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('double precision', { name: 'from', nullable: true, precision: 53 })
  from: number | null;

  @Column('double precision', { name: 'to', nullable: true, precision: 53 })
  to: number | null;

  @Column('double precision', {
    name: 'regulated_score',
    nullable: true,
    precision: 53,
  })
  regulatedScore: number | null;
}
