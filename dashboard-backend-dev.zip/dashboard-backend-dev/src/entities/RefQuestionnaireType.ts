import { Column, Entity, Index, OneToMany } from 'typeorm';
import { UiKycQuestionCategory } from './UiKycQuestionCategory';

@Index('ref_questionnaire_type_pk', ['code'], { unique: true })
@Entity('ref_questionnaire_type', { schema: 'public' })
export class RefQuestionnaireType {
  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'name_he', nullable: true })
  nameHe: string | null;

  @Column('character varying', { name: 'name_en', nullable: true })
  nameEn: string | null;

  @Column('smallint', { name: 'display_order', nullable: true })
  displayOrder: number;

  @Column('boolean', { name: 'is_active', nullable: true })
  isActive: string | null;

  @Column('character varying', { primary: true, name: 'code' })
  @OneToMany((type) => UiKycQuestionCategory, (uiKycQuestionCategory) => uiKycQuestionCategory.questionnaireType)
  code: UiKycQuestionCategory[];

  @OneToMany(() => UiKycQuestionCategory, (uiKycQuestionCategory) => uiKycQuestionCategory.questionnaireType)
  uiKycQuestionCategory: UiKycQuestionCategory[];
}
