// @index('./*', f => `export * from '${f.path}';\n`)
export * from './AfiAnswerScore';

export * from './AfiAnswerSegment';

export * from './AfiCalculationResult';

export * from './AfiKycQuestions';

export * from './AfiRegulatedAdjustment';

export * from './AfiSocioeconomic';

export * from './AnalyticsTopStocksPortfolio';

export * from './AssetAnalytics';

export * from './AssetArticles';

export * from './AssetArticlesSiteLogo';

export * from './Assets';

export * from './AssetsHistory';

export * from './AssetsLogo';

export * from './AssetsTemp';

export * from './BaseEntities';

export * from './BaseEventEntity';

export * from './CombinedUserProduct';

export * from './CommunicationChannels';

export * from './DataSnapshot';

export * from './FibCalculationMciIndex';

export * from './FibCalculationResult';

export * from './FibFundCategory';

export * from './FibFundHouseStatistics';

export * from './FibFundsRating';

export * from './FibFundsStatistics';

export * from './FibFundsStatisticsParameters';

export * from './FibIndexRatingWeight';

export * from './FibParameters';

export * from './FlywaySchemaHistory';

export * from './FlywaySchemaHistoryDataflow';

export * from './FundAssets';

export * from './FundAssetsTemp';

export * from './FundDividend';

export * from './FundItemsDistribution';

export * from './FundPension';

export * from './FundPensionDistribution';

export * from './FundPensionDistributionByAssetType';

export * from './FundPensionFinqInterest';

export * from './FundPensionHoldings';

export * from './FundPensionHoldingsSummery';

export * from './FundPensionYield';

export * from './Funds';

export * from './FundsBack';

export * from './FundsHistory';

export * from './Gender';

export * from './GeneralParameters';

export * from './InvestmentChannelsCAGR';

export * from './KycQuestionnaire';

export * from './KycQuestionnaireChapter';

export * from './KycQuestionnairePage';

export * from './kycRespondentProgress';

export * from './MatchParameters';

export * from './NewsTickerHeader';

export * from './PortfolioGraph';

export * from './PortfolioSelectionDetails';

export * from './PortfolioSelectionFilters';

export * from './PortfolioSelections';

export * from './ProductPlan';

export * from './ProductPlanExclusivity';

export * from './ProductPlanPricing';

export * from './ProductPlansWaitingList';

export * from './Products';

export * from './RefAddress';

export * from './RefAssetType';

export * from './RefBankAccountTypes';

export * from './RefBankBranches';

export * from './RefBanks';

export * from './RefBenchmarks';

export * from './RefBizportalAssetTypes';

export * from './RefBizportalCurrency';

export * from './RefBizportalSectors';

export * from './RefBizportalTradingPlace';

export * from './RefCalculationCategory';

export * from './RefCalculationMethod';

export * from './RefCities';

export * from './RefCommunicationChannels';

export * from './RefCountries';

export * from './RefCurrency';

export * from './RefDistributionGroup';

export * from './RefDocumentsTypes';

export * from './RefFinqAgreement';

export * from './RefFlow';

export * from './RefFlowStage';

export * from './RefFundCategory';

export * from './RefFundClassification';

export * from './RefFundHouse';

export * from './RefFundPurityType';

export * from './RefFundSecondaryClassification';

export * from './RefFundSubCategory';

export * from './RefFundSubType';

export * from './RefFundTaxStatus';

export * from './RefFundType';

export * from './RefInvestmentPaths';

export * from './RefInvestmentPathsGroups';

export * from './RefNotificationGroup';

export * from './RefNotificationsTypes';

export * from './RefPaymentMethod';

export * from './RefPensionCompanies';

export * from './RefPensionFeeTrack';

export * from './RefPensionProductFinqCategories';

export * from './RefPensionProductsSecondaryCategories';

export * from './RefPensionProductsSubCategories';

export * from './RefPortfolioGraphPeriod';

export * from './RefPortfolioStatus';

export * from './RefPricingPlan';

export * from './RefPricingPlanProducts';

export * from './RefProductConflicts';

export * from './RefProducts';

export * from './RefProductSubscriptionMethods';

export * from './RefProposalType';

export * from './RefQuestionnaireType';

export * from './RefRoles';

export * from './RefSectors';

export * from './RefSectorTranslations';

export * from './RefStockRating';

export * from './RefStreets';

export * from './RefTradeLocations';

export * from './RefUiType';

export * from './RefUserActivities';

export * from './RefUserBankTransactionTypes';

export * from './RefUserOccupations';

export * from './RefUserProductStatus';

export * from './RefUserPublicRole';

export * from './RefUserReportGroup';

export * from './RefUserReports';

export * from './RefUserStages';

export * from './StocksRanking';

export * from './TopStocksPortfolioYields';

export * from './TopStocksTransactions';

export * from './UiKycAnswers';

export * from './UiKycQuestionCategory';

export * from './UiKycQuestionGroup';

export * from './UiKycQuestions';

export * from './UiLeadSource';

export * from './UiStockPortfolios';

export * from './UserApprovedFinqAgreement';

export * from './UserBankAccountPartners';

export * from './UserBankAccounts';

export * from './UserBankAccountsBalance';

export * from './UserBankAccountsBalanceSummary';

export * from './UserBankAccountsTransactions';

export * from './UserBeneficiariesDetails';

export * from './UserBeneficiariesEvent';

export * from './UserChildrenDetails';

export * from './UserChildrenEvent';

export * from './UserContact';

export * from './UserContract';

export * from './UserDetails';

export * from './UserDocuments';

export * from './UserDocumentsDetails';

export * from './UserEmployerDetails';

export * from './UserEmployerEvent';

export * from './UserEvent';

export * from './UserFavorite';

export * from './UserFavoriteDetails';

export * from './UserFinqRiskLevelHistory';

export * from './UserFlowStage';

export * from './UserIntercomContact';

export * from './UserHubSpotContact';

export * from './UserHubSpotDeal';

export * from './UserIdentityVerification';

export * from './UserInvestmentRiskAnalytics';

export * from './UserInvestmentRiskLevels';

export * from './UserInvestmentRiskScores';

export * from './UserKycAnswers';

export * from './UserKycAnswersHistory';

export * from './UserMeetings';

export * from './UserNotifications';

export * from './UserNotificationsHistory';

export * from './UserPartners';

export * from './UserPayme';

export * from './UserPaymentToken';

export * from './UserPensionMislakaPolicies';

export * from './UserPensionMislakaPolicyBasicInsuranceCoverages';

export * from './UserPensionMislakaPolicyBenefits';

export * from './UserPensionMislakaPolicyDeposits';

export * from './UserPensionMislakaPolicyInsuranceCoverages';

export * from './UserPensionMislakaPolicyInvestmentPlans';

export * from './UserPensionMislakaPolicyMitriyot';

export * from './UserPensionMislakaPolicyPensionInsuranceCoverages';

export * from './UserPensionMislakaQueries';

export * from './UserPensionMislakaQueryExclusions';

export * from './UserPensionRecommendations';

export * from './UserPensionRecommendationsBenefits';

export * from './UserPensionRecommendationsTransactions';

export * from './UserPensionRecommendationsTransactionsHoldings';

export * from './UserPensionRecommendationsCombinations';

export * from './UserPensionRecommendationsCombinationsHoldings';

export * from './UserPensionRecommendationsCombinationsHoldingsSimulations';

export * from './UserPensionRecommendationsFormally';

export * from './UserPensionRiskAnalytics';

export * from './UserPensionRiskLevels';

export * from './UserPortfolioPendingRequestDetails';

export * from './UserPortfolioPendingRequests';

export * from './UserProductPayment';

export * from './UserProducts';

export * from './UserReports';

export * from './UserRoles';

export * from './Users';

export * from './UserSession';

export * from './UserSpouseDetails';

export * from './UserSpouseEvent';

export * from './UserStages';

export * from './UserStripe';

export * from './UserSubscriptions';

export * from './UserWaitingListNotification';
