import { Column, Entity } from 'typeorm';

@Entity('ref_bizportal_asset_types', { schema: 'public' })
export class RefBizportalAssetTypes {
  @Column('character varying', { primary: true, name: 'bizportal_asset_type' })
  bizportalAssetType: string;

  @Column('character varying', { name: 'asset_type_id', nullable: true })
  assetTypeId: string | null;
}
