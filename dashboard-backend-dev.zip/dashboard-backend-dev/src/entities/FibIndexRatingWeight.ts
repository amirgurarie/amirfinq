import { Column, Entity, Index } from 'typeorm';

@Index('fib_index_rating_weight_pk', ['id'], { unique: true })
@Entity('fib_index_rating_weight', { schema: 'public' })
export class FibIndexRatingWeight {
  @Column('smallint', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('real', { name: 'rating_weight', nullable: true, precision: 24 })
  ratingWeight: number | null;

  @Column('character varying', { name: 'index', nullable: true })
  index: string | null;

  @Column('character varying', { name: 'calculation_method', nullable: true })
  calculationMethod: string | null;
}
