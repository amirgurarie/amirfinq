import { Column, Entity, Index, OneToMany } from 'typeorm';
import { UserRoles } from './UserRoles';
import { UserRoleType } from 'src/houston/houston-auth/decorators/roles';

@Index('ref_roles_pk', ['id'], { unique: true })
@Entity('ref_roles', { schema: 'public' })
export class RefRoles {
  @Column({ primary: true, unique: true })
  id: UserRoleType;

  @OneToMany(() => UserRoles, (userRoles) => userRoles.role)
  userRoles: UserRoles[];
}
