import { Column, Entity } from 'typeorm';

@Entity('ref_communication_channels', { schema: 'public' })
export class RefCommunicationChannels {
  @Column('character varying', {
    primary: true,
    name: 'code',
    nullable: true,
    length: 255,
  })
  code: string | null;

  @Column('character varying', {
    name: 'description',
    nullable: true,
    length: 255,
  })
  description: string | null;
}
