import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseUserPortfolioDetailsWithPrice } from './BaseEntities';
import { RefAssetType } from './RefAssetType';
import { UserFavorite } from './UserFavorite';

@Index('user_favorite_details_pk', ['id'], { unique: true })
@Entity('user_favorite_details', { schema: 'public' })
export class UserFavoriteDetails extends BaseUserPortfolioDetailsWithPrice {
  @ManyToOne(() => RefAssetType, (type) => type.userProposalFavoriteAssetDetails)
  @JoinColumn([{ name: 'asset_type', referencedColumnName: 'id' }])
  assetType: RefAssetType;

  @ManyToOne(() => UserFavorite, (type) => type.userProposalFavoriteAssetDetails)
  @JoinColumn([{ name: 'favorite_id', referencedColumnName: 'id' }])
  favoriteAssets: UserFavorite;
}
