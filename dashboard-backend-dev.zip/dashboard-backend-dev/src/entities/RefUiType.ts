import { Column, Entity, Index, OneToMany } from 'typeorm';
import { UiKycAnswers } from './UiKycAnswers';
import { UiKycQuestions } from './UiKycQuestions';

@Index('ref_ui_type_pk', ['id'], { unique: true })
@Entity('ref_ui_type', { schema: 'public' })
export class RefUiType {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'answer_value', nullable: true })
  answerValue: string | null;

  @Column('character varying', { name: 'ui_sub_type', nullable: true })
  uiSubType: string | null;

  @Column('character varying', { name: 'ui_type', nullable: true })
  uiType: string | null;

  @OneToMany(() => UiKycQuestions, (uiKycQuestions) => uiKycQuestions.uiType)
  uiKycQuestions: UiKycQuestions[];
}
