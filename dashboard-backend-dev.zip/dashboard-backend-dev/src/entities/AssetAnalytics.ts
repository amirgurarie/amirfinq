import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { Assets } from './Assets';

@Index('asset_analytics_pk', ['id'], { unique: true })
@Entity('asset_analytics', { schema: 'public' })
export class AssetAnalytics {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'symbol' })
  symbol: string;

  @Column('double precision', { name: 'low_price_target', nullable: true })
  lowPriceTarget: number;

  @Column('double precision', { name: 'high_price_target', nullable: true })
  highPriceTarget: number;

  @Column('double precision', { name: 'price_target', nullable: true })
  priceTarget: number;

  @Column('integer', { name: 'number_buy_ratings', nullable: true })
  numberBuyRatings: number;

  @Column('integer', { name: 'number_sell_ratings', nullable: true })
  numberSellRatings: number;

  @Column('character varying', { name: 'analyst_consensus', nullable: true })
  analystConsensus: string;

  @Column('double precision', { name: 'price_target_upside', nullable: true })
  priceTargetUpside: number;

  @Column('character varying', { name: 'price_target_currency_code', nullable: true })
  priceTargetCurrencyCode: string;

  @Column('integer', { name: 'number_of_analysts', nullable: true })
  numberOfAnalysts: number;

  @Column('integer', { name: 'smart_score', nullable: true })
  smartScore: number;

  @Column('character varying', { name: 'blogger_consensus', nullable: true })
  bloggerConsensus: string;

  @Column('double precision', { name: 'blogger_bullish_sentiment', nullable: true })
  bloggerBullishSentiment: number;

  @Column('double precision', { name: 'blogger_sector_avg', nullable: true })
  bloggerSectorAvg: number;

  @Column('character varying', { name: 'insider_trend', nullable: true })
  insiderTrend: string;

  @Column('timestamp with time zone', { name: 'insiders_last_3months_sum', nullable: true })
  insidersLast3MonthsSum: string;

  @Column('character varying', { name: 'hedge_fund_trend', nullable: true })
  hedgeFundTrend: string;

  @Column('double precision', { name: 'hedge_fund_trend_value', nullable: true })
  hedgeFundTrendValue: number;

  @Column('character varying', { name: 'news_sentiment', nullable: true })
  newsSentiment: string;

  @Column('double precision', { name: 'news_sentiments_bearish_percent', nullable: true })
  newsSentimentsBearishPercent: number;

  @Column('double precision', { name: 'news_sentiments_bullish_percents', nullable: true })
  newsSentimentsBullishPercents: number;

  @Column('character varying', { name: 'investor_sentiment', nullable: true })
  investorSentiment: string;

  @Column('double precision', { name: 'investor_holding_change_last7days', nullable: true })
  investorHoldingChangeLast7days: number;

  @Column('double precision', { name: 'investor_holding_change_last30_days', nullable: true })
  investorHoldingChangeLast30Days: number;

  @Column('double precision', { name: 'fundamentals_return_on_equity', nullable: true })
  fundamentalsReturnOnEquity: number;

  @Column('double precision', { name: 'fundamentals_asset_growth', nullable: true })
  fundamentalsAssetGrowth: number;

  @Column('double precision', { name: 'technicals_twelve_months_momentum', nullable: true })
  technicalsTwelveMonthsMomentum: number;

  @Column('character varying', { name: 'sma_ranking', nullable: true })
  smaRanking: string;

  @Column('double precision', { name: 'bearish_ratio', nullable: true })
  bearishRatio: number;

  @Column('integer', { name: 'num_of_bloggers', nullable: true })
  numOfBloggers: number;

  @Column('integer', { name: 'bullish_count', nullable: true })
  bullishCount: number;

  @Column('integer', { name: 'bearish_count', nullable: true })
  bearishCount: number;

  @Column('double precision', { name: 'news_sentiment_stock_positive', nullable: true })
  newsSentimentStockPositive: number;

  @Column('double precision', { name: 'news_sentiment_stock_neutral', nullable: true })
  newsSentimentStockNeutral: number;

  @Column('double precision', { name: 'news_sentiment_stock_negative', nullable: true })
  newsSentimentStockNegative: number;

  @Column('double precision', { name: 'news_sentiment_score', nullable: true })
  newsSentimentScore: number;

  @Column('double precision', { name: 'news_sentiment_buzz_weekly_avg', nullable: true })
  newsSentimentBuzzWeeklyAvg: number;

  @Column('integer', { name: 'news_sentiment_buzz_this_week', nullable: true })
  newsSentimentBuzzThisWeek: number;

  @Column('double precision', { name: 'news_sentiment_buzz', nullable: true })
  newsSentimentBuzz: number;

  @Column('character varying', { name: 'asset_id' })
  assetId: string;

  @ManyToOne(() => Assets, (assets) => assets.assetAnalytics)
  @JoinColumn([{ name: 'asset_id', referencedColumnName: 'id' }])
  asset: Assets;
}
