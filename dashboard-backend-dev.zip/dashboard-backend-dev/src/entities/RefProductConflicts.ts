import { Column, Entity, Index } from 'typeorm';

@Index('ref_product_conflicts_pk', ['productId', 'conflictWithProductId'], { unique: true })
@Entity('ref_product_conflicts', { schema: 'public' })
export class RefProductConflicts {
  @Column('character varying', { primary: true, name: 'product_id', nullable: false })
  productId: string;

  @Column('character varying', { primary: true, name: 'conflict_with_product_id', nullable: false })
  conflictWithProductId: string;
}
