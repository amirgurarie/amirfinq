import { Column, Entity, ManyToOne, JoinColumn } from 'typeorm';
import { Users } from 'src/entities';
import { Page } from '../shared/modules/analytics/interface/page.interface';

@Entity('user_sessions', { schema: 'public' })
export class UserSession {
  @Column('uuid', {
    primary: true,
    name: 'session_id',
    default: () => 'uuid_generate_v4()',
  })
  sessionId: string;

  @Column('uuid', { name: 'user_id', nullable: true })
  userId?: string | null;

  @ManyToOne(() => Users, (users) => users.userSessions)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user?: Users;

  @Column('character varying', { name: 'ip', nullable: true })
  ip?: string;

  @Column('character varying', { name: 'country', nullable: true })
  country?: string;

  @Column('character varying', { name: 'city', nullable: true })
  city?: string;

  @Column('character varying', { name: 'browser', nullable: true })
  browser?: string;

  @Column('character varying', { name: 'operating_system', nullable: true })
  operatingSystem?: string;

  @Column('character varying', { name: 'device', nullable: true })
  device?: string;

  @Column('boolean', { name: 'is_mobile', nullable: true })
  isMobile?: boolean;

  @Column('character varying', { name: 'user_agent', nullable: true })
  userAgent?: string;

  @Column('character varying', { name: 'user_agent_id', nullable: true })
  userAgentId: string;

  @Column('boolean', { name: 'is_returning', nullable: true })
  isReturning: boolean;

  @Column('timestamp with time zone', { name: 'created_date' })
  createdDate: Date;

  @Column('timestamp with time zone', { name: 'expiry_date' })
  expiryDate: Date;

  @Column('timestamp with time zone', { name: 'login_date', nullable: true })
  loginDate?: Date;

  @Column('boolean', { name: 'is_bot', nullable: true })
  isBot: boolean;

  @Column('boolean', { name: 'utm', nullable: true })
  utm?: Utm;

  @Column('boolean', { name: 'referrer', nullable: true })
  referrer?: Referrer;

  @Column('boolean', { name: 'affiliates', nullable: true })
  affiliates?: Affiliates;

  @Column('jsonb', { name: 'first_page', nullable: true })
  firstPage?: Page;
}

export interface Utm {
  id?: string;
  source?: string;
  medium?: string;
  campaign?: string;
  content?: string;
  term?: string;
}

export interface Referrer {
  url?: string;
  host?: string;
}

export interface Affiliates {
  impact_click_id?: string;
  linkedin_click_id?: string;
  google_client_id?: string;
}
