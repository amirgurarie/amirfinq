import {
  BasicInsuranceCoveragePayerEnum,
  BasicInsuranceTrackTypeEnum,
  IncludesSavingsEnum,
  InsuranceAmountIndexTypeEnum,
  InsuranceCoveragePaymentMethodEnum,
} from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import { UserPensionMislakaPolicyInsuranceCoverage } from './UserPensionMislakaPolicyInsuranceCoverages';

@Index('user_pension_mislaka_policy_basic_insurance_coverages_pk', ['id'], { unique: true })
@Entity('user_pension_mislaka_policy_basic_insurance_coverages', { schema: 'public' })
export class UserPensionMislakaPolicyBasicInsuranceCoverage {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('integer', { name: 'policy_id', nullable: false })
  policyId: number;

  @Column('integer', { name: 'insurance_coverage_id', nullable: true })
  insuranceCoverageId: number | null;

  @Column('character varying', { name: 'coverage_num_id', nullable: true })
  coverageNumId: string | null; // ID_Kisuy from KisuyYesodi

  @Column('character varying', { name: 'product_code', nullable: true })
  productCode: string | null; // KOD-MUTZAR-LEFI-KIDUD-ACHID-LAYESODI

  @Column('enum', { name: 'insurance_amount_index_type', nullable: true, enum: InsuranceAmountIndexTypeEnum })
  insuranceAmountIndexType: InsuranceAmountIndexTypeEnum | null; // SUG-HATZMADA-SCHUM-BITUAH xxx vv

  @Column('enum', { name: 'insurance_premium_index_type', nullable: true, enum: InsuranceAmountIndexTypeEnum })
  insurancePremiumIndexType: InsuranceAmountIndexTypeEnum | null; //SUG-HATZMADA-DMEI-BITUAH vv

  @Column('enum', { name: 'insurance_track_type', nullable: true, enum: BasicInsuranceTrackTypeEnum })
  insuranceTrackType: BasicInsuranceTrackTypeEnum | null; // SUG-MASLUL-LEBITUAH vvv

  @Column('enum', { name: 'includes_savings', nullable: true, enum: IncludesSavingsEnum })
  includesSavings: IncludesSavingsEnum | null; // IND-SCHUM-BITUAH-KOLEL-CHISACHON vvv

  @Column('float', { name: 'track_insurance_amount', nullable: true, precision: 15, scale: 2 })
  trackInsuranceAmount: number | null; // SCHUM-BITUACH-LEMASLUL

  @Column('integer', { name: 'salary_count', nullable: true })
  salaryCount: number | null; // MISPAR-MASKOROT

  @Column('double precision', { name: 'savings_allocation_percentage', nullable: true, precision: 10, scale: 2 })
  savingsAllocationPercentage: number | null; // ACHUZ-HAKTZAA-LE-CHISACHON

  @Column('double precision', { name: 'max_death_benefit_limit', nullable: true, precision: 15, scale: 2 })
  maxDeathBenefitLimit: number | null; // TIKRAT-GAG-HATAM-LEMIKRE-MAVET

  @Column('double precision', { name: 'death_benefit_amount', nullable: true, precision: 15, scale: 2 })
  deathBenefitAmount: number | null; // SCHUM-BITUAH-LEMAVET vvv

  @Column('enum', { name: 'payment_method', nullable: true, enum: InsuranceCoveragePaymentMethodEnum })
  paymentMethod: InsuranceCoveragePaymentMethodEnum | null; // OFEN-TASHLUM-SCHUM-BITUACH vv

  @Column('timestamp', { name: 'coverage_end_date', nullable: true })
  coverageEndDate: Date | null; // TAARICH-TOM-KISUY vvv

  @Column('double precision', { name: 'monthly_cost', nullable: true, precision: 15, scale: 2 })
  monthlyCost: number | null; // DMEI-BITUAH-LETASHLUM-BAPOAL vvv

  @Column('double precision', { name: 'remaining_cost_until_end', nullable: true, precision: 15, scale: 2 })
  remainingCostUntilEnd: number | null; // Sum of PREMIA-ZFOYA from HitpatchutPremia vvv

  @Column('enum', { name: 'coverage_payer', nullable: true, enum: BasicInsuranceCoveragePayerEnum })
  coveragePayer: BasicInsuranceCoveragePayerEnum | null; // ???

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: any | null;

  @Column('timestamp', { name: 'created_at', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;

  @ManyToOne(() => UserPensionMislakaPolicies, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'policy_id', referencedColumnName: 'id' })
  policy: UserPensionMislakaPolicies;

  @ManyToOne(
    () => UserPensionMislakaPolicyInsuranceCoverage,
    (insuranceCoverage) => insuranceCoverage.basicInsuranceCoverages,
    { onDelete: 'CASCADE', nullable: true },
  )
  @JoinColumn({ name: 'insurance_coverage_id', referencedColumnName: 'id' })
  insuranceCoverage: UserPensionMislakaPolicyInsuranceCoverage | null;
}
