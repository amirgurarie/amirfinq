import { FundPension } from 'src/entities/FundPension';
import { Column, Entity, Index, OneToMany } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';

@Index('ref_pension_companies_pk', ['companyId'], { unique: true })
@Entity('ref_pension_companies', { schema: 'public' })
export class RefPensionCompanies {
  @Column('character varying', { name: 'company_id', primary: true })
  companyId: string | null;

  @Column('character varying', { name: 'company_name', nullable: true })
  companyName: string | null;

  @Column('character varying', { name: 'company_text', nullable: true })
  companyText: string | null;

  @Column('character varying', { name: 'logo_path', nullable: true })
  logoPath: string | null;

  @Column('character varying', { name: 'short_text', nullable: true })
  shortText: string | null;

  @Column('bigint', { name: 'ui_order', nullable: true })
  uiOrder: number;

  @Column('integer', { name: 'service_rate_pension', nullable: true })
  serviceRatePension: number;

  @Column('integer', { name: 'service_rate_insurance', nullable: true })
  serviceRateInsurance: number;

  @Column('integer', { name: 'service_rate_benefit', nullable: true })
  serviceRateBenefit: number;

  @OneToMany(() => FundPension, (fundPension) => fundPension.pensionCompany)
  funds: FundPension[];

  @OneToMany(() => UserPensionMislakaPolicies, (fundPension) => fundPension.company)
  mislakaPolicies: UserPensionMislakaPolicies[];
}
