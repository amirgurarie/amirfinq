import { Column, Entity, Index, ManyToOne, OneToMany } from 'typeorm';
import { RefUserReports } from './RefUserReports';

@Index('ref_user_report_groups_pk', ['id'], { unique: true })
@Entity('ref_user_report_groups', { schema: 'public' })
export class RefUserReportGroup {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @OneToMany(() => RefUserReports, (RefUserReports) => RefUserReports.reportGroup)
  report: RefUserReports;
}
