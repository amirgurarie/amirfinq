import { Column, Entity, Index } from 'typeorm';

@Index('afi_kyc_questions_pk', ['id'], { unique: true })
@Entity('afi_kyc_questions', { schema: 'public' })
export class AfiKycQuestions {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'question_id', nullable: true })
  questionId: string | null;

  @Column('boolean', { name: 'regulated_question', nullable: true })
  regulatedQuestion: boolean | null;

  @Column('character varying', {
    name: 'calculation_method',
    nullable: true,
    length: 255,
  })
  calculationMethod: string | null;

  @Column('character varying', {
    name: 'questionnaire_type',
    nullable: true,
    length: 255,
  })
  questionnaireType: string | null;

  @Column('double precision', { name: 'regulated_weight', precision: 53 })
  regulatedWeight: number;

  @Column('double precision', { name: 'afi_weight', precision: 53 })
  afiWeight: number;

  @Column('character varying', {
    name: 'category',
    nullable: true,
    length: 255,
  })
  category: string | null;

  @Column('boolean', { name: 'positive_relation', nullable: true })
  positiveRelation: boolean | null;

  @Column('double precision', {
    name: 'max_range',
    nullable: true,
    precision: 53,
  })
  maxRange: number | null;

  @Column('double precision', {
    name: 'min_range',
    nullable: true,
    precision: 53,
  })
  minRange: number | null;
}
