import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { RefAssetType } from './RefAssetType';
import { PortfolioSelections } from './PortfolioSelections';

@Index('protfolio_selection_deatiles_pk', ['id'], { unique: true })
@Entity('portfolio_selection_details', { schema: 'public' })
export class PortfolioSelectionDetails {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'asset_id', nullable: true })
  assetId: string | null;

  @Column('real', { name: 'asset_percentage', nullable: true, precision: 24 })
  assetPercentage: number | null;

  @ManyToOne(() => RefAssetType, (refAssetType) => refAssetType.portfolioSelectionDetails)
  @JoinColumn([{ name: 'asset_type', referencedColumnName: 'id' }])
  assetType: RefAssetType;

  @ManyToOne(() => PortfolioSelections, (portfolioSelections) => portfolioSelections.portfolioSelectionDetails)
  @JoinColumn([{ name: 'portfolio_id', referencedColumnName: 'id' }])
  portfolio: PortfolioSelections;
}
