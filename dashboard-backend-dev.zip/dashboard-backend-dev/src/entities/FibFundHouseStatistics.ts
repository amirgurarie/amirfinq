import { Column, Entity } from 'typeorm';

@Entity('fib_fund_house_statistics', { schema: 'public' })
export class FibFundHouseStatistics {
  @Column('character varying', {
    primary: true,
    name: 'fund_house',
    nullable: true,
  })
  fundHouse: string | null;

  @Column('double precision', {
    name: 'avg_yield',
    nullable: true,
    precision: 53,
  })
  avgYield: number | null;

  @Column('double precision', {
    name: 'median_yield',
    nullable: true,
    precision: 53,
  })
  medianYield: number | null;
}
