import { Column, Entity, ManyToOne, JoinColumn, Index, PrimaryGeneratedColumn } from 'typeorm';
import { ProductPlan } from './ProductPlan';
import { ProductTempTypes } from 'src/common/productTemp/types/productTemp.types';

@Index('product_plan_pricing_pk', ['id'], { unique: true })
@Entity('product_plan_pricing', { schema: 'public' })
export class ProductPlanPricing {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('character varying', { name: 'currency' })
  currency: string;

  @Column('double precision', { name: 'price', precision: 10, scale: 2 })
  price: number;

  @Column('character varying', { name: 'type' })
  type: ProductTempTypes.PeriodTypeEnum;

  @Column('character varying', { name: 'stripe_price_id' })
  stripePriceId: string;

  @Column('character varying', { name: 'trial_period' })
  trialPeriod: string;

  @ManyToOne(() => ProductPlan, (productPlan) => productPlan.pricing)
  @JoinColumn({ name: 'product_plan_id', referencedColumnName: 'id' })
  productPlan: ProductPlan;
}
