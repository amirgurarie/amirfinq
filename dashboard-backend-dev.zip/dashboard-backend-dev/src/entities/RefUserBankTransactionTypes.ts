import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { UserBankAccountsTransactions } from './UserBankAccountsTransactions';
import { Users } from './Users';

@Index('ref_user_bank_transaction_types_pk', ['id'], { unique: true })
@Entity('ref_user_bank_transaction_types', { schema: 'public' })
export class RefUserBankTransactionTypes {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @OneToMany(() => UserBankAccountsTransactions, (type) => type.transactionType)
  transaction: UserBankAccountsTransactions;
}
