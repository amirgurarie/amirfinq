import { Column, Entity, Index } from 'typeorm';

@Index('data_snapshots_pk', ['recordDate'], { unique: true })
@Entity('data_snapshots', { schema: 'public' })
export class DataSnapshot {
  @Column('integer', { primary: true, name: 'record_date' })
  recordDate: Date;

  @Column('integer', { name: 'new_signups' })
  newSignups: number;

  @Column('integer', { name: 'agg_signups' })
  aggSignups: number;

  @Column('integer', { name: 'new_signups_verified' })
  newSignupsVerified: number;

  @Column('integer', { name: 'agg_signups_verified' })
  aggSignupsVerified: number;

  @Column('integer', { name: 'new_subscriptions' })
  newSubscriptions: number;

  @Column('jsonb', { name: 'new_subscriptions_items' })
  newSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_subscriptions' })
  aggSubscriptions: number;

  @Column('jsonb', { name: 'agg_subscriptions_items' })
  aggSubscriptionsItems: number[];

  @Column('integer', { name: 'new_paid_subscriptions' })
  newPaidSubscriptions: number;

  @Column('jsonb', { name: 'new_paid_subscriptions_items' })
  newPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_paid_subscriptions' })
  aggPaidSubscriptions: number;

  @Column('jsonb', { name: 'agg_paid_subscriptions_items' })
  aggPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'new_trial_subscriptions' })
  newTrialSubscriptions: number;

  @Column('jsonb', { name: 'new_trial_subscriptions_items' })
  newTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_trial_subscriptions' })
  aggTrialSubscriptions: number;

  @Column('jsonb', { name: 'agg_trial_subscriptions_items' })
  aggTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'new_churns' })
  newChurns: number;

  @Column('jsonb', { name: 'new_churns_items' })
  newChurnsItems: number[];

  @Column('integer', { name: 'agg_churns' })
  aggChurns: number;

  @Column('jsonb', { name: 'agg_churns_items' })
  aggChurnsItems: number[];

  @Column('integer', { name: 'new_paid_churns' })
  newPaidChurns: number;

  @Column('jsonb', { name: 'new_paid_churns_items' })
  newPaidChurnsItems: number[];

  @Column('integer', { name: 'agg_paid_churns' })
  aggPaidChurns: number;

  @Column('jsonb', { name: 'agg_paid_churns_items' })
  aggPaidChurnsItems: number[];

  @Column('integer', { name: 'new_trial_churns' })
  newTrialChurns: number;

  @Column('jsonb', { name: 'new_trial_churns_items' })
  newTrialChurnsItems: number[];

  @Column('integer', { name: 'agg_trial_churns' })
  aggTrialChurns: number;

  @Column('jsonb', { name: 'agg_trial_churns_items' })
  aggTrialChurnsItems: number[];

  @Column('integer', { name: 'new_net_subscriptions' })
  newNetSubscriptions: number;

  @Column('jsonb', { name: 'new_net_subscriptions_items' })
  newNetSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_net_subscriptions' })
  aggNetSubscriptions: number;

  @Column('jsonb', { name: 'agg_net_subscriptions_items' })
  aggNetSubscriptionsItems: number[];

  @Column('integer', { name: 'new_net_paid_subscriptions' })
  newNetPaidSubscriptions: number;

  @Column('jsonb', { name: 'new_net_paid_subscriptions_items' })
  newNetPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_net_paid_subscriptions' })
  aggNetPaidSubscriptions: number;

  @Column('jsonb', { name: 'agg_net_paid_subscriptions_items' })
  aggNetPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'new_net_trial_subscriptions' })
  newNetTrialSubscriptions: number;

  @Column('jsonb', { name: 'new_net_trial_subscriptions_items' })
  newNetTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_net_trial_subscriptions' })
  aggNetTrialSubscriptions: number;

  @Column('jsonb', { name: 'agg_net_trial_subscriptions_items' })
  aggNetTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'new_pension_subscriptions' })
  newPensionSubscriptions: number;

  @Column('jsonb', { name: 'new_pension_subscriptions_items' })
  newPensionSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_pension_subscriptions' })
  aggPensionSubscriptions: number;

  @Column('jsonb', { name: 'agg_pension_subscriptions_items' })
  aggPensionSubscriptionsItems: number[];

  @Column('integer', { name: 'new_pension_paid_subscriptions' })
  newPensionPaidSubscriptions: number;

  @Column('jsonb', { name: 'new_pension_paid_subscriptions_items' })
  newPensionPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_pension_paid_subscriptions' })
  aggPensionPaidSubscriptions: number;

  @Column('jsonb', { name: 'agg_pension_paid_subscriptions_items' })
  aggPensionPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'new_pension_trial_subscriptions' })
  newPensionTrialSubscriptions: number;

  @Column('jsonb', { name: 'new_pension_trial_subscriptions_items' })
  newPensionTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_pension_trial_subscriptions' })
  aggPensionTrialSubscriptions: number;

  @Column('jsonb', { name: 'agg_pension_trial_subscriptions_items' })
  aggPensionTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'new_pension_churns' })
  newPensionChurns: number;

  @Column('jsonb', { name: 'new_pension_churns_items' })
  newPensionChurnsItems: number[];

  @Column('integer', { name: 'agg_pension_churns' })
  aggPensionChurns: number;

  @Column('jsonb', { name: 'agg_pension_churns_items' })
  aggPensionChurnsItems: number[];

  @Column('integer', { name: 'new_pension_paid_churns' })
  newPensionPaidChurns: number;

  @Column('jsonb', { name: 'new_pension_paid_churns_items' })
  newPensionPaidChurnsItems: number[];

  @Column('integer', { name: 'agg_pension_paid_churns' })
  aggPensionPaidChurns: number;

  @Column('jsonb', { name: 'agg_pension_paid_churns_items' })
  aggPensionPaidChurnsItems: number[];

  @Column('integer', { name: 'new_pension_trial_churns' })
  newPensionTrialChurns: number;

  @Column('jsonb', { name: 'new_pension_trial_churns_items' })
  newPensionTrialChurnsItems: number[];

  @Column('integer', { name: 'agg_pension_trial_churns' })
  aggPensionTrialChurns: number;

  @Column('jsonb', { name: 'agg_pension_trial_churns_items' })
  aggPensionTrialChurnsItems: number[];

  @Column('integer', { name: 'new_pension_net_subscriptions' })
  newPensionNetSubscriptions: number;

  @Column('jsonb', { name: 'new_pension_net_subscriptions_items' })
  newPensionNetSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_pension_net_subscriptions' })
  aggPensionNetSubscriptions: number;

  @Column('jsonb', { name: 'agg_pension_net_subscriptions_items' })
  aggPensionNetSubscriptionsItems: number[];

  @Column('integer', { name: 'new_pension_net_paid_subscriptions' })
  newPensionNetPaidSubscriptions: number;

  @Column('jsonb', { name: 'new_pension_net_paid_subscriptions_items' })
  newPensionNetPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_pension_net_paid_subscriptions' })
  aggPensionNetPaidSubscriptions: number;

  @Column('jsonb', { name: 'agg_pension_net_paid_subscriptions_items' })
  aggPensionNetPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'new_pension_net_trial_subscriptions' })
  newPensionNetTrialSubscriptions: number;

  @Column('jsonb', { name: 'new_pension_net_trial_subscriptions_items' })
  newPensionNetTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_pension_net_trial_subscriptions' })
  aggPensionNetTrialSubscriptions: number;

  @Column('jsonb', { name: 'agg_pension_net_trial_subscriptions_items' })
  aggPensionNetTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'new_stocks_subscriptions' })
  newStocksSubscriptions: number;

  @Column('jsonb', { name: 'new_stocks_subscriptions_items' })
  newStocksSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_stocks_subscriptions' })
  aggStocksSubscriptions: number;

  @Column('jsonb', { name: 'agg_stocks_subscriptions_items' })
  aggStocksSubscriptionsItems: number[];

  @Column('integer', { name: 'new_stocks_paid_subscriptions' })
  newStocksPaidSubscriptions: number;

  @Column('jsonb', { name: 'new_stocks_paid_subscriptions_items' })
  newStocksPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_stocks_paid_subscriptions' })
  aggStocksPaidSubscriptions: number;

  @Column('jsonb', { name: 'agg_stocks_paid_subscriptions_items' })
  aggStocksPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'new_stocks_trial_subscriptions' })
  newStocksTrialSubscriptions: number;

  @Column('jsonb', { name: 'new_stocks_trial_subscriptions_items' })
  newStocksTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_stocks_trial_subscriptions' })
  aggStocksTrialSubscriptions: number;

  @Column('jsonb', { name: 'agg_stocks_trial_subscriptions_items' })
  aggStocksTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'new_stocks_churns' })
  newStocksChurns: number;

  @Column('jsonb', { name: 'new_stocks_churns_items' })
  newStocksChurnsItems: number[];

  @Column('integer', { name: 'agg_stocks_churns' })
  aggStocksChurns: number;

  @Column('jsonb', { name: 'agg_stocks_churns_items' })
  aggStocksChurnsItems: number[];

  @Column('integer', { name: 'new_stocks_paid_churns' })
  newStocksPaidChurns: number;

  @Column('jsonb', { name: 'new_stocks_paid_churns_items' })
  newStocksPaidChurnsItems: number[];

  @Column('integer', { name: 'agg_stocks_paid_churns' })
  aggStocksPaidChurns: number;

  @Column('jsonb', { name: 'agg_stocks_paid_churns_items' })
  aggStocksPaidChurnsItems: number[];

  @Column('integer', { name: 'new_stocks_trial_churns' })
  newStocksTrialChurns: number;

  @Column('jsonb', { name: 'new_stocks_trial_churns_items' })
  newStocksTrialChurnsItems: number[];

  @Column('integer', { name: 'agg_stocks_trial_churns' })
  aggStocksTrialChurns: number;

  @Column('jsonb', { name: 'agg_stocks_trial_churns_items' })
  aggStocksTrialChurnsItems: number[];

  @Column('integer', { name: 'new_stocks_net_subscriptions' })
  newStocksNetSubscriptions: number;

  @Column('jsonb', { name: 'new_stocks_net_subscriptions_items' })
  newStocksNetSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_stocks_net_subscriptions' })
  aggStocksNetSubscriptions: number;

  @Column('jsonb', { name: 'agg_stocks_net_subscriptions_items' })
  aggStocksNetSubscriptionsItems: number[];

  @Column('integer', { name: 'new_stocks_net_paid_subscriptions' })
  newStocksNetPaidSubscriptions: number;

  @Column('jsonb', { name: 'new_stocks_net_paid_subscriptions_items' })
  newStocksNetPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_stocks_net_paid_subscriptions' })
  aggStocksNetPaidSubscriptions: number;

  @Column('jsonb', { name: 'agg_stocks_net_paid_subscriptions_items' })
  aggStocksNetPaidSubscriptionsItems: number[];

  @Column('integer', { name: 'new_stocks_net_trial_subscriptions' })
  newStocksNetTrialSubscriptions: number;

  @Column('jsonb', { name: 'new_stocks_net_trial_subscriptions_items' })
  newStocksNetTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'agg_stocks_net_trial_subscriptions' })
  aggStocksNetTrialSubscriptions: number;

  @Column('jsonb', { name: 'agg_stocks_net_trial_subscriptions_items' })
  aggStocksNetTrialSubscriptionsItems: number[];

  @Column('integer', { name: 'new_net_agreements_signed' })
  newNetAgreementsSigned: number;

  @Column('integer', { name: 'agg_net_agreements_signed' })
  aggNetAgreementsSigned: number;

  @Column('integer', { name: 'agg_managed_portfolios' })
  aggManagedPortfolios: number;

  @Column('integer', { name: 'agg_net_managed_portfolios' })
  aggNetManagedPortfolios: number;

  @Column('float', { name: 'agg_net_assets_under_management' })
  aggNetAssetsUnderManagement: number;
}
