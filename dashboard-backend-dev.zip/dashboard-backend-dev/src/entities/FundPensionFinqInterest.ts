import { Column, Entity, Index, JoinColumn, OneToOne } from 'typeorm';
import { FundPension } from './FundPension';

@Index('fund_pension_finq_interest_pk', ['fundId'], { unique: true })
@Entity('fund_pension_finq_interest', { schema: 'public' })
export class FundPensionFinqInterest {
  @Column('character varying', { name: 'fund_id', primary: true })
  fundId: string | null;

  @Column('character varying', { name: 'finq_category', nullable: true })
  finqCategory: string | null;

  @Column('bigint', { name: 'finq_risk_level', nullable: true })
  finqRiskLevel: number;

  @Column('float', { name: 'finq_rank', nullable: true })
  finqRank: number;

  @Column('float', { name: 'origin_finq_interest', nullable: true })
  originFinqInterest: number;

  @Column('float', { name: 'standardized_finq_interest', nullable: true })
  standardizedFinqInterest: number;
}
