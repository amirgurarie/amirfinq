import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('fund_assets_pk', ['fundId', 'assetId'], { unique: true })
@Entity('fund_assets', { schema: 'public' })
export class FundAssets {
  @Column('character varying', { name: 'fund_id', primary: true, nullable: false })
  fundId: string | null;

  @Column('character varying', { name: 'asset_id', primary: true, nullable: false })
  assetId: string | null;

  @Column('double precision', { name: 'asset_percentage', nullable: true, precision: 53 })
  assetPercentage: number | null;

  @Column('double precision', { name: 'turnover', nullable: true, precision: 53 })
  turnover: number | null;
}
