import { PayActionStatus, PaymentMethodTypes } from 'src/payments/types/payment.enum';
import { Index, Entity, JoinColumn, ManyToOne, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { RefPaymentMethod } from './RefPaymentMethod';
import { Users } from './Users';
import { UserSubscriptions } from './UserSubscriptions';

@Index('user_payme_pk', ['id'], { unique: true })
@Entity('user_payme', { schema: 'public' })
export class UserPayme {
  @PrimaryGeneratedColumn({ name: 'id' })
  id: number;

  @ManyToOne(() => Users, (users) => users.userPayme)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user?: Users;

  @Column('uuid', { name: 'user_id', nullable: true })
  userId: string | null;

  @Column('timestamp with time zone', { name: 'creation_date', nullable: true })
  creationDate: string | Date;

  @Column('timestamp with time zone', { name: 'start_date', nullable: true })
  startDate: string | Date;

  @Column('timestamp with time zone', { name: 'sub_prev_date', nullable: true })
  subPrevDate: string | Date;

  @Column('timestamp with time zone', { name: 'sub_next_date', nullable: true })
  subNextDate: string | Date;

  @Column('character varying', { name: 'payme_id' })
  paymeId: string;

  @Column('character varying', { name: 'payment_status' })
  paymentStatus: PayActionStatus;

  @Column('character varying', { name: 'subscription_id' })
  subscriptionId: string;

  @Column('character varying', { name: 'payment_url' })
  paymentUrl: string;

  @Column('integer', { name: 'payment_amount' })
  paymentAmount: number;

  @Column('character varying', { name: 'error_text' })
  errorText: string;

  @Column('character varying', { name: 'sub_status' })
  subStatus: string;

  @Column('character varying', { name: 'sub_description' })
  subDescription: string;

  @Column('character varying', { name: 'product_ids' })
  productIds: string;

  @Column('character varying', { name: 'seller_payme_id' })
  sellerPaymeId: string;

  @Column('character varying', { name: 'sub_payme_code' })
  subPaymeCode: string;

  @Column('integer', { name: 'sub_iteration_type' })
  subIterationType: number;

  @Column('integer', { name: 'sub_iterations_completed' })
  subIterationsCompleted: number;

  @Column('integer', { name: 'sub_iterations_left' })
  subIterationsLeft: number;

  @Column('integer', { name: 'sub_iterations' })
  subIterations: number;

  @Column('character varying', { name: 'currency' })
  currency: string;

  @Column('character varying', { name: 'payme_sale_id' })
  paymeSaleId: string;

  @Column('boolean', { name: 'sub_paid' })
  subPaid: boolean;

  @Column('character varying', { name: 'buyer_key' })
  buyerKey: string;

  @ManyToOne(() => RefPaymentMethod, (type) => type.id)
  @JoinColumn({ name: 'payment_method', referencedColumnName: 'id' })
  paymentMethod: RefPaymentMethod;

  @Column('character varying', { name: 'payment_method', nullable: false })
  paymentMethodId: PaymentMethodTypes;

  @ManyToOne(() => UserSubscriptions, (type) => type.payment)
  @JoinColumn({ name: 'payme_id', referencedColumnName: 'paymeId' })
  subscription: UserSubscriptions;
}
