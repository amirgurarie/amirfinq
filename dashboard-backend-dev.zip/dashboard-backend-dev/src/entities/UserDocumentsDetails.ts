import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserDocuments } from './UserDocuments';

@Index('user_documents_url_pk', ['id'], { unique: true })
@Entity('user_documents_details', { schema: 'public' })
export class UserDocumentsDetails {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'url', nullable: true })
  url: string | null;

  @Column('character varying', { name: 'name', nullable: true })
  name: string | null;

  @Column('character varying', { name: 'name_he', nullable: true })
  nameHe: string | null;

  @ManyToOne(() => UserDocuments, (userDocuments) => userDocuments.userDocumentsDetails)
  @JoinColumn([{ name: 'document_id', referencedColumnName: 'id' }])
  document: UserDocuments;
}
