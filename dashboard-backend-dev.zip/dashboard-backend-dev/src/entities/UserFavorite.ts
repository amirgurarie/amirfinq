import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { UserFavoriteDetails } from './UserFavoriteDetails';
import { RefAssetType } from './RefAssetType';
import { RefProposalType } from './RefProposalType';
import { Users } from './Users';
import { RefProducts } from './RefProducts';

@Index('user_favorite_pk', ['id'], { unique: true })
@Entity('user_favorite', { schema: 'public' })
export class UserFavorite {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('timestamp with time zone', { name: 'add_to_favorite_date', nullable: true })
  addToFavoriteDate: Date | null;

  @Column('character varying', { name: 'proposal_sub_type', nullable: true })
  proposalSubType: string | null;

  @Column('numeric', { name: 'finq_risk_level', nullable: true })
  finqRiskLevel: number | null;

  @Column('double precision', { name: 'avg_yield_1_year', nullable: true, precision: 53 })
  avgYield_1Year: number | null;

  @Column('double precision', { name: 'stock_exposure', nullable: true, precision: 53 })
  stockExposure: number | null;

  @Column('character varying', { name: 'asset_id', nullable: true })
  assetId: string | null;

  @OneToMany(
    () => UserFavoriteDetails,
    (userProposalFavoriteAssetDetails) => userProposalFavoriteAssetDetails.favoriteAssets,
  )
  userProposalFavoriteAssetDetails: UserFavoriteDetails[];

  @ManyToOne(() => RefAssetType, (type) => type.userFavorite)
  @JoinColumn([{ name: 'asset_type', referencedColumnName: 'id' }])
  assetType: RefAssetType;

  @ManyToOne(() => RefProposalType, (type) => type.userFavorite)
  @JoinColumn([{ name: 'proposal_type', referencedColumnName: 'id' }])
  proposalType: RefProposalType;

  @ManyToOne(() => Users, (type) => type.userFavorite)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @ManyToOne(() => RefProducts, (type) => type.id)
  @JoinColumn([{ name: 'product_id', referencedColumnName: 'id' }])
  product?: RefProducts | string;
}
