import { Column, Entity, Index, OneToMany } from 'typeorm';
import { ProductPlan } from './ProductPlan';

@Index('products_pk', ['id'], { unique: true })
@Entity('products', { schema: 'public' })
export class Product {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('smallint', { name: 'display_order', nullable: true })
  displayOrder: number;

  @Column('boolean', { name: 'is_active', nullable: true })
  isActive: boolean;

  @Column('boolean', { name: 'is_visible', nullable: true })
  isVisible: boolean;

  @OneToMany((type) => ProductPlan, (plans) => plans.product)
  plans: ProductPlan[];
}
