import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { UiKycQuestionCategory } from './UiKycQuestionCategory';
import { UiKycQuestions } from './UiKycQuestions';

@Index('ui_kyc_question_group_pk', ['id'], { unique: true })
@Entity('ui_kyc_question_group', { schema: 'public' })
export class UiKycQuestionGroup {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', {
    name: 'description_he_female',
    nullable: true,
    length: 255,
  })
  descriptionHeFemale: string | null;

  @Column('integer', { name: 'display_order' })
  displayOrder: number;

  @Column('character varying', { name: 'hint_he', nullable: true })
  hintHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'hint_en', nullable: true })
  hintEn: string | null;

  @Column('character varying', { name: 'description_he_male', nullable: true })
  descriptionHeMale: string | null;

  @ManyToOne(() => UiKycQuestionCategory, (uiKycQuestionCategory) => uiKycQuestionCategory.uiKycQuestionGroups)
  @JoinColumn([{ name: 'category_id', referencedColumnName: 'id' }])
  category: UiKycQuestionCategory;

  @OneToMany(() => UiKycQuestions, (uiKycQuestions) => uiKycQuestions.group)
  uiKycQuestions: UiKycQuestions[];
}
