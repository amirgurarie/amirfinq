import { AssetTypes } from 'src/finance/portfolios/interfaces/assetType.const';
import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { RefNotificationsTypes } from './RefNotificationsTypes';
import { Users } from './Users';

export type FromToAssetsType = {
  assetId: string;
  assetType: AssetTypes;
  assetPercentage: number;
}[];

export type NotificationParams = {
  replacements:
    | {
        fromAssets: FromToAssetsType;
        toAssets: FromToAssetsType;
      }[]
    | null;
};

@Index('user_notifications_pk', ['id'], { unique: true })
@Entity('user_notifications', { schema: 'public' })
export class UserNotifications {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('jsonb', { name: 'notification_params', default: {}, nullable: true })
  notificationParams: NotificationParams | null;

  @Column('timestamp with time zone', {
    name: 'notification_due_date',
    nullable: true,
  })
  notificationDueDate: string | null;

  @Column('timestamp with time zone', {
    name: 'creation_date',
    nullable: true,
    default: () => 'CURRENT_TIMESTAMP',
  })
  creationDate: Date | null;

  @Column('timestamp with time zone', { name: 'update_date', nullable: false })
  updateDate: Date | null;

  @Column('character varying', { name: 'accept_decline', nullable: false })
  acceptDecline: string | null;

  @Column('timestamp with time zone', {
    name: 'accept_decline_date',
    nullable: true,
  })
  acceptDeclineDate: Date | null;

  @Column('boolean', { name: 'mail_sent', nullable: true })
  mailSent: boolean | null;

  @Column('timestamp with time zone', {
    name: 'mail_sent_date',
    nullable: true,
  })
  mailSentDate: string | null;

  @Column('boolean', { name: 'sms_sent', nullable: true })
  smsSent: boolean | null;

  @Column('timestamp with time zone', { name: 'sms_sent_date', nullable: true })
  smsSentDate: string | null;

  @Column('boolean', { name: 'message_seen', nullable: true })
  messageSeen: boolean | null;

  @Column('character varying', { name: 'error_message', nullable: true })
  errorMessage: string | null;

  @ManyToOne(() => RefNotificationsTypes, (type) => type.id)
  @JoinColumn([{ name: 'notification_type', referencedColumnName: 'id' }])
  notificationType: RefNotificationsTypes;

  @ManyToOne(() => Users, (users) => users.userNotifications)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
