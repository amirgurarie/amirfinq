import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { PensionRecommendationTypes } from 'src/finance/pensions/modules/portfolio/modules/recommendations/types/recommendations.namespace';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import { UserPensionRecommendationCombinationCurrentHoldings } from './UserPensionRecommendationsCombinationsHoldings';
import { UserPensionRecommendationTransactions } from './UserPensionRecommendationsTransactions';

@Index('user_pension_recommendation_transaction_holdings_pk', ['id'], { unique: true })
@Entity('user_pension_recommendation_transaction_holdings', { schema: 'public' })
export class UserPensionRecommendationHoldings {
  @PrimaryGeneratedColumn('uuid', { name: 'holding_id' })
  id: string;

  @Column('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @Column('uuid', { name: 'transaction_id', nullable: false })
  transactionId: string;

  @Column({
    type: 'enum',
    name: 'product_category_id',
    enum: PensionCategoriesEnum,
    nullable: false,
  })
  productCategoryId: PensionCategoriesEnum;

  @Column({
    type: 'enum',
    name: 'essential_action',
    enum: PensionRecommendationTypes.Holding.EssentialActionsEnum,
    nullable: true,
  })
  essentialAction: PensionRecommendationTypes.Holding.EssentialActionsEnum | null;

  @Column('integer', { name: 'policy_id', nullable: false })
  policyId: number;

  @Column('float', { name: 'accumulation_amount', nullable: true })
  accumulationAmount: number | null; // policy.currentSavings

  @Column('float', { name: 'monthly_deposit_amount', nullable: true })
  monthlyDepositAmount: number | null; // reportedSalary * policy provisions

  @Column('float', { name: 'accumulation_management_fee', nullable: true })
  accumulationManagementFee: number | null; // policy.accManagementFees

  @Column('float', { name: 'deposit_management_fee', nullable: true })
  depositManagementFee: number | null; // policy.depositManagementFees

  @Column('float', { name: 'reported_salary', nullable: true })
  reportedSalary: number | null; // policy.sacarMeduvach

  @Column('float', { name: 'compensation_provision_percentage', nullable: true })
  compensationProvisionPercentage: number | null; // policy.compensationProvision

  @Column('float', { name: 'employer_provision_percentage', nullable: true })
  employerProvisionPercentage: number | null; // policy.employerProvision

  @Column('float', { name: 'employee_provision_percentage', nullable: true })
  employeeProvisionPercentage: number | null; // policy.employeeProvision

  @Column({ type: 'jsonb', name: 'holding_payload', nullable: true })
  payload: PensionRecommendationTypes.Holding.CurrentPayload | null;

  @OneToMany(
    () => UserPensionRecommendationCombinationCurrentHoldings,
    (combinationHoldings) => combinationHoldings.holding,
    { onDelete: 'CASCADE' },
  )
  combinationHoldings: UserPensionRecommendationCombinationCurrentHoldings[];

  @ManyToOne(() => UserPensionRecommendationTransactions, (transaction) => transaction.holdings, {
    onDelete: 'CASCADE',
  })
  @JoinColumn([{ name: 'transaction_id', referencedColumnName: 'id' }])
  transaction: UserPensionRecommendationTransactions;

  @ManyToOne(() => UserPensionMislakaPolicies, (policy) => policy.recommendationHoldings, {
    onDelete: 'CASCADE',
  })
  @JoinColumn([{ name: 'policy_id', referencedColumnName: 'id' }])
  policy: UserPensionMislakaPolicies;
}
