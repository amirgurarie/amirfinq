import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';

import { StocksRanking } from './StocksRanking';
import { Assets } from './Assets';

@Index('assets_history_pk', ['asset', 'tradeDate'])
@Entity('assets_history', { schema: 'public' })
export class AssetsHistory {
  @Column('character varying', { name: 'asset_id', primary: true })
  assetId: string;

  @Column('float', { name: 'price' })
  price: number;

  @Column('date', { name: 'trade_date', primary: true })
  tradeDate: Date;

  @Column('float', { name: 'yield_12_month', nullable: true })
  yieldMonth12: number;

  @Column('float', { name: 'daily_change', nullable: true })
  dailyChange: number;

  @Column('float', { name: 'adjustment_factor', nullable: true })
  adjustmentFactor: number;

  @ManyToOne(() => Assets, (assets) => assets.isin)
  @JoinColumn([{ name: 'asset_id', referencedColumnName: 'isin' }])
  asset: Assets;

  stocksRanking: StocksRanking[];
}
