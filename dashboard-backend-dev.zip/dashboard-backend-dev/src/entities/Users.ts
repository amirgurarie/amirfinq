import { UserHubSpotContact } from 'src/entities/UserHubSpotContact';
import { UserStripe } from 'src/entities/UserStripe';
import { IUserLogData } from 'src/shared/types/userLogData.interface';
import { UserStatusEnum } from 'src/users/userStatus.enum';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, OneToOne } from 'typeorm';
import { PricingPlanEnum } from './../finance/portfolios/interfaces/pricingPlan.enum';
import { RefCountries } from './RefCountries';
import { RefUserOccupations } from './RefUserOccupations';
import { UserBankAccounts } from './UserBankAccounts';
import { UserBankAccountsBalance } from './UserBankAccountsBalance';
import { UserBankAccountBalanceSummary } from './UserBankAccountsBalanceSummary';
import { UserBankAccountsTransactions } from './UserBankAccountsTransactions';
import { UserDetails } from './UserDetails';
import { UserDocuments } from './UserDocuments';
import { UserEvent } from './UserEvent';
import { UserFavorite } from './UserFavorite';
import { UserKycAnswers } from './UserKycAnswers';
import { UserKycAnswersHistory } from './UserKycAnswersHistory';
import { UserNotifications } from './UserNotifications';
import { UserPartners } from './UserPartners';
import { UserPayme } from './UserPayme';
import { UserPortfolioPendingRequests } from './UserPortfolioPendingRequests';
import { UserStages } from './UserStages';
import { UserSession } from './UserSession';
import { KycRespondentProgress } from './kycRespondentProgress';
import { UserRoles } from './UserRoles';
import { UserIntercomContact } from './UserIntercomContact';

@Index('users_pk', ['id'], { unique: true })
@Entity('users', { schema: 'public' })
export class Users {
  @Column('uuid', {
    primary: true,
    name: 'id',
    default: () => 'uuid_generate_v4()',
  })
  id: string;

  @Column('character varying', {
    name: 'first_name',
    nullable: true,
    length: 255,
  })
  firstName: string | null;

  @Column('character varying', {
    name: 'last_name',
    nullable: true,
    length: 255,
  })
  lastName: string | null;

  @Column('character varying', {
    name: 'email',
    nullable: true,
    length: 255,
    unique: true,
  })
  email: string | null;

  @Column('character varying', { name: 'gender', nullable: true, length: 255 })
  gender: string | null;

  @Column('character varying', {
    name: 'default_language',
    nullable: true,
    length: 255,
  })
  defaultLanguage: string | null;

  @Column('boolean', { name: 'other_country_resident', nullable: true })
  otherCountryResident: boolean | null;

  @Column('integer', { name: 'marketing_score', nullable: true })
  marketingScore: number | null;

  @Column('smallint', { name: 'public_role', nullable: true })
  publicRole: number | null;

  // TODO: To be removed
  @Column('integer', { name: 'notification_frequency', nullable: true })
  notificationFrequency: number | null;

  @Column('character varying', { name: 'user_status', nullable: true })
  userStatus: UserStatusEnum | null;

  // TODO: To be removed
  @Column('character varying', {
    name: 'status_comments',
    nullable: true,
    length: 255,
  })
  statusComments: string | null;

  @Column('timestamp with time zone', { name: 'last_seen', nullable: true })
  lastSeen: Date | null;

  // TODO: To be removed
  @Column('character varying', {
    name: 'update_by',
    nullable: true,
    length: 255,
  })
  updateBy: string | null;

  @Column('timestamp with time zone', {
    name: 'update_date',
    default: () => 'now()',
  })
  updateDate: Date;

  @Column('double precision', {
    name: 'finq_risk_level',
    nullable: true,
    precision: 53,
  })
  finqRiskLevel: number | null;

  @Column('double precision', {
    name: 'regular_risk_level',
    nullable: true,
    precision: 53,
  })
  regularRiskLevel: number | null;

  @Column('character varying', { name: 'link_to_auth0_id', nullable: true })
  linkToAuth0Id: string | null;

  @Column('boolean', { name: 'email_proposal', nullable: true })
  emailProposal: boolean | null;

  @Column('boolean', { name: 'email_confirmed', nullable: true })
  emailConfirmed: boolean | null;

  @Column('character varying', { name: 'connection_type', nullable: true })
  connectionType: string | null;

  @Column('boolean', { name: 'missing_user_in_auth0', nullable: true })
  missingUserInAuth0: boolean | null;

  @Column('boolean', { name: 'missing_contact_in_hubspot', nullable: true })
  missingContactInHubspot: boolean | null;

  @Column('boolean', { name: 'mismatch_hubspot_contact_id', nullable: true })
  mismatchHubspotContactId: boolean | null;

  @Column('character varying', { name: 'real_hubspot_contact_id', nullable: true })
  realHubspotContactId: string | null;

  @Column('integer', { name: 'city', nullable: true })
  city: string | null;

  @Column('integer', { name: 'street', nullable: true })
  street: string | null;

  @Column('character varying', { name: 'picture', nullable: true })
  picture: string | null;

  @Column('character varying', { name: 'cell', nullable: true })
  cell: string | null;

  // TODO: To be removed
  @Column('boolean', { name: 'by_post', nullable: true })
  byPost: boolean | null;

  @Column('boolean', { name: 'us_resident', nullable: true })
  usResident: boolean | null;

  @Column('bigint', { name: 'invest_amount', nullable: true })
  investAmount: string | null;

  // TODO: To be removed
  @Column('boolean', { name: 'bank_account_exist', nullable: true })
  bankAccountExist: boolean | null;

  @Column('integer', { name: 'home_number', nullable: true })
  homeNumber: number | null;

  @Column('integer', { name: 'postal_code', nullable: true })
  postalCode: number | null;

  @Column('boolean', { name: 'signed_toc', nullable: true })
  signedToc: boolean | null;

  @Column('boolean', { name: 'signed_marketing', nullable: true })
  signedMarketing: boolean | null;

  @Column('boolean', { name: 'signed_beneficiary_statement', nullable: true })
  signedBeneficiaryStatement: boolean | null;

  @Column('smallint', { name: 'beneficiary_statement', nullable: true })
  beneficiaryStatement: number | null;

  @Column('timestamp with time zone', {
    name: 'beneficiary_statement_signed_date',
    nullable: true,
  })
  beneficiaryStatementSignedDate: number;

  @Column('character varying', { name: 'id_card_number', nullable: true })
  idCardNumber: string | null;

  @Column('timestamp without time zone', {
    name: 'id_card_issue_date',
    nullable: true,
  })
  idCardIssueDate: Date | null;

  @Column('timestamp without time zone', {
    name: 'date_of_birth',
    nullable: true,
  })
  dateOfBirth: Date | null;

  // TODO: To be removed
  @Column('real', { name: 'profile_progress', nullable: true, precision: 24 })
  profileProgress: number | null;

  @Column('timestamp with time zone', {
    name: 'finq_risk_level_update_date',
    nullable: true,
  })
  finqRiskLevelUpdateDate: Date | null;

  @Column('boolean', { name: 'finq_risk_level_by_user', nullable: true })
  finqRiskLevelByUser: boolean | null;

  // TODO: To be removed
  @Column('timestamp with time zone', {
    name: 'contractual_agreement_signed_date',
    nullable: true,
  })
  contractualAgreementSignedDate: Date | null;

  @Column('character varying', { name: 'money_origin', nullable: true })
  moneyOrigin: string | null;

  @Column('integer', { name: 'investment_paths_groups_id', nullable: true })
  investmentPathsGroupsId: number | null;

  @Column('integer', { name: 'pricing_plan', nullable: true })
  pricingPlan: PricingPlanEnum;

  @Column('jsonb', { name: 'log_data', default: {}, nullable: true })
  logData: IUserLogData;

  @Column('character varying', { name: 'stripe_customer_id', nullable: true })
  stripeCustomerId: string | null;

  @Column('character varying', { name: 'verification_code', nullable: true })
  verificationCode: string | null;

  @Column('timestamp with time zone', { name: 'verification_code_date', nullable: true })
  verificationCodeDate: Date | null;

  @OneToMany(() => UserBankAccounts, (userBankAccounts) => userBankAccounts.user)
  userBankAccounts: UserBankAccounts[];

  @OneToMany(() => UserBankAccountsBalance, (type) => type.user)
  userBankAccountsBalances: UserBankAccountsBalance[];

  @OneToMany(() => UserBankAccountBalanceSummary, (type) => type.user)
  userBankAccountsBalancesSummaries: UserBankAccountBalanceSummary[];

  @OneToMany(() => UserBankAccountsTransactions, (userBankAccountsTransactions) => userBankAccountsTransactions.user)
  userBankAccountsTransactions: UserBankAccountsTransactions[];

  @OneToMany(() => UserDocuments, (userDocuments) => userDocuments.user)
  userDocuments: UserDocuments[];

  @OneToMany(() => UserKycAnswers, (userKycAnswers) => userKycAnswers.user)
  userKycAnswers: UserKycAnswers[];

  @OneToMany(() => UserKycAnswersHistory, (userKycAnswersHistory) => userKycAnswersHistory.user)
  userKycAnswersHistories: UserKycAnswersHistory[];

  @OneToMany(() => UserNotifications, (userNotifications) => userNotifications.user)
  userNotifications: UserNotifications[];

  @OneToMany(() => UserPartners, (userPartners) => userPartners.user)
  userPartners: UserPartners[];

  @OneToMany(() => UserPortfolioPendingRequests, (userPortfolioPendingRequests) => userPortfolioPendingRequests.user)
  userPortfolioPendingRequests: UserPortfolioPendingRequests[];

  @OneToMany(() => UserFavorite, (userFavorite) => userFavorite.user)
  userFavorite: UserFavorite[];

  @OneToMany(() => UserStages, (userStages) => userStages.user)
  userStages: UserStages[];

  @OneToMany(() => UserPayme, (userPayme) => userPayme.user)
  userPayme: UserPayme[];

  @OneToMany(() => UserStripe, (userStripe) => userStripe.user)
  userStripe: UserStripe[];

  @OneToMany(() => UserHubSpotContact, (type) => type.user)
  userHubSpotContact: UserHubSpotContact[];

  @OneToOne(() => UserIntercomContact, (type) => type.user)
  userIntercomContact: UserIntercomContact;

  @OneToMany(() => UserSession, (userSession) => userSession.user)
  userSessions: UserSession[];

  @ManyToOne(() => RefCountries, (refCountries) => refCountries.users)
  @JoinColumn([{ name: 'country_resident', referencedColumnName: 'id' }])
  countryResident: RefCountries;

  @ManyToOne(() => RefUserOccupations, (refUserOccupations) => refUserOccupations.users)
  @JoinColumn([{ name: 'occupation', referencedColumnName: 'id' }])
  occupation: RefUserOccupations;

  @OneToOne(() => UserDetails, (userDetails) => userDetails.user)
  userDetails: UserDetails;

  @OneToMany(() => UserEvent, (userEvents) => userEvents.user)
  userEvents: UserEvent[];

  @OneToMany(() => KycRespondentProgress, (userKycProgress) => userKycProgress.user)
  userKycProgress: KycRespondentProgress[];

  @OneToMany(() => UserRoles, (userRoles) => userRoles.user, { onDelete: 'CASCADE', onUpdate: 'CASCADE' })
  roles: UserRoles[];
}
