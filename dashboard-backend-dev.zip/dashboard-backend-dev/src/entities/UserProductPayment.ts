import { Column, Entity, ManyToOne, JoinColumn, PrimaryGeneratedColumn } from 'typeorm';
import { CombinedUserProduct } from './CombinedUserProduct';

@Entity('user_product_payment', { schema: 'public' })
export class UserProductPayment {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => CombinedUserProduct, (userProduct) => userProduct.payments)
  @JoinColumn({ name: 'user_product_id', referencedColumnName: 'id' })
  userProduct: CombinedUserProduct;

  @Column('character varying', { name: 'payment_status' })
  paymentStatus: string;

  @Column('character varying', { name: 'status_code' })
  statusCode: string;

  @Column('text', { name: 'status_details' })
  statusDetails: string;

  @Column('character varying', { name: 'sub_external_id' })
  subExternalId: string;

  @Column('character varying', { name: 'sub_external_code' })
  subExternalCode: string;

  @Column('date', { name: 'sub_created' })
  subCreated: Date;

  @Column('date', { name: 'sub_start_date' })
  subStartDate: Date;

  @Column('date', { name: 'sub_next_date' })
  subNextDate: Date;

  @Column('integer', { name: 'sub_status' })
  subStatus: number;

  @Column('integer', { name: 'sub_iteration_type' })
  subIterationType: number;

  @Column('character varying', { name: 'sub_currency' })
  subCurrency: string;

  @Column('double precision', { precision: 10, scale: 2, name: 'sub_price' })
  subPrice: number;

  @Column('integer', { name: 'sub_iterations' })
  subIterations: number;

  @Column('integer', { name: 'sub_iterations_completed' })
  subIterationsCompleted: number;

  @Column('integer', { name: 'sub_iterations_left' })
  subIterationsLeft: number;

  @Column('date', { name: 'sub_payment_date' })
  subPaymentDate: Date;

  @Column('character varying', { name: 'event_type' })
  eventType: string;

  @Column('date', { name: 'created_at' })
  createdAt: Date;

  @Column('jsonb', { name: 'payload' })
  payload: any;

  @Column('jsonb', { name: 'customer_external_details' })
  customerExternalDetails: any;
}
