import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { PortfolioGraph } from './PortfolioGraph';

@Index('ref_portfolio_graph_period_pk', ['id'])
@Entity('ref_portfolio_graph_period', { schema: 'public' })
export class RefPortfolioGraphPeriod {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he' })
  descriptionHe: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string;

  @Column('boolean', { name: 'is_active', nullable: true })
  isActive: boolean;

  @Column('integer', { name: 'display_order', nullable: true })
  displayOrder: number;

  @OneToMany(() => PortfolioGraph, (portfolioGraph) => portfolioGraph.graphPeriod)
  portfolioGraph: PortfolioGraph;
}
