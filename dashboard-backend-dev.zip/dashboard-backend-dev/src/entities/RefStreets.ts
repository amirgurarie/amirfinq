import { RefCities } from 'src/entities/RefCities';
import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Index('ref_streets_pk', ['id'], { unique: true })
@Entity('ref_streets', { schema: 'public' })
export class RefStreets {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('integer', { name: 'city_id', nullable: true })
  cityId: number | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('integer', { name: 'index_reference', nullable: true })
  indexReference: string | null;

  @Column('integer', { name: 'street_symbol', nullable: true })
  streetSymbol: string | null;

  @ManyToOne(() => RefCities, (refCities) => refCities.streets)
  @JoinColumn([{ name: 'city_id', referencedColumnName: 'id' }])
  refCities: RefCities;
}
