import { Column, Entity, Index, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { KycQuestionnaireChapter } from './KycQuestionnaireChapter';
import { KycRespondentProgress } from './kycRespondentProgress';

@Index('kyc_questionnaires_pk', ['id'], { unique: true })
@Entity('kyc_questionnaires', { schema: 'public' })
export class KycQuestionnaire {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('character varying', { name: 'key' })
  key: string;

  @OneToMany(() => KycQuestionnaireChapter, (kycChapter) => kycChapter.kycQuestionnaire)
  kycChapters: KycQuestionnaireChapter[];

  @OneToMany(() => KycRespondentProgress, (kycRespondentProgress) => kycRespondentProgress.kycQuestionnaire)
  kycRespondentProgresses: KycRespondentProgress[];
}
