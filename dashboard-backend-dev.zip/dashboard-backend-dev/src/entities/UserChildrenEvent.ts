import { Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { BaseEventEntity } from './BaseEventEntity';
import { UserChildrenDetails } from './UserChildrenDetails';

@Index('user_children_events_pk', ['id'], { unique: true })
@Entity('user_children_events', { schema: 'public' })
export class UserChildrenEvent extends BaseEventEntity {
  @ManyToOne(() => UserChildrenDetails, (user) => user.childrenEvents)
  @JoinColumn([{ name: 'child_id', referencedColumnName: 'id' }])
  childrenDetails?: UserChildrenDetails;
}
