import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { Users } from './Users';

@Index('user_bank_accounts_balance_pk', ['accountNumber', 'assetId', 'bankCode'], { unique: true })
@Entity('user_bank_accounts_balance', { schema: 'public' })
export class UserBankAccountsBalance {
  @Column('integer', { primary: true, name: 'bank_code' })
  bankCode: number;

  @Column('integer', { name: 'bank_branch' })
  bankBranch: number;

  @Column('character varying', { primary: true, name: 'account_number' })
  accountNumber: string;

  @Column('character varying', { primary: true, name: 'asset_id' })
  assetId: string;

  @Column('character varying', { name: 'balance_type', nullable: true })
  balanceType: string | null;

  @Column('double precision', {
    name: 'balance_amount',
    nullable: true,
    precision: 53,
  })
  balanceAmount: number | null;

  @Column('double precision', {
    name: 'avg_purchase_rate',
    nullable: true,
    precision: 53,
  })
  avgPurchaseRate: number | null;

  @Column('double precision', {
    name: 'rate_to_date',
    nullable: true,
    precision: 53,
  })
  rateToDate: number | null;

  @Column('double precision', {
    name: 'balance_value',
    nullable: true,
    precision: 53,
  })
  balanceValue: number | null;

  @Column('double precision', {
    name: 'profit_percentage',
    nullable: true,
    precision: 53,
  })
  profitPercentage: number | null;

  @Column('double precision', {
    name: 'asset_percentage',
    nullable: true,
    precision: 53,
  })
  assetPercentage: number | null;

  @Column('character varying', { name: 'isin', nullable: true })
  isin: string | null;

  @Column('timestamp with time zone', {
    name: 'creation_date',
    nullable: true,
    default: () => 'CURRENT_TIMESTAMP',
  })
  creationDate: Date | null;

  @Column('timestamp with time zone', { name: 'update_date', nullable: true })
  updateDate: Date | null;

  @Column('integer', { name: 'external_id', nullable: true })
  externalId: number | null;

  @Column('character varying', { name: 'status', nullable: true })
  status: string | null;

  @Column('character varying', { name: 'asset_type', nullable: true })
  assetType: string | null;

  @ManyToOne(() => Users, (users) => users.userBankAccountsBalances)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
