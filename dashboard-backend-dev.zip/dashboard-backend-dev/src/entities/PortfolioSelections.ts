import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { PortfolioSelectionDetails } from './PortfolioSelectionDetails';
import { RefProposalType } from './RefProposalType';
import { PortfolioSelectionFilters } from './PortfolioSelectionFilters';

@Index('portfolio_selections_pk', ['id'], { unique: true })
@Entity('portfolio_selections', { schema: 'public' })
export class PortfolioSelections {
  @Column('character varying', { primary: true, name: 'id' })
  id: number;

  @Column('real', { name: 'finq_risk_level', precision: 24 })
  finqRiskLevel: number;

  @Column('character varying', { name: 'proposal_sub_type', nullable: true })
  proposalSubType: string | null;

  @Column('double precision', {
    name: 'avg_yield_1_year',
    nullable: true,
    precision: 53,
  })
  avgYield_1Year: number | null;

  @Column('double precision', {
    name: 'stock_exposure',
    nullable: true,
    precision: 53,
  })
  stockExposure: number | null;

  @Column('character varying', { name: 'proposal_name_he', nullable: true })
  proposalNameHe: string | null;

  @Column('character varying', { name: 'proposal_name_en', nullable: true })
  proposalNameEn: string | null;

  @OneToMany(() => PortfolioSelectionDetails, (portfolioSelectionDetails) => portfolioSelectionDetails.portfolio)
  portfolioSelectionDetails: PortfolioSelectionDetails[];

  @ManyToOne(() => RefProposalType, (refProposalType) => refProposalType.portfolioSelections)
  @JoinColumn([{ name: 'proposal_type', referencedColumnName: 'id' }])
  proposalType: RefProposalType;

  @ManyToOne(
    () => PortfolioSelectionFilters,
    (portfolioSelectionFilters) => portfolioSelectionFilters.portfolioSelections,
  )
  @JoinColumn([{ name: 'selection_filter_id', referencedColumnName: 'id' }])
  selectionFilter: PortfolioSelectionFilters;
}
