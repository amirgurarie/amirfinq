import { Column, Entity, Index, OneToMany } from 'typeorm';
import { Users } from './Users';

@Index('ref_countries_pk', ['id'], { unique: true })
@Entity('ref_countries', { schema: 'public' })
export class RefCountries {
  @Column('bigint', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'country_code', nullable: true })
  countryCode: string | null;

  @OneToMany(() => Users, (users) => users.countryResident)
  users: Users[];
}
