import {
  FinancialSupport,
  GenderEnum,
  InvestmentsBackground,
  MoneySource,
  UserBeneficiaryOptions,
  UserContingentBeneficiaryOptions,
  UserEmployeeStatus,
  UserFamilyStatus,
  UserOtherBeneficiaries,
} from 'src/shared/enums';
import { Column, Entity, Index, JoinColumn, OneToMany, OneToOne, PrimaryColumn } from 'typeorm';
import { UserBeneficiariesDetails } from './UserBeneficiariesDetails';
import { UserChildrenDetails } from './UserChildrenDetails';
import { UserEmployerDetails } from './UserEmployerDetails';
import { UserIdentityVerification } from './UserIdentityVerification';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import { UserPensionMislakaQueries } from './UserPensionMislakaQueries';
import { Users } from './Users';
import { UserSpouseDetails } from './UserSpouseDetails';

@Index('user_details_pk', ['id'], { unique: true })
@Entity('user_details', { schema: 'public' })
export class UserDetails {
  @PrimaryColumn('uuid')
  id: string;

  @Column('character varying', { name: 'first_name', nullable: true, length: 60 })
  firstName: string | null;

  @Column('character varying', { name: 'last_name', nullable: true, length: 60 })
  lastName: string | null;

  @Column('character varying', { name: 'email', nullable: true, length: 255 })
  email: string | null;

  @Column('character varying', { name: 'phone_number', nullable: true, length: 20 })
  phoneNumber: string | null;

  @Column('character varying', { name: 'phone_number_country_code', nullable: true, length: 20 })
  phoneNumberCountryCode: string | null;

  @Column('date', { name: 'date_of_birth', nullable: true })
  dateOfBirth: Date | null;

  @Column('enum', { name: 'gender', nullable: true, enum: GenderEnum })
  genderPronoun: GenderEnum | null;

  @Column('character varying', { name: 'id_number', nullable: true, length: 255 })
  idNumber: string | null;

  @Column('date', { name: 'date_of_issue', nullable: true })
  dateOfIssue: Date | null;

  @Column('enum', { name: 'gender_by_identity_card', nullable: true, enum: GenderEnum })
  gender: GenderEnum | null;

  @Column('enum', { name: 'employee_status', nullable: true, enum: UserEmployeeStatus })
  employeeStatus: UserEmployeeStatus | null;

  @Column('boolean', { name: 'recent_employment_change', nullable: true })
  recentEmploymentChange: boolean | null;

  @Column('character varying', { name: 'job_occupation', nullable: true, length: 255 })
  jobOccupation: string | null;

  @Column('boolean', { name: 'public_position', nullable: true })
  publicPosition: boolean | null;

  @Column('boolean', { name: 'health_change', nullable: true })
  healthChange: boolean | null;

  @Column('boolean', { name: 'smoking', nullable: true })
  smoking: boolean | null;

  @Column('enum', { name: 'other_beneficiaries', nullable: true, enum: UserOtherBeneficiaries })
  otherBeneficiaries: UserOtherBeneficiaries | null;

  @Column('boolean', { name: 'refused_services', nullable: true })
  refusedServices: boolean | null;

  @Column('enum', { name: 'family_status', nullable: true, enum: UserFamilyStatus })
  familyStatus: UserFamilyStatus | null;

  @Column('integer', { name: 'children_amount', nullable: true })
  childrenAmount: number | null;

  @Column('enum', { name: 'financial_support', nullable: true, enum: FinancialSupport })
  financialSupport: FinancialSupport | null;

  @Column('enum', { name: 'investments_background', nullable: true, enum: InvestmentsBackground })
  investmentsBackground: InvestmentsBackground | null;

  @Column('integer', { name: 'investments_period', nullable: true })
  investmentsPeriod: number | null;

  @Column('integer', { name: 'response_strategy', nullable: true })
  responseStrategy: number | null;

  @Column('integer', { name: 'risk_tolerance_scenario', nullable: true })
  riskToleranceScenario: number | null;

  @Column('float8', { name: 'investment_risk', nullable: true })
  investmentRisk: number | null;

  @Column('integer', { name: 'investment_risk_level', nullable: true })
  investmentRiskLevel: number | null;

  @Column('float8', { name: 'pension_risk', nullable: true })
  pensionRisk: number | null;

  @Column('integer', { name: 'pension_risk_level', nullable: true })
  pensionRiskLevel: number | null;

  @Column('timestamp', { name: 'verification_date', nullable: true })
  verificationDate: number | null;

  @Column('timestamp', { name: 'disclaimer_ack_date', nullable: true })
  disclaimerAcknowledgmentDate: Date | null;

  @Column('character varying', { name: 'investments_purpose', nullable: true })
  investmentsPurpose: string | null;

  @Column('character varying', { name: 'investments_amount', nullable: true })
  investmentsAmount: string | null;

  @Column('character varying', { name: 'investments_economic', nullable: true })
  investmentsEconomic: string | null;

  @Column('character varying', { name: 'investments_lost', nullable: true })
  investmentsLost: string | null;

  @Column('character varying', { name: 'job_lost', nullable: true })
  jobLost: string | null;

  @Column('character varying', { name: 'age', nullable: true })
  age: string | null;

  @Column('character varying', { name: 'job_preference', nullable: true })
  jobPreference: string | null;

  @Column('character varying', { name: 'another_citizen', nullable: true })
  anotherCitizen: string | null;

  @Column('character varying', { name: 'usa_citizen', nullable: true })
  usaCitizen: string | null;

  @Column('character varying', { name: 'public_job', nullable: true })
  publicJob: string | null;

  @Column('character varying', { name: 'money_source', nullable: true })
  moneySource: MoneySource | null;

  @Column('boolean', { name: 'beneficiary_declared', nullable: true })
  beneficiaryDeclared: boolean | null;

  @Column('boolean', { name: 'beneficiary_declared_approved', nullable: true })
  beneficiaryDeclaredApproved: boolean | null;

  @Column('character varying', { name: 'city', nullable: true })
  city: string | null;

  @Column('character varying', { name: 'street', nullable: true })
  street: string | null;

  @Column('character varying', { name: 'house_number', nullable: true, length: 255 })
  houseNumber: string | null;

  @Column('character varying', { name: 'postal_code', nullable: true, length: 255 })
  postalCode: string | null;

  @Column('enum', { name: 'primary_beneficiary', nullable: true, enum: UserBeneficiaryOptions })
  primaryBeneficiary: string | null;

  @Column('enum', { name: 'contingent_beneficiary', nullable: true, enum: UserContingentBeneficiaryOptions })
  contingentBeneficiary: string | null;

  @Column('boolean', { name: 'signed_contract', nullable: true })
  signedContract: boolean;

  // Phase 2

  @Column('boolean', { name: 'significant_health_event', nullable: true })
  significantHealthEvent: boolean;

  @Column('boolean', { name: 'section_fourteen', nullable: true })
  sectionFourteen: boolean;

  @Column('float8', { name: 'pension_deposit_percentage', nullable: true })
  pensionDepositPercentage: number;

  @Column('boolean', { name: 'update_pension_deposit_percentage', nullable: true })
  updatePensionDepositPercentage: boolean;

  @Column('float8', { name: 'pension_provision_amount', nullable: true })
  pensionProvisionAmount: number;

  @Column('float8', { name: 'education_reported_salary', nullable: true })
  educationReportedSalary: number;

  @Column('boolean', { name: 'additional_allowance_or_pension', nullable: true })
  additionalAllowanceOrPension: boolean;

  @Column('float8', { name: 'additional_allowance_or_pension_amount', nullable: true })
  additionalAllowanceOrPensionAmount: number;

  @Column('integer', { name: 'aroya_person_id', nullable: true })
  aroyaPersonId: number;

  // Phase 3

  @Column('boolean', { name: 'occupation_lifestyle_risks', nullable: true })
  occupationLifestyleRisks: boolean;

  @Column('character varying', { name: 'occupation_lifestyle_risks_explanation', nullable: true })
  occupationLifestyleRisksExplanation: string;

  @Column('boolean', { name: 'agreed_pension_required_terms', nullable: true })
  agreedPensionRequiredTerms: boolean;

  @Column('boolean', { name: 'extended_foreign_stay', nullable: true })
  extendedForeignStay: boolean;

  @Column('character varying', { name: 'extended_foreign_stay_country', nullable: true })
  extendedForeignStayCountry: string;

  @Column('text', { name: 'extreme_hobbies', nullable: true })
  extremeHobbies: string[];

  @Column('boolean', { name: 'air_worker', nullable: true })
  airWorker: boolean;

  @Column('character varying', { name: 'picture', nullable: true })
  picture: string;

  // Phase 3 - End

  @OneToOne(() => Users, (user) => user.userDetails)
  @JoinColumn([{ name: 'id', referencedColumnName: 'id' }])
  user: Users;

  @OneToOne(() => UserSpouseDetails, (spouse) => spouse.userDetails)
  spouse: UserSpouseDetails;

  @OneToOne(() => UserEmployerDetails, (employer) => employer.userDetails)
  employer: UserEmployerDetails;

  @OneToMany(() => UserBeneficiariesDetails, (beneficiary) => beneficiary.userDetails)
  beneficiaries: UserBeneficiariesDetails[];

  @OneToMany(() => UserChildrenDetails, (children) => children.userDetails)
  children: UserChildrenDetails[];

  @OneToMany(() => UserPensionMislakaPolicies, (userPensionMislakaPolicies) => userPensionMislakaPolicies.userDetails)
  mislakaPolicies: UserPensionMislakaPolicies[];

  @OneToMany(() => UserPensionMislakaQueries, (userPensionMislakaQueries) => userPensionMislakaQueries.userDetails)
  mislakaQueries: UserPensionMislakaQueries[];

  @OneToOne(() => UserIdentityVerification, (identityVerification) => identityVerification.userDetails)
  identityVerification: UserIdentityVerification;
}
