import { Column, Entity, Index } from 'typeorm';

@Index('user_waiting_list_notification_pk', ['email', 'notificationType'], { unique: true })
@Entity('user_waiting_list_notification', { schema: 'public' })
export class UserWaitingListNotification {
  @Column('character varying', { primary: true, name: 'email' })
  email: string;

  @Column('character varying', { primary: true, name: 'notification_type' })
  notificationType: string;

  @Column('timestamp without time zone', { name: 'notification_request_date' })
  notificationRequestDate: string | Date;
}
