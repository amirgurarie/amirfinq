import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { PensionRecommendationTypes } from 'src/finance/pensions/modules/portfolio/modules/recommendations/types/recommendations.namespace';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { FundPension } from './FundPension';
import { UserPensionRecommendationCombinations } from './UserPensionRecommendationsCombinations';
import { UserPensionRecommendationCombinationHoldingSimulations } from './UserPensionRecommendationsCombinationsHoldingsSimulations';
import { UserPensionRecommendationHoldings } from './UserPensionRecommendationsTransactionsHoldings';

export abstract class BaseRecommendationCombinationHoldingEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'combination_holding_id' })
  id: string;

  @Column('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @Column('uuid', { name: 'combination_id', nullable: false })
  combinationId: string;

  // Keep this here, used for leftJoinAndMapOne
  latestSimulation: UserPensionRecommendationCombinationHoldingSimulations;
}

@Index('user_pension_recommendation_combination_current_holdings_pk', ['id'], { unique: true })
@Entity('user_pension_recommendation_combination_current_holdings', { schema: 'public' })
export class UserPensionRecommendationCombinationCurrentHoldings extends BaseRecommendationCombinationHoldingEntity {
  @Column('uuid', { name: 'transaction_holding_id', nullable: false })
  holdingId: string;

  @Column('boolean', { name: 'is_selected', nullable: false, default: true })
  isSelected: boolean;

  @Column({
    type: 'enum',
    name: 'practical_action',
    enum: PensionRecommendationTypes.Holding.PracticalActionsEnum,
    nullable: true,
  })
  practicalAction: PensionRecommendationTypes.Holding.PracticalActionsEnum | null;

  @ManyToOne(() => UserPensionRecommendationHoldings, (holding) => holding.combinationHoldings)
  @JoinColumn([{ name: 'transaction_holding_id', referencedColumnName: 'id' }])
  holding: UserPensionRecommendationHoldings;

  @ManyToOne(() => UserPensionRecommendationCombinations, (combination) => combination.currentHoldings)
  @JoinColumn([{ name: 'combination_id', referencedColumnName: 'id' }])
  combination: UserPensionRecommendationCombinations;

  @OneToMany(
    () => UserPensionRecommendationCombinationHoldingSimulations,
    (simulations) => simulations.currentHolding,
    {
      cascade: true,
    },
  )
  simulations: UserPensionRecommendationCombinationHoldingSimulations[];
}

@Index('user_pension_recommendation_combination_target_holdings_pk', ['id'], { unique: true })
@Entity('user_pension_recommendation_combination_target_holdings', { schema: 'public' })
export class UserPensionRecommendationCombinationTargetHoldings extends BaseRecommendationCombinationHoldingEntity {
  @Column({
    type: 'enum',
    name: 'product_category_id',
    enum: PensionCategoriesEnum,
    nullable: false,
  })
  productCategoryId: PensionCategoriesEnum;

  @Column('character varying', { name: 'fund_id', nullable: true })
  fundId: string | null;

  @Column('float', { name: 'accumulation_amount', nullable: true })
  accumulationAmount: number | null; // policy.currentSavings

  @Column('float', { name: 'monthly_deposit_amount', nullable: true })
  monthlyDepositAmount: number | null; // reportedSalary * policy provisions

  @Column('float', { name: 'accumulation_management_fee', nullable: true })
  accumulationManagementFee: number | null; // policy.accManagementFees

  @Column('float', { name: 'deposit_management_fee', nullable: true })
  depositManagementFee: number | null; // policy.depositManagementFees

  @Column('float', { name: 'reported_salary', nullable: true })
  reportedSalary: number | null; // policy.sacarMeduvach

  // TODO: remove - this column is not used
  @Column('float', { name: 'compensation_provision_percentage', nullable: true })
  compensationProvisionPercentage: number | null; // policy.compensationProvision

  // TODO: remove - this column is not used
  @Column('float', { name: 'employer_provision_percentage', nullable: true })
  employerProvisionPercentage: number | null; // policy.employerProvision

  // TODO: remove - this column is not used
  @Column('float', { name: 'employee_provision_percentage', nullable: true })
  employeeProvisionPercentage: number | null; // policy.employeeProvision

  @Column({ type: 'jsonb', name: 'holding_payload', nullable: true })
  payload: PensionRecommendationTypes.Holding.TargetPayload | null;

  @ManyToOne(() => FundPension, (fund) => fund.recommendationTargetHoldings)
  @JoinColumn([{ name: 'fund_id', referencedColumnName: 'fundId' }])
  fund: FundPension;

  @ManyToOne(() => UserPensionRecommendationCombinations, (combination) => combination.targetHoldings)
  @JoinColumn([{ name: 'combination_id', referencedColumnName: 'id' }])
  combination: UserPensionRecommendationCombinations;

  @OneToMany(() => UserPensionRecommendationCombinationHoldingSimulations, (simulations) => simulations.targetHolding, {
    cascade: true,
  })
  simulations: UserPensionRecommendationCombinationHoldingSimulations[];
}
