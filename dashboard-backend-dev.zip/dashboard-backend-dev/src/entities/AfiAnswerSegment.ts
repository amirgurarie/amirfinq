import { Column, Entity, Index } from 'typeorm';

@Index('afi_answer_segment_pk', ['id'], { unique: true })
@Entity('afi_answer_segment', { schema: 'public' })
export class AfiAnswerSegment {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'question_id', nullable: true })
  questionId: string | null;

  @Column('double precision', { name: 'from', nullable: true, precision: 53 })
  from: number | null;

  @Column('double precision', { name: 'to', nullable: true, precision: 53 })
  to: number | null;

  @Column('double precision', { name: 'min', nullable: true, precision: 53 })
  min: number | null;

  @Column('double precision', { name: 'max', nullable: true, precision: 53 })
  max: number | null;
}
