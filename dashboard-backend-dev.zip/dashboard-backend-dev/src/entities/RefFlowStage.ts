import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { RefFlow } from './RefFlow';
import { FlowStage } from 'src/flow-stages/flowStage.namespace';

@Entity('ref_flow_stages')
@Index('ref_flow_stages_pk', ['flowKey', 'stageKey'], { unique: true })
export class RefFlowStage {
  @PrimaryColumn({ name: 'flow_key', enum: FlowStage.FlowKey })
  flowKey: FlowStage.FlowKey;

  @PrimaryColumn({ name: 'stage_key', enum: FlowStage.StageKey })
  stageKey: FlowStage.StageKey;

  @Column({ name: 'stage_order' })
  stageOrder: number;

  @Column({
    name: 'is_active',
    type: 'boolean',
    default: true,
  })
  isActive: boolean;

  @ManyToOne(() => RefFlow, (flow) => flow.stages)
  @JoinColumn({
    name: 'flow_key',
    referencedColumnName: 'flowKey',
  })
  flow: RefFlow;
}
