import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';

@Index('user_pension_mislaka_policy_pension_insurance_coverages_pk', ['id'], { unique: true })
@Entity('user_pension_mislaka_policy_pension_insurance_coverages', { schema: 'public' })
export class UserPensionMislakaPolicyPensionInsuranceCoverage {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('integer', { name: 'policy_id', nullable: false })
  policyId: number;

  @Column('integer', { name: 'monthly_disability_allowance', nullable: true })
  monthlyDisabilityAllowance: number | null; // SACH-PENSIAT-NECHUTR

  @Column('integer', { name: 'monthly_disability_cost', nullable: true })
  disabilityMonthlyCost: number | null; // ALUT-KISUI-NECHUT

  @Column('integer', { name: 'monthly_sheerim_cost', nullable: true })
  sheerimMonthlyCost: number | null; // ALUT-KISUY-SHEERIM

  @Column('integer', { name: 'salary_rate', nullable: true })
  salaryRate: number | null; // SHEUR-KISUY-NECHUT

  @Column('boolean', { name: 'insurance_coverage_waiver', nullable: true })
  insuranceCoverageWaiver: boolean | null; // VITUR-KISUI-BITUCHI

  @Column('boolean', { name: 'disability_extension', nullable: true })
  disabilityExtension: boolean | null; // NECHUT-MITPATAHAT

  @Column('integer', { name: 'salary_for_disability_and_sheerim', nullable: true })
  salaryForDisabilityAndSheerim: number | null; // SACHAR-KOVEA-LE-NECHUT-VE-SHEERIM

  @Column('character varying', { name: 'sheerim_waiver_type', nullable: true })
  sheerimWaiverType: string | null; // SUG-VITOR-SHAERIM

  @Column('character varying', { name: 'sheerim_waiver_end_date', nullable: true })
  sheerimWaiverEndDate: Date | null; // TAARICH-CIUM-VITOR-SEERIM

  @Column('integer', { name: 'sheerim_widower_allowance', nullable: true })
  sheerimWidowerAllowance: number | null; // KITZBAT-SHEERIM-LEALMAN-O-ALMANA

  @Column('integer', { name: 'widower_coverage_rate', nullable: true })
  widowerCoverageRate: number | null; // SHIUR-KISUY-ALMAN-O-ALMANA

  @Column('integer', { name: 'sheerim_orphan_allowance', nullable: true })
  sheerimOrphanAllowance: number | null; // KITZBAT-SHEERIM-LEYATOM

  @Column('integer', { name: 'orphan_coverage_rate', nullable: true })
  orphanCoverageRate: number | null; // SHIUR-KISUY-YATOM

  @Column('integer', { name: 'sheerim_supported_parent_allowance', nullable: true })
  sheerimSupportedParentAllowance: number | null; // KITZBAT-SHEERIM-LEHORE-NITMACH

  @Column('integer', { name: 'supported_parent_coverage_rate', nullable: true })
  supportedParentCoverageRate: number | null; // SHIUR-KISUY-HORE-NITMACH

  @Column('float', { name: 'max_sheerim_allowance', nullable: true })
  maxSheerimAllowance: number | null; // KITZBAT-SHEERIM-LEALMAN-O-ALMANA + KITZBAT-SHEERIM-LEYATOM + KITZBAT-SHEERIM-LEHORE-NITMACH

  @Column('integer', { name: 'retirement_age', nullable: true })
  retirementAge: number | null; // GIL-PRISHA-LEPENSIYAT-ZIKNA

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: any | null;

  @Column('timestamp', { name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => UserPensionMislakaPolicies, (policy) => policy.insuranceCoverages, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'policy_id', referencedColumnName: 'id' })
  policy: UserPensionMislakaPolicies;
}
