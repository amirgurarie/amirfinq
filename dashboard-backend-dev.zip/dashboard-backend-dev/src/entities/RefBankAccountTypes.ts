import { Column, Entity, Index, OneToMany } from 'typeorm';
import { UserBankAccounts } from './UserBankAccounts';

@Index('ref_bank_account_types_pk', ['id'], { unique: true })
@Entity('ref_bank_account_types', { schema: 'public' })
export class RefBankAccountTypes {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @OneToMany(() => UserBankAccounts, (userBankAccounts) => userBankAccounts.accountType)
  userBankAccounts: UserBankAccounts[];
}
