import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { RefTradeLocations } from './RefTradeLocations';

@Index('ref_bizportal_trading_place_pk', ['bizportalTradingPlace'], {
  unique: true,
})
@Entity('ref_bizportal_trading_place', { schema: 'public' })
export class RefBizportalTradingPlace {
  @Column('character varying', {
    primary: true,
    name: 'bizportal_trading_place',
  })
  bizportalTradingPlace: string;

  @ManyToOne(() => RefTradeLocations, (refTradeLocations) => refTradeLocations.refBizportalTradingPlaces)
  @JoinColumn([{ name: 'trading_place_id', referencedColumnName: 'id' }])
  tradingPlace: RefTradeLocations;
}
