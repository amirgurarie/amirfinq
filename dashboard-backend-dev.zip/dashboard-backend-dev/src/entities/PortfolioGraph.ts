import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { RefPortfolioGraphPeriod } from './RefPortfolioGraphPeriod';

@Index('portfolio_graph_pk', ['selectionId'])
@Entity('portfolio_graph', { schema: 'public' })
export class PortfolioGraph {
  @Column('integer', { primary: true, name: 'selection_id' })
  selectionId: string;

  @Column('date', { name: 'selection_day' })
  selectionDay: Date;

  @Column('real', { name: 'total_amount', nullable: true, precision: 24 })
  totalAmount: number | null;

  @Column('real', { name: 'daily_change', nullable: true, precision: 24 })
  dailyChange: number | null;

  @ManyToOne(() => RefPortfolioGraphPeriod, (refPortfolioGraphPeriod) => refPortfolioGraphPeriod.portfolioGraph)
  @JoinColumn([{ name: 'graph_period', referencedColumnName: 'id' }])
  graphPeriod: RefPortfolioGraphPeriod[];
}
