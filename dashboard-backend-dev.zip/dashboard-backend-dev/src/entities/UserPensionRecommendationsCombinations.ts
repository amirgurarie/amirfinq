import { PensionRecommendationTypes } from 'src/finance/pensions/modules/portfolio/modules/recommendations/types/recommendations.namespace';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import {
  UserPensionRecommendationCombinationCurrentHoldings,
  UserPensionRecommendationCombinationTargetHoldings,
} from './UserPensionRecommendationsCombinationsHoldings';
import { UserPensionRecommendationTransactions } from './UserPensionRecommendationsTransactions';

@Index('user_pension_recommendation_combinations_pk', ['id', 'transactionId', 'hash'], { unique: true })
@Entity('user_pension_recommendation_combinations', { schema: 'public' })
export class UserPensionRecommendationCombinations {
  @PrimaryGeneratedColumn('uuid', { name: 'combination_id' })
  id: string;

  @Column('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @Column('uuid', { name: 'transaction_id', nullable: false })
  transactionId: string;

  @Column('text', { name: 'hash', nullable: false })
  hash: string;

  @Column('boolean', { name: 'is_selected', nullable: false, default: true })
  isSelected: boolean;

  @Column('float', { name: 'total_salary_deposit_amount', nullable: true })
  totalSalaryDepositAmount: number | null;

  @Column('float', { name: 'total_one_time_accumulation_amount', nullable: true })
  totalOneTimeAccumulationAmount: number | null;

  @Column('float', { name: 'total_monthly_deposit_amount', nullable: true })
  totalMonthlyDepositAmount: number | null;

  @Column('float', { name: 'compensation_provision_percentage', nullable: true })
  compensationProvisionPercentage: number | null;

  @Column('float', { name: 'compensation_provision_amount', nullable: true })
  compensationProvisionAmount: number | null;

  @Column('float', { name: 'employer_provision_percentage', nullable: true })
  employerProvisionPercentage: number | null;

  @Column('float', { name: 'employer_provision_amount', nullable: true })
  employerProvisionAmount: number | null;

  @Column('float', { name: 'employee_provision_percentage', nullable: true })
  employeeProvisionPercentage: number | null;

  @Column('float', { name: 'employee_provision_amount', nullable: true })
  employeeProvisionAmount: number | null;

  @Column({ type: 'jsonb', name: 'simulation_payload', nullable: true })
  simulation: PensionRecommendationTypes.Combination.SimulationPayload | null;

  @Column('timestamp', { name: 'created_at', default: () => 'now()' })
  createdAt: Date;

  @OneToMany(() => UserPensionRecommendationCombinationCurrentHoldings, (holdings) => holdings.combination, {
    cascade: true,
  })
  currentHoldings: UserPensionRecommendationCombinationCurrentHoldings[];

  @OneToMany(() => UserPensionRecommendationCombinationTargetHoldings, (holdings) => holdings.combination, {
    cascade: true,
  })
  targetHoldings: UserPensionRecommendationCombinationTargetHoldings[];

  @ManyToOne(() => UserPensionRecommendationTransactions, (transaction) => transaction.combinations, {
    onDelete: 'CASCADE',
  })
  @JoinColumn([{ name: 'transaction_id', referencedColumnName: 'id' }])
  transaction: UserPensionRecommendationTransactions;
}
