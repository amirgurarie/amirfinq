import { Column, Entity, Index, OneToMany } from 'typeorm';
import { UserDocuments } from './UserDocuments';

@Index('ref_documents_types_pk', ['id'], { unique: true })
@Entity('ref_documents_types', { schema: 'public' })
export class RefDocumentsTypes {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'document_group', nullable: true })
  documentGroup: string | null;

  @Column('character varying', { name: 'document_sub_group', nullable: true })
  documentSubGroup: string | null;

  @Column('character varying', { name: 'document_sub_group_order', nullable: true })
  documentSubGroupOrder: number;

  @OneToMany(() => UserDocuments, (userDocuments) => userDocuments.documentType)
  userDocuments: UserDocuments[];
}
