import { Column, Entity, Index, PrimaryColumn } from 'typeorm';

@Index('user_pension_risk_analytics_pk', ['userId', 'creationDate'], { unique: true })
@Entity('user_pension_risk_analytics', { schema: 'public' })
export class UserPensionRiskAnalytics {
  @PrimaryColumn('character varying', { name: 'user_id', primary: true })
  userId: string;

  @Column('timestamp with time zone', {
    name: 'creation_date',
    default: () => 'now()',
    primary: true,
  })
  creationDate: Date;

  @Column('date', { name: 'date_of_birth', nullable: false })
  dateOfBirth: Date;

  @Column('float', { name: 'age', nullable: false })
  age: number;

  @Column('integer', { name: 'response_strategy', nullable: true })
  responseStrategy: number;

  @Column('integer', { name: 'risk_tolerance_scenario', nullable: true })
  riskToleranceScenario: number;

  @Column('float', { name: 'user_pension_risk', nullable: false })
  userPensionRisk: number;

  @Column('float', { name: 'user_pension_risk_level', nullable: false })
  userPensionRiskLevel: number;
}
