import { Column, Entity, Index } from 'typeorm';

@Index('ref_pricing_plan_products_pk', ['id'], { unique: true })
@Entity('ref_pricing_plan_products', { schema: 'public' })
export class RefPricingPlanProducts {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'pricing_plan_id', nullable: false })
  pricingPlanId: string;

  @Column('character varying', { name: 'product_id', nullable: false })
  productId: string;

  @Column('boolean', { name: 'default_product', nullable: true })
  defaultProduct: boolean;
}
