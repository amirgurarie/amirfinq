import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { KycQuestionnaire } from './KycQuestionnaire';
import { Users } from './Users';

@Index('kyc_respondent_progress_pk', ['id'], { unique: true })
@Entity('kyc_respondent_progress', { schema: 'public' })
export class KycRespondentProgress {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ name: 'questionnaire_chapter_id' })
  kycChapterId: number;

  @Column({ name: 'questionnaire_page_id' })
  kycPageId: number;

  @Column({ name: 'phase' })
  phase: number;

  @Column({ name: 'status' })
  status: string;

  @ManyToOne(() => KycQuestionnaire, (kycQuestionnaire) => kycQuestionnaire.kycRespondentProgresses)
  @JoinColumn({ name: 'questionnaire_id', referencedColumnName: 'id' })
  kycQuestionnaire?: KycQuestionnaire;

  @ManyToOne(() => Users, (user) => user.userKycProgress)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user?: Users;
}
