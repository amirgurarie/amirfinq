import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { RefCities } from 'src/entities/RefCities';
import { RefInvestmentPathsGroups } from './RefInvestmentPathsGroups';

@Index('ref_investment_paths_pk', ['id'], { unique: true })
@Entity('ref_investment_paths', { schema: 'public' })
export class RefInvestmentPaths {
  @Column('integer', { name: 'id', primary: true })
  id: number;

  @Column('character varying', { name: 'name_he', nullable: true })
  nameHe: number | null;

  @Column('character varying', { name: 'name_en', nullable: true })
  nameEn: string | null;

  @Column('character varying', { name: 'subtitle_he', nullable: true })
  subtitleHe: string | null;

  @Column('character varying', { name: 'subtitle_en', nullable: true })
  subtitleEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'display_order', nullable: true })
  displayOrder: string | null;

  @Column('boolean', { name: 'is_finq_recommendation', nullable: true })
  isFinqRecommendation: boolean | null;

  @Column('character varying', { name: 'store_filter', nullable: true })
  storeFilter: string | null;

  @Column('character varying', { name: 'image_path_he', nullable: true })
  imagePathHe: string | null;

  @Column('character varying', { name: 'image_path_en', nullable: true })
  imagePathEn: string | null;

  @Column('boolean', { name: 'is_active', nullable: true })
  isActive: boolean | null;

  @ManyToOne(() => RefInvestmentPathsGroups, (type) => type.path)
  @JoinColumn([{ name: 'paths_groups_id', referencedColumnName: 'id' }])
  groups: RefInvestmentPathsGroups[] | null;
}
