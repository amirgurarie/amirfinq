import { Column, Entity } from 'typeorm';

@Entity('ref_fund_purity_type', { schema: 'public' })
export class RefFundPurityType {
  @Column('character varying', {
    primary: true,
    name: 'purity_type',
    nullable: true,
  })
  purityType: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;
}
