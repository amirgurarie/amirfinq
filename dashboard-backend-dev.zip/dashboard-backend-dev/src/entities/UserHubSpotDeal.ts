import { UserHubSpotContact } from 'src/entities/UserHubSpotContact';
import { ProductsEnum } from 'src/shared/enums';
import { OneToMany } from 'typeorm';
import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('user_hubspot_deal_pk', ['contactId', 'dealId'], { unique: true })
@Entity('user_hubspot_deal', { schema: 'public' })
export class UserHubSpotDeal {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'product_type', nullable: true })
  productType: ProductsEnum;

  @Column('character varying', { name: 'product_plan_code', nullable: true })
  productPlanCode?: string;

  @Column('character varying', { name: 'product_plan_pricing_type', nullable: true })
  productPlanPricingType?: string;

  @Column('character varying', { primary: true, name: 'deal_id', nullable: false })
  dealId?: string;

  @Column('character varying', { primary: true, name: 'contact_id', nullable: false })
  contactId?: string;

  @Column('integer', { name: 'user_product_id', nullable: true })
  userProductId?: number;

  @OneToMany(() => UserHubSpotContact, (type) => type.contactId)
  contact?: UserHubSpotContact;
}
