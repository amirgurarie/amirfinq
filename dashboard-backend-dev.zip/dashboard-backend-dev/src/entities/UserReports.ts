import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { RefUserReports } from './RefUserReports';
import { Users } from './Users';

@Index('user_reports_pk', ['id'], { unique: true })
@Entity('user_reports', { schema: 'public' })
export class UserReports {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @ManyToOne(() => Users, (users) => users.userStages)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @Column('timestamp with time zone', { name: 'report_date', nullable: true })
  reportDate: Date;

  @Column('character varying', { name: 'path', nullable: true })
  path: Date;

  @ManyToOne(() => RefUserReports, (refUserReports) => refUserReports.id)
  @JoinColumn([{ name: 'report_type', referencedColumnName: 'id' }])
  reportType: RefUserReports;
}
