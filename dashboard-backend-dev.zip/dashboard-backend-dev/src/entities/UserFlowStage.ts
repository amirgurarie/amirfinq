import { Entity, Column, ManyToOne, JoinColumn, PrimaryColumn, Index } from 'typeorm';
import { RefFlowStage } from './RefFlowStage';
import { FlowStage } from 'src/flow-stages/flowStage.namespace';

@Entity('user_flow_stages')
@Index('user_flow_stages_pk', ['flowKey', 'currentStage', 'createdAt', 'userId'], { unique: true })
export class UserFlowStage {
  @PrimaryColumn('uuid', { name: 'user_id' })
  userId: string;

  @PrimaryColumn({ name: 'flow_key', enum: FlowStage.FlowKey })
  flowKey: FlowStage.FlowKey;

  @PrimaryColumn({ name: 'current_stage', enum: FlowStage.StageKey })
  currentStage: FlowStage.StageKey;

  @Column({
    type: 'timestamp with time zone',
    name: 'created_at',
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt: Date;

  @Column({
    type: 'timestamp with time zone',
    name: 'updated_at',
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt: Date;

  @ManyToOne(() => RefFlowStage)
  @JoinColumn([
    {
      name: 'current_stage',
      referencedColumnName: 'stageKey',
    },
    {
      name: 'flow_key',
      referencedColumnName: 'flowKey',
    },
  ])
  refFlowStage: RefFlowStage;
}
