import { Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { BaseEventEntity } from './BaseEventEntity';
import { UserEmployerDetails } from './UserEmployerDetails';

@Index('user_employer_events_pk', ['id'], { unique: true })
@Entity('user_employer_events', { schema: 'public' })
export class UserEmployerEvent extends BaseEventEntity {
  @ManyToOne(() => UserEmployerDetails, (user) => user.userEmployerEvents)
  @JoinColumn([{ name: 'employer_id', referencedColumnName: 'id' }])
  employerDetails?: UserEmployerDetails;
}
