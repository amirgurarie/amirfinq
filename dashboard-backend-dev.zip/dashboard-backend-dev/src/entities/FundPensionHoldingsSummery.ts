import { Entity, Column, PrimaryGeneratedColumn, Index } from 'typeorm';

@Index('fund_pension_holdings_summery_pk', ['id'], { unique: false })
@Entity('fund_pension_holdings_summery', { schema: 'public' })
export class FundPensionHoldingSummary {
  // FIX: This column doesnt exists on fund_pension_holdings_summery table
  @PrimaryGeneratedColumn()
  id: string;

  @Column('character varying', { name: 'sub_category', nullable: true })
  subCategory: string;

  @Column('character varying', { name: 'fund', nullable: true })
  fund: string;

  @Column('character varying', { name: 'category', nullable: true })
  category: string;

  @Column('double precision', { name: 'asset_value', nullable: true })
  assetValue: number;

  @Column('character varying', { name: 'asset_type', nullable: true })
  assetType: string;

  @Column('double precision', { name: 'asset_percentage', nullable: true })
  assetPercentage: number;
}
