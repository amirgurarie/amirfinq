import { Column, Entity, Index } from 'typeorm';

@Index('news_ticker_header_pk', ['msgId'], { unique: true })
@Entity('news_ticker_header', { schema: 'public' })
export class NewsTickerHeader {
  @Column('integer', { primary: true, name: 'msg_id' })
  msgId: number;

  @Column('smallint', { name: 'section_id', nullable: true })
  sectionId: number | null;

  @Column('character varying', { name: 'credit', nullable: true })
  credit: string | null;

  @Column('timestamp with time zone', { name: 'last_updated', nullable: true })
  lastUpdated: Date | null;

  @Column('timestamp with time zone', { name: 'msg_date', nullable: true })
  msgDate: Date | null;

  @Column('character varying', { name: 'msg_descriptor', nullable: true })
  msgDescriptor: string | null;

  @Column('character varying', { name: 'msg_header', nullable: true })
  msgHeader: string | null;
}
