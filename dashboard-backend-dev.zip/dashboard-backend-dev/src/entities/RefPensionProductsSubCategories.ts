import { Column, Entity, Index, OneToMany } from 'typeorm';
import { FundPension } from './FundPension';

@Index('ref_pension_products_sub_categories_pk', ['subCategoryCode'], { unique: true })
@Entity('ref_pension_products_sub_categories', { schema: 'public' })
export class RefPensionProductsSubCategories {
  @Column('character varying', { name: 'sub_category_code', primary: true })
  subCategoryCode: string | null;

  @Column('character varying', { name: 'sub_category_name', nullable: true })
  subCategoryName: string | null;

  @Column('character varying', { name: 'short_text', nullable: true })
  shortText: string | null;

  @Column('character varying', { name: 'long_text', nullable: true })
  longText: string | null;

  @Column('character varying', { name: 'icon', nullable: true })
  icon: string | null;

  @Column('bigint', { name: 'ui_order' })
  uiOrder: number;

  @OneToMany(() => FundPension, (fundPension) => fundPension.pensionSubcategory)
  funds: FundPension[];
}
