import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserBankAccounts } from './UserBankAccounts';

@Index('user_bank_account_partners_pk', ['id'], { unique: true })
@Entity('user_bank_account_partners', { schema: 'public' })
export class UserBankAccountPartners {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'first_name', nullable: true })
  firstName: string | null;

  @Column('character varying', { name: 'last_name', nullable: true })
  lastName: string | null;

  @Column('character varying', { name: 'company_number', nullable: true })
  companyNumber: string | null;

  @Column('character varying', { name: 'card_id', nullable: true })
  cardId: string | null;

  @Column('timestamp without time zone', {
    name: 'card_issue_date',
    nullable: true,
  })
  cardIssueDate: Date | null;

  @Column('integer', { name: 'city', nullable: true })
  city: number | null;

  @Column('character varying', { name: 'street', nullable: true })
  street: number | null;

  @Column('integer', { name: 'home_number', nullable: true })
  homeNumber: number | null;

  @Column('character varying', { name: 'postal_code', nullable: true })
  postalCode: string | null;

  @Column('character varying', { name: 'cell', nullable: true })
  cell: string | null;

  @Column('character varying', { name: 'email', nullable: true })
  email: string | null;

  @ManyToOne(() => UserBankAccounts, (userBankAccounts) => userBankAccounts.userBankAccountPartners)
  @JoinColumn([{ name: 'bank_account_id', referencedColumnName: 'id' }])
  bankAccount: UserBankAccounts;
}
