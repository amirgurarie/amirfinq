import { Column, CreateDateColumn, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import { DepositorTypeEnum, DepositTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';

@Index('user_pension_mislaka_policy_deposits_pk', ['policyId', 'createdAt'], { unique: true })
@Entity('user_pension_mislaka_policy_deposits', { schema: 'public' })
export class UserPensionMislakaPolicyDeposits {
  @PrimaryGeneratedColumn('increment', { name: 'id' })
  depositId: number;

  @Column('integer', { name: 'policy_id', nullable: false })
  policyId: number;

  @Column('date', { name: 'deposit_date', nullable: false })
  depositDate: Date;

  @Column('character varying', { name: 'deposit_type', nullable: false })
  depositType: DepositTypeEnum;

  @Column('character varying', { name: 'depositor_type', nullable: false })
  depositorType: DepositorTypeEnum;

  @Column('float4', { name: 'amount', nullable: false })
  amount: number;

  @Column('float4', { name: 'salary_basis', nullable: true })
  salaryBasis: number;

  @Column('date', { name: 'salary_month', nullable: true })
  salaryMonth: Date;

  @Column('date', { name: 'payment_month', nullable: true })
  paymentMonth: Date;

  @Column('character varying', { name: 'transferring_fund_id', nullable: true })
  transferringFundId: string;

  @Column('character varying', { name: 'transferring_fund_name', nullable: true })
  transferringFundName: string;

  @Column('character varying', { name: 'employer_id', nullable: true })
  employerId: string;

  @Column('character varying', { name: 'payer_name', nullable: true })
  payerName: string;

  @Column('jsonb', { name: 'additional_details', nullable: true })
  payload: any | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => UserPensionMislakaPolicies, (policy) => policy.deposits, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'policy_id', referencedColumnName: 'id' })
  policy: UserPensionMislakaPolicies;
}
