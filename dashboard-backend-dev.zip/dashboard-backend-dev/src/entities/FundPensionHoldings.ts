import { Entity, Column, Index, JoinColumn, ManyToOne } from 'typeorm';
import { FundPension } from './FundPension';

@Index('fund_pension_holdings_pk', ['fundId', 'assetId'], { unique: true })
@Entity('fund_pension_holdings', { schema: 'public' })
export class FundPensionHoldings {
  @Column('character varying', { name: 'fund_id', primary: true })
  fundId: string;

  @Column('character varying', { name: 'asset_id', primary: true })
  assetId: string;

  @Column('character varying', { name: 'asset_name' })
  assetName: string;

  @Column('double precision', { name: 'asset_percentage' })
  assetPercentage: number;

  @Column('character varying', { name: 'fund_name' })
  fundName: string;

  @Column('character varying', { name: 'sheet_name' })
  sheetName: string;

  @Column('character varying', { name: 'trade_location' })
  tradeLocation: string;

  @Column('character varying', { name: 'trade_location_code' })
  tradeLocationCode: string;

  @Column('character varying', { name: 'document_id' })
  documentId: string;

  @Column('character varying', { name: 'issuer_number' })
  issuerNumber: string;

  @Column('character varying', { name: 'asset_rate' })
  assetRate: string;

  @Column('character varying', { name: 'currency_type' })
  currencyType: string;

  @Column('double precision', { name: 'interest_rate' })
  interestRate: number;

  @Column('double precision', { name: 'yield_to_maturity' })
  yieldToMaturity: number;

  @Column('double precision', { name: 'market_value' })
  marketValue: number;

  @Column('double precision', { name: 'asset_percentage_sheet' })
  assetPercentageSheet: number;

  @Column('double precision', { name: 'avg_bond_duration' })
  avgBondDuration: number;

  @Column('double precision', { name: 'nominal_value' })
  nominalValue: number;

  @Column('double precision', { name: 'asset_price' })
  assetPrice: number;

  @Column('double precision', { name: 'nominal_value_rate' })
  nominalValueRate: number;

  @Column('character varying', { name: 'sector' })
  sector: string;

  @Column('character varying', { name: 'asset_type' })
  assetType: string;

  @Column('real', { name: 'sheet_number', nullable: true, precision: 24 })
  sheetNumber: number;

  @ManyToOne(() => FundPension, (type) => type.fundPensionHoldings)
  @JoinColumn({ name: 'fund_id', referencedColumnName: 'fundId' })
  fundPension: FundPension;
}
