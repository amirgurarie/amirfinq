import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('funds_history_fund_id_idx', ['fundId', 'tradeDate'], {})
@Index('funds_history_pk', ['id'], { unique: true })
@Index('funds_history_update_date_idx', ['tradeDate'], {})
@Entity('funds_history', { schema: 'public' })
export class FundsHistory {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'fund_id', nullable: true })
  fundId: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('double precision', { name: 'price', nullable: true, precision: 53 })
  price: number | null;

  @Column('timestamp with time zone', { name: 'trade_date', nullable: true })
  tradeDate: Date | null;

  @Column('double precision', {
    name: 'yield_1_year',
    nullable: true,
    precision: 53,
  })
  yield_1Year: number | null;

  @Column('double precision', {
    name: 'yield_3_years',
    nullable: true,
    precision: 53,
  })
  yield_3Years: number | null;

  @Column('double precision', {
    name: 'yield_5_years',
    nullable: true,
    precision: 53,
  })
  yield_5Years: number | null;

  @Column('double precision', {
    name: 'daily_price_change',
    nullable: true,
    precision: 53,
  })
  dailyPriceChange: number | null;

  @Column('double precision', {
    name: 'momentum',
    nullable: true,
    precision: 53,
  })
  momentum: number | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;
}
