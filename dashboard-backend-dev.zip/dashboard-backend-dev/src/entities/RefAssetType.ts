import { Column, Entity, Index, OneToMany } from 'typeorm';
import { Assets } from './Assets';
import { PortfolioSelectionDetails } from './PortfolioSelectionDetails';
import { UserPortfolioPendingRequestDetails } from './UserPortfolioPendingRequestDetails';
import { UserFavoriteDetails } from './UserFavoriteDetails';
import { UserFavorite } from './UserFavorite';

@Index('ref_asset_type_pk', ['id'], { unique: true })
@Entity('ref_asset_type', { schema: 'public' })
export class RefAssetType {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @OneToMany(() => Assets, (assets) => assets.assetType)
  assets: Assets[];

  @OneToMany(() => PortfolioSelectionDetails, (portfolioSelectionDetails) => portfolioSelectionDetails.assetType)
  portfolioSelectionDetails: PortfolioSelectionDetails[];

  @OneToMany(
    () => UserPortfolioPendingRequestDetails,
    (userPortfolioPendingRequestDetails) => userPortfolioPendingRequestDetails.assetType,
  )
  userPortfolioPendingRequestDetails: UserPortfolioPendingRequestDetails[];

  @OneToMany(
    () => UserFavoriteDetails,
    (userProposalFavoriteAssetDetails) => userProposalFavoriteAssetDetails.assetType,
  )
  userProposalFavoriteAssetDetails: UserFavoriteDetails[];

  @OneToMany(() => UserFavorite, (userFavorite) => userFavorite.assetType)
  userFavorite: UserFavorite[];
}
