import { Column, Entity, Index } from 'typeorm';

@Index('ref_pension_products_finq_categories_pk', ['categoryCode'], { unique: true })
@Entity('ref_pension_products_finq_categories', { schema: 'public' })
export class RefPensionProductFinqCategories {
  @Column('character varying', { name: 'category_code', primary: true })
  categoryCode: string | null;

  @Column('character varying', { name: 'category_name', nullable: true })
  categoryName: string | null;

  @Column('character varying', { name: 'short_text', nullable: true })
  shortText: string | null;

  @Column('character varying', { name: 'long_text', nullable: true })
  longText: string | null;

  @Column('bigint', { name: 'ui_order', nullable: true })
  uiOrder: number;
}
