import { Users } from 'src/entities';
import { Column, Entity, Index, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';

@Index('user_intercom_contact_pk', ['contactId'], { unique: true })
@Entity('user_intercom_contact', { schema: 'public' })
export class UserIntercomContact {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'email', nullable: true })
  email: string;

  @Column('character varying', { name: 'contact_id', primary: true, nullable: false })
  contactId: string;

  @Column('character varying', { name: 'user_id', nullable: false })
  userId: string;

  @OneToOne(() => Users, (user) => user.userIntercomContact)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
