import { Column, Entity, Index, OneToMany } from 'typeorm';
import { Funds } from './Funds';

@Index('ref_fund_house_pk', ['id'], { unique: true })
@Entity('ref_fund_house', { schema: 'public' })
export class RefFundHouse {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'fund_house', nullable: true })
  fundHouse: string | null;

  @Column('character varying', { name: 'logo', nullable: true })
  logo: string | null;

  @Column('character varying', { name: 'logo_150', nullable: true })
  logo150: string | null;

  @Column('smallint', { name: 'filter_order', nullable: true })
  filterOrder: number | null;

  @Column('integer', { name: 'ui_order', nullable: true })
  uiOrder: number | null;

  @Column('character varying', { name: 'external_fund_house', nullable: true })
  externalFundHouse: string | null;

  @Column('character varying', { name: 'fund_house_en', nullable: true })
  fundHouseEn: string | null;

  @Column('boolean', { name: 'local_trade', nullable: true })
  localTrade: boolean | null;

  @OneToMany(() => Funds, (funds) => funds.fundHouse)
  funds: Funds[];
}
