import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, OneToOne } from 'typeorm';
import { AssetAnalytics } from './AssetAnalytics';
import { AssetsLogo } from './AssetsLogo';
import { RefAssetType } from './RefAssetType';
import { RefCurrency } from './RefCurrency';
import { RefSectors } from './RefSectors';
import { RefTradeLocations } from './RefTradeLocations';
import { StocksRanking } from './StocksRanking';

@Index('assets_pk', ['id'], { unique: true })
@Entity('assets', { schema: 'public' })
export class Assets {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'isin', nullable: true })
  isin: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'company_description_en', nullable: true })
  companyDescriptionEn: string | null;

  @Column('character varying', { name: 'company_description_he', nullable: true })
  companyDescriptionHe: string | null;

  @Column('double precision', {
    name: 'current_price',
    nullable: true,
    precision: 53,
  })
  currentPrice: number | null;

  @Column('double precision', { name: 'yield', nullable: true, precision: 53 })
  yield: number | null;

  @Column('character varying', { name: 'asset_linkage', nullable: true })
  assetLinkage: string | null;

  @Column('double precision', {
    name: 'duration',
    nullable: true,
    precision: 53,
  })
  duration: number | null;

  @Column('character varying', { name: 'asset_issuer', nullable: true })
  assetIssuer: string | null;

  @Column('double precision', { name: 'pe', nullable: true, precision: 53 })
  pe: number | null;

  @Column('double precision', { name: 'pe_current', nullable: true, precision: 53 })
  peCurrent: number | null;

  @Column('double precision', { name: 'pe_5_years_avg', nullable: true, precision: 53 })
  pe5YearsAvg: number | null;

  @Column('double precision', { name: 'pb', nullable: true, precision: 53 })
  pb: number | null;

  @Column('double precision', { name: 'pb_5_years_close', nullable: true, precision: 53 })
  pb5YearsClose: number | null;

  @Column('double precision', { name: 'ps', nullable: true, precision: 53 })
  ps: number | null;

  @Column('double precision', { name: 'ps_current', nullable: true, precision: 53 })
  psCurrent: number | null;

  @Column('double precision', {
    name: 'esg_score',
    nullable: true,
    precision: 53,
  })
  esgScore: number | null;

  @Column('double precision', {
    name: 'yield_month12',
    nullable: true,
    precision: 53,
  })
  yieldMonth12: number | null;

  @Column('character varying', { name: 'none_grade_bond', nullable: true })
  noneGradeBond: string | null;

  @Column('character varying', { name: 'symbol', nullable: true })
  symbol: string | null;

  @Column('double precision', {
    name: 'daily_change',
    nullable: true,
    precision: 53,
  })
  dailyChange: number | null;

  @Column('double precision', {
    name: 'forward_price_earning',
    nullable: true,
    precision: 53,
  })
  forwardPriceEarning: number | null;

  @Column('double precision', {
    name: 'realtime_price',
    nullable: true,
    precision: 53,
  })
  realTimePrice: number | null;

  @Column('double precision', {
    name: 'realtime_price_change',
    nullable: true,
    precision: 53,
  })
  realTimePriceChange: number | null;

  @Column('double precision', { name: 'market_cap', nullable: true, precision: 53 })
  marketCap: number | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  // Return assetType as a string without the need to join the table
  @Column('character varying', { name: 'asset_type', nullable: true })
  type: RefAssetType;

  @Column('character varying', { name: 'orig_sector', nullable: true })
  origSector: string;

  @ManyToOne(() => RefAssetType, (refAssetType) => refAssetType.assets)
  @JoinColumn([{ name: 'asset_type', referencedColumnName: 'id' }])
  assetType: RefAssetType;

  @ManyToOne(() => RefCurrency, (refCurrency) => refCurrency.assets)
  @JoinColumn([{ name: 'currency', referencedColumnName: 'id' }])
  currency: RefCurrency;

  @ManyToOne(() => RefSectors, (refSectors) => refSectors.assets)
  @JoinColumn([{ name: 'sector', referencedColumnName: 'id' }])
  sector: RefSectors;

  @ManyToOne(() => RefTradeLocations, (refTradeLocations) => refTradeLocations.assets)
  @JoinColumn([{ name: 'trade_location', referencedColumnName: 'id' }])
  tradeLocation: RefTradeLocations;

  @OneToMany(() => StocksRanking, (type) => type.assets)
  stocksRanking: StocksRanking[];

  @OneToMany(() => AssetAnalytics, (type) => type.asset)
  assetAnalytics: AssetAnalytics[];

  // @OneToMany(() => AssetsHistory, (assetsHistory) => assetsHistory.asset)
  // assetsHistory: AssetsHistory[];

  @OneToOne(() => AssetsLogo, (assetsLogo) => assetsLogo.assets)
  assetsLogo: AssetsLogo;
}
