import { Column, Entity, ManyToOne, JoinColumn, Index, PrimaryGeneratedColumn } from 'typeorm';
import { ProductPlan } from './ProductPlan';
import { ProductTempTypes } from 'src/common/productTemp/types/productTemp.types';

@Index('product_plans_exclusivity_pk', ['id'], { unique: true })
@Entity('product_plans_exclusivity', { schema: 'public' })
export class ProductPlanExclusivity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('integer', { name: 'low_product_plan_id' })
  lowProductPlanId: number;

  @Column('integer', { name: 'high_product_plan_id' })
  highProductPlanId: number;

  @ManyToOne(() => ProductPlan, (productPlan) => productPlan.higherProductPlans)
  @JoinColumn({ name: 'low_product_plan_id', referencedColumnName: 'id' })
  lowProductPlan: ProductPlan;

  @ManyToOne(() => ProductPlan, (productPlan) => productPlan.lowerProductPlans)
  @JoinColumn({ name: 'high_product_plan_id', referencedColumnName: 'id' })
  highProductPlan: ProductPlan;
}
