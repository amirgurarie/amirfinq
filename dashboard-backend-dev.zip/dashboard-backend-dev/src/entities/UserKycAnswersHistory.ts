import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Users } from './Users';

@Index('user_kyc_answers_history_pk', ['id'], { unique: true })
@Entity('user_kyc_answers_history', { schema: 'public' })
export class UserKycAnswersHistory {
  @Column('character varying', { name: 'question_id', nullable: true })
  questionId: string | null;

  @Column('character varying', { name: 'answer_value', nullable: true })
  answerValue: string | null;

  @Column('character varying', { name: 'questionnaire_type', nullable: true })
  questionnaireType: string | null;

  @Column('date', { name: 'answer_date', nullable: true })
  answerDate: string | null;

  @Column('character varying', { name: 'group_id', nullable: true })
  groupId: string | null;

  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @ManyToOne(() => Users, (users) => users.userKycAnswersHistories)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
