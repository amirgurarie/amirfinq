import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Users } from './Users';

@Index('user_kyc_answers_pk', ['id'], { unique: true })
@Entity('user_kyc_answers', { schema: 'public' })
export class UserKycAnswers {
  @Column('character varying', { name: 'question_id' })
  questionId: string;

  @Column('character varying', { name: 'answer_value', nullable: true })
  answerValue: string | null;

  @Column('character varying', { name: 'questionnaire_type', nullable: true })
  questionnaireType: string | null;

  @Column('timestamp with time zone', { name: 'answer_date', nullable: true })
  answerDate: Date | null;

  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @ManyToOne(() => Users, (users) => users.userKycAnswers)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
