import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { InterestRateTypesEnum } from 'src/finance/pensions/modules/portfolio/modules/recommendations/modules/simulation/interfaces/simulation.interface';
import { PensionRecommendationTypes } from 'src/finance/pensions/modules/portfolio/modules/recommendations/types/recommendations.namespace';
import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
import {
  UserPensionRecommendationCombinationCurrentHoldings,
  UserPensionRecommendationCombinationTargetHoldings,
} from './UserPensionRecommendationsCombinationsHoldings';

@Index(
  'user_pension_recommendation_combination_holding_simulations_pk',
  ['requestId', 'userId', 'combinationHoldingId', 'combinationHoldingType'],
  {
    unique: false,
  },
)
@Entity('user_pension_recommendation_combination_holding_simulations', { schema: 'public' })
export class UserPensionRecommendationCombinationHoldingSimulations {
  @PrimaryGeneratedColumn('uuid', { name: 'recalc_id' })
  recalcId: string;

  @PrimaryColumn('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @PrimaryColumn('uuid', { name: 'request_id', nullable: false })
  requestId: string;

  @Column('uuid', { name: 'combination_holding_id', nullable: false })
  combinationHoldingId: string;

  @Column('enum', {
    name: 'combination_holding_type',
    enum: PensionRecommendationTypes.Holding.TypesEnum,
    nullable: false,
  })
  combinationHoldingType: PensionRecommendationTypes.Holding.TypesEnum;

  @Column({
    type: 'enum',
    name: 'product_category_id',
    enum: PensionCategoriesEnum,
    nullable: false,
  })
  productCategoryId: PensionCategoriesEnum;

  @Column('enum', { name: 'interest_rate_type', enum: InterestRateTypesEnum, nullable: false })
  interestRateType: InterestRateTypesEnum;

  @Column('float', { name: 'interest_rate', nullable: false })
  interestRate: number;

  @Column('float', { name: 'future_wealth', nullable: true })
  futureWealth: number | null; // total hon

  @Column('float', { name: 'future_allowance', nullable: true })
  futureAllowance: number | null; // total tzvira kitzba

  @Column('float', { name: 'monthly_future_allowance', nullable: true })
  monthlyFutureAllowance: number | null; // monthly kitzba

  @Column({ type: 'jsonb', name: 'simulation_payload', nullable: true })
  payload: PensionRecommendationTypes.Holding.SimulationPayload | null;

  @Column('timestamp', { name: 'created_at', default: () => 'now()' })
  createdAt: Date;

  @ManyToOne(() => UserPensionRecommendationCombinationCurrentHoldings, {
    onDelete: 'CASCADE',
    nullable: true,
  })
  @JoinColumn([{ name: 'combination_holding_id', referencedColumnName: 'id' }])
  currentHolding: UserPensionRecommendationCombinationCurrentHoldings;

  @ManyToOne(() => UserPensionRecommendationCombinationTargetHoldings, {
    onDelete: 'CASCADE',
    nullable: true,
  })
  @JoinColumn([{ name: 'combination_holding_id', referencedColumnName: 'id' }])
  targetHolding: UserPensionRecommendationCombinationTargetHoldings;
}
