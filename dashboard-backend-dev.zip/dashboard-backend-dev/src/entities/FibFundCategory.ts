import { Column, Entity } from 'typeorm';

@Entity('fib_fund_category', { schema: 'public' })
export class FibFundCategory {
  @Column('integer', { primary: true, name: 'id', nullable: true })
  id: number | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;
}
