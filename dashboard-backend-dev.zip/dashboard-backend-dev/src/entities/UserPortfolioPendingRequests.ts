import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { UserPortfolioPendingRequestDetails } from './UserPortfolioPendingRequestDetails';
import { RefPortfolioStatus } from './RefPortfolioStatus';
import { Users } from './Users';

@Index('user_portfolio_pending_requests_pk', ['id'], { unique: true })
@Entity('user_portfolio_pending_requests', { schema: 'public' })
export class UserPortfolioPendingRequests {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id?: number;

  @Column('timestamp with time zone', { name: 'request_date', nullable: true })
  requestDate: Date | null;

  @Column('character varying', { name: 'proposal_id', nullable: true })
  proposalId: string | null;

  @Column('character varying', { name: 'portfolio_id', nullable: true })
  portfolioId: string | null;

  @Column('character varying', { name: 'portfolio_type', nullable: true })
  portfolioType: string | null;

  @Column('character varying', { name: 'portfolio_sub_type', nullable: true })
  portfolioSubType: string | null;

  @Column('character varying', { name: 'portfolio_name_he', nullable: true })
  portfolioNameHe: string | null;

  @Column('character varying', { name: 'portfolio_name_en', nullable: true })
  portfolioNameEn: string | null;

  @Column('real', { name: 'finq_risk_level', nullable: true, precision: 24 })
  finqRiskLevel: number | null;

  @Column('double precision', {
    name: 'avg_yield_1_year',
    nullable: true,
    precision: 53,
  })
  avgYield_1Year: number | null;

  @Column('double precision', {
    name: 'stock_exposure',
    nullable: true,
    precision: 53,
  })
  stockExposure: number | null;

  @OneToMany(
    () => UserPortfolioPendingRequestDetails,
    (userPortfolioPendingRequestDetails) => userPortfolioPendingRequestDetails.pendingRequest,
  )
  userPortfolioPendingRequestDetails?: UserPortfolioPendingRequestDetails[];

  @Column('character varying', { name: 'request_status', nullable: true })
  requestStatus: string | null;

  @ManyToOne(() => Users, (users) => users.userPortfolioPendingRequests)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @Column('character varying', { name: 'request_asset_type', nullable: true })
  requestAssetType: string | null;

  @Column('character varying', { name: 'request_type', nullable: true })
  requestType?: string | null;

  @Column('double precision', { name: 'amount', nullable: true, precision: 53 })
  amount?: number | null;

  @Column('timestamp with time zone', {
    name: 'creation_date',
    nullable: true,
    default: () => 'CURRENT_TIMESTAMP',
  })
  creationDate?: Date | null;
}
