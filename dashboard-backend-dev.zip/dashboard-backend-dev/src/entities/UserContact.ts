import { Column, Entity } from 'typeorm';

@Entity('user_contact', { schema: 'public' })
export class UserContact {
  @Column('bigint', { primary: true, name: 'id' })
  id: string;

  @Column('bigint', { name: 'cell', nullable: true })
  cell: string | null;

  @Column('character varying', { name: 'city', nullable: true, length: 255 })
  city: string | null;

  @Column('character varying', { name: 'email', nullable: true, length: 255 })
  email: string | null;

  @Column('character varying', { name: 'street', nullable: true, length: 255 })
  street: number | null;

  @Column('integer', { name: 'street_number', nullable: true })
  streetNumber: number | null;

  @Column('integer', { name: 'zip_code', nullable: true })
  zipCode: number | null;

  @Column('uuid', { name: 'user_id', nullable: true })
  userId: string | null;
}
