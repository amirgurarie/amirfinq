import { Column, Entity, Index, OneToMany } from 'typeorm';
import { PortfolioSelections } from './PortfolioSelections';
import { UserFavorite } from './UserFavorite';

@Index('ref_proposal_type_pk', ['id'], { unique: true })
@Entity('ref_proposal_type', { schema: 'public' })
export class RefProposalType {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @OneToMany(() => PortfolioSelections, (portfolioSelections) => portfolioSelections.proposalType)
  portfolioSelections: PortfolioSelections[];

  @OneToMany(() => UserFavorite, (userFavorite) => userFavorite.proposalType)
  userFavorite: UserFavorite[];
}
