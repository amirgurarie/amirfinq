import { Column, Entity, Index } from 'typeorm';

@Index('ref_user_public_role_pk', ['id'], { unique: true })
@Entity('ref_user_public_role', { schema: 'public' })
export class RefUserPublicRole {
  @Column('smallint', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;
}
