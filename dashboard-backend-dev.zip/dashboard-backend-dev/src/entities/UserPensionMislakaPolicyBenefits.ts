import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';

@Index('user_pension_mislaka_policy_benefits_pk', ['beneficiaryId', 'policyId', 'createdAt'], { unique: true })
@Entity('user_pension_mislaka_policy_benefits', { schema: 'public' })
export class UserPensionMislakaPolicyBenefits {
  @PrimaryGeneratedColumn({ name: 'policy_beneficiary_id' })
  beneficiaryId: number;

  @PrimaryColumn('integer', { name: 'policy_id', nullable: false })
  policyId: number;

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: any | null;

  @Column('timestamp', { name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => UserPensionMislakaPolicies, (policy) => policy.benefits, { onDelete: 'CASCADE' })
  @JoinColumn([{ name: 'policy_id', referencedColumnName: 'id' }])
  policy: UserPensionMislakaPolicies;
}
