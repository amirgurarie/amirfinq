import { Column, Entity, Index, OneToMany } from 'typeorm';

@Index('ref_user_activities_pk', ['id'], { unique: true })
@Entity('ref_user_activities', { schema: 'public' })
export class RefUserActivities {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'type', nullable: true })
  type: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;
}
