import { Column, Entity, Index } from 'typeorm';

@Index('communication_channels_pkey', ['id'], { unique: true })
@Entity('communication_channels', { schema: 'public' })
export class CommunicationChannels {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'code', nullable: true, length: 255 })
  code: string | null;

  @Column('character varying', {
    name: 'description',
    nullable: true,
    length: 255,
  })
  description: string | null;
}
