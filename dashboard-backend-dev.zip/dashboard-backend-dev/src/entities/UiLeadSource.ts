import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('ui_lead_source_pk', ['id'], { unique: true })
@Entity('ui_lead_source', { schema: 'public' })
export class UiLeadSource {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'ref' })
  ref: string;

  @Column('character varying', { name: 'lead_source' })
  leadSource: string;

  @Column('character varying', { name: 'last_click_domain' })
  lastClickDomain: string;
}
