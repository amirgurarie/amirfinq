import { Entity, PrimaryGeneratedColumn, ManyToOne, JoinColumn, Index, CreateDateColumn } from 'typeorm';
import { Users } from './Users';
import { RefRoles } from './RefRoles';

@Index('user_roles_pk', ['id'], { unique: true })
@Entity('user_roles', { schema: 'public' })
export class UserRoles {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => Users, (user) => user.roles)
  @JoinColumn({ name: 'user_id', referencedColumnName: 'id' })
  user: Users;

  @ManyToOne(() => RefRoles, (role) => role.id)
  @JoinColumn({ name: 'role_id', referencedColumnName: 'id' })
  role: RefRoles;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;
}
