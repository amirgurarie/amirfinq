import { Column, Entity, Index } from 'typeorm';

@Index('investment_channels_cagr_pk', ['assetType', 'tradeLocation'], { unique: true })
@Entity('investment_channels_cagr', { schema: 'public' })
export class InvestmentChannelsCAGR {
  @Column('character varying', { name: 'asset_type', primary: true })
  assetType: string;

  @Column('character varying', { name: 'trade_location', primary: true })
  tradeLocation: string;

  @Column('double precision', { name: 'cagr', nullable: true, precision: 53 })
  CAGR: number | null;
}
