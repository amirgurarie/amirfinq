import { Column, Entity, Index } from 'typeorm';

@Index('fund_pension_yields_pk', ['id', 'reportPeriod'], { unique: true })
@Entity('fund_pension_yields', { schema: 'public' })
export class FundPensionYields {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'fund_name' })
  fundName: string;

  @Column('character varying', { name: 'fund_classification' })
  fundClassification: string;

  @Column('character varying', { name: 'controlling_corporation' })
  controllingCorporation: string;

  @Column('character varying', { name: 'managing_corporation' })
  managingCorporation: string;

  @Column('character varying', { name: 'target_population' })
  targetPopulation: string;

  @Column('character varying', { name: 'specialization' })
  specialization: string;

  @Column('character varying', { name: 'sub_specialization' })
  subSpecialization: string;

  @Column('character varying', { name: 'managing_corporation_legal_id' })
  managingCorporationLegalId: string;

  @Column('character varying', { name: 'fund_type' })
  fundType: string;

  @Column('character varying', { name: 'parent_company_id' })
  parentCompanyId: string;

  @Column('character varying', { name: 'parent_company_name' })
  parentCompanyName: string;

  @Column('double precision', { name: 'deposits' })
  deposits: number;

  @Column('double precision', { name: 'withdrawals' })
  withdrawals: number;

  @Column('double precision', { name: 'internal_transfers' })
  internalTransfers: number;

  @Column('double precision', { name: 'net_monthly_deposits' })
  netMonthlyDeposits: number;

  @Column('double precision', { name: 'total_assets' })
  totalAssets: number;

  @Column('double precision', { name: 'avg_annual_management_fee' })
  avgAnnualManagementFee: number;

  @Column('double precision', { name: 'avg_deposit_fee' })
  avgDepositFee: number;

  @Column('double precision', { name: 'monthly_yield' })
  monthlyYield: number;

  @Column('double precision', { name: 'year_to_date_yield' })
  yearToDateYield: number;

  @Column('double precision', { name: 'yield_trailing_3_yrs' })
  yieldTrailing3Yrs: number;

  @Column('double precision', { name: 'yield_trailing_5_yrs' })
  yieldTrailing5Yrs: number;

  @Column('double precision', { name: 'standard_deviation' })
  standardDeviation: number;

  @Column('double precision', { name: 'alpha' })
  alpha: number;

  @Column('double precision', { name: 'sharpe_ratio' })
  sharpeRatio: number;

  @Column('double precision', { name: 'liquid_assets_percent' })
  liquidAssetsPercent: number;

  @Column('double precision', { name: 'stock_market_exposure' })
  stockMarketExposure: number;

  @Column('double precision', { name: 'foreign_exposure' })
  foreignExposure: number;

  @Column('double precision', { name: 'foreign_currency_exposure' })
  foreignCurrencyExposure: number;

  @Column('double precision', { name: 'actuarial_adjustment' })
  actuarialAdjustment: number;

  @Column('date', { primary: true, name: 'report_period' })
  reportPeriod: string;

  @Column('date', { name: 'report_date' })
  reportDate: string;

  @Column('date', { name: 'inception_date' })
  inceptionDate: string;

  accumulatedYield?: number;
}
