import { Column, Entity, Index, OneToMany } from 'typeorm';
import { Assets } from './Assets';
import { RefBizportalSectors } from './RefBizportalSectors';

@Index('ref_sectors_pk', ['id'], { unique: true })
@Entity('ref_sectors', { schema: 'public' })
export class RefSectors {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'text_en', nullable: true })
  textEn: string | null;

  @Column('character varying', { name: 'text_he', nullable: true })
  textHe: string | null;

  @Column('character varying', { name: 'tipranks_sector', nullable: true })
  tipRanksSector: string | null;

  @Column('integer', { name: 'ui_order', nullable: true })
  uiOrder: number;

  @Column('character varying', { name: 'image_path', nullable: true })
  imagePath: string;

  @OneToMany(() => Assets, (assets) => assets.sector)
  assets: Assets[];

  @OneToMany(() => RefBizportalSectors, (refBizportalSectors) => refBizportalSectors.sector)
  refBizportalSectors: RefBizportalSectors[];
}
