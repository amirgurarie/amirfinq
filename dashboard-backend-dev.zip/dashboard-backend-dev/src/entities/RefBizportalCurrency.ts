import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { RefCurrency } from './RefCurrency';

@Index('ref_bizportal_currency_pk', ['bizportalCurrency'], { unique: true })
@Entity('ref_bizportal_currency', { schema: 'public' })
export class RefBizportalCurrency {
  @Column('character varying', { primary: true, name: 'bizportal_currency' })
  bizportalCurrency: string;

  @ManyToOne(() => RefCurrency, (refCurrency) => refCurrency.refBizportalCurrencies)
  @JoinColumn([{ name: 'currency_id', referencedColumnName: 'id' }])
  currency: RefCurrency;
}
