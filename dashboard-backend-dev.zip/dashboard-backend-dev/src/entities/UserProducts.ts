import { UserSubscriptions } from 'src/entities/UserSubscriptions';
import { RefProducts, Users } from 'src/entities';
import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';

@Index('user_products_pk', ['userId', 'productId'], { unique: true })
@Entity('user_products', { schema: 'public' })
export class UserProducts {
  @Column('character varying', { primary: true, name: 'user_id' })
  userId: string;

  @ManyToOne(() => Users, (users) => users.id)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @Column('character varying', { primary: true, name: 'product_id' })
  productId: string;

  @ManyToOne(() => RefProducts, (type) => type.id)
  @JoinColumn([{ name: 'product_id', referencedColumnName: 'id' }])
  product: RefProducts;

  @Column('character varying', { name: 'user_subscription_id' })
  subscriptionId: number;

  @ManyToOne(() => UserSubscriptions, (type) => type.id)
  @JoinColumn([{ name: 'user_subscription_id', referencedColumnName: 'id' }])
  subscription: UserSubscriptions;
}
