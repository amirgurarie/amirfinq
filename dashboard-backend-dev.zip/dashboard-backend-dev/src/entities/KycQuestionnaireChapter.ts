import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { KycQuestionnaire } from './KycQuestionnaire';
import { KycQuestionnairePage } from './KycQuestionnairePage';

@Index('kyc_questionnaire_chapters_pk', ['id'], { unique: true })
@Entity('kyc_questionnaire_chapters', { schema: 'public' })
export class KycQuestionnaireChapter {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('character varying', { name: 'key' })
  key: string;

  @Column('integer', { name: 'phase' })
  phase: number;

  @Column('bigint', { name: 'display_order' })
  displayOrder: number;

  @ManyToOne(() => KycQuestionnaire, (kycQuestionnaire) => kycQuestionnaire.kycChapters)
  @JoinColumn([{ name: 'questionnaire_id', referencedColumnName: 'id' }])
  kycQuestionnaire: KycQuestionnaire;

  @OneToMany(() => KycQuestionnairePage, (kycPage) => kycPage.kycChapter)
  kycPages: KycQuestionnairePage[];
}
