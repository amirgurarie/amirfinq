import { Column, Entity, Index, OneToMany } from 'typeorm';
import { PortfolioSelections } from './PortfolioSelections';

@Index('portfolio_selection_filters_pk', ['id'], { unique: true })
@Entity('portfolio_selection_filters', { schema: 'public' })
export class PortfolioSelectionFilters {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'filter_description', nullable: true })
  filterDescription: string | null;

  @Column('character varying', { name: 'filter_json', nullable: true })
  filterJson: string | null;

  @Column('timestamp with time zone', { name: 'last_update', nullable: true })
  lastUpdate: Date | null;

  @Column('integer', { name: 'counter', nullable: true })
  counter: number | null;

  @Column('character varying', { name: 'filter_status', nullable: true })
  filterStatus: string | null;

  @OneToMany(() => PortfolioSelections, (portfolioSelections) => portfolioSelections.selectionFilter)
  portfolioSelections: PortfolioSelections[];
}
