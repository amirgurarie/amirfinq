import { Column, Entity, Index, OneToMany } from 'typeorm';
import { UserNotifications } from './UserNotifications';

@Index('ref_notifications_types_pk', ['id'], { unique: true })
@Entity('ref_notifications_types', { schema: 'public' })
export class RefNotificationsTypes {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', {
    name: 'notification_template_id',
    nullable: true,
  })
  notificationTemplateId: string | null;

  @Column('character varying', { name: 'notification_group', nullable: true })
  notificationGroup: string | null;

  @Column('boolean', { name: 'show_on_screen', nullable: true })
  showOnScreen: boolean | null;

  @Column('boolean', { name: 'show_on_main_screen', nullable: true })
  showOnMainScreen: boolean | null;

  @Column('integer', { name: 'days_to_show_on_main_screen', nullable: true })
  daysToShowOnMainScreen: number | null;

  @Column('character varying', { name: 'text_he', nullable: true })
  textHe: string | null;

  @Column('character varying', { name: 'text_en', nullable: true })
  textEn: string | null;

  @Column('character varying', { name: 'short_text_he', nullable: true })
  shortTextHe: string | null;

  @Column('character varying', { name: 'short_text_en', nullable: true })
  shortTextEn: string | null;

  @Column('character varying', { name: 'detailed_text_he', nullable: true })
  detailedTextHe: string | null;

  @Column('character varying', { name: 'detailed_text_en', nullable: true })
  detailedTextEn: string | null;

  @Column('character varying', { name: 'header_text_he', nullable: true })
  headerTextHe: string | null;

  @Column('character varying', { name: 'header_text_en', nullable: true })
  headerTextEn: string | null;

  @OneToMany(() => UserNotifications, (type) => type.notificationType)
  userNotifications: UserNotifications[];
}
