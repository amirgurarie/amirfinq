import { Column, Entity, Index, OneToMany } from 'typeorm';
import { RefBankBranches } from './RefBankBranches';
import { UserBankAccounts } from './UserBankAccounts';

@Index('ref_banks_pk', ['id'], { unique: true })
@Entity('ref_banks', { schema: 'public' })
export class RefBanks {
  @Column('bigint', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string;

  @Column('integer', { name: 'ui_sort', nullable: true })
  uiSort: number;

  @Column('character varying', { name: 'logo', nullable: true })
  logo: string;

  @OneToMany(() => RefBankBranches, (refBankBranches) => refBankBranches.bankNumber)
  refBankBranches: RefBankBranches[];

  @OneToMany(() => UserBankAccounts, (userBankAccounts) => userBankAccounts.bank)
  userBankAccounts: UserBankAccounts[];
}
