import { PensionRecommendationTypes } from 'src/finance/pensions/modules/portfolio/modules/recommendations/types/recommendations.namespace';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionRecommendations } from './UserPensionRecommendations';
import { UserPensionRecommendationCombinations } from './UserPensionRecommendationsCombinations';
import { UserPensionRecommendationHoldings } from './UserPensionRecommendationsTransactionsHoldings';

@Index('user_pension_recommendation_transactions_pk', ['id'], { unique: true })
@Entity('user_pension_recommendation_transactions', { schema: 'public' })
export class UserPensionRecommendationTransactions {
  @PrimaryGeneratedColumn('uuid', { name: 'transaction_id' })
  id: string;

  @Column('uuid', { name: 'recommendation_id', nullable: false })
  recommendationId: string;

  @Column('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @Column('character varying', { name: 'title', nullable: true })
  title: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column({ type: 'enum', name: 'type', enum: PensionRecommendationTypes.Transaction.TypesEnum, nullable: false })
  type: PensionRecommendationTypes.Transaction.TypesEnum;

  @Column({ type: 'jsonb', name: 'transaction_payload', nullable: true })
  payload: PensionRecommendationTypes.Transaction.Payload | null;

  @ManyToOne(() => UserPensionRecommendations, (recommendation) => recommendation.transactions, {
    onDelete: 'CASCADE',
  })
  @JoinColumn([{ name: 'recommendation_id', referencedColumnName: 'id' }])
  recommendation: UserPensionRecommendations;

  @OneToMany(() => UserPensionRecommendationCombinations, (combination) => combination.transaction, {
    cascade: true,
  })
  combinations: UserPensionRecommendationCombinations[];

  @OneToMany(() => UserPensionRecommendationHoldings, (holding) => holding.transaction, {
    cascade: true,
  })
  holdings: UserPensionRecommendationHoldings[];

  // Keep this here, used for leftJoinAndMapOne
  selectedCombination: UserPensionRecommendationCombinations;
}
