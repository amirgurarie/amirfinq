import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { UserDetails } from './UserDetails';
import { PensionPortfolioExclusion } from 'src/finance/pensions/modules/portfolio/modules/exclusions/types/exclusions.enum';

@Index('pk_pension_mislaka_query_exclusions', ['userId', 'requestId', 'exception'], { unique: true })
@Entity('pension_mislaka_query_exclusions', { schema: 'public' })
export class UserPensionMislakaQueryExclusions {
  @PrimaryColumn('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @PrimaryColumn('uuid', { name: 'request_id', nullable: false, default: () => 'uuid_generate_v4()' })
  requestId: string;

  @PrimaryColumn('enum', { name: 'exception', nullable: false, enum: PensionPortfolioExclusion })
  exception: PensionPortfolioExclusion;

  @Column('timestamp with time zone', { name: 'created_at', nullable: false, default: () => 'now()' })
  createdAt: string;

  @ManyToOne(() => UserDetails, (user) => user.mislakaQueries)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails: UserDetails;
}
