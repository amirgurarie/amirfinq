import { Column, Entity, Index, PrimaryColumn } from 'typeorm';

@Index('user_investment_risk_scores_pk', ['userDetailsKey', 'userDetailsValue'], { unique: true })
@Entity('user_investment_risk_scores', { schema: 'public' })
export class UserInvestmentRiskScores {
  @PrimaryColumn('character varying', { name: 'user_details_key', primary: true })
  userDetailsKey: string;

  @Column('character varying', { name: 'user_details_value', primary: true })
  userDetailsValue: string;

  @Column('float', { name: 'user_investment_risk_score', nullable: false })
  userInvestmentRiskScore: number;
}
