import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Funds } from './Funds';

@Index('fund_dividend_pk', ['id'], { unique: true })
@Entity('fund_dividend', { schema: 'public' })
export class FundDividend {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('timestamp with time zone', { name: 'dividend_date', nullable: true })
  dividendDate: Date | null;

  @Column('double precision', { name: 'rate', nullable: true, precision: 53 })
  rate: number | null;

  @Column('double precision', { name: 'yield', nullable: true, precision: 53 })
  yield: number | null;

  @ManyToOne(() => Funds, (funds) => funds.fundDividends)
  @JoinColumn([{ name: 'fund_id', referencedColumnName: 'id' }])
  fund: Funds;
}
