import { Column, Entity, Index } from 'typeorm';

@Index('fund_pension_distribution_by_asset_type_pk', ['fundId', 'assetType', 'distributionGroup', 'itemCode'], {
  unique: true,
})
@Entity('fund_pension_distribution_by_asset_type', { schema: 'public' })
export class FundPensionDistributionByAssetType {
  @Column('character varying', { name: 'fund_id', primary: true })
  fundId: string | null;

  @Column('character varying', { name: 'distribution_group', primary: true })
  distributionGroup: string | null;

  @Column('character varying', { name: 'item_code', primary: true, nullable: true })
  itemCode: string | null;

  @Column('double precision', { name: 'item_percentage', nullable: true, precision: 53 })
  itemPercentage: number | null;

  @Column('character varying', { name: 'asset_type', primary: true, nullable: true })
  assetType: string;
}
