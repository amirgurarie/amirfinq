import { Column, Entity, Index, OneToMany } from 'typeorm';
import { Assets } from './Assets';
import { RefBizportalCurrency } from './RefBizportalCurrency';

@Index('ref_currency_pk', ['id'], { unique: true })
@Entity('ref_currency', { schema: 'public' })
export class RefCurrency {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @OneToMany(() => Assets, (assets) => assets.currency)
  assets: Assets[];

  @OneToMany(() => RefBizportalCurrency, (refBizportalCurrency) => refBizportalCurrency.currency)
  refBizportalCurrencies: RefBizportalCurrency[];
}
