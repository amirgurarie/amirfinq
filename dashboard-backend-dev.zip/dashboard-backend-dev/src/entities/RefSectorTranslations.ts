import { Column, Entity, Index } from 'typeorm';

@Index('ref_sector_translations_pk', ['sectorCombinationId'], { unique: true })
@Entity('ref_sector_translations', { schema: 'public' })
export class RefSectorTranslations {
  @Column('character varying', { primary: true, name: 'sector_combination_id' })
  sectorCombinationId: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;
}
