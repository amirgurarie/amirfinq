import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { RefDocumentsTypes } from './RefDocumentsTypes';
import { Users } from './Users';
import { UserDocumentsDetails } from './UserDocumentsDetails';

@Index('user_documents_pk', ['id'], { unique: true })
@Entity('user_documents', { schema: 'public' })
export class UserDocuments {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('integer', { name: 'partner_id', nullable: true })
  partnerId: number | null;

  @Column('timestamp with time zone', { name: 'update_date', nullable: true })
  updateDate: Date | null;

  @Column('boolean', { name: 'approved', nullable: true })
  approved: boolean | null;

  @ManyToOne(() => RefDocumentsTypes, (refDocumentsTypes) => refDocumentsTypes.userDocuments)
  @JoinColumn([{ name: 'document_type', referencedColumnName: 'id' }])
  documentType: RefDocumentsTypes;

  @ManyToOne(() => Users, (users) => users.userDocuments)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @OneToMany(() => UserDocumentsDetails, (userDocumentsDetails) => userDocumentsDetails.document)
  userDocumentsDetails: UserDocumentsDetails[];
}
