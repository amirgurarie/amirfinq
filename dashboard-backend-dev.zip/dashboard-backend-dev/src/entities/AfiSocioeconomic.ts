import { Column, Entity, Index } from 'typeorm';

@Index('afi_socioeconomic_pk', ['indexReference'], { unique: true })
@Entity('afi_socioeconomic', { schema: 'public' })
export class AfiSocioeconomic {
  @Column('bigint', { primary: true, name: 'index_reference' })
  indexReference: string;

  @Column('integer', { name: 'cluster10', nullable: true })
  cluster10: number | null;

  @Column('double precision', {
    name: 'points_index',
    nullable: true,
    precision: 53,
  })
  pointsIndex: number | null;

  @Column('integer', { name: 'cluster20', nullable: true })
  cluster20: number | null;
}
