import { Column, PrimaryGeneratedColumn } from 'typeorm';

export class BaseUserPortfolioDetails {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'asset_id', nullable: true })
  assetId: string | null;

  @Column('double precision', {
    name: 'asset_percentage',
    nullable: true,
    precision: 53,
  })
  assetPercentage: number | null;
}

export class BaseUserPortfolioDetailsWithPrice extends BaseUserPortfolioDetails {
  @Column('double precision', {
    name: 'asset_price',
    nullable: true,
    precision: 53,
  })
  assetPrice?: number | null;
}
