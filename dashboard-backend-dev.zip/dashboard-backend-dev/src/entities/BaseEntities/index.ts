// @index('./*', f => `export * from '${f.path}'`)
export * from './BaseUserPortfolioDetails';
