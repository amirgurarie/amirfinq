import { UserEventsEnum } from 'src/shared/enums';
import { Column, CreateDateColumn, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Users } from './Users';

export abstract class BaseEventEntity {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('character varying', { name: 'event_key' })
  eventKey: string;

  @Column('jsonb', { name: 'event_value' })
  eventValue: { value: any };

  @Column('character varying', { name: 'source' })
  source: UserEventsEnum;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => Users, (user) => user.userEvents)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
