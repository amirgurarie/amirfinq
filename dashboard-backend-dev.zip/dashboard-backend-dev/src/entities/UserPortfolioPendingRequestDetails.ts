import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { BaseUserPortfolioDetailsWithPrice } from './BaseEntities';
import { RefAssetType } from './RefAssetType';
import { UserPortfolioPendingRequests } from './UserPortfolioPendingRequests';

@Index('user_portfolio_pending_requests_details_pk', ['id'], { unique: true })
@Entity('user_portfolio_pending_request_details', { schema: 'public' })
export class UserPortfolioPendingRequestDetails extends BaseUserPortfolioDetailsWithPrice {
  @ManyToOne(() => RefAssetType, (refAssetType) => refAssetType.userPortfolioPendingRequestDetails)
  @JoinColumn([{ name: 'asset_type', referencedColumnName: 'id' }])
  assetType: RefAssetType;

  @ManyToOne(
    () => UserPortfolioPendingRequests,
    (userPortfolioPendingRequests) => userPortfolioPendingRequests.userPortfolioPendingRequestDetails,
  )
  @JoinColumn([{ name: 'pending_request_id', referencedColumnName: 'id' }])
  pendingRequest: UserPortfolioPendingRequests;

  @Column('character varying', { name: 'status', nullable: true })
  status: string | null;
}
