import { Column, CreateDateColumn, Entity, Index, JoinColumn, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserDetails } from './UserDetails';
import { UserIdentificationStatus } from '../shared/enums';

@Index('user_identity_verification_pk', ['id'], { unique: true })
@Entity('user_identity_verification', { schema: 'public' })
export class UserIdentityVerification {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('uuid', { name: 'user_id' })
  userId: string;

  @Column('character varying', { name: 'sale_external_id', nullable: true })
  saleExternalId: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @Column('timestamptz', { name: 'verification_date', nullable: true })
  verificationDate: Date | null;

  @Column('timestamptz', { name: 'verification_received_date', nullable: true })
  verificationReceivedDate: Date | null;

  @Column('enum', { name: 'status', nullable: true, enum: UserIdentificationStatus })
  status: UserIdentificationStatus | null;

  @OneToOne(() => UserDetails, (user) => user.identityVerification)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails: UserDetails;
}
