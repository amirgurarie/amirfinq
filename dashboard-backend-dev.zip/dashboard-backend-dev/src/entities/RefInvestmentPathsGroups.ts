import { Column, Entity, Index, OneToMany } from 'typeorm';
import { RefInvestmentPaths } from './RefInvestmentPaths';

@Index('ref_investment_paths_groups_pk', ['id'], { unique: true })
@Entity('ref_investment_paths_groups', { schema: 'public' })
export class RefInvestmentPathsGroups {
  @Column('integer', { name: 'id', primary: true })
  id: number;

  @Column('character varying', { name: 'description', nullable: true })
  description: number | null;

  @Column('double precision', { name: 'risk_from', nullable: true })
  riskFrom: string | null;

  @Column('double precision', { name: 'risk_to', nullable: true })
  riskTo: number | null;

  @Column('integer', { name: 'investment_amount_from', nullable: true })
  investmentAmountFrom: number | null;

  @Column('integer', { name: 'investment_amount_to', nullable: true })
  investmentAmountTo: number | null;

  @Column('smallint', { name: 'duration_from', nullable: true })
  durationFrom: number | null;

  @Column('smallint', { name: 'duration_to', nullable: true })
  durationTo: string | null;

  @OneToMany(() => RefInvestmentPaths, (type) => type.groups)
  path: RefInvestmentPaths[];
}
