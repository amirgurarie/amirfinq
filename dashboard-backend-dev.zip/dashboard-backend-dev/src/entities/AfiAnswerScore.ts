import { Column, Entity, Index } from 'typeorm';

@Index('afi_answer_score_pk', ['id'], { unique: true })
@Entity('afi_answer_score', { schema: 'public' })
export class AfiAnswerScore {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('double precision', { name: 'score', precision: 53 })
  score: number;

  @Column('character varying', { name: 'answer_id' })
  answerId: string;
}
