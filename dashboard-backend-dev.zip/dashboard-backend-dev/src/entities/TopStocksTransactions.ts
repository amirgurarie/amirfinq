import { VirtualColumn } from 'src/shared/decorators/virtualColumn.decorator';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToOne } from 'typeorm';
import { Assets } from './Assets';
import { StocksRanking } from './StocksRanking';
import { GeneralParameters } from './GeneralParameters';
import { TopStocksPortfolioYields } from './TopStocksPortfolioYields';

@Index('top_stocks_transactions_pk', ['portfolioId', 'assetId', 'transactionDate', 'transactionType'], { unique: true })
@Entity('top_stocks_transactions', { schema: 'public' })
export class TopStocksTransactions {
  @Column('character varying', { name: 'portfolio_id', primary: true })
  portfolioId: string;

  @Column('character varying', { name: 'asset_id', primary: true })
  assetId: string;

  @Column('double precision', { name: 'quantity', nullable: true, precision: 53 })
  quantity: number | null;

  @Column('double precision', { name: 'quantity_display', nullable: true, precision: 53 })
  quantityDisplay: number | null;

  @Column('double precision', { name: 'price', nullable: true, precision: 53 })
  price: number | null;

  @Column('character varying', { name: 'transaction_type', nullable: true, primary: true })
  transactionType: string | null;

  @Column('character varying', { name: 'transaction_type_display', nullable: true })
  transactionTypeDisplay: string | null;

  @Column('timestamp without time zone', { name: 'transaction_date', nullable: true, primary: true })
  transactionDate: string;

  @Column('integer', { name: 'asset_order', nullable: true })
  assetOrder: number | null;

  @Column('double precision', { name: 'profit_loss', nullable: true, precision: 53 })
  profitLoss: number | null;

  @Column('double precision', { name: 'asset_allocation', nullable: true, precision: 53 })
  assetAllocation: number | null;

  @Column('boolean', { name: 'rebalanced', nullable: true })
  rebalanced: boolean | null;

  @ManyToOne(() => StocksRanking, (stocksRanking) => stocksRanking.assetId)
  @JoinColumn([{ name: 'asset_id', referencedColumnName: 'assetId' }])
  asset: StocksRanking | null;

  @ManyToOne(() => GeneralParameters, (type) => type.topStocksTransactions)
  @JoinColumn([{ name: 'transaction_date', referencedColumnName: 'stockRankingDate' }])
  generalParameters: GeneralParameters;

  @ManyToOne(() => TopStocksPortfolioYields, (type) => type.portfolioTransactions)
  @JoinColumn([{ name: 'portfolio_id', referencedColumnName: 'portfolioId' }])
  portfolioYield: TopStocksPortfolioYields;
}
