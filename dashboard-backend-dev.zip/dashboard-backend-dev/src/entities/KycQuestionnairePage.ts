import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { KycQuestionnaireChapter } from './KycQuestionnaireChapter';

@Index('kyc_questionnaire_pages_pk', ['id'], { unique: true })
@Entity('kyc_questionnaire_pages', { schema: 'public' })
export class KycQuestionnairePage {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('character varying', { name: 'key' })
  key: string;

  @Column('bigint', { name: 'display_order' })
  displayOrder: number;

  @ManyToOne(() => KycQuestionnaireChapter, (kycChapter) => kycChapter.kycPages)
  @JoinColumn([{ name: 'questionnaire_chapter_id', referencedColumnName: 'id' }])
  kycChapter: KycQuestionnaireChapter;
}
