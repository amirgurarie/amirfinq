import { Column, Entity, Index } from 'typeorm';

@Index('fib_funds_statistics_pk', ['id'], { unique: true })
@Entity('fib_funds_statistics', { schema: 'public' })
export class FibFundsStatistics {
  @Column('character varying', { name: 'statistics_type', nullable: true })
  statisticsType: string | null;

  @Column('character varying', { name: 'finq_category', nullable: true })
  finqCategory: string | null;

  @Column('double precision', {
    name: 'deposit_exposure',
    nullable: true,
    precision: 53,
  })
  depositExposure: number | null;

  @Column('double precision', {
    name: 'gov_bond_exposure',
    nullable: true,
    precision: 53,
  })
  govBondExposure: number | null;

  @Column('double precision', {
    name: 'corp_bond_exposure',
    nullable: true,
    precision: 53,
  })
  corpBondExposure: number | null;

  @Column('double precision', {
    name: 'number_of_securities',
    nullable: true,
    precision: 53,
  })
  numberOfSecurities: number | null;

  @Column('double precision', {
    name: 'bond_avg_duration',
    nullable: true,
    precision: 53,
  })
  bondAvgDuration: number | null;

  @Column('double precision', {
    name: 'non_grade_bond_exposure',
    nullable: true,
    precision: 53,
  })
  nonGradeBondExposure: number | null;

  @Column('double precision', {
    name: 'foreign_currency_linked',
    nullable: true,
    precision: 53,
  })
  foreignCurrencyLinked: number | null;

  @Column('double precision', {
    name: 'cpi_linked',
    nullable: true,
    precision: 53,
  })
  cpiLinked: number | null;

  @Column('double precision', {
    name: 'local_currency_linked',
    nullable: true,
    precision: 53,
  })
  localCurrencyLinked: number | null;

  @Column('double precision', {
    name: 'daily_price_change',
    nullable: true,
    precision: 53,
  })
  dailyPriceChange: number | null;

  @Column('double precision', { name: 'pe', nullable: true, precision: 53 })
  pe: number | null;

  @Column('double precision', { name: 'pb', nullable: true, precision: 53 })
  pb: number | null;

  @Column('double precision', { name: 'ps', nullable: true, precision: 53 })
  ps: number | null;

  @Column('double precision', { name: 'esg', nullable: true, precision: 53 })
  esg: number | null;

  @Column('double precision', {
    name: 'momentum',
    nullable: true,
    precision: 53,
  })
  momentum: number | null;

  @Column('double precision', {
    name: 'yield_1_year',
    nullable: true,
    precision: 53,
  })
  yield_1Year: number | null;

  @Column('double precision', {
    name: 'yield_3_years',
    nullable: true,
    precision: 53,
  })
  yield_3Years: number | null;

  @Column('double precision', {
    name: 'yield_5_years',
    nullable: true,
    precision: 53,
  })
  yield_5Years: number | null;

  @Column('bigint', { primary: true, name: 'id' })
  id: string;
}
