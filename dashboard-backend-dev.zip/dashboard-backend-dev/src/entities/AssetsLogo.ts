import { GeneralParameters } from './GeneralParameters';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToOne, PrimaryColumn } from 'typeorm';
import { Assets } from './Assets';

@Index('assets_logo_pk', ['assetId'], { unique: true })
@Entity('assets_logo', { schema: 'public' })
export class AssetsLogo {
  @Column('character varying', {
    name: 'asset_id',
    primary: true,
  })
  assetId: string;

  @Column('character varying', {
    name: 'logo_path',
  })
  logoPath: Date;

  @OneToOne(() => Assets, (assets) => assets.assetsLogo)
  @JoinColumn([{ name: 'asset_id', referencedColumnName: 'id' }])
  assets: Assets;
}
