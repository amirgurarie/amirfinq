import { Column, Entity, Index } from 'typeorm';

@Index('gender_pkey', ['id'], { unique: true })
@Entity('gender', { schema: 'public' })
export class Gender {
  @Column('integer', { primary: true, name: 'id' })
  id: number;

  @Column('character varying', { name: 'code', nullable: true, length: 255 })
  code: string | null;

  @Column('character varying', {
    name: 'description',
    nullable: true,
    length: 255,
  })
  description: string | null;
}
