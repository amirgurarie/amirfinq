import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { UiKycAnswers } from './UiKycAnswers';
import { UiKycQuestionGroup } from './UiKycQuestionGroup';
import { RefUiType } from './RefUiType';
import { camelCase } from 'lodash';
import { isNullOrUndefined } from 'src/shared/helpers/utils';

@Index('ui_kyc_questions_pk', ['id'], { unique: true })
@Entity('ui_kyc_questions', { schema: 'public' })
export class UiKycQuestions {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', {
    name: 'description_he_female',
    nullable: true,
    length: 255,
  })
  descriptionHeFemale: string | null;

  @Column('boolean', { name: 'active', nullable: true })
  active: boolean | null;

  @Column('integer', { name: 'display_order' })
  displayOrder: number;

  @Column('boolean', { name: 'mandatory', nullable: true })
  mandatory: boolean | null;

  @Column('integer', { name: 'min_range', nullable: true })
  minRange: number | null;

  @Column('integer', { name: 'max_range', nullable: true })
  maxRange: number | null;

  @Column('character varying', { name: 'default_answer_value', nullable: true })
  defaultAnswerValue: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('character varying', { name: 'image', nullable: true })
  image: string | null;

  @Column('character varying', { name: 'description_he_male', nullable: true })
  descriptionHeMale: string | null;

  @Column('character varying', { name: 'prefix_en', nullable: true })
  prefixEn: string | null;

  @Column('character varying', { name: 'prefix_he', nullable: true })
  prefixHe: string | null;

  @Column('character varying', { name: 'suffix_en', nullable: true })
  suffixEn: string | null;

  @Column('character varying', { name: 'suffix_he', nullable: true })
  suffixHe: string | null;

  @Column('smallint', { name: 'stepper', nullable: true })
  stepper: number | null;

  @Column('character varying', {
    name: 'save_to_user',
    nullable: true,
    transformer: {
      to(value) {
        return value;
      },
      from(value) {
        if (value && !isNullOrUndefined(value)) {
          return camelCase(value);
        }

        return value;
      },
    },
  })
  saveToUser: string;

  @Column('character varying', { name: 'placeholder_en', nullable: true })
  placeholderEn: string | null;

  @Column('character varying', { name: 'placeholder_he_male', nullable: true })
  placeholderHeMale: string | null;

  @Column('character varying', {
    name: 'placeholder_he_female',
    nullable: true,
  })
  placeholderHeFemale: string | null;

  @OneToMany(() => UiKycAnswers, (uiKycAnswers) => uiKycAnswers.question)
  uiKycAnswers: UiKycAnswers[];

  @ManyToOne(() => UiKycQuestionGroup, (uiKycQuestionGroup) => uiKycQuestionGroup.uiKycQuestions)
  @JoinColumn([{ name: 'group_id', referencedColumnName: 'id' }])
  group: UiKycQuestionGroup;

  @ManyToOne(() => RefUiType, (refUiType) => refUiType.uiKycQuestions)
  @JoinColumn([{ name: 'ui_type', referencedColumnName: 'id' }])
  uiType: RefUiType;
}
