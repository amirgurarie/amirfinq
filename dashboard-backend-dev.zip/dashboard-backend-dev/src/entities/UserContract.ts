import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserDocuments } from './UserDocuments';

@Index('user_contract_pk', ['id'], { unique: true })
@Entity('user_contract', { schema: 'public' })
export class UserContract {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'user_id', nullable: true })
  userId: string | null;

  @Column('character varying', { name: 'cell', nullable: true })
  cell: string | null;

  @Column('character varying', { name: 'first_name', nullable: true })
  firstName: string | null;

  @Column('character varying', { name: 'last_name', nullable: true })
  lastName: string | null;

  @Column('character varying', { name: 'email', nullable: true })
  email: string | null;

  @Column('character varying', { name: 'id_card_number', nullable: true })
  idCardNumber: string | null;

  @Column('integer', { name: 'home_number', nullable: true })
  homeNumber: number | null;

  @Column('character varying', { name: 'city', nullable: true })
  city: string | null;

  @Column('character varying', { name: 'street', nullable: true })
  street: string | null;

  @Column('integer', { name: 'day', nullable: true })
  day: number | null;

  @Column('integer', { name: 'month', nullable: true })
  month: number | null;

  @Column('integer', { name: 'year', nullable: true })
  year: number | null;

  @Column('integer', { name: 'max_stock_exposure', nullable: true })
  maxStockExposure: number | null;

  @Column('integer', { name: 'max_foreign_currency_exposure', nullable: true })
  maxForeignCurrencyExposure: number | null;

  @Column('integer', { name: 'max_non_grade_bond_exposure', nullable: true })
  maxNonGradeBondExposure: number | null;

  @Column('timestamp with time zone', { name: 'creation_date', nullable: true })
  date: Date | null;

  @ManyToOne(() => UserDocuments, (userDocuments) => userDocuments)
  @JoinColumn([{ name: 'document_id', referencedColumnName: 'id' }])
  document: UserDocuments | null;
}
