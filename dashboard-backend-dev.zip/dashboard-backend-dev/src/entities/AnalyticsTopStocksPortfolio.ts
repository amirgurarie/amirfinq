import { GeneralParameters } from './GeneralParameters';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToOne, PrimaryColumn } from 'typeorm';
import { Assets } from './Assets';

@Index('analytics_top_stocks_portfolio_pk', ['assetId'], { unique: true })
@Entity('analytics_top_stocks_portfolio', { schema: 'public' })
export class AnalyticsTopStocksPortfolio {
  @Column('character varying', { name: 'portfolio_id', primary: true })
  portfolioId: string;

  @Column('character varying', { name: 'asset_id', primary: true })
  assetId: string;

  @Column('timestamp without time zone', { name: 'calculation_date', nullable: true })
  calculationDate: Date | null;

  @Column('double precision', { name: 'price', nullable: true, precision: 53 })
  yield: number | null;

  @Column('double precision', { name: 'price', nullable: true, precision: 53 })
  price: number | null;

  @Column('double precision', { name: 'price', nullable: true, precision: 53 })
  quantity: number | null;

  @Column('integer', { name: 'ranking_order', nullable: true })
  rankingOrder: number | null;
}
