import { Column, Entity } from 'typeorm';

@Entity('match_parameters', { schema: 'public' })
export class MatchParameters {
  @Column('character varying', {
    primary: true,
    name: 'param_name',
    nullable: true,
  })
  paramName: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('double precision', {
    name: 'param_value',
    nullable: true,
    precision: 53,
  })
  paramValue: number | null;
}
