import { Column, Entity, JoinColumn, ManyToOne } from 'typeorm';
import { RefSectors } from './RefSectors';

@Entity('ref_bizportal_sectors', { schema: 'public' })
export class RefBizportalSectors {
  @Column('character varying', { primary: true, name: 'bizportal_sector' })
  bizportalSector: string;

  @ManyToOne(() => RefSectors, (refSectors) => refSectors.refBizportalSectors)
  @JoinColumn([{ name: 'sector_id', referencedColumnName: 'id' }])
  sector: RefSectors;
}
