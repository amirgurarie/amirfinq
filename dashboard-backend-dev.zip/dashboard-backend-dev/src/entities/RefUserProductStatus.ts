import { Column, Entity, Index, PrimaryColumn } from 'typeorm';

/**
 *
 *
 * CURRENTLY NOT IN USE
 *
 */
@Index('ref_user_product_status_pk', ['id'], { unique: true })
@Entity('ref_user_product_status', { schema: 'public' })
export class RefUserProductStatus {
  @PrimaryColumn('character varying', { name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string;
}
