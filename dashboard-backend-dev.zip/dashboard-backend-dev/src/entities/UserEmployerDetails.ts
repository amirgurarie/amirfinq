import { Column, Entity, Index, JoinColumn, OneToMany, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserDetails } from './UserDetails';
import { UserEmployerEvent } from './UserEmployerEvent';

@Index('user_employer_details_pk', ['id'], { unique: true })
@Entity('user_employer_details', { schema: 'public' })
export class UserEmployerDetails {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('uuid', { name: 'user_id' })
  userId: string;

  @Column('character varying', { name: 'employer_name', nullable: true, length: 255 })
  employerName: string | null;

  @Column('character varying', { name: 'employer_identification_number', nullable: true, length: 255 })
  employerIdentificationNumber: string | null;

  @Column('character varying', { name: 'employer_address', nullable: true, length: 255 })
  employerAddress: string | null;

  @Column('character varying', { name: 'employer_contact_email', nullable: true, length: 255 })
  employerContactEmail: string | null;

  @Column('character varying', { name: 'employer_contact_name', nullable: true, length: 255 })
  employerContactName: string | null;

  @Column('character varying', { name: 'employer_contact_phone', nullable: true, length: 255 })
  employerContactPhone: string | null;

  @OneToOne(() => UserDetails, (user) => user.employer)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails?: UserDetails;

  @OneToMany(() => UserEmployerEvent, (userEmployerDetails) => userEmployerDetails.employerDetails)
  userEmployerEvents: UserEmployerEvent[];
}
