import { RefQuestionnaireType } from './RefQuestionnaireType';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { UiKycQuestionGroup } from './UiKycQuestionGroup';

@Index('ui_kyc_question_category_pk', ['id'], { unique: true })
@Entity('ui_kyc_question_category', { schema: 'public' })
export class UiKycQuestionCategory {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', {
    name: 'description_he',
    nullable: true,
    length: 255,
  })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('integer', { name: 'display_order' })
  displayOrder: number;

  @ManyToOne(() => RefQuestionnaireType, (type) => type.uiKycQuestionCategory)
  @JoinColumn([{ name: 'questionnaire_type', referencedColumnName: 'code' }])
  questionnaireType: RefQuestionnaireType;

  @OneToMany(() => UiKycQuestionGroup, (uiKycQuestionGroup) => uiKycQuestionGroup.category)
  uiKycQuestionGroups: UiKycQuestionGroup[];
}
