import { Column, Entity, Index } from 'typeorm';

@Index('ui_stock_portfolios_pk', ['id'], { unique: true })
@Entity('ui_stock_portfolios', { schema: 'public' })
export class UiStockPortfolios {
  @Column('character varying', { primary: true, name: 'portfolio_id' })
  id: string;

  @Column('character varying', { name: 'text_he', nullable: true })
  textHe: string;

  @Column('character varying', { name: 'text_en', nullable: true })
  textEn: string;

  @Column('character varying', { name: 'name_he', nullable: true })
  nameHe: string;

  @Column('character varying', { name: 'name_en', nullable: true })
  nameEn: string;

  @Column('integer', { name: 'display_order', nullable: true })
  displayOrder: number;

  @Column('integer', { name: 'asset_count', nullable: true })
  assetCount: number;

  @Column('double precision', { name: 'accumulated_yield', nullable: true, precision: 53 })
  accumulatedYield: number;
}
