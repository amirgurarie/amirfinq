import { Column, Entity, Index, OneToMany } from 'typeorm';
import { FundPension } from './FundPension';

@Index('ref_pension_products_secondary_categories_pk', ['subCategoryCode', 'secondaryCode'], { unique: true })
@Entity('ref_pension_products_secondary_categories', { schema: 'public' })
export class RefPensionProductsSecondaryCategories {
  @Column('character varying', { name: 'sub_category_code', primary: true })
  subCategoryCode: string | null;

  @Column('character varying', { name: 'secondary_code', primary: true, nullable: true })
  secondaryCode: string | null;

  @Column('character varying', { name: 'secondary_desc', nullable: true })
  secondaryDesc: string | null;

  @Column('character varying', { name: 'short_name', nullable: true })
  shortName: string | null;

  @Column('character varying', { name: 'long_name', nullable: true })
  longName: string | null;

  @Column('character varying', { name: 'id', nullable: true })
  id: string;

  @OneToMany(() => FundPension, (fundPension) => fundPension.fundSecondaryCategory)
  funds: FundPension[];
}
