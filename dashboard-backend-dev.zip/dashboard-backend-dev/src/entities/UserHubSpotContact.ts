import { Users } from 'src/entities';
import { UserHubSpotDeal } from 'src/entities/UserHubSpotDeal';
import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';

@Index('user_hubspot_contact_pk', ['contactId'], { unique: true })
@Entity('user_hubspot_contact', { schema: 'public' })
export class UserHubSpotContact {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'email', nullable: true })
  email: string;

  @Column('character varying', { name: 'contact_id', primary: true, nullable: false })
  contactId: string;

  @Column('character varying', { name: 'user_id', nullable: false })
  userId: string;

  @ManyToOne(() => Users, (users) => users.userHubSpotContact)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user?: Users;

  @ManyToOne(() => UserHubSpotDeal, (type) => type.contactId)
  @JoinColumn([{ name: 'contact_id', referencedColumnName: 'contactId' }])
  deals?: UserHubSpotDeal[];
}
