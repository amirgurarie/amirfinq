import { Column, Entity, Index, JoinColumn, OneToMany, OneToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserDetails } from './UserDetails';
import { UserSpouseEvent } from './UserSpouseEvent';

@Index('user_spouse_details_pk', ['id'], { unique: true })
@Entity('user_spouse_details', { schema: 'public' })
export class UserSpouseDetails {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('uuid', { name: 'user_id' })
  userId: string;

  @Column('character varying', { name: 'first_name' })
  firstName: string;

  @Column('character varying', { name: 'last_name' })
  lastName: string;

  @Column('character varying', { name: 'gender_by_identity_card' })
  gender: string;

  @Column('date', { name: 'date_of_birth' })
  dateOfBirth: Date;

  @Column('character varying', { name: 'id_card_number', unique: true, nullable: true })
  idNumber: string | null;

  @Column('character varying', { name: 'phone_number', nullable: true, length: 20 })
  phoneNumber: string | null;

  @Column('character varying', { name: 'phone_number_country_code', nullable: true, length: 20 })
  phoneNumberCountryCode: string | null;

  @OneToOne(() => UserDetails, (user) => user.spouse)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails?: UserDetails;

  @OneToMany(() => UserSpouseEvent, (userChildrenDetails) => userChildrenDetails.spouseDetails)
  userSpouseEvents: UserSpouseEvent[];
}
