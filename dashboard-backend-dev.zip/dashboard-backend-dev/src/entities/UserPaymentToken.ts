import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Users } from '.';
import { CombinedUserProduct } from './CombinedUserProduct';

@Index('user_payment_tokens_pk', ['id'], { unique: true })
@Entity('user_payment_tokens')
export class UserPaymentToken {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('uuid', { name: 'user_id' })
  userId: string;

  @Column('character varying', { name: 'token' })
  token: string;

  @Column('character varying', { name: 'card_mask' })
  cardMask: string;

  @Column('character varying', { name: 'card_exp' })
  cardExp: string;

  @Column('character varying', { name: 'seller_id', nullable: true })
  sellerId: string;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => Users)
  @JoinColumn({ name: 'user_id', referencedColumnName: 'id' })
  user: Users;

  @OneToMany(() => CombinedUserProduct, (combinedUserProduct) => combinedUserProduct.userPaymentToken)
  combinedUserProducts: CombinedUserProduct[];
}
