import { Column, Entity } from 'typeorm';

@Entity('ref_user_stages', { schema: 'public' })
export class RefUserStages {
  @Column('character varying', { primary: true, name: 'id', nullable: true })
  id: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;
}
