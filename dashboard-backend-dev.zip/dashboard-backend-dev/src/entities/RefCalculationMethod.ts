import { Column, Entity } from 'typeorm';

@Entity('ref_calculation_method', { schema: 'public' })
export class RefCalculationMethod {
  @Column('character varying', { primary: true, name: 'code' })
  code: string;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'calc_type', nullable: true })
  calcType: string | null;
}
