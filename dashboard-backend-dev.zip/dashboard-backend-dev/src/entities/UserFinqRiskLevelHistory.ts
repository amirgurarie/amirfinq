import { Column, Entity } from 'typeorm';

@Entity('user_finq_risk_level_history', { schema: 'public' })
export class UserFinqRiskLevelHistory {
  @Column('character varying', { name: 'user_id', nullable: true })
  userId: string;

  @Column('character varying', { name: 'finq_risk_level', nullable: true })
  finqRiskLevel: number;

  @Column('timestamp without time zone', { name: 'risk_level_changed_date', nullable: true, primary: true })
  riskLevelChangedDate: Date;

  @Column('boolean', { name: 'is_finq_risk_level_by_user', nullable: true })
  isFinqRiskLevelByUser: boolean;
}
