import { Column, Entity, Index, OneToMany } from 'typeorm';

@Index('ref_stock_rating_pk', ['id'], { unique: true })
@Entity('ref_stock_rating', { schema: 'public' })
export class RefStockRating {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('integer', { name: 'stock_order_from', nullable: true })
  stockOrderFrom: number;

  @Column('integer', { name: 'stock_order_to', nullable: true })
  stockOrderTo: number;
}
