import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { UserDetails } from './UserDetails';
import { PensionQueryUploadFormallyStatus } from 'src/finance/pensions/modules/PensionQueriesFormallyUploads/types/pensionQueriesFormallyStatus.enum';

@Index('unique_pension_mislaka_query_formally_upload', ['userId', 'requestId'], { unique: true })
@Entity('pension_mislaka_query_formally_uploads', { schema: 'public' })
export class UserPensionMislakaQueriesFormallyUploads {
  @PrimaryColumn('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @PrimaryColumn('uuid', { name: 'request_id', nullable: false })
  requestId: string;

  @Column('enum', { name: 'status', nullable: false, enum: PensionQueryUploadFormallyStatus })
  status: PensionQueryUploadFormallyStatus;

  @Column('timestamp with time zone', { name: 'start_date', nullable: true, default: () => 'now()' })
  startDate: string | null;

  @Column('timestamp with time zone', { name: 'last_try', nullable: true })
  lastTry: string | null;

  @Column('character varying', { name: 'error_message', nullable: true })
  errorMessage: string | null;

  @ManyToOne(() => UserDetails, (user) => user.mislakaQueries)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails: UserDetails;
}
