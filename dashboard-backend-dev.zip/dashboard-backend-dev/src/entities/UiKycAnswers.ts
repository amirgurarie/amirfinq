import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { UiKycQuestions } from './UiKycQuestions';
import { RefUiType } from './RefUiType';

@Index('ui_kyc_answers_pk', ['id'], { unique: true })
@Entity('ui_kyc_answers', { schema: 'public' })
export class UiKycAnswers {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', {
    name: 'question_id',
    nullable: true,
    length: 255,
  })
  questionId: string | null;

  @Column('character varying', {
    name: 'description_he_female',
    nullable: true,
    length: 255,
  })
  descriptionHeFemale: string | null;

  @Column('character varying', { name: 'description_he_male', nullable: true })
  descriptionHeMale: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('integer', { name: 'display_order' })
  displayOrder: number;

  @Column('character varying', { name: 'value' })
  value: string;

  @ManyToOne(() => UiKycQuestions, (uiKycQuestions) => uiKycQuestions.uiKycAnswers)
  @JoinColumn([{ name: 'question_id', referencedColumnName: 'id' }])
  question: UiKycQuestions;
}
