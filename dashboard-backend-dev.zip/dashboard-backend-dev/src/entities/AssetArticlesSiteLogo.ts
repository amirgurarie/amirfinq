import { Column, Entity, Index } from 'typeorm';

@Index('asset_articles_site_logo_pk', ['siteName'], { unique: true })
@Entity('asset_articles_site_logo', { schema: 'public' })
export class AssetArticlesSiteLogo {
  @Column('character varying', { name: 'logo_path', nullable: true })
  logoPath: string;

  @Column('character varying', { primary: true, name: 'site_name' })
  siteName: string;
}
