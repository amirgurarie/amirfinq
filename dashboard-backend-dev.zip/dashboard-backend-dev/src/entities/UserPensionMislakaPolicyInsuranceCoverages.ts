import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import {
  DevelopmentalDisabilityEnum,
  DiscountExistsEnum,
  DiscountTermsEnum,
  ExclusionTypeEnum,
  IndexLinkedPensionEnum,
  InsuranceAmountTypeEnum,
  InsuranceCoveragePayerEnum,
  InsuranceCoverageTypeEnum,
  InsuranceTypeOnManufacturerEnum,
  InsuredTypeEnum,
} from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { UserPensionMislakaPolicyBasicInsuranceCoverage } from './UserPensionMislakaPolicyBasicInsuranceCoverages';

@Index('user_pension_mislaka_policy_insurance_coverages_pk', ['id'], { unique: true })
@Entity('user_pension_mislaka_policy_insurance_coverages', { schema: 'public' })
export class UserPensionMislakaPolicyInsuranceCoverage {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('integer', { name: 'policy_id', nullable: false })
  policyId: number;

  @Column('character varying', { name: 'coverage_num_id', nullable: true })
  coverageNumId: string | null; // MISPAR-KISUI-BE-YATZRAN

  @Column('character varying', { name: 'insurance_coverage_name', nullable: true })
  insuranceCoverageName: string | null; // SHEM-KISUI-YATZRAN

  @Column('enum', { name: 'insurance_coverage_type', nullable: true, enum: InsuranceCoverageTypeEnum })
  insuranceCoverageType: InsuranceCoverageTypeEnum | null; // SUG-KISUY-BITOCHI

  @Column('character varying', { name: 'policy_number', nullable: true })
  policyNumber: string | null; // MISPAR-POLISA-O-HESHBON-NEGDI

  @Column('character varying', { name: 'customer_id', nullable: true })
  customerId: string | null; // MISPAR-ZIHUY-LAKOACH

  @Column('character varying', { name: 'insured_type', nullable: true })
  insuredType: InsuredTypeEnum | null; // SUG-MEVUTACH

  @Column('enum', { name: 'insurance_type', nullable: true, enum: InsuranceTypeOnManufacturerEnum })
  insuranceType: InsuranceTypeOnManufacturerEnum | null; // SUG-KISUI-ETZEL-YATZRAN

  @Column('timestamp', { name: 'coverage_start_date', nullable: true })
  coverageStartDate: Date | null; // TAARICH-TCHILAT-KISUY

  @Column('timestamp', { name: 'coverage_end_date', nullable: true })
  coverageEndDate: Date | null; // TAARICH-TOM-KISUY

  @Column('character varying', { name: 'coverage_appendix_code', nullable: true })
  coverageAppendixCode: string | null; // KOD-NISPACH-KISUY

  @Column('character varying', { name: 'occupation_type', nullable: true })
  occupationType: string | null; // SUG-ISUK

  @Column('boolean', { name: 'includes_franchise', nullable: true })
  includesFranchise: boolean | null;

  @Column('boolean', { name: 'includes_nursing', nullable: true })
  includesNursing: boolean | null;

  @Column('enum', { name: 'index_linked_pension', nullable: true, enum: IndexLinkedPensionEnum })
  indexLinkedPension: IndexLinkedPensionEnum | null; // KITZBA-ZMUDA-LAMADAD

  @Column('enum', { name: 'developing_disability', nullable: true, enum: DevelopmentalDisabilityEnum })
  developingDisability: DevelopmentalDisabilityEnum | null; // NACHUT-MITPATAHAT

  @Column('boolean', { name: 'government_subsidy_cancellation', nullable: true })
  governmentSubsidyCancellation: boolean | null;

  @Column('timestamp', { name: 'payment_end_date', nullable: true })
  paymentEndDate: Date | null; // TAARICH-HAFSAKAT-TASHLUM

  @Column('double precision', { name: 'basic_insurance_percentage', nullable: true })
  basicInsurancePercentage: number | null; // ACHUZ-ME-SCM-BTH-YESODI

  @Column('double precision', { name: 'salary_percentage', nullable: true })
  salaryPercentage: number | null; // ACHUZ-MESACHAR if bigger than 1 its "כפולות שכר"

  @Column('character varying', { name: 'insurance_payment_method', nullable: true })
  insurancePaymentMethod: string | null; // OFEN-TASHLUM-SCHUM-BITUACH

  @Column('double precision', { name: 'insurance_amount', nullable: true })
  insuranceAmount: number | null; // SCHUM-BITUACH

  @Column('double precision', { name: 'ceiling_amount', nullable: true })
  ceilingAmount: number | null; // TIKRAT-GAG-HATAM-LE-O-K-A

  @Column('double precision', { name: 'ceiling_increase_percentage', nullable: true })
  ceilingIncreasePercentage: number | null; // ACHUZ-HAGDALAT-GAG-HATAM-O-K-A

  @Column('enum', { name: 'insurance_coverage_payer', nullable: true, enum: InsuranceCoveragePayerEnum })
  insuranceCoveragePayer: InsuranceCoveragePayerEnum | null; // MESHALEM-HAKISUY

  @Column('double precision', { name: 'remaining_cost_until_end', nullable: true, precision: 15, scale: 2 })
  remainingCostUntilEnd: number | null; // Sum of PREMIA-ZFOYA from HitpatchutPremia

  @Column('integer', { name: 'external_kisuy_id', nullable: true })
  externalKisuyId: number | null; // ID_Kisuy from KisuyYesodi

  @Column('character varying', { name: 'exclusion_type', nullable: true })
  exclusionType: ExclusionTypeEnum | null; // SUG-HACHRAGA

  @Column('double precision', { name: 'monthly_payment', nullable: true, precision: 15, scale: 2 })
  monthlyPayment: number | null; // DMEI-BITUAH-LETASHLUM-BAPOAL

  @Column('character varying', { name: 'insurance_amount_type', nullable: true })
  insuranceAmountIndexType: InsuranceAmountTypeEnum | null; // SCHUM_SHEUR - Fixed sum or percentage

  @Column('character varying', { name: 'discount_exists', nullable: true })
  discountExists: DiscountExistsEnum | null; // HANACHA - Yes, No, Unknown

  @Column('character varying', { name: 'discount_terms', nullable: true })
  discountTerms: DiscountTermsEnum | null; // TNAEI-HANACHA - Type of discount terms

  @Column('integer', { name: 'training_period', nullable: true })
  trainingPeriod: number | null; // TKUFAT-ACHSHARA - Training period in months

  @Column('character varying', { name: 'personal_group_coverage', nullable: true })
  personalGroupCoverage: string | null; // KISUY-ISHY-KVOZATI - Personal group coverage

  @Column('integer', { name: 'waiting_period_months', nullable: true })
  waitingPeriodMonths: number | null; // TKUFAT-HAMTANA-CHODASHIM - Waiting period in months

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: any | null;

  @Column('timestamp', { name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => UserPensionMislakaPolicies, (policy) => policy.insuranceCoverages, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'policy_id', referencedColumnName: 'id' })
  policy: UserPensionMislakaPolicies;

  @OneToMany(() => UserPensionMislakaPolicyBasicInsuranceCoverage, (basicCoverage) => basicCoverage.insuranceCoverage)
  basicInsuranceCoverages: UserPensionMislakaPolicyBasicInsuranceCoverage[];
}
