import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

@Index('afi_calculation_result_pkey', ['id'], { unique: true })
@Entity('afi_calculation_result', { schema: 'public' })
export class AfiCalculationResult {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('uuid', { name: 'user_id' })
  userId: string;

  @Column('timestamp with time zone', {
    name: 'run_date',
    default: () => 'now()',
  })
  runDate: Date;

  @Column('double precision', {
    name: 'adjusted_regulated_risk_value',
    nullable: true,
    precision: 53,
  })
  adjustedRegulatedRiskValue: number | null;

  @Column('double precision', {
    name: 'regulated_risk_value',
    nullable: true,
    precision: 53,
  })
  regulatedRiskValue: number | null;

  @Column('double precision', {
    name: 'finq_risk_value',
    nullable: true,
    precision: 53,
  })
  finkRiskValue: number | null;

  @Column('double precision', {
    name: 'risk_value',
    nullable: true,
    precision: 53,
  })
  riskValue: number | null;

  @Column('double precision', {
    name: 'regulated_weight',
    nullable: true,
    precision: 53,
  })
  regulatedWeight: number | null;

  @Column('double precision', {
    name: 'afi_weight',
    nullable: true,
    precision: 53,
  })
  afiWeight: number | null;

  @Column('double precision', { name: 'score', nullable: true, precision: 53 })
  score: number | null;

  @Column('double precision', {
    name: 'min_range',
    nullable: true,
    precision: 53,
  })
  minRange: number | null;

  @Column('double precision', {
    name: 'max_range',
    nullable: true,
    precision: 53,
  })
  maxRange: number | null;

  @Column('double precision', {
    name: 'segment_from',
    nullable: true,
    precision: 53,
  })
  segmentFrom: number | null;

  @Column('double precision', {
    name: 'segment_to',
    nullable: true,
    precision: 53,
  })
  segmentTo: number | null;

  @Column('double precision', {
    name: 'segment_min',
    nullable: true,
    precision: 53,
  })
  segmentMin: number | null;

  @Column('double precision', {
    name: 'segment_max',
    nullable: true,
    precision: 53,
  })
  segmentMax: number | null;

  @Column('character varying', { name: 'calculation_method', nullable: true })
  calculationMethod: string | null;

  @Column('boolean', { name: 'regulated_question', nullable: true })
  regulatedQuestion: boolean | null;

  @Column('character varying', { name: 'answer_text', nullable: true })
  answerText: string | null;

  @Column('character varying', { name: 'answer_value', nullable: true })
  answerValue: string | null;

  @Column('boolean', { name: 'positive_relation', nullable: true })
  positiveRelation: boolean | null;

  @Column('character varying', { name: 'question_id' })
  questionId: string;
}
