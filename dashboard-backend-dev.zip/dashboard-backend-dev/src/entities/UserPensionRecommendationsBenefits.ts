import {
  BenefitScopesEnum,
  BenefitTypesEnum,
} from 'src/finance/pensions/modules/portfolio/modules/recommendations/modules/benefits/benefits.types';
import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionRecommendations } from './UserPensionRecommendations';

@Index('user_pension_recommendation_benefits_pk', ['id'], { unique: true })
@Index('user_pension_recommendation_benefits_idx', ['userId', 'requestId', 'recommendationId', 'benefitType'], {
  unique: false,
})
@Entity('user_pension_recommendation_benefits', { schema: 'public' })
export class UserPensionRecommendationBenefits {
  @PrimaryGeneratedColumn('uuid', { name: 'benefit_id' })
  id: string;

  @Column('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @Column('uuid', { name: 'request_id', nullable: false })
  requestId: string;

  @Column('uuid', { name: 'recommendation_id', nullable: false })
  recommendationId: string;

  // For holding-level benefits, this will reference the specific combination current holding
  // For recommendation-level benefits, this will be null
  @Column('uuid', { name: 'combination_holding_id', nullable: true })
  combinationHoldingId: string | null;

  @Column({
    type: 'enum',
    name: 'benefit_type',
    enum: BenefitTypesEnum,
    nullable: false,
  })
  benefitType: BenefitTypesEnum;

  @Column({
    type: 'enum',
    name: 'benefit_scope',
    enum: BenefitScopesEnum,
    nullable: false,
  })
  benefitScope: BenefitScopesEnum;

  @Column('boolean', { name: 'is_active', default: false })
  isActive: boolean;

  @Column('jsonb', { name: 'current_value', nullable: true })
  currentValue: { value: any } | null;

  @Column('jsonb', { name: 'target_value', nullable: true })
  targetValue: { value: any } | null;

  @Column('jsonb', { name: 'diff_value', nullable: true })
  diffValue: { value: any } | null;

  @Column('timestamp', { name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => UserPensionRecommendations, (recommendation) => recommendation.benefits, {
    onDelete: 'CASCADE',
  })
  @JoinColumn([{ name: 'recommendation_id', referencedColumnName: 'id' }])
  recommendation: UserPensionRecommendations;
}
