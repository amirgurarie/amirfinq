import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';
import { Users } from './Users';

@Index('user_meetings_pk', ['externalEventId'], { unique: true })
@Entity('user_meetings', { schema: 'public' })
export class UserMeetings {
  @PrimaryColumn('character varying', { name: 'external_event_id', nullable: false })
  externalEventId: string;

  @Column('character varying', { name: 'user_id', nullable: true })
  userId: string;

  @Column('character varying', { name: 'status', nullable: true })
  status: string;

  @Column('timestamp with time zone', { name: 'start_time', nullable: true })
  startTime: Date;

  @Column('timestamp with time zone', { name: 'created_at', nullable: true })
  createdAt: Date;

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: Record<string, any>;

  @ManyToOne(() => Users, (users) => users.userPartners)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
