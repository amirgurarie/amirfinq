import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { RefUserReportGroup } from './RefUserReportGroup';

@Index('ref_user_reports_pk', ['id'], { unique: true })
@Entity('ref_user_reports', { schema: 'public' })
export class RefUserReports {
  @Column('character varying', { primary: true, name: 'id' })
  id: string;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @ManyToOne(() => RefUserReportGroup, (refUserReportGroup) => refUserReportGroup.id)
  @JoinColumn([{ name: 'report_group', referencedColumnName: 'id' }])
  reportGroup: RefUserReportGroup;
}
