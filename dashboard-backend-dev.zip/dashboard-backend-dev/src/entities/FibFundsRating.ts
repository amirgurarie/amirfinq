import { Column, Entity, Index } from 'typeorm';

@Index('fib_funds_rating_pk', ['id'], { unique: true })
@Entity('fib_funds_rating', { schema: 'public' })
export class FibFundsRating {
  @Column('smallint', { primary: true, name: 'id' })
  id: number;

  @Column('smallint', { name: 'rating', nullable: true })
  rating: number | null;

  @Column('double precision', {
    name: 'percentage',
    nullable: true,
    precision: 53,
  })
  percentage: number | null;
}
