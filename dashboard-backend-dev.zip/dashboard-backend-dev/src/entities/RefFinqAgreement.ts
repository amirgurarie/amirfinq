import { RefProducts, UserApprovedFinqAgreement } from 'src/entities';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToOne, PrimaryGeneratedColumn } from 'typeorm';

@Index('ref_finq_agreement_pk', ['id'], { unique: true })
@Entity('ref_finq_agreement', { schema: 'public' })
export class RefFinqAgreement {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string;

  @Column('character varying', { name: 'path_he', nullable: true })
  pathHe: string;

  @Column('character varying', { name: 'path_en', nullable: true })
  pathEn: string;

  @Column('character varying', { name: 'type', nullable: true })
  type: string;

  @Column('character varying', { name: 'product_id', nullable: true })
  productId: string;

  @ManyToOne(() => RefProducts, (type) => type.id)
  @JoinColumn([{ name: 'product_id', referencedColumnName: 'id' }])
  product: RefProducts;

  @OneToOne(() => UserApprovedFinqAgreement, (type) => type.finqAgreement)
  @JoinColumn([{ name: 'id', referencedColumnName: 'finqAgreementId' }])
  userApprovedFinqAgreement: UserApprovedFinqAgreement;
}
