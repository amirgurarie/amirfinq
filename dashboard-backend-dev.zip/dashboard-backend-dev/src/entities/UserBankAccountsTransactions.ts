import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { RefUserBankTransactionTypes } from './RefUserBankTransactionTypes';
import { Users } from './Users';

@Index('user_bank_accounts_transactions_pk', ['bankCode', 'transactionNumber'], {
  unique: true,
})
@Entity('user_bank_accounts_transactions', { schema: 'public' })
export class UserBankAccountsTransactions {
  @Column('integer', { primary: true, name: 'bank_code', nullable: false })
  bankCode: number;

  @Column('integer', { name: 'bank_branch', nullable: false })
  bankBranch: number;

  @Column('character varying', { name: 'bank_account', nullable: false })
  bankAccount: string;

  @Column('character varying', { name: 'reference_number', nullable: false })
  referenceNumber: string;

  @Column('character varying', { name: 'isin', nullable: true })
  isin: string | null;

  @ManyToOne(() => RefUserBankTransactionTypes, (type) => type.id)
  @JoinColumn([{ name: 'transaction_type', referencedColumnName: 'id' }])
  transactionType: string | null;

  @Column('character varying', {
    name: 'transaction_description',
    nullable: true,
  })
  transactionDescription: string | null;

  @Column('double precision', {
    name: 'face_value',
    nullable: true,
    precision: 53,
  })
  faceValue: number | null;

  @Column('integer', {
    primary: true,
    name: 'transaction_number',
    nullable: false,
  })
  transactionNumber: number | null;

  @Column('double precision', { name: 'rate', nullable: true, precision: 53 })
  rate: number | null;

  @Column('double precision', {
    name: 'currency',
    nullable: true,
    precision: 53,
  })
  currency: number | null;

  @Column('double precision', {
    name: 'transaction_amount',
    nullable: true,
    precision: 53,
  })
  transactionAmount: number | null;

  @Column('double precision', {
    name: 'transaction_amount_currency',
    nullable: true,
    precision: 53,
  })
  transactionAmountCurrency: number | null;

  @Column('timestamp with time zone', {
    name: 'transaction_date',
    nullable: true,
  })
  transactionDate: Date | null;

  @Column('timestamp with time zone', {
    name: 'transaction_value_date',
    nullable: true,
  })
  transactionValueDate: Date | null;

  @Column('double precision', {
    name: 'commission',
    nullable: true,
    precision: 53,
  })
  commission: number | null;

  @Column('double precision', {
    name: 'withholding_tax',
    nullable: true,
    precision: 53,
  })
  withholdingTax: number | null;

  @Column('integer', { name: 'bank_transaction_code', nullable: true })
  bankTransactionCode: number | null;

  @Column('double precision', {
    name: 'shift_fee',
    nullable: true,
    precision: 53,
  })
  shiftFee: number | null;

  @Column('boolean', { name: 'is_manual', nullable: true })
  isManual: boolean | null;

  @Column('double precision', {
    name: 'exchange_rate',
    nullable: true,
    precision: 53,
  })
  exchangeRate: number | null;

  @Column('double precision', {
    name: 'total_value',
    nullable: true,
    precision: 53,
  })
  totalValue: number | null;

  @Column('double precision', {
    name: 'gross_return',
    nullable: true,
    precision: 53,
  })
  grossReturn: number | null;

  @Column('double precision', {
    name: 'net_return',
    nullable: true,
    precision: 53,
  })
  netReturn: number | null;

  @Column('timestamp with time zone', {
    name: 'settlement_date',
    nullable: true,
  })
  settlementDate: Date | null;

  @Column('double precision', {
    name: 'overseas_tax',
    nullable: true,
    precision: 53,
  })
  overseasTax: number | null;

  @Column('timestamp with time zone', {
    name: 'creation_date',
    nullable: true,
    default: () => 'CURRENT_TIMESTAMP',
  })
  creationDate: Date | null;

  @Column('timestamp with time zone', { name: 'update_date', nullable: true })
  updateDate: Date | null;

  @Column('character varying', { name: 'status', nullable: true })
  status: string | null;

  @ManyToOne(() => Users, (users) => users.userBankAccountsTransactions)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @Column('character varying', { name: 'asset_id', nullable: false })
  assetId: string;

  @Column('character varying', { name: 'asset_type', nullable: true })
  assetType: string | null;

  @Column('character varying', {
    name: 'external_transaction_type',
    nullable: true,
  })
  externalTransactionType: string | null;
}
