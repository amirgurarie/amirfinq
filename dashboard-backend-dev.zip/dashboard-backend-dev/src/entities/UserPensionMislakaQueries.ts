import {
  PensionQueryDataType,
  PensionQueryStatus,
} from 'src/finance/pensions/modules/pensionQueries/types/pensionQueries.enum';
import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryColumn } from 'typeorm';
import { UserDetails } from './UserDetails';

@Index('unique_pension_mislaka_query', ['userId', 'requestId', 'dataType'], { unique: true })
@Entity('pension_mislaka_queries', { schema: 'public' })
export class UserPensionMislakaQueries {
  @PrimaryColumn('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @PrimaryColumn('uuid', { name: 'request_id', nullable: false, default: () => 'uuid_generate_v4()' })
  requestId: string;

  @PrimaryColumn('enum', { name: 'data_type', nullable: false, enum: PensionQueryDataType })
  dataType: PensionQueryDataType;

  @Column('enum', { name: 'status', nullable: false, enum: PensionQueryStatus })
  status: PensionQueryStatus;

  @Column('timestamp with time zone', { name: 'start_date', nullable: true, default: () => 'now()' })
  startDate: string | null;

  @Column('timestamp with time zone', { name: 'close_date', nullable: true })
  closeDate: string | null;

  @Column('timestamp with time zone', { name: 'last_try', nullable: true })
  lastTry: string | null;

  @Column('character varying', { name: 'error_message', nullable: true })
  errorMessage: string | null;

  @ManyToOne(() => UserDetails, (user) => user.mislakaQueries)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails: UserDetails;
}
