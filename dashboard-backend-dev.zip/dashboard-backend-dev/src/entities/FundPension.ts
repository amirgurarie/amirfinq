import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany } from 'typeorm';
import { RefPensionCompanies } from './RefPensionCompanies';
import { RefPensionProductsSecondaryCategories } from './RefPensionProductsSecondaryCategories';
import { FundPensionHoldings } from './FundPensionHoldings';
import { RefPensionProductsSubCategories } from './RefPensionProductsSubCategories';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import { UserPensionMislakaPolicyInvestmentPlans } from './UserPensionMislakaPolicyInvestmentPlans';
import { UserPensionRecommendationCombinationTargetHoldings } from './UserPensionRecommendationsCombinationsHoldings';

@Index('fund_pension_pk', ['fundId'], { unique: true })
@Entity('fund_pension', { schema: 'public' })
export class FundPension {
  @Column('character varying', { name: 'fund_id', primary: true })
  fundId: string | null;

  @Column('character varying', { name: 'product', nullable: true })
  product: string | null;

  @Column('character varying', { name: 'fund_name', nullable: true })
  fundName: string | null;

  @Column('character varying', { name: 'fund_short_name', nullable: true })
  fundShortName: string | null;

  @Column('character varying', { name: 'fund_category', nullable: true })
  fundCategory: string | null;

  @Column('character varying', { name: 'fund_sub_category', nullable: true })
  fundSubCategory: string | null;

  @Column('character varying', { name: 'fund_secondary_category', nullable: true })
  fundSecondaryCategory: string | null;

  @Column('character varying', { name: 'parent_company_id', nullable: true })
  companyId: string | null;

  @Column('character varying', { name: 'company_id', nullable: true })
  originalCompanyId: string | null;

  @Column('character varying', { name: 'company_name', nullable: true })
  companyName: string | null;

  @Column('character varying', { name: 'tax_confirmation', nullable: true })
  taxConfirmation: string | null;

  @Column('character varying', { name: 'address', nullable: true })
  address: string | null;

  @Column('character varying', { name: 'city', nullable: true })
  city: string | null;

  @Column('character varying', { name: 'postal_code', nullable: true })
  postalCode: string | null;

  @Column('character varying', { name: 'email', nullable: true })
  email: string | null;

  @Column('character varying', { name: 'contact_person', nullable: true })
  contactPerson: string | null;

  @Column('character varying', { name: 'phone_number', nullable: true })
  phoneNumber: string | null;

  @Column('character varying', { name: 'fax', nullable: true })
  fax: string | null;

  @Column('character varying', { name: 'bank_code', nullable: true })
  bankCode: string | null;

  @Column('character varying', { name: 'bank_name', nullable: true })
  bankName: string | null;

  @Column('character varying', { name: 'branch_no', nullable: true })
  branchNo: string | null;

  @Column('character varying', { name: 'account_no', nullable: true })
  accountNo: string | null;

  @Column('character varying', { name: 'admiring_company_id', nullable: true })
  admiringCompanyId: string | null;

  @Column('character varying', { name: 'admiring_company_name', nullable: true })
  admiringCompanyName: string | null;

  @Column('character varying', { name: 'transactions', nullable: true })
  transactions: string | null;

  @Column('timestamp with time zone', { name: 'update_date', nullable: true })
  updateDate: string | null;

  @Column('character varying', { name: 'route_name', nullable: true })
  routeName: string | null;

  @Column('character varying', { name: 'route_short_name', nullable: true })
  routeShortName: string | null;

  @Column('float', { name: 'pe', nullable: true })
  pe: number;

  @Column('float', { name: 'ps', nullable: true })
  ps: number;

  @Column('float', { name: 'number_of_securities', nullable: true })
  numberOfSecurities: number;

  @Column('float', { name: 'number_of_sectors', nullable: true })
  numberOfSectors: number;

  @Column('float', { name: 'number_of_countries', nullable: true })
  numberOfCountries: number;

  @Column('float', { name: 'number_of_currencies', nullable: true })
  numberOfCurrencies: number;

  @Column('float', { name: 'bond_duration', nullable: true })
  bondDuration: number;

  @Column('float', { name: 'internal_yield', nullable: true })
  internalYield: number;

  @Column('character varying', { name: 'finq_category', nullable: true })
  finqCategory: string | null;

  @Column('bigint', { name: 'finq_risk_level', nullable: true })
  finqRiskLevel: number;

  @Column('float', { name: 'finq_yield_level', nullable: true })
  finqYieldLevel: number;

  @Column('float', { name: 'finq_rank', nullable: true })
  finqRank: number;

  @Column('character varying', { name: 'market', nullable: true })
  market: string | null;

  @Column('character varying', { name: 'fund_sub_type', nullable: true })
  fundSubType: string | null;

  @Column('character varying', { name: 'fund_purity_type', nullable: true })
  fundPurityType: string | null;

  @Column('float', { name: 'corporate_bond_allocation', nullable: true }) //float
  corporateBondAllocation: number;

  @Column('float', { name: 'govrament_bond_allocation', nullable: true }) //float
  govramentBondAllocation: number;

  @Column('float', { name: 'yield_12_months', nullable: true }) //float
  yield12Months: number;

  @Column('float', { name: 'equity_exposure', nullable: true }) //float
  equityExposure: number;

  @Column('float', { name: 'yield_3_months', nullable: true }) //float
  yield3Months: number;

  @Column('float', { name: 'yield_6_months', nullable: true }) //float
  yield6Months: number;

  @Column('float', { name: 'yield_24_months', nullable: true }) //float
  yield24Months: number;

  @Column('float', { name: 'yield_36_months', nullable: true }) //float
  yield36Months: number;

  @Column('float', { name: 'yield_60_months', nullable: true }) //float
  yield60Months: number;

  @Column('float', { name: 'yield_1_year_as_prev_1_year', nullable: true }) //float
  yield1YearAsPrev1Year: number;

  @Column('float', { name: 'yield_1_year_as_prev_2_years', nullable: true }) //float
  yield1YearAsPrev2Year: number;

  @Column('float', { name: 'yield_1_year_as_prev_3_years', nullable: true }) //float
  yield1YearAsPrev3Year: number;

  @Column('float', { name: 'yield_1_year_as_prev_4_years', nullable: true }) //float
  yield1YearAsPrev4Year: number;

  @Column('float', { name: 'yield_1_year_as_prev_5_years', nullable: true }) //float
  yield1YearAsPrev5Year: number;

  @Column('float', { name: 'yield_to_maturity', nullable: true }) //float
  yieldToMaturity: number;

  @Column('float', { name: 'yield_1_month', nullable: true }) //float
  yield1Month: number;

  @Column('float', { name: 'yield_ytd', nullable: true }) //float
  yieldYtd: number;

  @Column('float', { name: 'avg_deposit_fee', nullable: true }) //float
  avgDepositFee: number;

  @Column('float', { name: 'avg_annual_management_fee', nullable: true }) //float
  avgAnnualManagementFee: number;

  @Column('float', { name: 'eft_avg_std', nullable: true }) //float
  eftAvgStd: number;

  @Column('character varying', { name: 'secondary_category_id', nullable: true }) //float
  secondaryCategoryId: string;

  @Column('character varying', { name: 'fund_hash', nullable: true }) //float
  fundHash: string;

  @Column('date', { name: 'report_period', nullable: true }) //float
  reportPeriod: string;

  @ManyToOne(() => RefPensionCompanies, (type) => type.funds)
  @JoinColumn({ name: 'parent_company_id', referencedColumnName: 'companyId' })
  pensionCompany: RefPensionCompanies;

  @ManyToOne(() => RefPensionCompanies, (type) => type.funds)
  @JoinColumn({ name: 'company_id', referencedColumnName: 'companyId' })
  originalPensionCompany: RefPensionCompanies;

  @ManyToOne(() => RefPensionProductsSubCategories, (type) => type.funds)
  @JoinColumn({ name: 'fund_sub_category', referencedColumnName: 'subCategoryCode' })
  pensionSubcategory: RefPensionProductsSubCategories;

  @ManyToOne(() => RefPensionProductsSecondaryCategories, (type) => type.funds)
  @JoinColumn({ name: 'secondary_category_id', referencedColumnName: 'id' })
  pensionSecondaryCategory: RefPensionProductsSecondaryCategories;

  @OneToMany(() => FundPensionHoldings, (type) => type.fundPension)
  fundPensionHoldings: FundPensionHoldings[];

  @OneToMany(() => UserPensionMislakaPolicies, (type) => type.fund)
  mislakaPolicies: UserPensionMislakaPolicies[];

  @OneToMany(() => UserPensionMislakaPolicyInvestmentPlans, (type) => type.fund)
  investmentPlans: UserPensionMislakaPolicyInvestmentPlans[];

  @OneToMany(() => UserPensionRecommendationCombinationTargetHoldings, (holdings) => holdings.fund)
  recommendationTargetHoldings: FundPensionHoldings[];
}
