import { Column, Entity, Index } from 'typeorm';

@Index('fund_pension_distribution_pk', ['fundId'], { unique: true })
@Entity('fund_pension_distribution', { schema: 'public' })
export class FundPensionDistribution {
  @Column('character varying', { name: 'fund_id', primary: true })
  fundId: string | null;

  @Column('character varying', { name: 'distribution_group', primary: true })
  distributionGroup: string | null;

  @Column('character varying', { name: 'item_code', nullable: true })
  itemCode: string | null;

  @Column('double precision', { name: 'item_percentage', nullable: true, precision: 53 })
  itemPercentage: number | null;

  @Column('character varying', { name: 'sheet_name', nullable: true })
  sheetName: string | null;
}

export type FundPensionDistributionType = 'ASSETTYPE' | 'CURRENCY' | 'SECTOR' | 'TRADELOC';

export interface FundPensionDistributionRaw {
  fundId: string;
  code: string;
  description: string;
  distributionGroup: FundPensionDistributionType;
  percentage: number;
}
