import { Entity, Index } from 'typeorm';
import { BaseEventEntity } from './BaseEventEntity';

@Index('user_events_pk', ['id'], { unique: true })
@Entity('user_events', { schema: 'public' })
export class UserEvent extends BaseEventEntity {}
