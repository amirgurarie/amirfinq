import { Column, Entity } from 'typeorm';

@Entity('funds_back', { schema: 'public' })
export class FundsBack {
  @Column('character varying', { primary: true, name: 'id', nullable: true })
  id: string | null;

  @Column('character varying', { name: 'id_type', nullable: true })
  idType: string | null;

  @Column('character varying', { name: 'description', nullable: true })
  description: string | null;

  @Column('character varying', { name: 'fund_type', nullable: true })
  fundType: string | null;

  @Column('timestamp with time zone', {
    name: 'foundation_date',
    nullable: true,
  })
  foundationDate: Date | null;

  @Column('character varying', { name: 'classification', nullable: true })
  classification: string | null;

  @Column('bigint', { name: 'fund_house', nullable: true })
  fundHouse: string | null;

  @Column('character varying', { name: 'finq_category', nullable: true })
  finqCategory: string | null;

  @Column('double precision', {
    name: 'equity_exposure',
    nullable: true,
    precision: 53,
  })
  equityExposure: number | null;

  @Column('double precision', {
    name: 'deposit_exposure',
    nullable: true,
    precision: 53,
  })
  depositExposure: number | null;

  @Column('double precision', {
    name: 'gov_bond_exposure',
    nullable: true,
    precision: 53,
  })
  govBondExposure: number | null;

  @Column('double precision', {
    name: 'corp_bond_exposure',
    nullable: true,
    precision: 53,
  })
  corpBondExposure: number | null;

  @Column('integer', { name: 'number_of_securities', nullable: true })
  numberOfSecurities: number | null;

  @Column('double precision', {
    name: 'bond_avg_duration',
    nullable: true,
    precision: 53,
  })
  bondAvgDuration: number | null;

  @Column('double precision', {
    name: 'non_grade_bond_exposure',
    nullable: true,
    precision: 53,
  })
  nonGradeBondExposure: number | null;

  @Column('double precision', {
    name: 'cpi_linked',
    nullable: true,
    precision: 53,
  })
  cpiLinked: number | null;

  @Column('double precision', {
    name: 'foreign_currency_linked',
    nullable: true,
    precision: 53,
  })
  foreignCurrencyLinked: number | null;

  @Column('double precision', {
    name: 'local_currency_linked',
    nullable: true,
    precision: 53,
  })
  localCurrencyLinked: number | null;

  @Column('double precision', {
    name: 'current_price',
    nullable: true,
    precision: 53,
  })
  currentPrice: number | null;

  @Column('double precision', {
    name: 'five_day_price',
    nullable: true,
    precision: 53,
  })
  fiveDayPrice: number | null;

  @Column('double precision', {
    name: 'daily_price_change',
    nullable: true,
    precision: 53,
  })
  dailyPriceChange: number | null;

  @Column('double precision', { name: 'pe', nullable: true, precision: 53 })
  pe: number | null;

  @Column('double precision', { name: 'ps', nullable: true, precision: 53 })
  ps: number | null;

  @Column('double precision', {
    name: 'yield_1_year',
    nullable: true,
    precision: 53,
  })
  yield_1Year: number | null;

  @Column('double precision', {
    name: 'yield_3_years',
    nullable: true,
    precision: 53,
  })
  yield_3Years: number | null;

  @Column('double precision', {
    name: 'yield_5_years',
    nullable: true,
    precision: 53,
  })
  yield_5Years: number | null;

  @Column('double precision', {
    name: 'fund_size',
    nullable: true,
    precision: 53,
  })
  fundSize: number | null;

  @Column('double precision', {
    name: 'management_fee',
    nullable: true,
    precision: 53,
  })
  managementFee: number | null;

  @Column('character varying', { name: 'fund_manager_code', nullable: true })
  fundManagerCode: string | null;

  @Column('double precision', {
    name: 'manager_fund_duration',
    nullable: true,
    precision: 53,
  })
  managerFundDuration: number | null;

  @Column('double precision', { name: 'esg', nullable: true, precision: 53 })
  esg: number | null;

  @Column('boolean', { name: 'dividend_exist', nullable: true })
  dividendExist: boolean | null;

  @Column('double precision', { name: 'pb', nullable: true, precision: 53 })
  pb: number | null;

  @Column('double precision', {
    name: 'momentum',
    nullable: true,
    precision: 53,
  })
  momentum: number | null;

  @Column('double precision', {
    name: 'stock_percentage',
    nullable: true,
    precision: 53,
  })
  stockPercentage: number | null;

  @Column('double precision', {
    name: 'bond_percentage',
    nullable: true,
    precision: 53,
  })
  bondPercentage: number | null;

  @Column('double precision', {
    name: 'finq_yield_level',
    nullable: true,
    precision: 53,
  })
  finkYieldLevel: number | null;

  @Column('double precision', {
    name: 'finq_risk_level',
    nullable: true,
    precision: 53,
  })
  finqRiskLevel: number | null;

  @Column('character varying', { name: 'fund_purity_type', nullable: true })
  fundPurityType: string | null;

  @Column('double precision', { name: 'rating', nullable: true, precision: 53 })
  rating: number | null;

  @Column('timestamp with time zone', {
    name: 'batch_run_date',
    nullable: true,
  })
  batchRunDate: Date | null;

  @Column('character varying', { name: 'rating_category', nullable: true })
  ratingCategory: string | null;

  @Column('double precision', {
    name: 'sharp_1_year',
    nullable: true,
    precision: 53,
  })
  sharp_1Year: number | null;

  @Column('double precision', {
    name: 'sharp_2_years',
    nullable: true,
    precision: 53,
  })
  sharp_2Years: number | null;

  @Column('double precision', {
    name: 'sharp_3_years',
    nullable: true,
    precision: 53,
  })
  sharp_3Years: number | null;

  @Column('character varying', { name: 'isin', nullable: true })
  isin: string | null;

  @Column('double precision', {
    name: 'sharp_5_years',
    nullable: true,
    precision: 53,
  })
  sharp_5Years: number | null;

  @Column('double precision', {
    name: 'yield_2_years',
    nullable: true,
    precision: 53,
  })
  yield_2Years: number | null;
}
