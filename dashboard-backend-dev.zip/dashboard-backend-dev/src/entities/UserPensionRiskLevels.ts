import { Column, Entity, Index, PrimaryColumn } from 'typeorm';

@Index('user_pension_risk_levels_pk', ['fromRisk', 'toRisk'], { unique: true })
@Entity('user_pension_risk_levels', { schema: 'public' })
export class UserPensionRiskLevels {
  @PrimaryColumn('float', { name: 'from_risk', primary: true })
  fromRisk: number;

  @Column('float', { name: 'to_risk', primary: true })
  toRisk: number;

  @Column('int', { name: 'risk_level', nullable: false })
  riskLevel: number;
}
