import { Users } from 'src/entities';
import { Column, Entity, Index, JoinColumn, ManyToOne } from 'typeorm';
import { RefFinqAgreement } from './RefFinqAgreement';

@Index('user_approved_finq_agreement_pk', ['approveDate'], { unique: true })
@Entity('user_approved_finq_agreement', { schema: 'public' })
export class UserApprovedFinqAgreement {
  @Column('character varying', { name: 'user_id' })
  userId: string;

  @Column('timestamp with time zone', { name: 'approve_date', primary: true })
  approveDate: Date;

  @Column('character varying', { name: 'finq_agreement_id' })
  finqAgreementId: number;

  @ManyToOne(() => Users, (type) => type.id)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @ManyToOne(() => RefFinqAgreement, (type) => type.id)
  @JoinColumn([{ name: 'finq_agreement_id', referencedColumnName: 'id' }])
  finqAgreement: RefFinqAgreement;
}
