import { Entity, Column, PrimaryGeneratedColumn, Index, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Product } from './Products';
import { ProductPlanPricing } from './ProductPlanPricing';
import { ProductTempTypes } from 'src/common/productTemp/types/productTemp.types';
import { ProductPlansWaitingList } from './ProductPlansWaitingList';
import { CombinedUserProduct } from './CombinedUserProduct';
import { ProductPlanExclusivity } from './ProductPlanExclusivity';

@Index('product_plans_pk', ['id'], { unique: true })
@Entity('product_plans', { schema: 'public' })
export class ProductPlan {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('character varying', { name: 'code' })
  code: string;

  @Column('integer', { name: 'display_order' })
  displayOrder: number;

  @Column('character varying', { name: 'status' })
  status: ProductTempTypes.PlanStatus;

  @ManyToOne(() => Product, (product) => product.plans)
  @JoinColumn({ name: 'product_id', referencedColumnName: 'id' })
  product: Product;

  @OneToMany(() => ProductPlanPricing, (pricing) => pricing.productPlan)
  pricing: ProductPlanPricing[];

  @OneToMany(() => ProductPlansWaitingList, (waitingList) => waitingList.productPlan)
  productPlansWaitingLists: ProductPlansWaitingList[];

  @OneToMany(() => CombinedUserProduct, (userProduct) => userProduct.productPlan)
  combinedUserProducts: CombinedUserProduct[];

  @OneToMany(() => ProductPlanExclusivity, (productPlanExclusivity) => productPlanExclusivity.lowProductPlan)
  higherProductPlans: ProductPlanExclusivity[];

  @OneToMany(() => ProductPlanExclusivity, (productPlanExclusivity) => productPlanExclusivity.highProductPlan)
  lowerProductPlans: ProductPlanExclusivity[];
}
