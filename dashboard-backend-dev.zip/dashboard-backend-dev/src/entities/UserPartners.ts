import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Users } from './Users';

@Index('user_partners_pk', ['id'], { unique: true })
@Entity('user_partners', { schema: 'public' })
export class UserPartners {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'first_name', nullable: true })
  firstName: string | null;

  @Column('character varying', { name: 'last_name', nullable: true })
  lastName: string | null;

  @Column('character varying', { name: 'card_id', nullable: true })
  cardId: string | null;

  @Column('timestamp without time zone', {
    name: 'card_issue_date',
    nullable: true,
  })
  cardIssueDate: Date | null;

  @Column('character varying', { name: 'city', nullable: true })
  city: string | null;

  @Column('character varying', { name: 'street', nullable: true })
  street: number | null;

  @Column('integer', { name: 'home_number', nullable: true })
  homeNumber: number | null;

  @Column('character varying', { name: 'postal_code', nullable: true })
  postalCode: string | null;

  @Column('character varying', { name: 'cell', nullable: true })
  cell: string | null;

  @Column('character varying', { name: 'email', nullable: true })
  email: string | null;

  @Column('character varying', { name: 'partner_type', nullable: true })
  partnerType: string | null;

  @Column('character varying', { name: 'company_number', nullable: true })
  companyNumber: string | null;

  @ManyToOne(() => Users, (users) => users.userPartners)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;
}
