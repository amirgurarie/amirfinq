import { Column, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import {
  CollectiveInsuranceCoverageEnum,
  MitriyotInsuranceCoverageIdTypeEnum,
  JoiningFormStatusEnum,
  PayerTypeEnum,
  PaymentFrequencyEnum,
} from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';

@Index('user_pension_mislaka_policy_mitriyot_pk', ['id'], { unique: true })
@Entity('user_pension_mislaka_policy_mitriyot', { schema: 'public' })
export class UserPensionMislakaPolicyMitriyot {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('integer', { name: 'policy_id', nullable: true })
  policyId: number | null;

  @Column('enum', { name: 'has_collective_insurance_coverage', nullable: true, enum: CollectiveInsuranceCoverageEnum })
  hasCollectiveInsuranceCoverage: CollectiveInsuranceCoverageEnum | null; // KAYAM-KISUY-BITUCHI-COLECTIVI-LEAMITIM

  @Column('character varying', { name: 'insurance_company_name', nullable: true })
  insuranceCompanyName: string | null; // SHEM-MEVATACHAT

  @Column('timestamp', { name: 'insurance_start_date', nullable: true })
  insuranceStartDate: Date | null; // TAARICH-TCHILAT-HABITUACH

  @Column('timestamp', { name: 'insurance_end_date', nullable: true })
  insuranceEndDate: Date | null; // TAARICH-TOM-TKUFAT-HABITUAH

  @Column('enum', {
    name: 'insurance_product_type',
    nullable: true,
    enum: MitriyotInsuranceCoverageIdTypeEnum,
  })
  insuranceProductType: MitriyotInsuranceCoverageIdTypeEnum | null; // KOD-SUG-MUTZAR-BITUACH

  @Column('double precision', { name: 'insurance_amount', nullable: true })
  insuranceAmount: number | null; // SCHUM-BITUACH

  @Column('double precision', { name: 'coverage_cost', nullable: true })
  coverageCost: number | null; // ALUT-KISUI

  @Column('enum', {
    name: 'payer_type',
    nullable: true,
    enum: PayerTypeEnum,
  })
  payerType: PayerTypeEnum | null; // MESHALEM-DMEI-HABITUAH

  @Column('enum', {
    name: 'payment_frequency',
    nullable: true,
    enum: PaymentFrequencyEnum,
  })
  paymentFrequency: PaymentFrequencyEnum | null; // TADIRUT-HATSHLUM

  @Column('enum', {
    name: 'joining_form_status',
    nullable: true,
    enum: JoiningFormStatusEnum,
  })
  joiningFormStatus: JoiningFormStatusEnum | null; // HAIM-NECHTAM-TOFES-HITZTARFUT

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: any | null;

  @Column('timestamp', { name: 'created_at', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;

  @ManyToOne(() => UserPensionMislakaPolicies, (policy) => policy.mitriyot, { onDelete: 'SET NULL' })
  @JoinColumn({ name: 'policy_id', referencedColumnName: 'id' })
  policy: UserPensionMislakaPolicies;
}
