import { Column, Entity, Index, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
import { RefStreets } from './RefStreets';

@Index('ref_cities_pk', ['id'], { unique: true })
@Entity('ref_cities', { schema: 'public' })
export class RefCities {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @Column('character varying', { name: 'description_he', nullable: true })
  descriptionHe: string | null;

  @Column('character varying', { name: 'description_en', nullable: true })
  descriptionEn: string | null;

  @Column('integer', { name: 'city_num', nullable: true })
  cityNum: number | null;

  @Column('integer', { name: 'location_id', nullable: true })
  locationId: number | null;

  @Column('integer', { name: 'index_reference', nullable: true })
  indexReference: string | null;

  @OneToMany(() => RefStreets, (street) => street.refCities)
  streets: RefStreets[];
}
