import { PaymentMethodTypes } from '../payments/types/payment.enum';
import { RefPaymentMethod, UserPayme, UserProducts, Users } from 'src/entities';
import { Column, Entity, Index, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';

@Index('user_subscriptions_pk', ['id'], { unique: true })
@Entity('user_subscriptions', { schema: 'public' })
export class UserSubscriptions {
  @PrimaryGeneratedColumn({ type: 'integer', name: 'id' })
  id: number;

  @ManyToOne(() => Users, (users) => users.id)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  user: Users;

  @Column('character varying', { name: 'user_id', nullable: true })
  userId: string;

  @Column('integer', { name: 'price', nullable: true })
  price: number;

  @Column('character varying', { name: 'currency', nullable: true })
  currency: string;

  @Column('integer', { name: 'iterations', nullable: true })
  iterations: number;

  @Column('integer', { name: 'iterations_left', nullable: true })
  iterationsLeft: number;

  @Column('integer', { name: 'iterations_completed', nullable: true })
  iterationsCompleted: number;

  @Column('character varying', { name: 'card_mask', nullable: true })
  cardMask: string;

  @Column('character varying', { name: 'card_exp', nullable: true })
  cardExp: string;

  @Column('character varying', { name: 'payme_buyer_key', nullable: true })
  paymeBuyerKey: string;

  @Column('boolean', { name: 'is_active', nullable: true })
  isActive: boolean;

  @Column('timestamp with time zone', { name: 'payment_date', nullable: true })
  paymentDate: string | Date;

  @Column('timestamp with time zone', { name: 'subscription_date', nullable: true })
  subscriptionDate: string | Date;

  @Column('character varying', { name: 'payme_id', nullable: false })
  paymeId: string;

  @Column('character varying', { name: 'stripe_id', nullable: false })
  stripeId: string;

  @ManyToOne(() => RefPaymentMethod, (type) => type.id)
  @JoinColumn({ name: 'payment_method', referencedColumnName: 'id' })
  paymentMethod: RefPaymentMethod;

  @Column('character varying', { name: 'payment_method', nullable: false })
  paymentMethodId: string;

  @OneToMany(() => UserProducts, (type) => type.subscription)
  @JoinColumn({ name: 'id', referencedColumnName: 'subscription' })
  products: UserProducts[];

  @OneToMany(() => UserPayme, (type) => type.subscription)
  @JoinColumn({ name: 'payme_id', referencedColumnName: 'paymeId' })
  payment: UserPayme[];
}

export interface CreateSubscriptionInterface {
  userId: Users['id'];
  price: number;
  currency: string;
  iterations: number;
  iterationsLeft: number;
  iterationsCompleted: number;
  cardMask: string;
  cardExp: string;
  paymeBuyerKey: string;
  paymentDate: string | Date;
  subscriptionDate: string | Date;
  paymentMethodId: PaymentMethodTypes;
  paymeId: string;
  stripeId: string;
  isActive: boolean;
}
