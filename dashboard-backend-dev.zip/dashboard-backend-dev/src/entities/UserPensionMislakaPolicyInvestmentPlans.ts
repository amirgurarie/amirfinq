import { Column, CreateDateColumn, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserPensionMislakaPolicies } from './UserPensionMislakaPolicies';
import { FundPension } from './FundPension';

@Index('user_pension_mislaka_policy_investments_plan_pk', ['policyId', 'createdAt'], { unique: true })
@Entity('user_pension_mislaka_policy_investments_plan', { schema: 'public' })
export class UserPensionMislakaPolicyInvestmentPlans {
  @PrimaryGeneratedColumn('increment', { name: 'id' })
  planId: number;

  @Column('integer', { name: 'policy_id', nullable: false })
  policyId: number;

  @Column('jsonb', { name: 'payload', nullable: true })
  payload: any | null;

  @Column('character varying', { name: 'fund_id', nullable: true })
  fundId: string;

  @Column('character varying', { name: 'company_id', nullable: true })
  companyId: string;

  @Column('integer', { name: 'holdings_percentage', nullable: true })
  holdingPercentage: number;

  @Column('integer', { name: 'amount', nullable: true })
  amount: number;

  @Column('character varying', { name: 'plan_name', nullable: true })
  planName: string;

  @Column('timestamp', { name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => FundPension, (policy) => policy.investmentPlans, { onDelete: 'CASCADE' })
  @JoinColumn([
    { name: 'fund_id', referencedColumnName: 'fundId' },
    { name: 'company_id', referencedColumnName: 'originalCompanyId' },
  ])
  fund: FundPension;

  @ManyToOne(() => UserPensionMislakaPolicies, (policy) => policy.investmentPlans, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'policy_id', referencedColumnName: 'id' })
  policy: UserPensionMislakaPolicies;
}
