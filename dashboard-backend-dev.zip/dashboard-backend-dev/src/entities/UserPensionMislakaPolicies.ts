import {
  InsurancePolicyPaymentMethodEnum,
  PaymentFrequencyEnum,
} from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import {
  Column,
  CreateDateColumn,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { FundPension } from './FundPension';
import { RefPensionCompanies } from './RefPensionCompanies';
import { UserDetails } from './UserDetails';
import { UserPensionMislakaPolicyBasicInsuranceCoverage } from './UserPensionMislakaPolicyBasicInsuranceCoverages';
import { UserPensionMislakaPolicyBenefits } from './UserPensionMislakaPolicyBenefits';
import { UserPensionMislakaPolicyDeposits } from './UserPensionMislakaPolicyDeposits';
import { UserPensionMislakaPolicyInsuranceCoverage } from './UserPensionMislakaPolicyInsuranceCoverages';
import { UserPensionMislakaPolicyInvestmentPlans } from './UserPensionMislakaPolicyInvestmentPlans';
import { UserPensionMislakaPolicyMitriyot } from './UserPensionMislakaPolicyMitriyot';
import { UserPensionMislakaPolicyPensionInsuranceCoverage } from './UserPensionMislakaPolicyPensionInsuranceCoverages';
import { UserPensionRecommendationHoldings } from './UserPensionRecommendationsTransactionsHoldings';

@Index('user_pension_mislaka_policies_pk', ['userId', 'requestId'], { unique: true })
@Entity('user_pension_mislaka_policies', { schema: 'public' })
export class UserPensionMislakaPolicies {
  @PrimaryGeneratedColumn()
  id: number;

  @PrimaryColumn('uuid', { name: 'user_id', nullable: false })
  userId: string;

  @PrimaryColumn('uuid', { name: 'request_id', nullable: false })
  requestId: string;

  @Column('character varying', { name: 'policy_number_id', nullable: true })
  policyNumberId: string | null;

  @Column('integer', { name: 'external_id_policy', nullable: true })
  externalIdPolicy: number | null;

  @Column('character varying', { name: 'policy_type', nullable: true })
  policyType: string | null; // WAITING FOR AROYA - SUG_POLISA

  @Column('character varying', { name: 'plan_name', nullable: true })
  planName: string | null; // WAITING FOR AROYA - SHEM_TOCHNIT

  @Column('integer', { name: 'policy_savings_percentage', nullable: true })
  policySavingsPercentage: number | null; // WAITING FOR AROYA - PERCENTAGE_SAVINGS

  @Column('character varying', { name: 'yield_rate', nullable: true }) // TODO: unknown type
  yieldRate: string | null; // WAITING FOR AROYA - SHEUR_TSUA_BRUTO_CHS_1

  @Column('float', { name: 'other_employee_provision', nullable: true })
  otherEmployeeProvision: number | null; // WAITING FOR AROYA - SHONOT_OVED

  @Column('float', { name: 'other_employer_provision', nullable: true })
  otherEmployerProvision: number | null; // WAITING FOR AROYA - SHONOT_MASIK

  @Column('float', { name: 'aka_employer_provision', nullable: true })
  AKAEmployerProvision: number | null; // WAITING FOR AROYA - E_KOSHER

  @Column('character varying', { name: 'non_insured_policy_owner_name', nullable: true }) // TODO: move to insurance policy entity ?
  nonInsuredPolicyOwnerName: string | null; // SHEM-BAAL-POLISA-SHEEINO-MEVUTAH

  @Column('character varying', { name: 'insurance_payer_name', nullable: true }) // TODO: move to insurance policy entity ?
  insurancePayerName: string | null; // SHEM-MESHALEM

  @Column('enum', { name: 'insurance_payment_method', nullable: true, enum: InsurancePolicyPaymentMethodEnum }) // TODO: move to insurance policy entity ?
  insurancePaymentMethod: InsurancePolicyPaymentMethodEnum | null; // KOD-EMTZAEI-TASHLUM

  @Column('enum', { name: 'insurance_payment_frequency', nullable: true, enum: PaymentFrequencyEnum }) // TODO: move to insurance policy entity ?
  insurancePaymentFrequency: PaymentFrequencyEnum | null; // TADIRUT-TASHLUM

  @Column('character varying', { name: 'insurance_track_name', nullable: true })
  insuranceTrackName: string | null; // MaslulKerenPensya

  @Column('float', { name: 'annual_management_fees', nullable: true })
  annualManagementFees: number | null;

  @Column('float', { name: 'employee_47_provision', nullable: true })
  employee47Provision: number | null;

  @Column('character varying', { name: 'fund_id', nullable: true })
  fundId: string;

  @Column('character varying', { name: 'product_category_id', nullable: false })
  productCategoryId: string;

  @Column('character varying', { name: 'company_id', nullable: true })
  companyId: string | null;

  @Column('jsonb', { name: 'policy_details', nullable: true })
  policyDetails: any | null;

  @Column('jsonb', { name: 'current_savings_info', nullable: true })
  currentSavingsInfo: any | null;

  @Column('character varying', { name: 'status', nullable: true })
  status: string | null;

  @Column('character varying', { name: 'pos_stand', nullable: true })
  posStand: string | null;

  @Column('float', { name: 'deposit_management_fees', nullable: true })
  depositManagementFees: number | null;

  @Column('float', { name: 'acc_management_fees', nullable: true })
  accManagementFees: number | null;

  @Column('float', { name: 'max_deposit_management_fees', nullable: true })
  maxDepositManagementFees: number | null; // סכום מקסימלי לדמי ניהול חודשי מהפקדה

  @Column('float', { name: 'other_management_fees', nullable: true })
  otherManagementFees: number | null; // דמי ניהול אחרים

  @Column('character varying', { name: 'employer_name', nullable: true })
  employerName: string | null;

  @Column('timestamp', { name: 'liquidity_date', nullable: true })
  liquidityDate: Date | null;

  @Column('timestamp', { name: 'product_join_date', nullable: true })
  productJoinDate: Date | null;

  @Column('timestamp', { name: 'initial_join_date', nullable: true })
  initialJoinDate: Date | null;

  @Column('float', { name: 'employee_provision', nullable: true })
  employeeProvision: number | null;

  @Column('float', { name: 'employer_provision', nullable: true })
  employerProvision: number | null;

  @Column('float', { name: 'compensation_provision', nullable: true })
  compensationProvision: number | null;

  @Column('float', { name: 'salary', nullable: true })
  salary: number | null;

  @Column('float', { name: 'employee_deposits', nullable: true })
  employeeDeposits: number | null;

  @Column('float', { name: 'employer_deposits', nullable: true })
  employerDeposits: number | null;

  @Column('float', { name: 'total_yearly_deposits', nullable: true })
  totalYearlyDeposits: number | null;

  @Column('float', { name: 'current_savings', nullable: true })
  currentSavings: number | null;

  @Column('float', { name: 'current_wealth', nullable: true })
  currentWealth: number | null;

  @Column('float', { name: 'current_allowance', nullable: true })
  currentAllowance: number | null;

  @Column('float', { name: 'future_retirement_savings_with_deposits', nullable: true })
  futureRetirementSavingsWithDeposits: number | null;

  @Column('float', { name: 'future_retirement_savings_without_deposits', nullable: true })
  futureRetirementSavingsWithoutDeposits: number | null;

  @Column('float', { name: 'future_retirement_wealth_with_deposit', nullable: true })
  futureRetirementWealthWithDeposits: number | null;

  @Column('float', { name: 'future_retirement_wealth_without_deposit', nullable: true })
  futureRetirementWealthWithoutDeposits: number | null;

  @Column('float', { name: 'future_allowance_with_deposit', nullable: true })
  futureAllowanceWithDeposit: number | null;

  @Column('float', { name: 'future_allowance_without_deposit', nullable: true })
  futureAllowanceWithoutDeposit: number | null;

  @Column('float', { name: 'monthly_future_allowance_with_deposit', nullable: true })
  monthlyFutureAllowanceWithDeposit: number | null;

  @Column('float', { name: 'monthly_future_allowance_without_deposit', nullable: true })
  monthlyFutureAllowanceWithoutDeposit: number | null;

  @Column('boolean', { name: 'debt', nullable: true })
  debt: boolean | null;

  @Column('boolean', { name: 'loans', nullable: true })
  loans: boolean | null;

  @Column('boolean', { name: 'lien', nullable: true })
  lien: boolean | null;

  @Column('boolean', { name: 'bend', nullable: true })
  bend: boolean | null;

  @Column('boolean', { name: 'claim', nullable: true })
  claim: boolean | null;

  @Column('integer', { name: 'retirement_age', nullable: true })
  retirementAge: number | null;

  @Column('integer', { name: 'months_of_debt', nullable: true })
  monthsOfDebt: number | null;

  @Column('timestamp', { name: 'start_of_debt_date', nullable: true })
  startOfDebtDate: Date | null;

  @Column('integer', { name: 'debt_amount', nullable: true })
  debtAmount: number | null;

  @Column('timestamp', { name: 'information_validity_date', nullable: true })
  informationValidityDate: Date | null;

  @Column('boolean', { name: 'including_bond_eligibility', nullable: true })
  includingBondEligibility: boolean | null;

  @Column('float', { name: 'designated_bond_rate', nullable: true })
  designatedBondRate: number | null;

  @Column('float', { name: 'coefficient_rate', nullable: true })
  coefficientRate: number | null;

  @Column('character varying', { name: 'user_social_id', nullable: true })
  userSocialId: string | null;

  @CreateDateColumn({ name: 'created_at' })
  createdAt: Date;

  @ManyToOne(() => UserDetails, (user) => user.mislakaPolicies)
  @JoinColumn([{ name: 'user_id', referencedColumnName: 'id' }])
  userDetails: UserDetails;

  @ManyToOne(() => FundPension, (fund) => fund.mislakaPolicies)
  @JoinColumn([{ name: 'fund_id', referencedColumnName: 'fundId' }])
  fund: FundPension;

  @ManyToOne(() => RefPensionCompanies, (fund) => fund.mislakaPolicies)
  @JoinColumn([{ name: 'company_id', referencedColumnName: 'companyId' }])
  company: RefPensionCompanies;

  @OneToMany(() => UserPensionMislakaPolicyBenefits, (benefit) => benefit.policy, {
    cascade: true,
  })
  benefits: UserPensionMislakaPolicyBenefits[];

  @OneToMany(() => UserPensionMislakaPolicyInvestmentPlans, (investmentRoute) => investmentRoute.policy, {
    cascade: true,
  })
  investmentPlans: UserPensionMislakaPolicyInvestmentPlans[];

  @OneToMany(() => UserPensionMislakaPolicyInsuranceCoverage, (coverage) => coverage.policy, { cascade: true })
  insuranceCoverages: UserPensionMislakaPolicyInsuranceCoverage[];

  @OneToMany(() => UserPensionMislakaPolicyPensionInsuranceCoverage, (coverage) => coverage.policy, { cascade: true })
  pensionInsuranceCoverages: UserPensionMislakaPolicyPensionInsuranceCoverage[];

  @OneToMany(() => UserPensionMislakaPolicyBasicInsuranceCoverage, (coverage) => coverage.policy, { cascade: true })
  basicInsuranceCoverages: UserPensionMislakaPolicyBasicInsuranceCoverage[];

  @OneToMany(() => UserPensionMislakaPolicyMitriyot, (mitriyot) => mitriyot.policy)
  mitriyot: UserPensionMislakaPolicyMitriyot[];

  @OneToMany(() => UserPensionMislakaPolicyDeposits, (deposit) => deposit.policy, { onDelete: 'CASCADE' })
  deposits: UserPensionMislakaPolicyDeposits[];

  @OneToMany(() => UserPensionRecommendationHoldings, (holding) => holding.policy)
  recommendationHoldings: UserPensionRecommendationHoldings[];
}
