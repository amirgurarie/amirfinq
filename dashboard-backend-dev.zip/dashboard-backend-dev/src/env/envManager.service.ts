import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

import type { EnvironmentVariables } from './schema';

@Injectable()
export class EnvironmentManager {
  public environment: string;

  constructor(private readonly configService: ConfigService<EnvironmentVariables>) {
    this.environment = this.get('CORE_ENVIRONMENT');
  }

  public get isProd(): boolean {
    return this.environment === 'prod';
  }

  public get isQA(): boolean {
    return this.environment === 'qa';
  }

  public get isDev(): boolean {
    return this.environment === 'dev';
  }

  public get isFINQIsrael(): boolean {
    return this.get('CORE_DOMAIN').includes('finqai.co.il');
  }

  public get isFINQUSA(): boolean {
    return this.get('CORE_DOMAIN').includes('finqai.com');
  }

  public get<K extends keyof EnvironmentVariables>(
    path: K,
    defaultValue: EnvironmentVariables[K] = null,
  ): EnvironmentVariables[K] {
    return this.configService.get(path, defaultValue);
  }

  public getAppName() {
    const suffix = this.isProd ? '' : `[${this.environment.toUpperCase()}-${this.isFINQUSA ? 'USA' : 'ISR'}]`;

    return ['FINQ AI', suffix].filter(Boolean).join(' ');
  }
}
