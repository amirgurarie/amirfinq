import { plainToInstance } from 'class-transformer';
import { IsEnum, IsOptional, IsString, IsUrl, validateSync, type ValidationError } from 'class-validator';
import { Logger } from '@nestjs/common';

const CoreEnvironment = {
  dev: 'dev',
  qa: 'qa',
  prod: 'prod',
} as const;

class EnvironmentVariables {
  @IsString()
  @IsEnum(['development', 'production'])
  NODE_ENV: 'development' | 'production';

  @IsString()
  TYPEORM_CONNECTION: string;

  @IsString()
  TYPEORM_HOST: string;

  @IsString()
  TYPEORM_USERNAME: string;

  @IsString()
  TYPEORM_PASSWORD: string;

  @IsString()
  TYPEORM_DATABASE: string;

  @IsString()
  TYPEORM_PORT: string;

  @IsString()
  TYPEORM_DEBUG: string;

  @IsString()
  TYPEORM_LOGGING: string;

  @IsString()
  TYPEORM_MULTIPLE_STATEMENTS: string;

  @IsString()
  POSTGRES_DATABASE: string;

  @IsString()
  AUTH0_CLIENT_ID: string;

  @IsString()
  AUTH0_CLIENT_SECRET: string;

  @IsString()
  AUTH0_WEBHOOK_SECRET: string;

  @IsString()
  AUTH0_API_IDENTIFIER: string;

  @IsString()
  AUTH0_DOMAIN: string;

  @IsString()
  AUTH0_CONNECTION: string;

  @IsString()
  AUTH0_ISSUER_URL: string;

  @IsString()
  REDIS_HOST: string;

  @IsString()
  REDIS_PORT: string;

  @IsString()
  REDIS_CACHE_DURATION: string;

  @IsString()
  REDIS_PASSWORD: string;

  @IsString()
  RABBITMQ_URL: string;

  @IsString()
  AZURE_STORAGE_CONNECTION: string;

  @IsString()
  LOCAL_JWT_EXPIRES_IN: string;

  @IsString()
  LOCAL_JWT_SECRET: string;

  @IsString()
  MAX_ALLOWED_ONBOARDING_TIMES: string;

  @IsString()
  DEFAULT_PAGINATION_LIMIT: string;

  @IsString()
  PORTFOLIO_BUILDER_LOWEST_MATCH_PERCENTAGE: string;

  @IsString()
  PORTFOLIO_BUILDER_MIN_ASSETS_COUNT: string;

  @IsString()
  PORTFOLIO_BUILDER_MAX_SINGLE_STOCK_PERCENTAGE: string;

  @IsString()
  USER_SELECTIONS_URL: string;

  @IsString()
  SENDGRID_API_KEY: string;

  @IsString()
  AROYA_URL: string;

  @IsString()
  AROYA_USERNAME: string;

  @IsString()
  AROYA_PASSWORD: string;

  @IsString()
  AROYA_ID_CLIENT_CODE: string;

  @IsString()
  AROYA_CLIENT_IDENTIFIER: string;

  @IsString()
  PAYME_URL: string;

  @IsString()
  PAYME_ID: string;

  @IsString()
  PAYME_PENSION_ID: string;

  @IsString()
  STRIPE_API_SECRET_KEY: string;

  @IsString()
  STRIPE_WEBHOOK_SECRET: string;

  @IsString()
  HUBSPOT_API_KEY: string;

  @IsString()
  HUBSPOT_URL: string;

  @IsString()
  HUBSPOT_SIGNUP_FORM_ID: string;

  @IsString()
  HUBSPOT_LOGIN_FORM_ID: string;

  @IsString()
  HUBSPOT_PORTAL_ID: string;

  @IsString()
  HUBSPOT_OWNER_ID: string;

  @IsString()
  ANALYTICS_MAKE_OFFLINE_API: string;

  @IsUrl()
  OLD_APP_URL: string;

  @IsUrl()
  APP_URL: string;

  @IsEnum(CoreEnvironment)
  CORE_ENVIRONMENT: (typeof CoreEnvironment)[keyof typeof CoreEnvironment];

  @IsString()
  CORE_DOMAIN: string;

  @IsString()
  CORE_ORIGINS: string;

  @IsString()
  MAXMIND_ACCOUNT_ID: string;

  @IsString()
  MAXMIND_LICENSE_KEY: string;

  @IsString()
  CURRENCY_CONVERSION_API_KEY: string;

  @IsString()
  CURRENCY_CONVERSION_SEND_REQUEST: string;

  @IsString()
  INTERCOM_URL: string;

  @IsString()
  INTERCOM_API_TOKEN: string;

  @IsString()
  INTERCOM_SECRET_KEY: string;

  @IsString()
  CALENDLY_TOKEN: string;

  @IsString()
  CALENDLY_ORGANIZATION: string;

  @IsString()
  CALENDLY_WEBHOOK_SIGNING_KEY: string;

  @IsString()
  FORCE_USER_UNHAPPY_FLOW: string;

  @IsString()
  @IsOptional()
  AWS_ACCESS_KEY_ID: string;

  @IsString()
  @IsOptional()
  AWS_SECRET_ACCESS_KEY: string;

  @IsString()
  AWS_REGION: string;

  @IsString()
  FORMALLY_AWS_S3_BUCKET_NAME: string;

  @IsString()
  FORMALLY_AWS_S3_USER_GUID: string;

  @IsString()
  SENTRY_DSN: string;

  @IsString()
  GOV_ENDPOINT: string;

  @IsString()
  @IsOptional()
  TYPEORM_LOG_QUERIES: string;
}

const formatErrors = (errors: ValidationError[]) =>
  errors
    .map((error) => {
      const constraints = Object.values(error.constraints || {}).join(', ');

      return `\x1b[31m${error.property}:\x1b[0m ${constraints}`;
    })
    .join('\n');

export const validateEnv = (config: Record<string, unknown>) => {
  const logger = new Logger('EnvValidation');

  const validatedConfig = plainToInstance(EnvironmentVariables, config, {
    enableImplicitConversion: true,
  });

  const errors = validateSync(validatedConfig, { skipMissingProperties: false });

  if (errors.length > 0) {
    console.log(
      '\x1b[31m --------------------------------------------------------------------------------------------------- \x1b[0m \n',
    );
    logger.error('Environment validation failed. Missing or invalid variables:', formatErrors(errors));
    console.log(
      '\x1b[31m --------------------------------------------------------------------------------------------------- \x1b[0m \n',
    );

    // process.exit(1);
  } else {
    logger.log('✅ Environment variables validated successfully');
  }

  return validatedConfig;
};

// Export the type for use in other files
export type { EnvironmentVariables };
