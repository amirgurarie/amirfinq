export const dataChartSchemaResponse = {
  type: 'object',
  properties: {
    data: {
      type: 'object',
      properties: {
        chart: {
          type: 'object',
          properties: {
            unit: {
              type: 'string',
            },
            datasets: {
              type: 'array',
              items: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    timestamp: {
                      type: 'number',
                      description: 'date in seconds',
                    },
                    value: {
                      type: 'number',
                      description: 'depends on chart type it can be a price, sum of prices or average of prices',
                    },
                    additionalData: {
                      type: 'object',
                      properties: {
                        dailyPriceChange: {
                          type: 'number',
                          description:
                            'depends on chart type it can be a daily price change, sum of daily price changes or average of daily price changes',
                        },
                      },
                    },
                  },
                },
              },
            },
            y_axis: {
              type: 'object',
              properties: {
                unit_prefix: {
                  type: 'string',
                },
                unit_suffix: {
                  type: 'string',
                },
              },
            },
          },
        },
      },
    },
  },
};
