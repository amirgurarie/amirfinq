import { Body, Controller, Get, Param, Put, Query, UseFilters, UseGuards, UseInterceptors } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiBearerAuth, ApiBody, ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { CurrentAuthUser } from 'src/auth/currentAuthUser.decorator';
import { AbstractController } from 'src/shared';
import { ApiFailedHttpResponse } from 'src/shared/decorators/apiFailedHttpResponse.decorator';
import { ApiPaginationQuery } from 'src/shared/decorators/apiPaginationQuery.decorator';
import { ApiUnauthorizedHttpResponse } from 'src/shared/decorators/apiUnauthorizedHttpResponse.decorator';
import { ApiDataArrayResponse, ApiDataPaginatedResponse } from 'src/shared/decorators/dataResponse.decorator';
import { BadRequestExceptionFilter } from 'src/shared/filters/badRequestException.filter';
import { NotFoundExceptionFilter } from 'src/shared/filters/notFoundException.filter';
import { ActiveInvestmentGuard } from 'src/shared/guards/activeInvestment.guard';
import { LocalJwtAuthGuard } from 'src/shared/guards/localJwtAuth.guard';
import { PaginationTransformInterceptor } from 'src/shared/interceptors/paginationTransform.interceptor';
import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';
import { ReportsSubject } from './reports/reports.subject';
import { ApiReportFilterDto, ReportsFiltersDto } from './reports/reportsFilters.dto';
import { UserReportsService } from './reports/userReports.service';
import { TransactionsSubject } from './transactions/transactions.subject';
import { ApiTransactionsFilterDto, TransactionsFiltersDto } from './transactions/transactionsFilters.dto';
import { UserTransactionsService } from './transactions/userTransactions.service';
import { RefTypeSubject } from 'src/shared/subjects/refType.subject';
import { Users } from 'src/entities/Users';
import { ApiMessagesFilterDto, MessagesFiltersDto } from './messages/messagesFilters.dto';
import { MessagesSubject } from './messages/messages.subject';
import { UserMessagesService } from './messages/userMessages.service';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { MessagesUpdateDto } from './messages/messagesUpdate.dto';

export type DocsApiRequest = {
  user: Users;
  query: any;
  main?: { service: any; subject: any };
  groups?: { service: any; subject: any };
};

@ApiTags('Users Investment Documents')
@Controller('v1/users/inv')
@ApiExtraModels(ReportsSubject, TransactionsSubject, MessagesSubject, RefTypeSubject)
@UseFilters(NotFoundExceptionFilter, BadRequestExceptionFilter)
export class UserInvestmentDocsController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    protected readonly userReportsService: UserReportsService,
    protected readonly userTransactionsService: UserTransactionsService,
    protected readonly userMessagesService: UserMessagesService,
    protected readonly loggerService: LoggerService,
  ) {
    super(configService);
  }

  @Get('/reports')
  @ApiOperation({ summary: 'Retrieve user active reports' })
  @ApiReportFilterDto()
  @ApiDataPaginatedResponse(ReportsSubject, 'User active reports data')
  @ApiFailedHttpResponse()
  @ApiPaginationQuery()
  @ApiUnauthorizedHttpResponse()
  @UseGuards(LocalJwtAuthGuard, ActiveInvestmentGuard)
  @ApiBearerAuth()
  @UseInterceptors(PaginationTransformInterceptor)
  public async getInvReports(@CurrentAuthUser() { user }: AuthenticatedUser, @Query() query: ReportsFiltersDto) {
    return await this.getDocsApiData({
      user,
      query,
      main: {
        service: this.userReportsService.getUserReports.bind(this.userReportsService),
        subject: ReportsSubject,
      },
      groups: {
        service: this.userReportsService.getReportGroups.bind(this.userReportsService),
        subject: RefTypeSubject,
      },
    });
  }

  @Get('/transactions')
  @ApiOperation({ summary: 'Retrieve user active transactions' })
  @ApiTransactionsFilterDto()
  @ApiDataPaginatedResponse(TransactionsSubject, 'User active transactions data', RefTypeSubject)
  @ApiFailedHttpResponse()
  @ApiPaginationQuery()
  @ApiUnauthorizedHttpResponse()
  @UseGuards(LocalJwtAuthGuard, ActiveInvestmentGuard)
  @ApiBearerAuth()
  @UseInterceptors(PaginationTransformInterceptor)
  public async getInvTransactions(
    @CurrentAuthUser() { user }: AuthenticatedUser,
    @Query() query: TransactionsFiltersDto,
  ) {
    return await this.getDocsApiData({
      user,
      query,
      main: {
        service: this.userTransactionsService.getUserTransactions.bind(this.userTransactionsService),
        subject: TransactionsSubject,
      },
      groups: {
        service: this.userTransactionsService.getTransactionTypes.bind(this.userTransactionsService),
        subject: RefTypeSubject,
      },
    });
  }

  @Get('/messages')
  @ApiOperation({ summary: 'Retrieve user messages' })
  @ApiMessagesFilterDto()
  @ApiDataPaginatedResponse(MessagesSubject, 'User messages data', RefTypeSubject)
  @ApiFailedHttpResponse()
  @ApiPaginationQuery()
  @ApiUnauthorizedHttpResponse()
  @UseGuards(LocalJwtAuthGuard, ActiveInvestmentGuard)
  @ApiBearerAuth()
  @UseInterceptors(PaginationTransformInterceptor)
  public async getInvMessages(@CurrentAuthUser() { user }: AuthenticatedUser, @Query() query: MessagesFiltersDto) {
    return await this.getDocsApiData({
      user,
      query,
      main: {
        service: this.userMessagesService.getUserMessages.bind(this.userMessagesService),
        subject: MessagesSubject,
      },
      groups: {
        service: this.userMessagesService.getNotificationsGroups.bind(this.userMessagesService),
        subject: RefTypeSubject,
      },
    });
  }

  @Put('/messages/:id')
  @ApiOperation({ summary: 'Updates message by given id', tags: ['Inv'] })
  @ApiFailedHttpResponse()
  @ApiUnauthorizedHttpResponse()
  @UseGuards(LocalJwtAuthGuard, ActiveInvestmentGuard)
  @ApiBearerAuth()
  @ApiBody({ type: MessagesUpdateDto })
  @UseInterceptors(TransformInterceptor)
  public async updateMessage(
    @CurrentAuthUser() { user }: AuthenticatedUser,
    @Param('id') notificationId: number,
    @Body() body: MessagesUpdateDto,
  ) {
    const response = await this.userMessagesService.updateMessage(user, notificationId, body);

    return null;
  }

  @Get('/notifications')
  @ApiOperation({ summary: 'Retrieve user on screen notifications' })
  @ApiDataArrayResponse(MessagesSubject, 'User notifications')
  @ApiFailedHttpResponse()
  @ApiUnauthorizedHttpResponse()
  @UseGuards(LocalJwtAuthGuard, ActiveInvestmentGuard)
  @ApiBearerAuth()
  @UseInterceptors(TransformInterceptor)
  public async getInvNotifications(@CurrentAuthUser() { user }: AuthenticatedUser) {
    const [items, [newNotifications, count]] = await Promise.all([
      this.userMessagesService.getOnScreenNotifications(user.id),
      this.userMessagesService.getRawUnseenMessagesAndCount(user.id),
    ]);

    return {
      mainScreenNotifications: this.transformToArray(items, MessagesSubject),
      unSeenCount: count,
    };
  }

  async getDocsApiData({ user, query, main, groups }: DocsApiRequest) {
    const { skip, take } = this.pagination(query.index, query.size);

    const promises: Promise<any>[] = !main?.service ? [] : [main.service(user.id, query, skip, take)];

    if (query.withGroups && groups.service) {
      promises.push(groups.service());
    }

    const [[rawItems, total], rawGroups] = await Promise.all(promises);

    // return { data: rawItems }
    const items = this.transformToArray(rawItems, main.subject);
    const groupsData = !rawGroups ? null : this.transformToArray(rawGroups, groups.subject);

    return {
      data: items,
      groups: groupsData,
      total,
      index: skip,
      size: items.length,
    } as IPaginatedDataResponse<TransactionsSubject>;
  }
}
