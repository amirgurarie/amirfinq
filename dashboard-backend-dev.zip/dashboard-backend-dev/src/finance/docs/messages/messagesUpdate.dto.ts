import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsOptional, ValidationArguments } from 'class-validator';
import { TransformToBoolean } from 'src/shared/decorators/subjects/transformToBoolean.decorator';
import { IsCaseSensitive } from 'src/shared/validators/isCaseSensitive';
import { IsInInsensitive } from 'src/shared/validators/isInInsensitive';

export enum AcceptDeclineStates {
  Accept = 'ACCEPT',
  Decline = 'DECLINE',
}

export class MessagesUpdateDto {
  @IsOptional()
  @IsCaseSensitive(Object.values(AcceptDeclineStates))
  @ApiProperty({ required: true, isArray: false, enum: AcceptDeclineStates })
  public readonly acceptDecline?: AcceptDeclineStates;

  @IsOptional()
  @IsBoolean()
  @ApiProperty()
  public readonly messageSeen?: boolean;
}
