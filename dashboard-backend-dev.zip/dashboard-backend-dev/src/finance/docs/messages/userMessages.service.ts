import { FromToAssetsType, UserNotifications } from './../../../entities/UserNotifications';
import { Funds } from 'src/entities/Funds';
import { getFrequencyDates } from '../../portfolios/dto/durationQuery.dto';
import { Injectable, forwardRef, Inject } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { Repository } from 'typeorm';
import { PortfoliosHelperService } from 'src/finance/portfolios/services/portfoliosHelper.service';
import { Assets } from 'src/entities/Assets';
import { AssetTypes } from 'src/finance/portfolios/interfaces/assetType.const';
import { AcceptDeclineStates, MessagesFiltersDto } from './messagesFilters.dto';
import { uniqBy, flatten, flattenDeep } from 'lodash';
import { RefNotificationGroup } from 'src/entities/RefNotificationGroup';
import { UserPortfolioPendingRequestService } from 'src/finance/portfolios/proposals/services/userPortfolioPendingRequest.service';
import { Users } from 'src/entities/Users';
import { MessagesUpdateDto } from './messagesUpdate.dto';
import { isNullOrUndefined } from 'src/shared/helpers/utils';
import { AssetType } from 'src/finance/portfolios/interfaces/asset.type';

// Checks if a value exists and its different from given obj
const isExistsAndDifferent = (v: any, existingV: any) => !isNullOrUndefined(v) && v !== existingV;

@Injectable()
export class UserMessagesService extends ServiceHelper<UserNotifications> {
  constructor(
    // Entities
    @InjectRepository(UserNotifications)
    private readonly userNotificationsRepository: Repository<UserNotifications>,
    @InjectRepository(RefNotificationGroup)
    private readonly refNotificationGroupRepository: Repository<RefNotificationGroup>,
    // Services
    @Inject(forwardRef(() => UserPortfolioPendingRequestService))
    private readonly userPortfolioPendingRequestService: UserPortfolioPendingRequestService,
    private readonly portfoliosHelperService: PortfoliosHelperService,
  ) {
    super(userNotificationsRepository);
  }

  // Notification groups
  public async getNotificationsGroups(): Promise<RefNotificationGroup[]> {
    return this.refNotificationGroupRepository.find();
  }

  // On Main screen notifications
  public async getOnScreenNotifications(userId: string): Promise<UserNotifications[]> {
    const notifications = await this.getRawOnScreenNotifications(userId);

    return await this.getNotificationParamsAssets(notifications);
  }

  public getRawOnScreenNotifications(userId: string): Promise<UserNotifications[]> {
    return this.userNotificationsRepository
      .createQueryBuilder('userNotification')
      .innerJoinAndSelect('userNotification.notificationType', 'refNotificationType')
      .where('userNotification.user_id = :userId', { userId })
      .andWhere('refNotificationType.showOnMainScreen = :show', { show: true })
      .andWhere(
        `date_part('day',CURRENT_DATE) - date_part('day',"userNotification"."creation_date") <= refNotificationType.daysToShowOnMainScreen`,
      )
      .andWhere('userNotification.acceptDecline is null')
      .orderBy('userNotification.creationDate', 'DESC', 'NULLS LAST')
      .getMany();
  }

  public getRawUnseenMessagesAndCount(userId: string): Promise<[UserNotifications[], number]> {
    return this.userNotificationsRepository
      .createQueryBuilder('userNotification')
      .innerJoinAndSelect('userNotification.notificationType', 'refNotificationType')
      .where('userNotification.user_id = :userId', { userId })
      .andWhere('refNotificationType.showOnScreen = :show', { show: true })
      .andWhere('userNotification.messageSeen is not true') // unseen messages
      .getManyAndCount();
  }

  // User messages
  public async getUserMessages(
    userId: string,
    filters: Omit<MessagesFiltersDto, 'index' | 'size'> = null,
    skip: number,
    take: number,
  ): Promise<[any[], number]> {
    const [listItems, count] = await this.getRawUserMessages(userId, filters, skip, take);

    const notificationsWithAssets = await this.getNotificationParamsAssets(listItems);

    return [notificationsWithAssets, count];
  }

  public async getRawUserMessages(
    userId: string,
    filters: Omit<MessagesFiltersDto, 'index' | 'size'> = null,
    skip: number,
    take: number,
  ): Promise<[UserNotifications[], number]> {
    const query = this.userNotificationsRepository
      .createQueryBuilder('userNotification')
      .innerJoinAndSelect('userNotification.notificationType', 'refNotificationType')
      .where('userNotification.user_id = :userId', { userId })
      .andWhere('refNotificationType.showOnScreen = :show', { show: true })
      .orderBy('userNotification.creationDate', 'DESC', 'NULLS LAST');

    if (filters.type) {
      query.andWhere('userNotification.notificationType = :type', {
        type: filters.type,
      });
    }

    if (filters.frequency || (filters.duration && filters.frequency)) {
      query.andWhere('userNotification.creationDate BETWEEN :startDate and :endDate', getFrequencyDates(filters));
    }

    const [listItems, count] = await query.offset(skip).limit(take).getManyAndCount();

    return [listItems, count];
  }

  // Update message / EDIT message
  public async updateMessage(user: Users, notificationId: number, body: MessagesUpdateDto) {
    const notification = await this.findOneOrFail(notificationId, {
      where: { user },
    });
    const updates: Partial<UserNotifications> = {};
    const promises: Promise<any>[] = [];

    if (isExistsAndDifferent(body.messageSeen, notification.messageSeen)) {
      updates.messageSeen = body.messageSeen;
    }

    if (isExistsAndDifferent(body.acceptDecline, notification.acceptDecline)) {
      if (body.acceptDecline === AcceptDeclineStates.Accept) {
        promises.push(this.buyAssetsFromNotification(user, notificationId));
      }

      updates.acceptDecline = body.acceptDecline;
      updates.acceptDeclineDate = new Date();
    }

    if (Object.keys(updates)?.length) {
      // Calling all promises that waits.. if one failed, we will not update the notification
      await Promise.all(promises);

      return await this.update(notification.id, updates);
    }

    return 'nothing to update';
  }

  // Private inner methods
  private addAssetsToMessages(assets: AssetType[], notifications: UserNotifications[]) {
    const addAssets = (assetsArray: FromToAssetsType) => {
      if (!assetsArray.length) return [];

      return assetsArray.map((fund: any) => {
        const asset = assets.find((asset) => this.portfoliosHelperService.getAssetId(asset) === fund.assetId);
        let newAsset = fund;

        if (asset) newAsset = asset;

        return { type: fund.assetType, ...newAsset };
      });
    };

    const transactionWithAsset = notifications.map((transaction) => {
      if (!transaction.notificationParams.replacements?.length) return transaction;
      transaction.notificationParams.replacements = transaction.notificationParams.replacements.map(
        ({ fromAssets, toAssets }) => {
          if (fromAssets?.length || toAssets?.length) {
            fromAssets = addAssets(fromAssets);
            toAssets = addAssets(toAssets);
          }

          return { fromAssets, toAssets };
        },
      );

      return transaction;
    });

    return transactionWithAsset;
  }

  private async getNotificationParamsAssets(notifications: UserNotifications[]) {
    if (!notifications?.length) return Promise.resolve([]);

    // Flattening all assets id's so we can get them in one query
    const allReplacedAssets = notifications
      .map((item) => {
        if (!item.notificationParams.replacements?.length) {
          return null;
        }

        return item.notificationParams.replacements.map(({ fromAssets, toAssets }) => {
          if (fromAssets || toAssets) {
            return [...fromAssets, ...toAssets];
          } else {
            return null;
          }
        });
      })
      .filter(Boolean);

    // If we dont have assets that need to be replaced, we can return the notifications as is
    if (!allReplacedAssets?.length) return notifications;

    const uniqReplacedAssets = uniqBy(flattenDeep(allReplacedAssets), 'assetId');
    const [assets, funds] = await this.portfoliosHelperService.findAssetsForPortfolios(uniqReplacedAssets);

    const mappedTransactions = this.addAssetsToMessages([...funds, ...assets], notifications);

    return mappedTransactions;
  }

  private async buyAssetsFromNotification(user: Users, notificationId: number) {
    const notification = await this.findOneOrFail(notificationId, {
      where: { user },
    });
    if (notification.notificationParams?.replacements?.length) {
      return null;
    }

    const filterAssetsByType = (type: AssetTypes) =>
      flatten(
        notification.notificationParams?.replacements
          ?.map((replaces) => {
            const hasAssets = replaces.toAssets.some((fund) => fund.assetType === type);
            if (hasAssets) {
              return replaces.toAssets.filter((fund) => fund.assetType === type);
            } else return null;
          })
          .filter(Boolean),
      );

    const newPurchaseRes = await this.userPortfolioPendingRequestService.addPortfolioSelectionsRequest(user, {
      stocks: filterAssetsByType(AssetTypes.Stock) as unknown as Assets[],
      portfolio: {
        user: user.id,
        assetsDetails: filterAssetsByType(AssetTypes.Fund),
      } as any,
    });

    if (!newPurchaseRes) throw new Error(`Notification id ${notificationId} could not be updated`);

    return newPurchaseRes;
  }
}
