import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { isEmpty } from 'lodash';
import { FundSubject } from 'src/finance/portfolios/subject/fund.subject';
import { AssetsSubject } from 'src/finance/stocks/subjects/assets.subject';
import { AssetDiscriminator } from 'src/shared/decorators/assetDiscriminator.decorator';
import { DateToEpochTransform } from 'src/shared/decorators/subjects/dateToEpochTransform.decorator';
import { TransformToProperty } from 'src/shared/decorators/subjects/transformToProperty.decorator';

export class NotificationParamsReplacementSubject {
  @Expose()
  @AssetDiscriminator()
  fromAssets: (FundSubject | AssetsSubject)[];

  @Expose()
  @AssetDiscriminator()
  toAssets: (FundSubject | AssetsSubject)[];
}

export class NotificationParamsSubject {
  @Expose()
  @Type(() => NotificationParamsReplacementSubject)
  @ApiProperty({ type: NotificationParamsReplacementSubject })
  replacements: NotificationParamsReplacementSubject[] | null;
}

export class MessagesSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @Type(() => NotificationParamsSubject)
  @ApiProperty({ type: NotificationParamsSubject })
  @Transform(
    (value) => {
      // need to remove empty:false parameters
      if (!value.value.replacements?.length) return null;

      return value.value;
    },
    { toPlainOnly: true },
  )
  notificationParams: NotificationParamsSubject | null;

  @Expose({ name: 'date', toPlainOnly: true })
  @ApiProperty({ name: 'date' })
  @DateToEpochTransform()
  creationDate: string | null;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  acceptDeclineDate: string | null;

  @Expose()
  @ApiProperty()
  acceptDecline: string | null;

  @Expose()
  @ApiProperty()
  messageSeen: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.textHe')
  textHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.textEn')
  textEn: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.shortTextHe')
  shortTextHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.shortTextEn')
  shortTextEn: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.headerTextHe')
  headerTextHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.headerTextEn')
  headerTextEn: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.detailedTextHe')
  detailedTextHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationType.detailedTextEn')
  detailedTextEn: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationGroup.id')
  notificationGroup: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationGroup.descriptionHe')
  descriptionHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('notificationGroup.descriptionEn')
  descriptionEn: string | null;
}
