import { applyDecorators } from '@nestjs/common';
import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import {
  ApiDurationQuery,
  ApiWithGroupsQuery,
  DocsQueryPaginated,
  DurationQueryWithPaginationDto,
} from 'src/finance/portfolios/dto/durationQuery.dto';
import { IsCaseSensitive } from 'src/shared/validators/isCaseSensitive';

export enum UserMessagesGroupEnum {
  Status = 'STATUS',
  General = 'GENERAL',
  Action = 'ACTION',
}

export enum AcceptDeclineStates {
  Accept = 'ACCEPT',
  Decline = 'DECLINE',
}

export class MessagesAcceptDeclineDto {
  @IsCaseSensitive(Object.values(AcceptDeclineStates))
  @ApiProperty({
    required: true,
    isArray: false,
    enum: AcceptDeclineStates,
  })
  public readonly state?: AcceptDeclineStates;
}

export class MessagesFiltersDto extends DocsQueryPaginated {
  @IsOptional()
  @IsCaseSensitive(Object.values(UserMessagesGroupEnum))
  public readonly type?: UserMessagesGroupEnum;
}

export function ApiMessagesFilterDto() {
  return applyDecorators(
    ApiWithGroupsQuery(),
    ApiDurationQuery(),
    ApiQuery({ name: 'type', enum: UserMessagesGroupEnum, required: false }),
  );
}
