import { RefNotificationsTypes } from './../../entities/RefNotificationsTypes';
import { UserNotifications } from './../../entities/UserNotifications';
import { RefUserBankTransactionTypes } from './../../entities/RefUserBankTransactionTypes';
import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoggerModule } from 'src/shared/middlewares/logger/logger.module';
import { UserReportsService } from './reports/userReports.service';
import { UserBankAccountsTransactions } from 'src/entities/UserBankAccountsTransactions';
import { PortfoliosHelperService } from '../portfolios/services/portfoliosHelper.service';
import { UserTransactionsService } from './transactions/userTransactions.service';
import { UserInvestmentDocsController } from './portfolioDocs.controller';
import { PortfoliosModule } from '../portfolios/portfolios.module';
import { FundsModule } from '../funds/funds.module';
import { FundsCommonModule } from '../fundsCommon/fundsCommon.module';
import { UserMessagesService } from './messages/userMessages.service';
import { RefNotificationGroup } from 'src/entities/RefNotificationGroup';
import { ProposalsModule } from '../portfolios/proposals/proposals.module';
import { UserDocumentsModule } from 'src/users/userDocuments/userDocuments.module';
import { DocumentTypesModule } from 'src/common/documentTypes/documentTypes.module';
import { StocksModule } from '../stocks/stocks.module';
import { UserPortfolioPendingRequestModule } from 'src/users/userPortfolioPendingRequest/userPortfolioPendingRequest.module';

const services = [UserReportsService, UserMessagesService, UserTransactionsService];
@Module({
  imports: [
    TypeOrmModule.forFeature([
      // Transactions entities
      UserBankAccountsTransactions,
      RefUserBankTransactionTypes,
      // Messages entities
      UserNotifications,
      RefNotificationGroup,
      RefNotificationsTypes,
    ]),

    forwardRef(() => UserPortfolioPendingRequestModule),

    forwardRef(() => FundsModule),
    forwardRef(() => FundsCommonModule),
    forwardRef(() => PortfoliosModule),
    forwardRef(() => ProposalsModule),
    forwardRef(() => UserDocumentsModule),
    forwardRef(() => DocumentTypesModule),
    forwardRef(() => StocksModule),

    LoggerModule,
  ],

  controllers: [UserInvestmentDocsController],

  providers: [...services, PortfoliosHelperService],

  exports: services,
})
export class PortfolioDocsModule {}
