import { UserDocumentsService } from './../../../users/userDocuments/userDocuments.service';
import { getFrequencyDates } from '../../portfolios/dto/durationQuery.dto';
import { Injectable } from '@nestjs/common';
import { ReportsFiltersDto } from './reportsFilters.dto';
import { DocumentTypesService } from 'src/common/documentTypes/documentTypes.service';

@Injectable()
export class UserReportsService {
  constructor(
    private readonly userDocumentsService: UserDocumentsService,
    private readonly documentTypesService: DocumentTypesService,
  ) {}

  public async getReportGroups() {
    return await this.documentTypesService.getDocuments({ group: 'REPORTS' });
  }

  public async getUserReports(
    userId: string,
    filters: Omit<ReportsFiltersDto, 'index' | 'size'> = null,
    skip: number,
    take: number,
  ) {
    const documentsQuery = this.userDocumentsService.getUserDocumentsQuery(userId, {
      group: 'REPORTS',
      subGroup: filters.type,
    });

    if (filters.frequency || (filters.duration && filters.frequency)) {
      documentsQuery.andWhere('user_documents.update_date BETWEEN :startDate and :endDate', getFrequencyDates(filters));
    }

    const [listItems, count] = await documentsQuery.offset(skip).limit(take).getManyAndCount();

    return [listItems, count];
  }
}
