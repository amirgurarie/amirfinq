import { applyDecorators } from '@nestjs/common';
import { ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { ApiDurationQuery, ApiWithGroupsQuery, DocsQueryPaginated } from 'src/finance/portfolios/dto/durationQuery.dto';
import { IsCaseSensitive } from 'src/shared/validators/isCaseSensitive';

export enum UserReportsGroupEnum {
  Quarter = 'QREPORT',
  Year = 'YREPORT',
}

export class ReportsFiltersDto extends DocsQueryPaginated {
  @IsOptional()
  @IsCaseSensitive(Object.values(UserReportsGroupEnum))
  public readonly type?: UserReportsGroupEnum;
}

export function ApiReportFilterDto() {
  return applyDecorators(
    ApiWithGroupsQuery(),
    ApiDurationQuery(),
    ApiQuery({ name: 'type', enum: UserReportsGroupEnum, required: false }),
  );
}
