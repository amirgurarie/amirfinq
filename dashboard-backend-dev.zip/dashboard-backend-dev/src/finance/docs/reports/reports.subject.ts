import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { DateToEpochTransform } from 'src/shared/decorators/subjects/dateToEpochTransform.decorator';
import { TransformToProperty } from 'src/shared/decorators/subjects/transformToProperty.decorator';

export class ReportsSubject {
  @Expose()
  @ApiProperty()
  @TransformToProperty('userDocumentsDetails[0].id')
  id: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('userDocumentsDetails[0].url')
  path: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('userDocumentsDetails[0].nameHe')
  descriptionHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('userDocumentsDetails[0].name')
  descriptionEn: string | null;

  @Expose({ name: 'date', toPlainOnly: true })
  @ApiProperty({ name: 'date' })
  @DateToEpochTransform()
  updateDate: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('documentType.id')
  reportGroup: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('documentType.descriptionHe')
  reportGroupDescriptionHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('documentType.descriptionEn')
  reportGroupDescriptionEn: string | null;
}
