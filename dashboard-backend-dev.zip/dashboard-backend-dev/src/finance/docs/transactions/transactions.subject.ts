import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { AssetTypes } from 'src/finance/portfolios/interfaces/assetType.const';
import { DateToEpochTransform } from 'src/shared/decorators/subjects/dateToEpochTransform.decorator';
import { TransformToProperty } from 'src/shared/decorators/subjects/transformToProperty.decorator';

export class TransactionsSubject {
  @Expose({ name: 'date', toPlainOnly: true })
  @ApiProperty({ name: 'date' })
  @DateToEpochTransform()
  transactionDate: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('transactionType.id')
  transactionType: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('transactionType.descriptionHe')
  descriptionHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('transactionType.descriptionEn')
  descriptionEn: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty(['asset.description', 'asset.descriptionHe'], 'מזומן')
  assetDescriptionHe: string | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('asset.descriptionEn', 'Cash')
  assetDescriptionEn: AssetTypes | null;

  @Expose()
  @ApiProperty()
  @TransformToProperty('transactionAmount')
  transactionAmount: number | null = 0;
}
