import { RefUserBankTransactionTypes } from './../../../entities/RefUserBankTransactionTypes';
import { CASH_ASSET_ID } from './../../portfolios/interfaces/assetType.const';
import { getFrequencyDates } from '../../portfolios/dto/durationQuery.dto';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { Repository } from 'typeorm';
import { TransactionsFiltersDto, UserTransactionTypeEnum } from './transactionsFilters.dto';
import { PortfoliosHelperService } from 'src/finance/portfolios/services/portfoliosHelper.service';
import { UserBankAccountsTransactions } from 'src/entities/UserBankAccountsTransactions';
import { AssetTypes } from 'src/finance/portfolios/interfaces/assetType.const';
import { RefAssetTypesService } from 'src/finance/portfolios/services/refAssetTypes.service';
import { PortfolioStatusEnum } from 'src/finance/portfolios/interfaces/portfoliosStatus.enum';
import { AssetType } from 'src/finance/portfolios/interfaces/asset.type';

@Injectable()
export class UserTransactionsService extends ServiceHelper<UserBankAccountsTransactions> {
  constructor(
    @InjectRepository(UserBankAccountsTransactions)
    private readonly userBankAccountsTransactions: Repository<UserBankAccountsTransactions>,
    @InjectRepository(RefUserBankTransactionTypes)
    private readonly refUserBankTransactionTypes: Repository<RefUserBankTransactionTypes>,
    private readonly portfoliosHelperService: PortfoliosHelperService,
    private readonly refAssetTypesService: RefAssetTypesService,
  ) {
    super(userBankAccountsTransactions);
  }

  public async getTransactionTypes(): Promise<RefUserBankTransactionTypes[]> {
    return this.refUserBankTransactionTypes.find();
  }

  public async getRawUserTransactions(
    userId: string,
    filters: Omit<TransactionsFiltersDto, 'index' | 'size'> = null,
    skip: number,
    take: number,
  ): Promise<[UserBankAccountsTransactions[], number]> {
    const query = this.userBankAccountsTransactions
      .createQueryBuilder('userTransaction')
      .innerJoinAndSelect('userTransaction.transactionType', 'refTransactionType')
      .where('userTransaction.user_id = :userId', { userId })
      .andWhere('userTransaction.status = :status', {
        status: PortfolioStatusEnum.COMPLETED,
      })
      .orderBy('userTransaction.transactionDate', 'DESC', 'NULLS LAST');

    if (filters.type) {
      query.andWhere('userTransaction.transactionType = :type', {
        type: filters.type,
      });
    } else {
      query.andWhere('userTransaction.transactionType != :type', {
        type: UserTransactionTypeEnum.NA,
      });
    }

    if (filters.frequency || (filters.duration && filters.frequency)) {
      query.andWhere('userTransaction.transactionDate BETWEEN :startDate and :endDate', getFrequencyDates(filters));
    }

    const [listItems, count] = await query.offset(skip).limit(take).getManyAndCount();

    return [listItems, count];
  }

  public async addAssetsToTransactions(assets: AssetType[], transactions: UserBankAccountsTransactions[]) {
    const findInAssets = (transaction: UserBankAccountsTransactions) =>
      assets.find((x) => this.portfoliosHelperService.getAssetId(x) === transaction.assetId);
    const hasCash = transactions.find((x) => x.assetId === CASH_ASSET_ID);

    let cashAssetType = null;
    if (hasCash) {
      cashAssetType = await this.refAssetTypesService.findOne(AssetTypes.Cash);
    }

    const transactionWithAsset = transactions.map((transaction) => {
      let asset: any = findInAssets(transaction);
      if (transaction.assetId === CASH_ASSET_ID) {
        asset = cashAssetType;
      }

      if (asset) {
        asset['type'] = transaction.assetType;

        return { ...transaction, asset };
      }

      return transaction;
    });

    return transactionWithAsset;
  }

  public async getUserTransactions(
    userId: string,
    filters: Omit<TransactionsFiltersDto, 'index' | 'size'> = null,
    skip: number,
    take: number,
  ): Promise<[any[], number]> {
    const [listItems, count] = await this.getRawUserTransactions(userId, filters, skip, take);

    // TODO: remove when we have asset types
    const tempAddAssetTypes = listItems.map((item) => {
      if (item.assetType) {
        return item;
      } else if (item.assetId === CASH_ASSET_ID) {
        item.assetType = AssetTypes.Cash;
      } else if (/^\d+$/.test(item.assetId)) {
        item.assetType = AssetTypes.Fund;
      } else {
        item.assetType = AssetTypes.Stock;
      }

      return item;
    });

    const [assets, funds] = await this.portfoliosHelperService.findAssetsForPortfolios(tempAddAssetTypes);

    const mappedTransactions = await this.addAssetsToTransactions([...funds, ...assets], listItems);

    return [mappedTransactions, count];
  }
}
