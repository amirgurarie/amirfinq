import { applyDecorators } from '@nestjs/common';
import { ApiQuery } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';
import {
  ApiDurationQuery,
  ApiWithGroupsQuery,
  DocsQueryPaginated,
  DurationQueryWithPaginationDto,
} from 'src/finance/portfolios/dto/durationQuery.dto';
import { IsCaseSensitive } from 'src/shared/validators/isCaseSensitive';

export enum UserTransactionTypeEnum {
  Deposit = 'DEPOSIT',
  Buy = 'BUY',
  Sell = 'SELL',
  Dividend = 'DIVIDEND',
  Interest = 'INTEREST',
  NA = 'NA',
}

export class TransactionsFiltersDto extends DocsQueryPaginated {
  @IsOptional()
  @IsCaseSensitive(Object.values(UserTransactionTypeEnum))
  public readonly type?: UserTransactionTypeEnum;
}

export function ApiTransactionsFilterDto() {
  return applyDecorators(
    ApiWithGroupsQuery(),
    ApiDurationQuery(),
    ApiQuery({ name: 'type', enum: UserTransactionTypeEnum, required: false }),
  );
}
