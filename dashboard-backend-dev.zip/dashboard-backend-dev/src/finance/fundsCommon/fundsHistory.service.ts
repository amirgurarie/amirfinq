import { ChartQueryDto } from './../portfolios/dto/chartQuery.dto';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ServiceHelper } from '../../shared/modules/service.helper';
import { FundsHistory } from '../../entities/FundsHistory';
import { getFrequencyDates } from '../portfolios/dto/durationQuery.dto';

type FundYieldResponseType = {
  timestamp: number;
  value: number;
  daily_price_change: number;
};
@Injectable()
export class FundsHistoryService extends ServiceHelper<FundsHistory> {
  constructor(
    @InjectRepository(FundsHistory)
    private readonly fundsHistoryRepository: Repository<FundsHistory>,
  ) {
    super(fundsHistoryRepository);
  }

  public async getFundYields(fundId: string, filters: ChartQueryDto): Promise<FundYieldResponseType[]> {
    const query = this.fundsHistoryRepository
      .createQueryBuilder('funds_history')
      .select([
        'EXTRACT(EPOCH FROM funds_history.trade_date) as timestamp',
        'funds_history.price as value',
        'funds_history.daily_price_change as daily_price_change',
      ])
      .where('funds_history.fund_id = :fundId', { fundId });
    if (filters.frequency || (filters.duration && filters.frequency) || filters.fromDate) {
      query.andWhere('funds_history.trade_date BETWEEN :startDate and :endDate', getFrequencyDates(filters));
    }
    query.orderBy('funds_history.trade_date', 'DESC');

    return await query.getRawMany();
  }

  public async getPortfolioYieldsInDays(
    portfolioId: number,
    portfolioIdProperty: string,
    detailsProperty: string,
    dates: { startDate: string; endDate: string },
  ) {
    const { startDate, endDate } = dates;

    return await this.fundsHistoryRepository
      .createQueryBuilder('funds_history')
      .select([
        `sum(funds_history.price*${detailsProperty}.asset_percentage) as value`,
        `EXTRACT(EPOCH FROM funds_history.trade_date) as timestamp`,
        `sum(funds_history.daily_price_change*${detailsProperty}.asset_percentage) as daily_price_change`,
      ])
      .innerJoin(`${detailsProperty}`, `${detailsProperty}`, `funds_history.fund_id=${detailsProperty}.asset_id`)
      .where(`${detailsProperty}.${portfolioIdProperty} = :portfolioId`, {
        portfolioId,
      })
      .andWhere(`funds_history.trade_date between (${startDate}) and ${endDate}`)
      .groupBy('funds_history.trade_date')
      .orderBy('funds_history.trade_date', 'DESC')
      .getRawMany();
  }

  public async getPortfolioYieldsInWeeks(
    portfolioId: number,
    portfolioIdProperty: string,
    detailsProperty: string,
    dates: { startDate: string; endDate: string },
  ) {
    const { startDate, endDate } = dates;

    return await this.fundsHistoryRepository
      .createQueryBuilder('funds_history')
      .select([
        `avg(funds_history.price*${detailsProperty}.asset_percentage) as value`,
        `sum(funds_history.daily_price_change*${detailsProperty}.asset_percentage) as daily_price_change`,
        "EXTRACT(EPOCH FROM DATE_TRUNC('week', funds_history.trade_date)) as timestamp",
      ])
      .innerJoin(`${detailsProperty}`, `${detailsProperty}`, `funds_history.fund_id=${detailsProperty}.asset_id`)
      .where(`${detailsProperty}.${portfolioIdProperty} = :portfolioId`, {
        portfolioId,
      })
      .andWhere(`funds_history.trade_date between (${startDate}) and ${endDate}`)
      .groupBy("DATE_TRUNC('week', trade_date)")
      .orderBy("DATE_TRUNC('week', trade_date)", 'DESC')
      .getRawMany();
  }

  public async getFundYieldsInWeeks(
    fundId: string,
    dates: { startDate: string; endDate: string },
  ): Promise<FundYieldResponseType[]> {
    const { startDate, endDate } = dates;

    return await this.fundsHistoryRepository
      .createQueryBuilder('funds_history')
      .select([
        "EXTRACT(EPOCH FROM DATE_TRUNC('week', funds_history.trade_date)) as timestamp",
        'AVG (funds_history.price) as value',
        'AVG(funds_history.daily_price_change) as daily_price_change',
      ])
      .where('funds_history.fund_id = :fundId', { fundId })
      .andWhere(`funds_history.trade_date between (${startDate}) and ${endDate}`)
      .groupBy("DATE_TRUNC('week', trade_date)")
      .orderBy("DATE_TRUNC('week', trade_date)", 'DESC')
      .getRawMany();
  }

  public async getFundYieldsInDays(
    fundId: string,
    dates: { startDate: string; endDate: string },
  ): Promise<FundYieldResponseType[]> {
    const { startDate, endDate } = dates;

    return await this.fundsHistoryRepository
      .createQueryBuilder('funds_history')
      .select([
        'EXTRACT(EPOCH FROM funds_history.trade_date) as timestamp',
        'funds_history.price as value',
        'funds_history.daily_price_change as daily_price_change',
      ])
      .where('funds_history.fund_id = :fundId', { fundId })
      .andWhere(`funds_history.trade_date between (${startDate}) and ${endDate}`)
      .orderBy('funds_history.trade_date', 'DESC')
      .getRawMany();
  }
}
