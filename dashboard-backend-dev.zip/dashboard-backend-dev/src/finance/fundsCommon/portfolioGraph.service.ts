import { ServiceHelper } from 'src/shared/modules/service.helper';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PortfolioGraph } from '../../entities/PortfolioGraph';
import { PortfolioFrequencyEnum } from 'src/shared/dto/charts/frequencyCharts.enum';
import { RefPortfolioGraphPeriod } from '../../entities/RefPortfolioGraphPeriod';
import { PortfolioGraphColumns } from '../portfolios/portfolioGraph.enum';
import { ChartQueryDtoPortfolioGraph } from '../portfolios/dto/chartQuery.dto';

@Injectable()
export class PortfolioGraphService extends ServiceHelper<PortfolioGraph> {
  constructor(
    @InjectRepository(PortfolioGraph)
    private readonly portfolioGraphRepository: Repository<PortfolioGraph>,
    @InjectRepository(RefPortfolioGraphPeriod)
    private readonly refPortfolioGraphPeriodRepository: Repository<RefPortfolioGraphPeriod>,
  ) {
    super(portfolioGraphRepository);
  }

  public async getPortfolioYields(
    selectionId: number,
    filters: ChartQueryDtoPortfolioGraph,
    column: PortfolioGraphColumns,
  ) {
    return await this.portfolioGraphRepository
      .createQueryBuilder('portfolio_graph')
      .select([
        'portfolio_graph.total_amount as "value"',
        'EXTRACT(EPOCH FROM portfolio_graph.selection_day) as timestamp',
        'portfolio_graph.daily_change as "daily_price_change"',
      ])
      .leftJoin('portfolio_graph.graphPeriod', 'ref_portfolio_graph_period')
      .where(`portfolio_graph.${column} = :selectionId`, {
        selectionId,
      })
      .andWhere('portfolio_graph.graph_period = :period', {
        period: filters.frequency,
      })
      .orderBy('ref_portfolio_graph_period.display_order', 'DESC')
      .addOrderBy('timestamp', 'DESC')
      .getRawMany();
  }

  public async getPeriodList(): Promise<RefPortfolioGraphPeriod[]> {
    return await this.refPortfolioGraphPeriodRepository.find({
      where: {
        isActive: true,
      },
      order: {
        displayOrder: 'ASC',
      },
    });
  }
}
