export interface IFundAssetType {
  id: string;
  percentage: number;
  name_en: string;
  name_he: string;
}
