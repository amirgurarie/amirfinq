import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FundsHistory } from '../../entities/FundsHistory';
import { FundsHistoryService } from './fundsHistory.service';
import { GeneralParametersModule } from '../../shared/modules/generalParameters/generalParameters.module';
import { FundAssets } from '../../entities/FundAssets';
import { FundAssetsService } from './fundAssets.service';
import { FundItemDistributionService } from './fundItemsDistribution.service';
import { FundsModule } from '../funds/funds.module';
import { FinanceQueryHelper } from './financeQuery.helper';
import { YieldsService } from './yields.service';
import { AssetsService } from './assets.service';
import { Assets } from 'src/entities/Assets';
import { FundItemsDistribution } from 'src/entities/FundItemsDistribution';
import { ProposalsModule } from '../portfolios/proposals/proposals.module';
import { PortfolioGraphService } from './portfolioGraph.service';
import { PortfolioGraph } from 'src/entities/PortfolioGraph';
import { RefPortfolioGraphPeriod } from 'src/entities/RefPortfolioGraphPeriod';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      FundsHistory,
      FundAssets,
      Assets,
      FundItemsDistribution,
      PortfolioGraph,
      RefPortfolioGraphPeriod,
    ]),
    GeneralParametersModule,
    forwardRef(() => FundsModule),
    forwardRef(() => ProposalsModule),
  ],
  providers: [
    YieldsService,
    FundsHistoryService,
    FundAssetsService,
    FundItemDistributionService,
    FinanceQueryHelper,
    AssetsService,
    PortfolioGraphService,
  ],
  exports: [YieldsService, FundAssetsService, FundItemDistributionService, FundsHistoryService, AssetsService],
})
export class FundsCommonModule {}
