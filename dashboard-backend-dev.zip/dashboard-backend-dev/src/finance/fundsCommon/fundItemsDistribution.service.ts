import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ServiceHelper } from '../../shared/modules/service.helper';
import { FundAssets } from '../../entities/FundAssets';
import { IFundAssetType } from './fundAssetType.interface';
import { IFundLocation } from '../funds/interfaces/fundLocation.interface';
import { IFundSector } from '../funds/interfaces/fundSector.interface';
import { FinanceQueryHelper } from './financeQuery.helper';
import { IFundCurrency } from '../funds/interfaces/fundCurrency.interface';
import { PortfolioKind, ProposalsMapService } from '../portfolios/proposals/services/proposalsMap.service';
import { FundItemsDistribution } from '../../entities/FundItemsDistribution';

@Injectable()
export class FundItemDistributionService extends ServiceHelper<FundItemsDistribution> {
  constructor(
    @InjectRepository(FundItemsDistribution)
    private readonly fundAssetsRepository: Repository<FundItemsDistribution>,
    private readonly financeQueryHelper: FinanceQueryHelper<FundItemsDistribution>,
  ) {
    super(fundAssetsRepository);
  }

  public async getAssetTypesByFund(fundId: string): Promise<IFundAssetType[]> {
    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_asset_type.description_en as name_en',
        'ref_asset_type.description_he as name_he',
        'sum(fund_items_distribution.item_percentage) as percentage',
        'ref_asset_type.id as id',
      ])
      .leftJoin('ref_asset_type', 'ref_asset_type', 'fund_items_distribution.item_code=ref_asset_type.id')
      .where('fund_items_distribution.fund_id = :fundId', {
        fundId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'ASSETTYPE'`)
      .groupBy('ref_asset_type.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }

  public async getAssetTypesByPortfolio(
    portfolioOrUserId: number | string,
    kind: PortfolioKind,
  ): Promise<IFundAssetType[]> {
    const [detailsProperty, portfolioIdProperty] = ProposalsMapService.getPropertiesNames(kind);

    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_asset_type.description_en as name_en',
        'ref_asset_type.description_he as name_he',
        `sum(fund_items_distribution.item_percentage*${detailsProperty}.asset_percentage) as percentage`,
        'ref_asset_type.id as id',
      ])
      .innerJoin(
        `${detailsProperty}`,
        `${detailsProperty}`,
        `fund_items_distribution.fund_id=${detailsProperty}.asset_id`,
      )
      .leftJoin('ref_asset_type', 'ref_asset_type', 'fund_items_distribution.item_code=ref_asset_type.id')
      .where(`${detailsProperty}.${portfolioIdProperty} = :portfolioOrUserId`, {
        portfolioOrUserId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'ASSETTYPE'`)
      .groupBy('ref_asset_type.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }

  public async getSectorsByFund(fundId: string): Promise<Array<IFundSector>> {
    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_sectors.description_en as name_en',
        'ref_sectors.description_he as name_he',
        'sum(fund_items_distribution.item_percentage) as percentage',
        'ref_sectors.id as id',
      ])
      .leftJoin('ref_sectors', 'ref_sectors', 'fund_items_distribution.item_code=ref_sectors.id')
      .where('fund_items_distribution.fund_id = :fundId', {
        fundId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'SECTOR'`)
      .groupBy('ref_sectors.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }

  public async getSectorsByPortfolio(portfolioOrUserId: number | string, kind: PortfolioKind): Promise<IFundSector[]> {
    const [detailsProperty, portfolioIdProperty] = ProposalsMapService.getPropertiesNames(kind);

    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_sectors.description_en as name_en',
        'ref_sectors.description_he as name_he',
        `sum(fund_items_distribution.item_percentage*${detailsProperty}.asset_percentage) as percentage`,
        'ref_sectors.id as id',
      ])
      .innerJoin(
        `${detailsProperty}`,
        `${detailsProperty}`,
        `fund_items_distribution.fund_id=${detailsProperty}.asset_id`,
      )
      .leftJoin('ref_sectors', 'ref_sectors', 'fund_items_distribution.item_code=ref_sectors.id')
      .where(`${detailsProperty}.${portfolioIdProperty} = :portfolioOrUserId`, {
        portfolioOrUserId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'SECTOR'`)
      .groupBy('ref_sectors.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }

  public async getLocationsByFund(fundId: string, assetType?: string): Promise<IFundLocation[]> {
    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_trade_locations.description_en as name_en',
        'ref_trade_locations.description_he as name_he',
        'sum(fund_items_distribution.item_percentage) as percentage',
        'ref_trade_locations.id as id',
      ])
      .leftJoin(
        'ref_trade_locations',
        'ref_trade_locations',
        'fund_items_distribution.item_code=ref_trade_locations.id',
      )
      .where('fund_items_distribution.fund_id = :fundId', {
        fundId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'TRADLOC'`)
      .groupBy('ref_trade_locations.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }

  public async getLocationsByPortfolio(
    portfolioOrUserId: number | string,
    kind: PortfolioKind,
  ): Promise<IFundLocation[]> {
    const [detailsProperty, portfolioIdProperty] = ProposalsMapService.getPropertiesNames(kind);

    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_trade_locations.description_en as name_en',
        'ref_trade_locations.description_he as name_he',
        `sum(fund_items_distribution.item_percentage*${detailsProperty}.asset_percentage) as percentage`,
        'ref_trade_locations.id as id',
      ])
      .innerJoin(
        `${detailsProperty}`,
        `${detailsProperty}`,
        `fund_items_distribution.fund_id=${detailsProperty}.asset_id`,
      )
      .leftJoin(
        'ref_trade_locations',
        'ref_trade_locations',
        'fund_items_distribution.item_code=ref_trade_locations.id',
      )
      .where(`${detailsProperty}.${portfolioIdProperty} = :portfolioOrUserId`, {
        portfolioOrUserId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'TRADLOC'`)
      .groupBy('ref_trade_locations.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }

  public async getCurrencyExposuresByFund(fundId: string): Promise<IFundCurrency[]> {
    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_currency.description_en as currency_description_en',
        'ref_currency.description as currency_description',
        'sum(fund_items_distribution.item_percentage) as percentage',
        'ref_currency.id as id',
      ])
      .leftJoin('ref_currency', 'ref_currency', 'fund_items_distribution.item_code=ref_currency.id')
      .where('fund_items_distribution.fund_id = :fundId', {
        fundId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'CURRENCY'`)
      .groupBy('ref_currency.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }

  public async getCurrencyExposuresByPortfolios(
    portfolioOrUserId: number | string,
    kind: PortfolioKind,
  ): Promise<IFundCurrency[]> {
    const [detailsProperty, portfolioIdProperty] = ProposalsMapService.getPropertiesNames(kind);

    return await this.fundAssetsRepository
      .createQueryBuilder('fund_items_distribution')
      .select([
        'ref_currency.description_en as currency_description_en',
        'ref_currency.description as currency_description',
        `sum(fund_items_distribution.item_percentage*${detailsProperty}.asset_percentage) as percentage`,
        'ref_currency.id as id',
      ])
      .innerJoin(
        `${detailsProperty}`,
        `${detailsProperty}`,
        `fund_items_distribution.fund_id=${detailsProperty}.asset_id`,
      )
      .leftJoin('ref_currency', 'ref_currency', 'fund_items_distribution.item_code=ref_currency.id')
      .where(`${detailsProperty}.${portfolioIdProperty} = :portfolioOrUserId`, {
        portfolioOrUserId,
      })
      .andWhere(`fund_items_distribution.distribution_group = 'CURRENCY'`)
      .groupBy('ref_currency.id')
      .orderBy('percentage', 'DESC')
      .getRawMany();
  }
}
