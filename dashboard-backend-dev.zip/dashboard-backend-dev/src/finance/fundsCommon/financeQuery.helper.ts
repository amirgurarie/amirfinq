import { SelectQueryBuilder } from 'typeorm';
import { Injectable } from '@nestjs/common';

@Injectable()
export class FinanceQueryHelper<T> {
  public addWhereAssetsAssetType(
    query: SelectQueryBuilder<T>,
    assetsTableAlias: string,
    assetType?: string,
  ): SelectQueryBuilder<T> {
    if (assetType) {
      query.andWhere(`upper(${assetsTableAlias}.asset_type) = upper(:assetType)`, {
        assetType,
      });
    }

    return query;
  }
}
