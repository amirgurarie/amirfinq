export interface IPortfolio {
  currency: string;
  batchRunDate?: number;
}
