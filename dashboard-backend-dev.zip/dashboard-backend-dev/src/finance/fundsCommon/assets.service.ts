import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ServiceHelper } from '../../shared/modules/service.helper';
import { Assets } from 'src/entities/Assets';

@Injectable()
export class AssetsService extends ServiceHelper<Assets> {
  constructor(
    @InjectRepository(Assets)
    private readonly assetsRepository: Repository<Assets>,
  ) {
    super(assetsRepository);
  }

  public async findAssetsByArrayIds(assetsIds: string[]): Promise<Assets[]> {
    if (!assetsIds.length) return Promise.resolve([]);

    return await this.assetsRepository.findByIds([...new Set(assetsIds)], {
      relations: ['currency', 'assetType', 'sector', 'tradeLocation', 'assetsLogo'],
    });
  }
}
