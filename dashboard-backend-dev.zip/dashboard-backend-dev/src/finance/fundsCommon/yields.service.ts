import { PortfolioGraphService } from './portfolioGraph.service';
import { Injectable } from '@nestjs/common';
import { GeneralParametersService } from '../../shared/modules/generalParameters/generalParameters.service';
import { FundsHistoryService } from './fundsHistory.service';
import { GeneralParameters } from '../../entities/GeneralParameters';
import { FinanceHelper } from '../finance.helper';
import { RefPortfolioGraphPeriod } from 'src/entities/RefPortfolioGraphPeriod';
import { ChartQueryDto } from '../portfolios/dto/chartQuery.dto';
import { PortfolioGraph } from 'src/entities/PortfolioGraph';

@Injectable()
export class YieldsService {
  private _generalParameters: GeneralParameters;

  constructor(
    private readonly fundsHistoryService: FundsHistoryService,
    private readonly generalParametersService: GeneralParametersService,
    private readonly portfolioGraphService: PortfolioGraphService,
  ) {}

  public async portfolioGraphYields({ portfolioId, queryFilters, column }): Promise<PortfolioGraph[]> {
    return await this.portfolioGraphService.getPortfolioYields(portfolioId, queryFilters, column);
  }

  public async getRefPortfolioPeriod(): Promise<RefPortfolioGraphPeriod[]> {
    return await this.portfolioGraphService.getPeriodList();
  }

  public async getFundYields(
    fundId: string,
    filters: ChartQueryDto,
  ): Promise<{ timestamp: number; value: number; daily_price_change: number }[]> {
    return await this.fundsHistoryService.getFundYields(fundId, filters);
  }

  public async getYAxis(): Promise<{
    unitPrefix: string;
    unitSuffix: string;
  }> {
    const generalParameters = await this.retrieveGeneralParameters();

    return {
      unitPrefix: FinanceHelper.getCurrencySign(generalParameters.currency),
      unitSuffix: '',
    };
  }

  public getGeneralParameters(): GeneralParameters {
    return this._generalParameters;
  }

  public async retrieveGeneralParameters(): Promise<GeneralParameters> {
    const generalParameters = await this.generalParametersService.findFirst();

    if (!generalParameters) {
      throw new Error('Ref Parameters does not exist');
    }

    this._generalParameters = generalParameters;

    return generalParameters;
  }

  private static transformBatchRunDateToString(refParameter: GeneralParameters): string {
    return refParameter.fundBatchRunDate.toISOString().replace('T', ' ').replace('Z', '');
  }
}
