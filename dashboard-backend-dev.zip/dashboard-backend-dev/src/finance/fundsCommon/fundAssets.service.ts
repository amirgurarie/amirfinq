import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ServiceHelper } from '../../shared/modules/service.helper';
import { FundAssets } from '../../entities/FundAssets';
import { IFundAssetType } from './fundAssetType.interface';
import { IFundHolding } from '../funds/interfaces/fundHolding.interface';
import { IFundLocation } from '../funds/interfaces/fundLocation.interface';
import { IFundSector } from '../funds/interfaces/fundSector.interface';
import { FinanceQueryHelper } from './financeQuery.helper';
import { IFundCurrency } from '../funds/interfaces/fundCurrency.interface';
import { PortfolioKind, ProposalsMapService } from '../portfolios/proposals/services/proposalsMap.service';
import { FundItemsDistribution } from '../../entities/FundItemsDistribution';

@Injectable()
export class FundAssetsService extends ServiceHelper<FundAssets> {
  constructor(
    @InjectRepository(FundAssets)
    private readonly fundAssetsRepository: Repository<FundAssets>,
    private readonly financeQueryHelper: FinanceQueryHelper<FundAssets>,
  ) {
    super(fundAssetsRepository);
  }

  public async getHoldingsByFund(
    fundId: string,
    skip: number,
    take: number,
    assetType?: string,
  ): Promise<[IFundHolding[], number]> {
    let query = this.fundAssetsRepository
      .createQueryBuilder('fund_assets')
      .select([
        'assets.id as fund_assets_asset_id',
        'assets.asset_type as fund_asset_type',
        'ref_asset_type.description_en as fund_asset_type_description_en',
        'ref_asset_type.description_he as fund_asset_type_description_he',
        'assets.isin as fund_asset_isin',
        'assets.description as assets_description', // Hebrew name
        'assets.description_en as fund_asset_description_en', // English name
        'sum(fund_assets.asset_percentage) as fund_assets_percentage',
      ])
      .leftJoin('assets', 'assets', 'fund_assets.asset_id=assets.id')
      .innerJoin('ref_asset_type', 'ref_asset_type', 'assets.asset_type=ref_asset_type.id')
      .where('fund_assets.fund_id = :fundId', { fundId })
      .orderBy('fund_assets_percentage', 'DESC', 'NULLS LAST')
      .groupBy('assets.id')
      .addGroupBy('assets.description')
      .addGroupBy('ref_asset_type.id')
      .offset(skip)
      .limit(take);

    query = this.financeQueryHelper.addWhereAssetsAssetType(query, 'assets', assetType);

    return await Promise.all<IFundHolding[], number>([query.getRawMany(), query.getCount()]);
  }

  public async getHoldingsByPortfolio(
    portfolioId: number,
    kind: PortfolioKind,
    skip: number,
    take: number,
    assetType?: string,
  ): Promise<[IFundHolding[], number]> {
    const [detailsProperty, portfolioIdProperty] = ProposalsMapService.getPropertiesNames(kind);

    let query = this.fundAssetsRepository
      .createQueryBuilder('fund_assets')
      .select([
        'assets.id as fund_assets_asset_id',
        'assets.asset_type as fund_asset_type',
        'ref_asset_type.description_en as fund_asset_type_description_en',
        'ref_asset_type.description_he as fund_asset_type_description_he',
        'assets.isin as fund_asset_isin',
        `sum(fund_assets.turnover*${detailsProperty}.asset_percentage) as fund_assets_turnover`,
        `sum(fund_assets.asset_percentage*${detailsProperty}.asset_percentage) as fund_assets_percentage`,
        'assets.description as assets_description',
        'assets.description_en as fund_asset_description_en',
        `sum(assets.yield_month12*${detailsProperty}.asset_percentage) as assets_yield_month12`,
      ])
      .innerJoin(`${detailsProperty}`, `${detailsProperty}`, `fund_assets.fund_id=${detailsProperty}.asset_id`)
      .leftJoin('assets', 'assets', 'fund_assets.asset_id=assets.id')
      .innerJoin('ref_asset_type', 'ref_asset_type', 'assets.asset_type=ref_asset_type.id')
      .where(`${detailsProperty}.${portfolioIdProperty} = :portfolioId`, {
        portfolioId,
      })
      .orderBy('fund_assets_percentage', 'DESC', 'NULLS LAST')
      .groupBy('assets.id')
      .addGroupBy('assets.description')
      .addGroupBy('ref_asset_type.id')
      .offset(skip)
      .limit(take);

    query = this.financeQueryHelper.addWhereAssetsAssetType(query, 'assets', assetType);

    return await Promise.all<IFundHolding[], number>([query.getRawMany(), query.getCount()]);
  }
}
