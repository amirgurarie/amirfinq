import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { DateToEpochTransform } from 'src/shared/decorators/subjects/dateToEpochTransform.decorator';

export class GeneralParametersSubject {
  @Expose()
  @ApiProperty()
  currency: string | null;

  @Expose()
  @ApiProperty()
  localTrade: boolean | null;

  @Expose()
  @ApiProperty()
  alertsMonthlyPrice: number | null;

  @Expose()
  @ApiProperty()
  alertsYearlyPrice: number | null;

  @Expose()
  @ApiProperty()
  fullManagementPrice: number | null;

  @Expose()
  @ApiProperty()
  assetRealtimeInterval: number;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  assetRealtimeUpdateTime: Date;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  fundBatchRunDate: Date | null;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  stockRankingDate: Date | null;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  stockRankingDateTime: Date | null;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  stockRankingYieldDate: Date | null;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  stockRankingYieldDateTime: Date | null;

  @Expose()
  @ApiProperty()
  pensionHoldingsQuarter?: string | null;
}
