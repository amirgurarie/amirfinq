import { Controller, Get, UseFilters, UseInterceptors } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiExtraModels, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AbstractController } from 'src/shared/controller';
import { ApiFailedHttpResponse } from 'src/shared/decorators/apiFailedHttpResponse.decorator';
import { ApiDataObjectResponse } from 'src/shared/decorators/dataResponse.decorator';
import { BadRequestExceptionFilter } from 'src/shared/filters/badRequestException.filter';
import { NotFoundExceptionFilter } from 'src/shared/filters/notFoundException.filter';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { GeneralParametersService } from 'src/shared/modules/generalParameters/generalParameters.service';
import { GeneralParametersSubject } from './subject/generalParameters.subject';

@ApiTags('Finance')
@Controller('v1/generalparameters')
@ApiExtraModels(GeneralParametersSubject)
@UseFilters(NotFoundExceptionFilter, BadRequestExceptionFilter)
export class GeneralParametersController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    private readonly generalParametersService: GeneralParametersService,
  ) {
    super(configService);
  }

  @Get()
  @ApiOperation({ summary: 'Retrieve Site General Parameters' })
  @ApiDataObjectResponse(GeneralParametersSubject, 'Site General Parameters')
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async get() {
    const generalParameter = await this.generalParametersService.findFirst();

    return this.transformToObject(generalParameter, GeneralParametersSubject);
  }
}
