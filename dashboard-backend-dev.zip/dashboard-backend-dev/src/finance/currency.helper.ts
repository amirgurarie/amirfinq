enum CurrencySign {
  nis = '₪',
  dollar = '$',
  dolar = '$',
}

export class CurrencyHelper {
  static getCurrencySign(currencyName: string): string {
    return CurrencySign[currencyName.toLowerCase()] || CurrencySign.nis;
  }

  public static supplementByCurrency(dataToBeUpdated: any[], currency: string) {
    return dataToBeUpdated.map((item) => {
      return Object.assign(item, { currency });
    });
  }
}
