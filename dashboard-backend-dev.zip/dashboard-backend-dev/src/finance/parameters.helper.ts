import dayjs from 'dayjs';
import { RANGE_ELEMENTS_COUNT, STRING_ARRAY_SEPARATOR, STRING_RANGE_SEPARATOR } from '../constants';
import { BadRequestError } from '../shared/errors/badRequest.error';
import { isNullOrUndefined } from 'src/shared/helpers/utils';
import { Brackets, SelectQueryBuilder } from 'typeorm';

export class ParametersHelper {
  static getMinMaxRangeParams(range: string): [string, string] {
    const rangeArray = range.split(STRING_RANGE_SEPARATOR, RANGE_ELEMENTS_COUNT);
    if (rangeArray.length < RANGE_ELEMENTS_COUNT) {
      throw new BadRequestError(null, "Range strings contains less parameters that it's needed");
    }

    return rangeArray as [string, string];
  }

  static getArrayParams(range: string): string[] {
    if (isNullOrUndefined(range)) return [];

    const rangeArray = range.split(STRING_ARRAY_SEPARATOR);

    return rangeArray.map((item) => {
      return item.trim();
    });
  }

  public static transformDateToIsoStringWithoutTimezone(date: Date): string {
    return date.toISOString().replace('T', ' ').replace('Z', '');
  }

  public static addSearch(searchQuery: string, fields: string[]): [string, Record<string, string>] {
    const query = fields.map((arg) => `LOWER(${arg}) like :search`).join(' or ');

    return [query, { search: `%${searchQuery.toLowerCase()}%` }];
  }

  public static subtractDays(days, format = 'YYYY-MM-DD') {
    return dayjs().subtract(days, 'day').format(format);
  }

  static addFlexibleSearch<T>(
    queryBuilder: SelectQueryBuilder<T>,
    search: string,
    columns: string[],
    exactMatchColumns: Set<string> = new Set(), // Add a parameter for exact matches
  ): SelectQueryBuilder<T> {
    if (!search) {
      return queryBuilder;
    }

    const tokens = search
      .replace(/״/g, '"')
      .split(' ')
      .filter((token) => token.trim() !== '');

    for (const [tokenIndex, token] of tokens.entries()) {
      const tokenConditions = [];
      const sanitizedToken = token.replace(/[%_]/g, '\\$&'); // Escape % and _

      for (const [columnIndex, column] of columns.entries()) {
        const parameterKey = `search_${tokenIndex}_${columnIndex}`;
        let condition = `${column} ILIKE :${parameterKey}`;
        let parameterValue = `%${sanitizedToken}%`;

        // Use exact matching for specified columns
        if (exactMatchColumns.has(column)) {
          condition = `${column} = :${parameterKey}`;
          parameterValue = sanitizedToken;
        }

        tokenConditions.push(condition);
        queryBuilder = queryBuilder.setParameter(parameterKey, parameterValue);
      }

      if (tokenConditions.length > 0) {
        const whereCondition = `(${tokenConditions.join(' OR ')})`;
        queryBuilder = queryBuilder.andWhere(whereCondition);
      }
    }

    return queryBuilder;
  }

  static addOrderByRelevance<T>(
    queryBuilder: SelectQueryBuilder<T>,
    search: string,
    columns: string[],
  ): SelectQueryBuilder<T> {
    if (!search) {
      return queryBuilder;
    }

    const tokens = search
      .toLowerCase()
      .split(' ')
      .filter((token) => token.trim() !== '');

    // Add virtual columns for each token in each column and exact match
    for (const [tokenIndex, token] of tokens.entries()) {
      for (const [columnIndex, column] of columns.entries()) {
        // Add virtual columns for exact match
        if (tokenIndex === 0) {
          // Assuming exact match is checked only for the first token
          const exactMatchAlias = `exact_match_${columnIndex}`;
          queryBuilder.addSelect(`(CASE WHEN LOWER(${column}) ILIKE :exactSearch THEN 0 ELSE 1 END)`, exactMatchAlias);
          queryBuilder.addOrderBy(exactMatchAlias, 'ASC');
        }

        // Add virtual columns for token-based match
        const tokenAlias = `token_match_${columnIndex}_${tokenIndex}`;
        queryBuilder.addSelect(`(CASE WHEN LOWER(${column}) ILIKE '%${token}%' THEN 0 ELSE 1 END)`, tokenAlias);
        queryBuilder.addOrderBy(tokenAlias, 'ASC');
      }
    }

    queryBuilder.setParameter('exactSearch', `%${search.toLowerCase().trim()}%`);

    return queryBuilder;
  }

  public static addSearchWithBrackets<T>(queryBuilder: SelectQueryBuilder<T>, search: string, columns: string[]) {
    return queryBuilder.andWhere(
      new Brackets((qb) => {
        qb.where(...ParametersHelper.addSearch(search, columns));
      }),
    );
  }
}
