import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsArray, IsNotEmpty, IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

export class AssetFavoritesDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  public readonly assetId: string;

  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  public readonly assetType: string;
}

export class UpdateAssetFavoritesDto {
  @ValidateNested({ each: true })
  @ApiProperty({
    isArray: true,
    name: 'assets',
    required: true,
    type: AssetFavoritesDto,
  })
  @ArrayNotEmpty()
  @IsArray()
  @Type(() => AssetFavoritesDto)
  public readonly assets: AssetFavoritesDto[];
}

export class InsertAssetFavoritesDto extends UpdateAssetFavoritesDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  public readonly productId: string;
}

export type UpdateAssetFavoritesType = typeof UpdateAssetFavoritesDto;

export type AssetFavoritesType = AssetFavoritesDto;
