import { IsOptional, IsString } from 'class-validator';
import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { PaginationDto } from 'src/shared/dto/pagination.dto';
import { applyDecorators } from '@nestjs/common';

export class FavoritesQueryDto extends PaginationDto {
  @IsString()
  @IsOptional()
  @ApiProperty()
  public readonly product: string;
}

export function ApiFavoritesQueryDto() {
  return applyDecorators(
    ApiQuery({
      name: 'product',
      type: String,
      description: 'Must be a comma-separated list of string, can have several elements. Сan be empty.',
      required: false,
    }),
  );
}
