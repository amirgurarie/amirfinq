import { Injectable, NotFoundException } from '@nestjs/common';
import { FAVORITE_USER_PORTFOLIO_PREFIX, PORTFOLIO_SELECTION_PREFIX } from 'src/constants';
import { Funds } from 'src/entities/Funds';
import { PortfolioSelections } from 'src/entities/PortfolioSelections';
import { RefAssetType } from 'src/entities/RefAssetType';
import { UserFavorite } from 'src/entities/UserFavorite';
import { Users } from 'src/entities/Users';
import { NotFoundError } from 'src/shared/errors/notFound.error';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { In } from 'typeorm';
import { AssetsHelper } from '../assets.helper';
import { FavoriteItemType, getCurrency, getFinqRiskLevelFromObject } from '../portfolios/interfaces/asset.type';
import { AssetTypes } from '../portfolios/interfaces/assetType.const';
import { PortfolioSelectionDetailsInterface } from '../portfolios/selectedPortfolios/interfaces/portfolioSelectionDetails.interface';
import { PortfolioSelectionsInterface } from '../portfolios/selectedPortfolios/interfaces/portfolioSelections.interface';
import { PortfolioSelectionsService } from '../portfolios/selectedPortfolios/services/portfolioSelections.service';
import { RefAssetTypesService } from '../portfolios/services/refAssetTypes.service';
import { AssetFavoritesService } from './assetFavorites.service';
import { AssetFavoritesType, InsertAssetFavoritesDto } from './dto/updateAssetFavorites.dto';
import { UserProposalFavoriteAssetDetailsInterface, UserFavoriteInterface } from './interfaces/favorites.interface';
import { FavoriteAssetInterface } from './types/favorites.interface';
import { FavoritesQueryDto } from './dto/getAssetFavorites.dto';
import { PortfoliosHelperService } from '../portfolios/services/portfoliosHelper.service';
import { FinanceHelper } from '../finance.helper';
import { GeneralParameters } from 'src/entities';

@Injectable()
export class AssetFavoritesManager {
  constructor(
    private readonly assetFavoritesService: AssetFavoritesService,
    private readonly assetsHelper: AssetsHelper,
    private readonly assetTypeService: RefAssetTypesService,
    private readonly portfolioSelectionsService: PortfolioSelectionsService,
    private readonly portfoliosHelperService: PortfoliosHelperService,
    private readonly loggerService: LoggerService,
  ) {}

  public getOriginalPortfolioSelectionsFromAssetsList(
    assetsList: { assetType: RefAssetType | string; assetId: string }[],
    user?: Users,
  ): Promise<PortfolioSelections[]> {
    const portfoliosList = assetsList
      .filter((item) => {
        // TODO: use of PORTFOLIO_ASSET_TYPE doesn't work in here. it returns undefined
        return this.assetsHelper.getAssetTypeId(item.assetType) === 'P';
      })
      .map((item) => {
        return item.assetId;
      });

    return this.portfolioSelectionsService.findByIds(portfoliosList, user);
  }

  public async getFavoritePortfolioSelectionsFromAssetsList(
    favoriteItems: UserFavorite[],
    user?: Users,
  ): Promise<PortfolioSelectionsInterface[]> {
    const portfoliosList = favoriteItems.filter((item) => {
      // TODO: use of PORTFOLIO_ASSET_TYPE doesn't work in here. it returns undefined
      return this.assetsHelper.getAssetTypeId(item.assetType) === 'P';
    });

    const allDetails = await this.assetFavoritesService.findAllFavoriteDetails(portfoliosList);

    // first convert the favorite items to portfolio selections interface
    const interfaces = portfoliosList.map((favorite): PortfolioSelectionsInterface => {
      const item: PortfolioSelectionsInterface = {
        id: favorite.assetId,
        proposalSubType: favorite.proposalSubType,
        proposalType: favorite.proposalType,
        avgYield_1Year: favorite.avgYield_1Year,
        stockExposure: favorite.stockExposure,
        finqRiskLevel: favorite.finqRiskLevel,
      } as PortfolioSelectionsInterface;

      const details = allDetails.filter((details) => {
        return details.favoriteAssets.id == favorite.id;
      });

      item.portfolioSelectionDetails = details.map((detail): PortfolioSelectionDetailsInterface => {
        return {
          id: detail.id,
          assetId: detail.assetId,
          assetPercentage: detail.assetPercentage,
          assetType: detail.assetType,
        } as PortfolioSelectionDetailsInterface;
      });

      return item;
    });

    // second, fill the details taken from the favorite items
    // Use the new Generic function instead of the old one that uses the portfolios selections repository
    const portfolios = await this.portfolioSelectionsService.getGenericPortfoliosSelectionsWithAssets(
      interfaces,
      'favorite',
      user,
    );

    return portfolios;
  }

  public async getFavorites(
    user: Users,
    filters: Omit<FavoritesQueryDto, 'index' | 'size'>,
    skip: number,
    take: number,
  ): Promise<[FavoriteAssetInterface[], number]> {
    const [favoritesItems, count] = await this.assetFavoritesService.getPaginatedFavorites(user, filters, skip, take);

    // extract only the funds and assets
    const [funds, assets] = await this.assetsHelper.getFundsAssetsLists(favoritesItems);

    // extract the portfolios only from the favorite items
    // this will return a full portfolio selection with all it's details and sub funds already filled
    const portfolios = await this.getFavoritePortfolioSelectionsFromAssetsList(favoritesItems, user);

    const fundsAndAssets: FavoriteItemType[] = [...funds, ...assets, ...portfolios];

    const favorites = favoritesItems
      .map((favorite): FavoriteAssetInterface => {
        const item = favorite;
        const fundOrAssetOrPortfolio = fundsAndAssets.find((val) => {
          return String(this.assetsHelper.getAssetId(val)) === String(favorite.assetId);
        });

        if (fundOrAssetOrPortfolio == null) return null; // this should never happen. if it does, debug why.

        const updates: any = {
          type: favorite.assetType.id,
          id: favorite.id,
        };

        if (!('assetId' in fundOrAssetOrPortfolio)) {
          updates.assetId = fundOrAssetOrPortfolio?.['id'];
        }

        return { ...item, asset: Object.assign(fundOrAssetOrPortfolio, updates) };
      })
      // 12/01/2023 - Updating the favorites page with the new design, which might cause to some assets to be null.
      // Until the DB will process through a cleanup, we can remove the line below that filters the null assets.
      .filter(Boolean);

    return [favorites, count];
  }

  public async getFavoriteById(
    favoriteId: number,
    user: Users,
    generalParameters: GeneralParameters,
  ): Promise<FavoriteAssetInterface> {
    const query = this.assetFavoritesService.favoriteAssetsRepository
      .createQueryBuilder('favorites')
      .leftJoinAndSelect('favorites.assetType', 'assetType')
      .leftJoinAndSelect('favorites.proposalType', 'proposalType')
      .leftJoinAndSelect('favorites.product', 'product')
      .where('favorites.user_id = :userId', { userId: user.id })
      .andWhere('favorites.id = :favoriteId', { favoriteId })
      .andWhere('favorites.asset_type is not null')
      .andWhere('favorites.product_id is not null');

    const favorite = await query.getOne();

    const [[funds, assets], portfolios] = await Promise.all([
      // extract only the funds and assets
      this.assetsHelper.getFundsAssetsLists([favorite]),

      // extract the portfolios only from the favorite items
      // this will return a full portfolio selection with all it's details and sub funds already filled
      this.getFavoritePortfolioSelectionsFromAssetsList([favorite], user),
    ]);

    const fundOrAssetOrPortfolio = [...funds, ...assets, ...portfolios].find((val) => {
      return String(this.assetsHelper.getAssetId(val)) === String(favorite.assetId);
    });

    if (fundOrAssetOrPortfolio == null) return null; // this should never happen. if it does, debug why.

    const updates: any = { type: favorite.assetType.id, id: favorite.id };

    if (!('assetId' in fundOrAssetOrPortfolio)) {
      updates.assetId = fundOrAssetOrPortfolio?.['id'];
    }

    const asset = Object.assign(fundOrAssetOrPortfolio, updates);

    const assetWithAdditionalData = Object.assign(asset, {
      batchRunDate: generalParameters.fundBatchRunDate,

      currency: getCurrency(asset) ?? FinanceHelper.getCurrencySign(generalParameters.currency),

      matchPercentage: FinanceHelper.calculateFundMatchPercentage(
        getFinqRiskLevelFromObject(user, 0),
        getFinqRiskLevelFromObject(asset, 1),
      ),
    });

    return assetWithAdditionalData;
  }

  public async addFavorites(favoriteBody: InsertAssetFavoritesDto, user: Users): Promise<UserFavorite[]> {
    const inputAssets = favoriteBody.assets.map((item) => {
      return {
        // remove the portfolio selection prefix in the id
        ...item,
        assetId: item.assetId.replace(PORTFOLIO_SELECTION_PREFIX, ''),
      };
    });

    const [[funds, assets], portfolios] = await Promise.all([
      this.assetsHelper.getFundsAssetsLists(inputAssets),
      this.getOriginalPortfolioSelectionsFromAssetsList(inputAssets),
    ]);

    if (funds.length + assets.length + portfolios.length !== inputAssets.length) {
      throw new NotFoundError(null, 'Asset or Portfolio Selection not found');
    }

    const fundsOrAssetsOrPortfolios = [...funds, ...assets, ...portfolios];
    const usedAssetTypes = this.getUsedAssetTypes(inputAssets);

    const [assetTypes, userFavoriteAssets] = await Promise.all([
      this.assetTypeService.findAll({
        where: { id: In(usedAssetTypes) },
      }),
      this.assetFavoritesService.findAll({
        where: { user, assetType: In(usedAssetTypes) },
        relations: ['assetType'],
      }),
    ]);

    const dataToAdd = await this.collectUsersFavoriteAssets(
      { productId: favoriteBody.productId, assets: inputAssets },
      assetTypes,
      fundsOrAssetsOrPortfolios,
      userFavoriteAssets,
      user,
    );

    //create the entity and it's details arrays
    const res = Promise.all(
      dataToAdd.map(async (data) => {
        const favoriteModel = this.assetFavoritesService.newModel(data);

        let savedDetails = [];
        if (data.userProposalFavoriteAssetDetails?.length) {
          savedDetails = data.userProposalFavoriteAssetDetails.map((detail) => {
            this.loggerService.debug(detail, 'details before adding new favorite');
            const detailEntities = this.assetFavoritesService.favoriteAssetDetailsRepository.create(detail);
            detailEntities.favoriteAssets = favoriteModel;

            return detailEntities;
          });
        }

        const entity = await this.assetFavoritesService.save(favoriteModel, {});

        if (savedDetails.length) {
          await this.assetFavoritesService.favoriteAssetDetailsRepository.save(savedDetails);
        }

        return entity;
      }),
    );

    return res;
  }

  public async removeFromFavoriteAssets(inputAssets: AssetFavoritesType[], user: Users) {
    /*
     * Favorites can be deleted either with the prefixed 'favorite-1234' id or by the assetId itself.
     * To make sure we are deleting the right assets we also need to check the assetType and the user.
     *
     * Steps:
     * 1. Get all the favorite assets of the user
     * 2. Get the right IDs to delete, based on the input assets
     * 3. Delete the favorites and their details
     */
    const promises = inputAssets.map(async ({ assetId, assetType }) => {
      const idFieldName = assetId.startsWith(FAVORITE_USER_PORTFOLIO_PREFIX) ? 'id' : 'assetId';

      const userFavorites = await this.assetFavoritesService.findAll({
        where: { user, assetType, [idFieldName]: this.assetsHelper.cleanPrefixedId(assetId) },
        select: ['id'],
      });

      if (!userFavorites.length) throw new NotFoundException(`Asset ${assetId} not found`);

      return this.assetFavoritesService.removeFavoritesAndDetails(userFavorites);
    });

    return Promise.all(promises);
  }

  private getUsedAssetTypes(inputAssets: AssetFavoritesType[]): string[] {
    return [
      ...new Set(
        inputAssets.map((inputAsset: AssetFavoritesType) => {
          return inputAsset.assetType;
        }),
      ),
    ];
  }

  private collectUsersFavoriteAssets(
    favoriteBody: InsertAssetFavoritesDto,
    assetTypes: RefAssetType[],
    fundsOrAssetsOrPortfolios: FavoriteItemType[],
    userFavoriteAssets: UserFavorite[],
    user: Users,
  ): Promise<Omit<UserFavoriteInterface, 'id'>[]> {
    return favoriteBody.assets.reduce((acc: any, inputAsset) => {
      // Find the asset type
      const assetType = assetTypes.find((assetType) => assetType.id === inputAsset.assetType);

      // Find the fund or asset
      const fundOrAsset = fundsOrAssetsOrPortfolios.find((dbEntity: FavoriteItemType) => {
        return String(this.assetsHelper.getAssetId(dbEntity)) === String(inputAsset.assetId);
      });

      // Check if the asset already exists in the user's favorites
      const existInDb = userFavoriteAssets.find((userAsset) => {
        return userAsset.assetId === inputAsset.assetId && userAsset.assetType.id === assetType.id;
      });

      // If the asset doesn't exist in the user's favorites, add it
      if (!existInDb) {
        const assetToAdd = this.collectUsersFavoriteAsset(fundOrAsset, user, assetType, favoriteBody);
        acc.push(assetToAdd);
      }

      return acc;
    }, []);
  }

  private collectUsersFavoriteAsset(
    asset: FavoriteItemType,
    user: Users,
    assetType: RefAssetType,
    favoriteBody: InsertAssetFavoritesDto,
  ): UserFavoriteInterface {
    if ((asset as PortfolioSelections).proposalType !== undefined) {
      // is portfolio
      // portfolio selection. so take all it's proprties and add it to the favorite asset and details

      const proposal = asset as PortfolioSelections;

      return {
        assetId: String(proposal.id),
        user: user,
        addToFavoriteDate: new Date(),
        assetType: assetType,
        proposalType: proposal.proposalType,
        proposalSubType: proposal.proposalSubType,
        finqRiskLevel: proposal.finqRiskLevel,
        stockExposure: proposal.stockExposure,
        avgYield_1Year: proposal.avgYield_1Year,
        product: favoriteBody.productId,
        userProposalFavoriteAssetDetails: proposal.portfolioSelectionDetails.map(
          (item: any): UserProposalFavoriteAssetDetailsInterface => {
            return {
              assetId: item.assetId,
              assetPercentage: item.assetPercentage,
              assetType: item.assetType,
              assetPrice: (item.asset as Funds).currentPrice,
            };
          },
        ),
      };
    }

    return {
      assetId: String(this.assetsHelper.getAssetId(asset)),
      user,
      addToFavoriteDate: new Date(),
      assetType,
      proposalType: null,
      proposalSubType: null,
      avgYield_1Year: null,
      finqRiskLevel: null,
      stockExposure: null,
      userProposalFavoriteAssetDetails: null,
      product: favoriteBody.productId,
    };
  }

  public async findFullPortfolioOneBy(favoriteId: number, user: Users): Promise<PortfolioSelectionsInterface> {
    const userFavorite = await this.assetFavoritesService.favoriteAssetsRepository.findOne({
      where: { id: favoriteId },
      relations: ['assetType', 'userProposalFavoriteAssetDetails'],
    });

    // extract the portfolios only from the favorite items
    // this will return a full portfolio selection with all it's details and sub funds already filled
    const portfolios = await this.getFavoritePortfolioSelectionsFromAssetsList([userFavorite], user);

    const lists = this.portfoliosHelperService.getAssetsList(portfolios?.[0].portfolioSelectionDetails);
    const [funds, assets] = await this.portfoliosHelperService.getFundsAssetsLists(lists);

    return {
      ...(userFavorite as unknown as PortfolioSelectionsInterface),
      portfolioSelectionDetails: this.portfoliosHelperService.addAssetsToPortfolioDetails(
        userFavorite.userProposalFavoriteAssetDetails,
        funds,
        assets,
      ),
    };
  }
}
