import { UserFavorite } from 'src/entities/UserFavorite';
import { FavoriteItemType } from 'src/finance/portfolios/interfaces/asset.type';

export type AssetDetailsInterface = FavoriteItemType & {
  type: string;
};

export type FavoriteAssetInterface = UserFavorite & {
  asset: AssetDetailsInterface;
};
