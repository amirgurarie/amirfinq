import { ConfigService } from '@nestjs/config';
import { AbstractController } from '../../shared/controller';
import { ApiBearerAuth, ApiExtraModels, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  Post,
  Query,
  UseFilters,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { NotFoundExceptionFilter } from '../../shared/filters/notFoundException.filter';
import { BadRequestExceptionFilter } from '../../shared/filters/badRequestException.filter';
import { LocalJwtAuthGuard } from '../../shared/guards/localJwtAuth.guard';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { CurrentAuthUser } from '../../auth/currentAuthUser.decorator';
import { AuthenticatedUser } from '../../shared/types/authenticatedUser.interface';
import { InsertAssetFavoritesDto, UpdateAssetFavoritesDto } from './dto/updateAssetFavorites.dto';
import { FundsService } from '../funds/funds.service';
import { ConflictExceptionFilter } from '../../shared/filters/conflictException.filter';
import { FinanceHelper } from '../finance.helper';
import { GeneralParametersService } from '../../shared/modules/generalParameters/generalParameters.service';
import { ApiDataArrayResponse } from '../../shared/decorators/dataResponse.decorator';
import { errorSchemaResponse } from '../../shared/decorators/errorSchemaResponse';
import { GeneralParameters } from '../../entities/GeneralParameters';
import { PaginationTransformInterceptor } from '../../shared/interceptors/paginationTransform.interceptor';
import { ApiPaginationQuery } from '../../shared/decorators/apiPaginationQuery.decorator';
import { AssetFavoritesManager } from './assetFavorites.manager';
import { getCurrency, getFinqRiskLevelFromObject } from '../portfolios/interfaces/asset.type';
import { UserFavoriteSubject } from './subject/userFavorites.subject';
import { FavoriteAssetInterface } from './types/favorites.interface';
import { AssetsSubject } from '../stocks/subjects/assets.subject';
import { ApiFavoritesQueryDto, FavoritesQueryDto } from './dto/getAssetFavorites.dto';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';

@ApiTags('Finance')
@Controller('v1/assets/favorites')
@UseFilters(NotFoundExceptionFilter, BadRequestExceptionFilter, ConflictExceptionFilter)
@UseGuards(LocalJwtAuthGuard)
@ApiBearerAuth()
@ApiExtraModels(UserFavoriteSubject, AssetsSubject)
export class AssetFavoritesController extends AbstractController {
  constructor(
    private readonly fundsService: FundsService,
    private readonly generalParametersService: GeneralParametersService,
    protected readonly configService: ConfigService,
    private readonly assetFavoritesManager: AssetFavoritesManager,
    private loggerService: LoggerService,
  ) {
    super(configService);
  }

  @Get()
  @ApiOperation({ summary: 'Get favorites assets for current user' })
  @ApiFailedHttpResponse()
  @ApiDataArrayResponse(UserFavoriteSubject, 'Get favorites assets for current user')
  @ApiPaginationQuery()
  @ApiFavoritesQueryDto()
  @UseInterceptors(PaginationTransformInterceptor)
  public async getFavorites(@CurrentAuthUser() authUserPayload: AuthenticatedUser, @Query() query: FavoritesQueryDto) {
    /*
     1. get favorites for user using skip and take
     2. for each row in favorites, replace it with a matching asset (stock) or portfolio
     3. return the result
    */
    const { index, size, ...filters } = query;
    const { skip, take } = this.pagination(index, size);

    const [rawFavoritesAndCount, generalParameters] = await Promise.all<
      [FavoriteAssetInterface[], number],
      GeneralParameters
    >([
      this.assetFavoritesManager.getFavorites(authUserPayload.user, filters, skip, take),
      this.generalParametersService.findFirst(),
    ]);

    const [rawFavorites, total] = rawFavoritesAndCount;

    const currency = FinanceHelper.getCurrencySign(generalParameters.currency);

    const additionalData = {
      currency,
      user: authUserPayload.user,
      batchRunDate: generalParameters.fundBatchRunDate,
    };

    const assetsResults = rawFavorites.map((favorite) => {
      const additionalAssetData = Object.assign(favorite.asset, {
        matchPercentage: FinanceHelper.calculateFundMatchPercentage(
          additionalData?.user ? additionalData?.user?.finqRiskLevel : 0,
          getFinqRiskLevelFromObject(favorite.asset, 1),
        ),
        currency: getCurrency(favorite.asset) ?? additionalData.currency,
        batchRunDate: additionalData.batchRunDate,
      });

      favorite.asset = additionalAssetData;

      return favorite;
    });

    const assets = this.transformToArray(assetsResults, UserFavoriteSubject);

    return {
      data: assets,
      total,
      index: skip,
      size: assets.length,
    } as IPaginatedDataResponse<UserFavoriteSubject>;
  }

  @Post()
  @HttpCode(200)
  @ApiOperation({ summary: 'Add assets to current user favorites assets' })
  @ApiFailedHttpResponse()
  @ApiResponse({
    status: 200,
    description: 'Favorite assets have been added or favorite assets are already added to the current user',
    schema: {
      properties: {
        data: {
          type: 'boolean',
        },
      },
    },
  })
  @UseInterceptors(TransformInterceptor)
  public async addFavorites(
    @CurrentAuthUser() authUserPayload: AuthenticatedUser,
    @Body() favoriteBody: InsertAssetFavoritesDto,
  ) {
    await this.assetFavoritesManager.addFavorites(favoriteBody, authUserPayload.user);
  }

  @Delete()
  @ApiOperation({ summary: "Remove assets from user's favorite assets" })
  @ApiFailedHttpResponse()
  @ApiResponse({
    status: 200,
    description: 'Asset has been deleted from favorite',
    schema: {
      properties: {
        data: {
          type: 'boolean',
        },
      },
    },
  })
  @ApiResponse({
    status: 409,
    description: "Cannot remove favorite assets that don't exist or don't belong to current user",
    schema: errorSchemaResponse,
  })
  @UseInterceptors(TransformInterceptor)
  public async deleteFavorites(
    @CurrentAuthUser() authUserPayload: AuthenticatedUser,
    @Body() assetFavorites: UpdateAssetFavoritesDto,
  ) {
    await this.assetFavoritesManager.removeFromFavoriteAssets(assetFavorites.assets, authUserPayload.user);

    return {};
  }
}
