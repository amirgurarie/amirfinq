import { RefProposalType } from 'src/entities/RefProposalType';
import { UserFavoriteDetails } from 'src/entities/UserFavoriteDetails';
import { UserFavorite } from 'src/entities/UserFavorite';

export type UserFavoriteInterface = Omit<UserFavorite, 'id' | 'userProposalFavoriteAssetDetails'> & {
  userProposalFavoriteAssetDetails: UserProposalFavoriteAssetDetailsInterface[];
};

export type UserProposalFavoriteAssetDetailsInterface = Omit<UserFavoriteDetails, 'id' | 'favoriteAssets'> & {};
