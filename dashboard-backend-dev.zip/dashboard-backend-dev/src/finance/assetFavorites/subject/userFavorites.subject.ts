import { FavoriteStockSubject } from './favoriteStock.subject';
import { ApiProperty, getSchemaPath } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { GeneralAssetDetailsSubject } from 'src/finance/portfolios/subject/generalAssetDetails.subject';
import { DateToEpochTransform } from 'src/shared/decorators/subjects/dateToEpochTransform.decorator';
import { TransformToProperty } from 'src/shared/decorators/subjects/transformToProperty.decorator';
import { FavoriteAssetSubject } from './favoriteAsset.subject';
import { FavoriteFundSubject } from './favoriteFund.subject';
import { FavoritePortfolioSubject } from './favoritePortfolio.subject';

export class UserFavoriteSubject {
  @Expose()
  @ApiProperty({
    description: 'Timestamp in seconds',
  })
  @DateToEpochTransform()
  addToFavoriteDate?: number;

  @Expose()
  @ApiProperty()
  @TransformToProperty('product.id')
  productId?: string;

  @Expose()
  @Type(() => GeneralAssetDetailsSubject, {
    discriminator: {
      property: 'type',
      subTypes: [
        { value: FavoriteFundSubject, name: 'F' },
        { value: FavoriteStockSubject, name: 'S' },
        { value: FavoriteAssetSubject, name: 'CB' },
        { value: FavoriteAssetSubject, name: 'GB' },
        { value: FavoriteAssetSubject, name: 'O' },
        { value: FavoriteAssetSubject, name: 'C' },
        { value: FavoritePortfolioSubject, name: 'P' },
      ],
    },
    keepDiscriminatorProperty: true,
  })
  @ApiProperty({
    required: true,
    isArray: false,
    oneOf: [
      { $ref: getSchemaPath(FavoriteFundSubject) },
      { $ref: getSchemaPath(FavoriteStockSubject) },
      { $ref: getSchemaPath(FavoriteAssetSubject) },
      { $ref: getSchemaPath(FavoritePortfolioSubject) },
    ],
  })
  asset?: FavoriteFundSubject | FavoriteStockSubject | FavoriteAssetSubject | FavoritePortfolioSubject;
}
