import { ApiProperty, OmitType } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { FAVORITE_USER_PORTFOLIO_PREFIX } from 'src/constants';
import { StocksSubject } from 'src/finance/stocks/subjects/stocks.subject';
import { PrefixWith } from 'src/shared/decorators/subjects/prefixWith.decorator';

export class FavoriteStockSubject extends OmitType(StocksSubject, ['assetId'] as const) {
  @Expose()
  @ApiProperty()
  @PrefixWith(FAVORITE_USER_PORTFOLIO_PREFIX)
  id: string;

  @ApiProperty()
  @Expose()
  assetId: string;
}
