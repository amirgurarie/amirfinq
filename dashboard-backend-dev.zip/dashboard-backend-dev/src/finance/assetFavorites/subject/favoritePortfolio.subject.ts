import { Expose, Transform, Type } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { FAVORITE_USER_PORTFOLIO_PREFIX, PORTFOLIO_SELECTION_PREFIX } from 'src/constants';
import { isFund } from 'src/finance/portfolios/interfaces/asset.type';
import { PORTFOLIO_ASSET_TYPE } from 'src/finance/portfolios/interfaces/assetType.const';
import { PortfolioSelectionsInterface } from 'src/finance/portfolios/selectedPortfolios/interfaces/portfolioSelections.interface';
import { PortfolioSelectionDetailSubject } from 'src/finance/portfolios/selectedPortfolios/subject/portfolioSelectionDetail.subject';
import { PortfoliosSubjectHelper } from 'src/finance/portfolios/subject/portfoliosSubject.helper';
import { PortfolioUnifiedSubject } from 'src/finance/portfolios/subject/portfoliosUnified.subject';
import { DateToEpochTransform } from 'src/shared/decorators/subjects/dateToEpochTransform.decorator';
import { PrefixWith } from 'src/shared/decorators/subjects/prefixWith.decorator';

export class FavoritePortfolioSubject extends PortfolioUnifiedSubject {
  @Expose()
  @ApiProperty()
  @PrefixWith(FAVORITE_USER_PORTFOLIO_PREFIX)
  id: string;

  @Expose()
  @ApiProperty()
  @PrefixWith(PORTFOLIO_SELECTION_PREFIX)
  assetId?: string;

  @Expose()
  @ApiProperty()
  portfolioStatus?: string;

  @Expose()
  @ApiProperty()
  matchPercentage?: number;

  @Expose()
  @ApiProperty()
  assetPrice?: number;

  @Expose()
  @ApiProperty()
  starRating?: number;

  @Expose()
  @ApiProperty()
  finqRiskLevel?: number;

  @Expose()
  @ApiProperty()
  stockExposure?: number;

  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('maxStockExposure', value.obj);
    },
    { toPlainOnly: true },
  )
  maxStockExposure?: number;

  @Expose()
  @ApiProperty({
    description: 'Timestamp in seconds',
  })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.getMaxHoldingUpdateDateFromFunds(value.obj);
    },
    { toPlainOnly: true },
  )
  maxHoldingsUpdateDate?: number;

  @Expose()
  @ApiProperty({
    description: 'Timestamp in seconds',
  })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.getMinHoldingUpdateDateFromFunds(value.obj);
    },
    { toPlainOnly: true },
  )
  minHoldingsUpdateDate?: number;

  @Expose({ name: 'avgYield1Year', toPlainOnly: true })
  @ApiProperty()
  avgYield_1Year?: number;

  @Expose()
  @DateToEpochTransform()
  @ApiProperty()
  batchRunDate?: number;

  @Expose()
  @ApiProperty()
  proposalSubType?: string;

  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('dailyPriceChange', value.obj);
    },
    { toPlainOnly: true },
  )
  dailyPriceChange?: number;

  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('internalYield', value.obj);
    },
    { toPlainOnly: true },
  )
  internalYield?: number;

  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('fundSize', value.obj);
    },
    { toPlainOnly: true },
  )
  assetSize?: number;

  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('esg', value.obj);
    },
    { toPlainOnly: true },
  )
  esg?: number;

  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('bondAvgDuration', value.obj);
    },
    { toPlainOnly: true },
  )
  bondAvgDuration?: number;

  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('managementFee', value.obj);
    },
    { toPlainOnly: true },
  )
  managementFee?: number;

  @Expose({ name: '3MonthYield', toPlainOnly: true })
  @ApiProperty({ name: '3MonthYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yield_3Months', value.obj);
    },
    { toPlainOnly: true },
  )
  getYieldMonth3() {
    return 0;
  }

  @Expose({ name: '1MonthYield', toPlainOnly: true })
  @ApiProperty({ name: '1MonthYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yield_1Month', value.obj);
    },
    { toPlainOnly: true },
  )
  getYieldMonth1() {
    return 0;
  }

  @Expose({ name: '1WeekYield', toPlainOnly: true })
  @ApiProperty({ name: '1WeekYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yield_1Week', value.obj);
    },
    { toPlainOnly: true },
  )
  getYieldWeek1() {
    return 0;
  }

  @Expose({ name: 'YearTDYield', toPlainOnly: true })
  @ApiProperty({ name: 'YearTDYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yieldYtd', value.obj);
    },
    { toPlainOnly: true },
  )
  getYieldYearTD() {
    return 0;
  }

  @Expose({ name: 'oneYearYield', toPlainOnly: true })
  @ApiProperty({ name: 'oneYearYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yield_1Year', value.obj);
    },
    { toPlainOnly: true },
  )
  getOneYieldYearTD() {
    return 0;
  }

  @Expose({ name: '2YearYield', toPlainOnly: true })
  @ApiProperty({ name: '2YearYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yield_2Years', value.obj);
    },
    { toPlainOnly: true },
  )
  get2YieldYearTD() {
    return 0;
  }

  @Expose({ name: '3YearYield', toPlainOnly: true })
  @ApiProperty({ name: '3YearYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yield_3Years', value.obj);
    },
    { toPlainOnly: true },
  )
  get3YieldYearTD() {
    return 0;
  }

  @Expose({ name: '5YearYield', toPlainOnly: true })
  @ApiProperty({ name: '5YearYield', type: 'number' })
  @Transform(
    (value) => {
      return PortfoliosSubjectHelper.calculateAveragePortfolioParametersFromFunds('yield_5Years', value.obj);
    },
    { toPlainOnly: true },
  )
  get5YieldYearTD() {
    return 0;
  }

  @Expose()
  @ApiProperty()
  currency: string;

  @Expose()
  @ApiProperty({ type: 'boolean' })
  @Transform(
    (value) => {
      const portfolio = value.obj as PortfolioSelectionsInterface;

      return portfolio?.portfolioSelectionDetails.some((userProposalDetail) => {
        return isFund(userProposalDetail?.asset) ? userProposalDetail?.asset?.dividendExist : false;
      });
    },
    { toPlainOnly: true },
  )
  get dividendExist() {
    return false;
  }

  @Expose({ name: 'assetsDetails', toPlainOnly: true })
  @Type(() => PortfolioSelectionDetailSubject)
  @ApiProperty({
    required: true,
    isArray: true,
    type: PortfolioSelectionDetailSubject,
    name: 'assetsDetails',
  })
  portfolioSelectionDetails?: PortfolioSelectionDetailSubject[];

  @Expose({ toPlainOnly: true })
  @ApiProperty({
    type: String,
  })
  get assetType(): string {
    return PORTFOLIO_ASSET_TYPE;
  }
}
