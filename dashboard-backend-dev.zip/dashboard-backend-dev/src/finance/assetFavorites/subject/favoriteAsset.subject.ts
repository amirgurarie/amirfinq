import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { FAVORITE_USER_PORTFOLIO_PREFIX } from 'src/constants';
import { AssetsSubject } from 'src/finance/stocks/subjects/assets.subject';
import { PrefixWith } from 'src/shared/decorators/subjects/prefixWith.decorator';

export class FavoriteAssetSubject extends AssetsSubject {
  @Expose()
  @ApiProperty()
  @PrefixWith(FAVORITE_USER_PORTFOLIO_PREFIX)
  id: string;

  @ApiProperty()
  @Expose()
  assetId: string;
}
