import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';
import { FAVORITE_USER_PORTFOLIO_PREFIX } from 'src/constants';
import { FundSubject } from 'src/finance/portfolios/subject/fund.subject';
import { PrefixWith } from 'src/shared/decorators/subjects/prefixWith.decorator';

export class FavoriteFundSubject extends FundSubject {
  @Expose()
  @ApiProperty()
  @PrefixWith(FAVORITE_USER_PORTFOLIO_PREFIX)
  id: string;

  @Expose()
  @ApiProperty()
  assetId: string;
}
