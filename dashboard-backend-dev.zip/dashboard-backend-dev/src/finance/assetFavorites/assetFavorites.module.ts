import { StocksModule } from './../stocks/stocks.module';
import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AssetFavoritesController } from './assetFavorites.controller';
import { AssetFavoritesService } from './assetFavorites.service';
import { LoggerModule } from '../../shared/middlewares/logger/logger.module';
import { FundsModule } from '../funds/funds.module';
import { GeneralParametersModule } from '../../shared/modules/generalParameters/generalParameters.module';
import { UserFavorite } from 'src/entities/UserFavorite';
import { AssetFavoritesManager } from './assetFavorites.manager';
import { AssetsHelper } from '../assets.helper';
import { PortfoliosModule } from '../portfolios/portfolios.module';
import { FundsCommonModule } from '../fundsCommon/fundsCommon.module';
import { PortfolioSelectionsModule } from '../portfolios/selectedPortfolios/portfolioSelections.module';
import { UserFavoriteDetails } from 'src/entities/UserFavoriteDetails';
import { ProductsModule } from 'src/common/products/products.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([UserFavorite, UserFavoriteDetails]),
    LoggerModule,
    GeneralParametersModule,
    forwardRef(() => ProductsModule),
    forwardRef(() => FundsModule),
    forwardRef(() => FundsCommonModule),
    forwardRef(() => PortfoliosModule),
    forwardRef(() => PortfolioSelectionsModule),
    forwardRef(() => StocksModule),
  ],
  controllers: [AssetFavoritesController],
  providers: [AssetFavoritesService, AssetFavoritesManager, AssetsHelper],
  exports: [AssetFavoritesService, AssetFavoritesManager, AssetsHelper],
})
export class AssetFavoritesModule {}
