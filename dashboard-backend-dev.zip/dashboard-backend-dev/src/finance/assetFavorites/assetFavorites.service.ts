import { FUND_ASSET_TYPE } from './../portfolios/interfaces/assetType.const';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { ServiceHelper } from '../../shared/modules/service.helper';
import { UserFavorite } from 'src/entities/UserFavorite';
import { Users } from 'src/entities/Users';
import { Injectable } from '@nestjs/common';
import { UserFavoriteDetails } from 'src/entities/UserFavoriteDetails';
import { FavoritesQueryDto } from './dto/getAssetFavorites.dto';
import { ParametersHelper } from '../parameters.helper';
import { RefAssetType } from 'src/entities';
import { PortfoliosHelperService } from '../portfolios/services/portfoliosHelper.service';

@Injectable()
export class AssetFavoritesService extends ServiceHelper<UserFavorite> {
  constructor(
    @InjectRepository(UserFavorite)
    public readonly favoriteAssetsRepository: Repository<UserFavorite>,
    @InjectRepository(UserFavoriteDetails)
    public readonly favoriteAssetDetailsRepository: Repository<UserFavoriteDetails>,
    protected readonly configService: ConfigService,
    protected readonly portfoliosHelperService: PortfoliosHelperService,
  ) {
    super(favoriteAssetsRepository);
  }

  public async getPaginatedFavorites(
    user: Users,
    filters: Omit<FavoritesQueryDto, 'index' | 'size'>,
    skip: number,
    take: number,
  ): Promise<[UserFavorite[], number]> {
    const query = this.favoriteAssetsRepository
      .createQueryBuilder('favorites')
      .leftJoinAndSelect('favorites.assetType', 'assetType')
      .leftJoinAndSelect('favorites.proposalType', 'proposalType')
      .leftJoinAndSelect('favorites.product', 'product')
      .where('favorites.user_id = :userId', { userId: user.id })
      .andWhere('favorites.asset_type is not null')
      .andWhere('favorites.product_id is not null')
      .orderBy('favorites.add_to_favorite_date', 'DESC');

    if (filters.product) {
      query.andWhere('favorites.product_id in (:...product)', {
        product: ParametersHelper.getArrayParams(filters.product),
      });
    }

    return query.offset(skip).limit(take).getManyAndCount();
  }

  public async findAllFavoriteDetails(favorites: UserFavorite[]): Promise<UserFavoriteDetails[]> {
    const selections = favorites.map((favorite) => {
      return { favoriteAssets: favorite };
    });
    const res = await this.favoriteAssetDetailsRepository.find({
      where: selections,
      relations: ['favoriteAssets', 'assetType'],
    });

    return res;
  }

  public async removeFavoritesAndDetails(favorites: UserFavorite[]) {
    if (!favorites.length) return [];

    // First we look for favorites details
    // If theres any, we delete them, then we delete the favorite itself

    const favoritesIds = favorites.map((favorite) => favorite.id);
    const favoritesDetails = await this.favoriteAssetDetailsRepository.find({
      where: { favoriteAssets: In(favoritesIds) },
      select: ['id'],
    });
    const detailsIds = favoritesDetails.map((details) => details.id);

    return Promise.all([
      favoritesDetails.length ? this.favoriteAssetDetailsRepository.delete(detailsIds) : null,
      this.favoriteAssetsRepository.delete(favoritesIds),
    ]);
  }
}
