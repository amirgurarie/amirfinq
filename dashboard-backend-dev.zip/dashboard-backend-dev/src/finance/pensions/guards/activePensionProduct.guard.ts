// import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
// import { ProductsEnum } from 'src/shared/enums';
// import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';
// import { UserSubscriptionsService } from 'src/users/userSubscriptions/user-subscriptions.service';

// Validates that user is has an active Pension product
// NOT IN USE
// @Injectable()
// export class ActivePensionProductGuard implements CanActivate {
//   constructor(public userSubscriptionsService: UserSubscriptionsService) {}

//   public async canActivate(context: ExecutionContext) {
//     const request = context.switchToHttp().getRequest();
//     const authUserPayload = request.user as AuthenticatedUser;

//     const userProducts = await this.userSubscriptionsService.findActiveSubscriptionsByProdCodes(
//       authUserPayload.user?.id,
//       [ProductsEnum.Pensions],
//     );

//     if (!userProducts.length) {
//       return false;
//     }

//     return true;
//   }
// }
