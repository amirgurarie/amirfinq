import { Controller, UseFilters, Get, UseInterceptors, Query, Param } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiTags, ApiExtraModels } from '@nestjs/swagger';
import { PensionsService } from 'src/finance/pensions/pensions.service';
import { PensionDepotCategoriesSubject } from 'src/finance/pensions/subject/pensionDepotCategories.subject';
import { PensionDepotExposureFilterSubject } from 'src/finance/pensions/subject/pensionDepotExposure.subject';
import { PensionDepotFundCompanySubject } from 'src/finance/pensions/subject/pensionDepotFundCompany.subject';
import { AbstractController } from 'src/shared';
import { CommonApiQueries } from 'src/shared/decorators/combinedDecorators.decorator';
import {
  ApiDataObjectResponse,
  ApiDataArrayResponse,
  ApiDataPaginatedResponse,
} from 'src/shared/decorators/dataResponse.decorator';
import { BadRequestExceptionFilter } from 'src/shared/filters/badRequestException.filter';
import { ForbiddenExceptionFilter } from 'src/shared/filters/forbiddenException.filter';
import { NotFoundExceptionFilter } from 'src/shared/filters/notFoundException.filter';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { PensionDepotFundSecondaryCategoryFilterSubject } from '../subject/pensionDepotFundSecondaryCategory.subject';
import {
  ApiPensionDepotCompanyFilter,
  ApiPensionDepotExposureFilter,
  ApiPensionDepotFundsFilter,
  ApiPensionDepotSecondaryFilter,
  ApiPensionDepotSubcategoryFilter,
  PensionDepotCompaniesFilterDto,
  PensionDepotExposureFilterDto,
  PensionDepotFundsFilterDto,
  PensionDepotSecondaryCategoryFilterDto,
  PensionDepotSubcategoryFilterDto,
} from '../dto/pensionDepotFilter.dto';
import { PensionDepotFundsSubject } from '../subject/pensionDepotFunds.subject';
import { PaginationTransformInterceptor } from 'src/shared/interceptors/paginationTransform.interceptor';

@ApiTags('Pensions')
@Controller('v1/pensions/depot/filters')
@ApiExtraModels(
  PensionDepotExposureFilterSubject,
  PensionDepotFundCompanySubject,
  PensionDepotCategoriesSubject,
  PensionDepotFundSecondaryCategoryFilterSubject,
  PensionDepotFundsSubject,
)
@UseFilters(NotFoundExceptionFilter, BadRequestExceptionFilter, ForbiddenExceptionFilter)
export class PensionsFiltersController extends AbstractController {
  constructor(protected readonly configService: ConfigService, protected readonly pensionsService: PensionsService) {
    super(configService);
  }

  @Get('/exposure')
  @CommonApiQueries({ summary: 'Depot filters exposure subcategory' })
  @ApiPensionDepotExposureFilter()
  @ApiDataObjectResponse(PensionDepotExposureFilterSubject, 'Depot filters exposure')
  @UseInterceptors(TransformInterceptor)
  public async getDepotExposureSubcategoryFilters(@Query() filters: PensionDepotExposureFilterDto) {
    const data = await this.pensionsService.getDepotExposureFilters(filters);

    return this.transformToObject(data, PensionDepotExposureFilterSubject);
  }

  @Get('/company')
  @CommonApiQueries({ summary: 'Depot filters fund company' })
  @ApiPensionDepotCompanyFilter()
  @ApiDataArrayResponse(PensionDepotFundCompanySubject, 'Depot filters fund company')
  @UseInterceptors(TransformInterceptor)
  public async getDepotFundCompanyFilters(@Query() filters: PensionDepotCompaniesFilterDto) {
    const data = await this.pensionsService.getDepotFundCompany(filters);

    const res = data.map((company) => ({
      id: company.companyId,
      shortText: company.shortText,
      fundsCount: company.funds.length,
      logoPath: company.logoPath,
    }));

    return this.transformToArray(res, PensionDepotFundCompanySubject);
  }

  @Get('/subcategory')
  @ApiPensionDepotSubcategoryFilter()
  @ApiDataArrayResponse(PensionDepotCategoriesSubject, 'Pensions Sub Categories')
  @UseInterceptors(TransformInterceptor)
  public async getDepotCategoryFilters(@Query() filters: PensionDepotSubcategoryFilterDto) {
    const data = await this.pensionsService.getDepotSubCategory(filters);
    const parsedData = this.pensionsService.groupBySubCategoryThenSecondaryCategory(data);

    return this.transformToArray(parsedData, PensionDepotCategoriesSubject);
  }

  @Get('/secondaryCategory')
  @ApiPensionDepotSecondaryFilter()
  @ApiDataArrayResponse(PensionDepotFundSecondaryCategoryFilterSubject, 'Pension depot secondary category')
  @UseInterceptors(TransformInterceptor)
  public async getDepotSubcategoryFilters(@Query() filters: PensionDepotSecondaryCategoryFilterDto) {
    const data = await this.pensionsService.getDepotSecondaryCategory(filters);

    return this.transformToArray(data, PensionDepotFundSecondaryCategoryFilterSubject);
  }

  @Get('/funds')
  @ApiPensionDepotFundsFilter()
  @ApiDataPaginatedResponse(PensionDepotFundsSubject, 'Pension depot secondary category')
  @UseInterceptors(PaginationTransformInterceptor)
  public async getFundsFlexibleSearch(@Query() query: PensionDepotFundsFilterDto) {
    const { index, size, ...filters } = query;
    const { skip, take } = this.pagination(index, size);
    const [data, total] = await this.pensionsService.getFundsByFlexibleSearch(filters, skip, take);

    const res = this.transformToArray(data, PensionDepotFundsSubject);

    return {
      data: res,
      index: skip,
      size: data.length,
      total,
    } as IPaginatedDataResponse<PensionDepotFundsSubject>;
  }
}
