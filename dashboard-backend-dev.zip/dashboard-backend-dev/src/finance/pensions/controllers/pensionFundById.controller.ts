import {
  Controller,
  UseFilters,
  Get,
  UseInterceptors,
  Param,
  Query,
  NotFoundException,
  UseGuards,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiTags, ApiExtraModels, ApiBearerAuth } from '@nestjs/swagger';
import { ParametersHelper } from 'src/finance/parameters.helper';
import { ApiPensionFundYieldsApiQuery, PensionFundYieldsDto } from 'src/finance/pensions/dto/pensionFundYields.dto';
import { DistributionGroupType } from 'src/finance/pensions/enum/pensionDistributions.enum';
import { PensionsService } from 'src/finance/pensions/pensions.service';
import {
  PensionFundInvestmentPolicySubject,
  BasePensionFundSubject,
} from 'src/finance/pensions/subject/pensionFund.subject';
import {
  PensionFundDistributionItemSubject,
  PensionFundDistributionSubject,
} from 'src/finance/pensions/subject/pensionFundDistribtions.subject';
import { PensionFundYieldsSubject } from 'src/finance/pensions/subject/pensionFundYields.subject';
import { ExtendedPensionLeadingFundsSubject } from 'src/finance/pensions/subject/pensionLeadingFunds.subject';
import { AbstractController } from 'src/shared';
import { CommonApiQueries } from 'src/shared/decorators/combinedDecorators.decorator';
import {
  ApiDataObjectResponse,
  ApiDataArrayResponse,
  ApiDataPaginatedResponse,
} from 'src/shared/decorators/dataResponse.decorator';
import { BadRequestExceptionFilter } from 'src/shared/filters/badRequestException.filter';
import { ForbiddenExceptionFilter } from 'src/shared/filters/forbiddenException.filter';
import { NotFoundExceptionFilter } from 'src/shared/filters/notFoundException.filter';
import { PaginationTransformInterceptor } from 'src/shared/interceptors/paginationTransform.interceptor';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { PensionFundHoldingsSubject } from '../subject/pensionFundHoldings.subject';
import { AnonymousLocalJwtAuthGuard } from 'src/shared/guards/anonymousLocalJwtAuth.guard';
import { PensionSingleFundComparedYieldLockTransformerInterceptor } from '../transformers/pensionSingleFundComparedYieldsLock.transformer';
import { ApiPensionDistributionFilter, PensionDistributionDto } from '../dto/pensionDistribution.dto';
import { ApiPensionHoldingsFilter, PensionHoldingsDto } from '../dto/pensionHolding.dto';
import { PensionSingleFundHoldingsLockTransformerInterceptor } from '../transformers/pensionSingleFundHoldingsLock.transformer';
import { PensionSingleFundExposuresLockTransformerInterceptor } from '../transformers/pensionSingleFundExposuresLock.transformer';
import { PensionFundStockExposureSubject } from '../subject/pensionFundStockExposure.subject';
import dayjs from 'dayjs';
import { ApiPensionComparisonYieldsFilter, PensionComparisonYieldsDto } from '../dto/pensionComparisonYields.dto';

@ApiTags('Pensions')
@Controller('v1/pensions/fund/:fundHash')
@ApiExtraModels(
  BasePensionFundSubject,
  PensionFundInvestmentPolicySubject,
  PensionFundYieldsSubject,
  PensionFundDistributionSubject,
  ExtendedPensionLeadingFundsSubject,
  PensionFundHoldingsSubject,
)
@UseFilters(NotFoundExceptionFilter, BadRequestExceptionFilter, ForbiddenExceptionFilter)
export class PensionsFundByIdController extends AbstractController {
  constructor(protected readonly configService: ConfigService, protected readonly pensionsService: PensionsService) {
    super(configService);
  }

  @Get('/')
  @CommonApiQueries({ summary: 'Pension company details by id' })
  @ApiDataObjectResponse(BasePensionFundSubject, 'Pension company by id')
  @UseGuards(AnonymousLocalJwtAuthGuard) // required for UserHasPensionTransformInterceptor
  @ApiBearerAuth()
  @UseInterceptors(TransformInterceptor)
  public async getFundById(@Param('fundHash') fundHash: string) {
    const data = await this.pensionsService.getFundById(fundHash);

    return this.transformToObject(data, BasePensionFundSubject);
  }

  @Get('/investmentPolicy')
  @CommonApiQueries({ summary: 'Pension company details by id' })
  @ApiDataObjectResponse(PensionFundInvestmentPolicySubject, 'Pension company by id')
  @UseInterceptors(TransformInterceptor)
  public async getFundInvestmentPolicy(@Param('fundHash') fundHash: string) {
    const data = await this.pensionsService.getFundInvestmentPolicyById(fundHash);

    return this.transformToObject(data, PensionFundInvestmentPolicySubject);
  }

  @Get('/yields')
  @ApiPensionFundYieldsApiQuery()
  @ApiDataArrayResponse(PensionFundYieldsSubject, 'Pension fund yields by id, allows comparison with other funds')
  @UseInterceptors(TransformInterceptor)
  public async getPensionYieldsByIds(@Param('fundHash') fundHash: string, @Query() query: PensionFundYieldsDto) {
    const { comparedWith, ...filters } = query;
    const ids = [fundHash, ...ParametersHelper.getArrayParams(comparedWith)];

    const data = await this.pensionsService.getPensionYieldsByIds(ids, filters);

    if (!data || data.some((item) => !item.datasets?.length)) {
      throw new NotFoundException(`No data found for funds with ids: ${ids.join(', ')}`);
    }

    const charts = this.transformToArray(data, PensionFundYieldsSubject);

    return { charts };
  }

  @Get('/yields/comparisons')
  @UseGuards(AnonymousLocalJwtAuthGuard) // required for UserHasPensionTransformInterceptor
  @ApiBearerAuth()
  @ApiPensionComparisonYieldsFilter()
  @ApiDataArrayResponse(PensionFundYieldsSubject, 'Pension fund yields by id, allows comparison with other funds')
  @UseInterceptors(PensionSingleFundComparedYieldLockTransformerInterceptor, TransformInterceptor)
  public async getPensionYieldsComparisons(
    @Param('fundHash') fundHash: string,
    @Query() query: PensionComparisonYieldsDto,
  ) {
    const data = await this.pensionsService.getFollowingRankFunds(fundHash, query);

    return this.transformToArray(data, ExtendedPensionLeadingFundsSubject);
  }

  @Get('/holdings')
  @UseGuards(AnonymousLocalJwtAuthGuard) // required for UserHasPensionTransformInterceptor
  @ApiBearerAuth()
  @CommonApiQueries({ summary: 'Pension Holdings by fund Id' })
  @ApiPensionHoldingsFilter()
  @ApiDataPaginatedResponse(PensionFundHoldingsSubject, 'Fund Pension holdings by id')
  @UseInterceptors(PensionSingleFundHoldingsLockTransformerInterceptor, PaginationTransformInterceptor)
  public async getFundPensionHoldingsByFundId(@Param('fundHash') fundHash: string, @Query() query: PensionHoldingsDto) {
    const { index, size, ...filters } = query;
    const { skip, take } = this.pagination(index, size);

    const [data, total] = await this.pensionsService.getFundHoldingsWithFilters(fundHash, take, skip, filters);
    const res = this.transformToArray(data, PensionFundHoldingsSubject);

    return {
      data: res,
      index: skip,
      size: data.length,
      total,
    } as IPaginatedDataResponse<PensionFundHoldingsSubject>;
  }

  @Get('/distributions/assets')
  @CommonApiQueries({ summary: 'Pension distributions' })
  @ApiDataObjectResponse(PensionFundDistributionItemSubject, 'Pension distributions assets by fund hash')
  @UseInterceptors(PaginationTransformInterceptor)
  public async getFundDistributionsAssets(@Param('fundHash') fundHash: string) {
    const [data, { reportPeriod }] = await this.pensionsService.getDistributionAssetsTypeByFundHash(fundHash);

    const res = this.transformToArray(data, PensionFundDistributionItemSubject);

    return {
      data: res,
      additional: {
        latestReportPeriod: reportPeriod,
      },
    };
  }

  @Get('/distributions/exposures')
  @UseGuards(AnonymousLocalJwtAuthGuard) // required for UserHasPensionTransformInterceptor
  @ApiBearerAuth()
  @ApiPensionDistributionFilter()
  @CommonApiQueries({ summary: 'Pension distributions' })
  @ApiDataObjectResponse(PensionFundDistributionSubject, 'Pension company by id')
  @UseInterceptors(PensionSingleFundExposuresLockTransformerInterceptor, TransformInterceptor)
  public async getFundDistributionsSectors(
    @Param('fundHash') fundHash: string,
    @Query() query: PensionDistributionDto,
  ) {
    const data = await this.pensionsService.getPensionDistributionsSectorsWithFilters(fundHash, query);

    return this.transformToObject(data, PensionFundDistributionSubject);
  }

  @Get('/stockExposure')
  @UseGuards(AnonymousLocalJwtAuthGuard) // required for UserHasPensionTransformInterceptor
  @ApiBearerAuth()
  @ApiDataObjectResponse(PensionFundStockExposureSubject, 'Pension fund latest stock exposure')
  @UseInterceptors(TransformInterceptor)
  public async getStockMarketExposure(@Param('fundHash') fundHash: string) {
    const data: PensionFundStockExposureSubject = await this.pensionsService.getStockMarketExposure(fundHash);
    data.reportPeriod = dayjs(data.period).valueOf();

    return this.transformToObject(data, PensionFundStockExposureSubject);
  }
}
