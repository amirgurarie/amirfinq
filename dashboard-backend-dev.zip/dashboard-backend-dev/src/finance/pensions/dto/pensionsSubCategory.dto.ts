import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional } from 'class-validator';
import { PensionCategoriesEnum } from '../enum/pensionCategories.enum';
import { applyDecorators } from '@nestjs/common';
import { TransformerHelper } from 'src/shared/helpers/transformer.helper';
import { ExposurePercentageEnum } from '../enum/pensionExposurePercentage.enum';

export class PensionProductSubCategoryDto {
  @ApiProperty({
    required: false,
    enum: PensionCategoriesEnum,
    description: `One of: ${Object.values(PensionCategoriesEnum)}`,
  })
  @IsNotEmpty()
  @IsEnum(PensionCategoriesEnum)
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;
}

export class PensionSubcategoryDto {
  @ApiProperty({
    required: true,
    enum: PensionCategoriesEnum,
    description: `One of: ${Object.values(PensionCategoriesEnum)}`,
  })
  @IsNotEmpty()
  @IsEnum(PensionCategoriesEnum)
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly managedCompanies?: string[] = [];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[] = [];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  // @IsEnum(ExposurePercentageEnum)
  public readonly exposurePercentageType?: ExposurePercentageEnum[];
}

export function ApiPensionSubcategoryFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      name: 'managedCompanies',
      required: false,
    }),
    ApiQuery({
      name: 'secondaryCategories',
      required: false,
    }),
    ApiQuery({
      name: 'exposurePercentageType',
      required: false,
      type: 'string',
    }),
  );
}
