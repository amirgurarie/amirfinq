import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional } from 'class-validator';
import { PensionCategoriesEnum } from '../enum/pensionCategories.enum';
import { applyDecorators } from '@nestjs/common';
import { TransformerHelper } from 'src/shared/helpers/transformer.helper';
import { ExposurePercentageEnum } from '../enum/pensionExposurePercentage.enum';

export class PensionCompanyDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(PensionCategoriesEnum)
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly subcategories?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly exposurePercentageType?: ExposurePercentageEnum[];
}

export function ApiPensionCompanyFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: true,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      name: 'subcategories',
      required: false,
    }),
    ApiQuery({
      name: 'secondaryCategories',
      required: false,
    }),
    ApiQuery({
      name: 'exposurePercentageType',
      required: false,
      type: 'string',
    }),
  );
}
