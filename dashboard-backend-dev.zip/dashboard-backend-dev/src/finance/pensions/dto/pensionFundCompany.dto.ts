import { applyDecorators } from '@nestjs/common';
import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { ApiPaginationQuery } from 'src/shared/decorators/apiPaginationQuery.decorator';
import { PaginationDto } from 'src/shared/dto/pagination.dto';
import { PensionCategoriesEnum } from '../enum/pensionCategories.enum';

export class PensionFundCompanyDto extends PaginationDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(PensionCategoriesEnum)
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty()
  @IsOptional()
  @IsString()
  public readonly search: string = '';
}

export function ApiPensionFundCompanyAndPaginationFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      name: 'search',
      required: false,
    }),
    ApiPaginationQuery(),
  );
}
