import { applyDecorators } from '@nestjs/common';
import { ApiQuery } from '@nestjs/swagger';
import { IsOptional, ValidateIf } from 'class-validator';
import { ApiDurationQuery, DurationDto } from 'src/finance/portfolios/dto/durationQuery.dto';
import { TransformerHelper } from 'src/shared/helpers/transformer.helper';
import { ConstraintTypeEnum } from 'src/shared/validators/constraints/isListStringConstraint';
import { IsListString } from 'src/shared/validators/isListString';
import { IsValidTimestamp } from 'src/shared/validators/isValidTimestamp';

export class PensionFundYieldsDto {
  /** Array of ids, splitted by commas, used to add more rows for comparison */
  @IsOptional()
  @IsListString(ConstraintTypeEnum.String)
  public readonly comparedWith?: string;

  /**
   * Period of time in months, used to calculate the yields
   */
  @IsOptional()
  @TransformerHelper.ToInt()
  public readonly period?: number = 6;

  @ValidateIf((obj) => !('period' in obj))
  @IsOptional()
  @IsValidTimestamp()
  public readonly fromDate: number;
}

export function ApiPensionFundYieldsApiQuery() {
  return applyDecorators(
    ApiQuery({
      name: 'comparedWith',
      required: false,
      type: 'string',
    }),
    ApiQuery({
      name: 'period',
      required: false,
      type: 'number',
      description: 'Period of time in months, used to calculate the yields',
    }),
    ApiQuery({
      name: 'fromDate',
      type: Number,
      required: false,
    }),
  );
}
