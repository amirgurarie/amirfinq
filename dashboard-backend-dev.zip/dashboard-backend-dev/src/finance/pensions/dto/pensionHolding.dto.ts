import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { applyDecorators } from '@nestjs/common';
import { PaginationDto } from 'src/shared/dto/pagination.dto';
import { ApiPaginationQuery } from 'src/shared/decorators/apiPaginationQuery.decorator';

export class PensionHoldingsDto extends PaginationDto {
  @ApiProperty({ type: String })
  @IsOptional()
  @IsString()
  public readonly itemCode?: string;
}

export function ApiPensionHoldingsFilter() {
  return applyDecorators(
    ApiPaginationQuery(),
    ApiQuery({
      name: 'itemCode',
      required: false,
    }),
  );
}
