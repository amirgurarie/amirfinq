import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { PensionCategoriesEnum } from '../enum/pensionCategories.enum';
import { applyDecorators } from '@nestjs/common';
import { ApiPaginationQuery } from 'src/shared/decorators/apiPaginationQuery.decorator';
import { PaginationDto } from 'src/shared/dto/pagination.dto';
import { TransformerHelper } from '../../../shared/helpers/transformer.helper';
import { ExposurePercentageEnum } from '../enum/pensionExposurePercentage.enum';

export class BasePensionDepotFilterDto {
  @ApiProperty()
  @IsNotEmpty()
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty()
  @IsNotEmpty()
  public readonly riskLevel: number = 5;
}

export function ApiPensionDepotBaseFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      type: 'number',
      name: 'riskLevel',
      required: false,
    }),
  );
}

export class BasePensionDepotFilterPaginatedDto extends PaginationDto {
  @ApiProperty()
  @IsNotEmpty()
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty()
  @IsNotEmpty()
  public readonly riskLevel: number = 5;

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly managedCompanies?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly subcategories?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly exposurePercentageType?: ExposurePercentageEnum[];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly excludedCategories?: string[];
}

export function ApiPensionDepotBaseWithPaginationFilter() {
  return applyDecorators(
    ApiPensionDepotBaseFilter(),
    ApiQuery({
      type: 'string',
      name: 'managedCompanies',
      required: false,
    }),
    ApiQuery({
      type: 'string',
      name: 'subcategories',
      required: false,
    }),
    ApiQuery({
      type: 'string',
      name: 'secondaryCategories',
      required: false,
    }),
    ApiQuery({
      type: 'string',
      name: 'exposurePercentageType',
      required: false,
    }),
    ApiPaginationQuery(),
  );
}

// pension/depot/filters DTOS

export class PensionDepotCompaniesFilterDto {
  @ApiProperty()
  @IsNotEmpty()
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly managedCompanies?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly subcategories?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly exposurePercentageType?: ExposurePercentageEnum[];

  @ApiProperty()
  @IsOptional()
  public readonly riskLevel?: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  public readonly search?: string = '';
}

export function ApiPensionDepotCompanyFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      name: 'riskLevel',
      required: false,
    }),
    ApiQuery({
      name: 'managedCompanies',
      required: false,
    }),
    ApiQuery({
      name: 'subcategories',
      required: false,
    }),
    ApiQuery({
      name: 'secondaryCategories',
      required: false,
    }),
    ApiQuery({
      name: 'search',
      required: false,
    }),
    ApiQuery({
      name: 'exposurePercentageType',
      required: false,
    }),
  );
}

export class PensionDepotExposureFilterDto {
  @ApiProperty()
  @IsNotEmpty()
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly managedCompanies?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly subcategories?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[];

  @ApiProperty()
  @IsOptional()
  public readonly riskLevel?: number;

  @ApiProperty()
  @IsOptional()
  @IsString()
  public readonly search?: string = '';
}

export function ApiPensionDepotExposureFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      name: 'riskLevel',
      required: false,
    }),
    ApiQuery({
      name: 'managedCompanies',
      required: false,
    }),
    ApiQuery({
      name: 'subcategories',
      required: false,
    }),
    ApiQuery({
      name: 'secondaryCategories',
      required: false,
    }),
    ApiQuery({
      name: 'search',
      required: false,
    }),
  );
}

export class PensionDepotSubcategoryFilterDto {
  @ApiProperty()
  @IsNotEmpty()
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty()
  @IsOptional()
  public readonly riskLevel?: number;

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly managedCompanies?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly subcategories?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly exposurePercentageType?: ExposurePercentageEnum[];

  @ApiProperty()
  @IsOptional()
  @IsString()
  public readonly search?: string = '';
}

export function ApiPensionDepotSubcategoryFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      name: 'riskLevel',
      required: false,
    }),
    ApiQuery({
      name: 'managedCompanies',
      required: false,
    }),
    ApiQuery({
      name: 'subcategories',
      required: false,
    }),
    ApiQuery({
      name: 'secondaryCategories',
      required: false,
    }),
    ApiQuery({
      name: 'exposurePercentageType',
      required: false,
    }),
    ApiQuery({
      name: 'search',
      required: false,
    }),
  );
}

export class PensionDepotSecondaryCategoryFilterDto {
  @ApiProperty()
  @IsNotEmpty()
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty()
  @IsOptional()
  public readonly riskLevel?: number;

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly managedCompanies?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly subcategories?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly exposurePercentageType?: ExposurePercentageEnum[];

  @ApiProperty()
  @IsOptional()
  @IsString()
  public readonly search?: string = '';
}

export function ApiPensionDepotSecondaryFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({
      name: 'riskLevel',
      required: false,
    }),
    ApiQuery({
      name: 'managedCompanies',
      required: false,
    }),
    ApiQuery({
      name: 'subcategories',
      required: false,
    }),
    ApiQuery({
      name: 'secondaryCategories',
      required: false,
    }),
    ApiQuery({
      name: 'exposurePercentageType',
      required: false,
    }),
    ApiQuery({
      name: 'search',
      required: false,
    }),
  );
}

export class PensionDepotFundsFilterDto extends PaginationDto {
  @IsOptional()
  @IsString()
  search: string;

  @IsOptional()
  @IsEnum(PensionCategoriesEnum)
  public readonly category: PensionCategoriesEnum;
}

export function ApiPensionDepotFundsFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'search',
      required: false,
    }),
    ApiPaginationQuery(),
  );
}
