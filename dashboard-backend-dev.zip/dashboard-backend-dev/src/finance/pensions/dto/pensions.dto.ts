import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { applyDecorators } from '@nestjs/common';
import { ApiQuery } from '@nestjs/swagger';
import { ApiPaginationQuery } from 'src/shared/decorators/apiPaginationQuery.decorator';
import { PaginationDto } from 'src/shared/dto/pagination.dto';
import { PensionCategoriesEnum } from '../enum/pensionCategories.enum';
import { TransformerHelper } from 'src/shared/helpers/transformer.helper';
import { ExposurePercentageEnum } from '../enum/pensionExposurePercentage.enum';
import { IsCaseSensitive } from 'src/shared/validators/isCaseSensitive';
import { OrderEnum } from 'src/shared/enums';

export enum PensionFundsSortBy {
  finqRank = 'finqRank',
  finqRiskLevel = 'finqRiskLevel',
  shortText = 'shortText',
  yieldYtd = 'yieldYtd',
  yield1Month = 'yield1Month',
  yield3Months = 'yield3Months',
  yield6Months = 'yield6Months',
  yield12Months = 'yield12Months',
  yield24Months = 'yield24Months',
  yield36Months = 'yield36Months',
  yield60Months = 'yield60Months',
  avgAnnualManagementFee = 'avgAnnualManagementFee',
  avgDepositFee = 'avgDepositFee',
}

export const PensionFundsSortByMap = {
  [PensionFundsSortBy.finqRank]: 'fund_pension.finq_rank',
  [PensionFundsSortBy.finqRiskLevel]: 'fund_pension.finq_risk_level',
  [PensionFundsSortBy.shortText]: 'ref_pension_companies.short_text',
  [PensionFundsSortBy.yieldYtd]: 'fund_pension.yield_ytd',
  [PensionFundsSortBy.yield1Month]: 'fund_pension.yield_1_month',
  [PensionFundsSortBy.yield3Months]: 'fund_pension.yield_3_months',
  [PensionFundsSortBy.yield6Months]: 'fund_pension.yield_6_months',
  [PensionFundsSortBy.yield12Months]: 'fund_pension.yield_12_months',
  [PensionFundsSortBy.yield24Months]: 'fund_pension.yield_24_months',
  [PensionFundsSortBy.yield36Months]: 'fund_pension.yield_36_months',
  [PensionFundsSortBy.yield60Months]: 'fund_pension.yield_60_months',
  [PensionFundsSortBy.avgAnnualManagementFee]: 'fund_pension.avg_annual_management_fee',
  [PensionFundsSortBy.avgDepositFee]: 'fund_pension.avg_deposit_fee',
} as const;

export class PaginatedPensionFundCompanyWithSort extends PaginationDto {
  @IsString()
  @IsOptional()
  @IsCaseSensitive(Object.values(PensionFundsSortBy))
  sortBy?: PensionFundsSortBy = PensionFundsSortBy.finqRank;

  @IsOptional()
  @IsCaseSensitive(Object.values(OrderEnum))
  public readonly order?: OrderEnum = OrderEnum.ASC;
}

export class PensionLeadingFundsDto extends PaginatedPensionFundCompanyWithSort {
  @ApiProperty()
  @IsOptional()
  public readonly riskLevel: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsEnum(PensionCategoriesEnum)
  public readonly category: PensionCategoriesEnum = PensionCategoriesEnum.COMPERHENSIVE;

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly managedCompanies?: string[];

  @ApiProperty({ type: String })
  @IsOptional()
  @TransformerHelper.parseStringToArray()
  public readonly exposurePercentageType?: ExposurePercentageEnum[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly subcategories?: string[];

  @ApiProperty({ type: String })
  @TransformerHelper.parseStringToArray()
  public readonly secondaryCategories?: string[];

  exclude?: string; // Not from ApiPropery Type (Shouldn't )
}

// Includes Both ApiDurationQuery and ApiQuery for category and risk level
export function ApiPensionLeadingFundsAndPaginationFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionCategoriesEnum,
      description: `One of: ${Object.values(PensionCategoriesEnum)}`,
    }),
    ApiQuery({ name: 'riskLevel', required: false }),
    ApiQuery({ name: 'managedCompanies', required: false }),
    ApiQuery({ name: 'subcategories', required: false }),
    ApiQuery({ name: 'secondaryCategories', required: false }),
    ApiQuery({ name: 'exposurePercentageType', required: false, type: 'string' }),
    ApiQuery({
      name: 'sortBy',
      required: false,
      enum: PensionFundsSortBy,
      description: `One of: ${Object.values(PensionFundsSortBy)}`,
    }),
    ApiQuery({
      name: 'order',
      required: false,
      enum: OrderEnum,
      description: `One of: ${Object.values(OrderEnum)}`,
    }),
    ApiPaginationQuery(),
  );
}
