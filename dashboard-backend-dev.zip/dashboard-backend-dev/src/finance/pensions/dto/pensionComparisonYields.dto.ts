import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { applyDecorators } from '@nestjs/common';

export enum PensionCompareBy {
  RISK_LEVEL = 'riskLevel',
  SECONDARY_CATEGORY = 'secondaryCategory',
}

export class PensionComparisonYieldsDto {
  @ApiProperty()
  @IsOptional()
  @IsEnum(PensionCompareBy)
  public readonly compareBy: PensionCompareBy;
}

export function ApiPensionComparisonYieldsFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'compareBy',
      required: false,
      enum: PensionCompareBy,
      description: `One of: ${Object.values(PensionCompareBy)}`,
    }),
  );
}
