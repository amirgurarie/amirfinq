import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { applyDecorators } from '@nestjs/common';

export class PensionDistributionDto {
  @ApiProperty({ type: String })
  @IsOptional()
  @IsString()
  public readonly itemCode?: string;
}

export function ApiPensionDistributionFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'itemCode',
      required: false,
    }),
  );
}

export class PensionDistributionFilterDto {
  @ApiProperty({ type: String })
  @IsString()
  @IsOptional()
  public readonly assetType?: string;
}
