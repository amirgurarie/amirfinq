import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ProductTempTypes } from 'src/common/productTemp/types/productTemp.types';
import { CombinedUserProductsService } from 'src/users/combinedUserProducts/combinedUserProducts.service';

export const MIN_PENSION_FUNDS_ITEMS_TO_RETURN = 5;

export const MIN_PENSION_FUNDS_SKIPPED_ITEMS = 0;

// Make sure this is the first interceptor in the chain
@Injectable()
export class UserHasPensionTransformInterceptor<T> implements NestInterceptor {
  constructor(public combinedProductsService: CombinedUserProductsService) {}

  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<
    Observable<
      | IPaginatedDataResponse<T>
      | { data: any[]; paging: { total: number; index: number; size: number }; locked: boolean }
    >
  > {
    const request = context.switchToHttp().getRequest();
    const userProducts = await this.combinedProductsService.findActiveSubscriptionsByFilters(request?.user?.user?.id, {
      productId: ProductTempTypes.ProductsEnum.Pensions,
      productPlanCodes: [
        ProductTempTypes.ProductPlanTypesEnum.DIY,
        ProductTempTypes.ProductPlanTypesEnum.DIY_AGENTS,
        ProductTempTypes.ProductPlanTypesEnum.DIY_LIGHT,
        ProductTempTypes.ProductPlanTypesEnum.DIY_PRO,
      ],
    });

    // Validating if the user has the correct plan
    // if the user subscribed for an active Pension product he should return 5 items
    // else return 3 items

    if (!userProducts?.length) {
      request.query.size = MIN_PENSION_FUNDS_ITEMS_TO_RETURN + '';
      request.query.index = MIN_PENSION_FUNDS_SKIPPED_ITEMS + '';
    }

    return next.handle().pipe(map((data: IPaginatedDataResponse<T>) => data));
  }
}
