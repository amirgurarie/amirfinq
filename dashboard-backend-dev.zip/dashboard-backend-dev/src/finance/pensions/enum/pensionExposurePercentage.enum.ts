export const ExposurePercentageEnum = {
  TOTAL: 'total',
  LOW: 'low',
  MID: 'mid',
  HIGH: 'high',
};

export type ExposurePercentageEnum = typeof ExposurePercentageEnum[keyof typeof ExposurePercentageEnum];
