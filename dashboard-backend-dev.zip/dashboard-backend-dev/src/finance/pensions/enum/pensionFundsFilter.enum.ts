export const PensionFundFilterEnum = {
  COMPANY: 'company',
  SUBCATEGORY: 'subcategory',
  ORIGINAL_COMPANY_ID: 'originalCompanyID',
};

export type PensionFundFilterEnum = (typeof PensionFundFilterEnum)[keyof typeof PensionFundFilterEnum];
