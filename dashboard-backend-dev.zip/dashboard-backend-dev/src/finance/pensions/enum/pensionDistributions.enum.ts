export const DistributionGroupType = {
  AssetType: 'ASSETTYPE',
  Sector: 'SECTOR',
  Currency: 'CURRENCY',
  TradeLocation: 'TRADELOC',
} as const;

export type DistributionGroupType = (typeof DistributionGroupType)[keyof typeof DistributionGroupType];

export const DistributionQueryFields = {
  [DistributionGroupType.AssetType]: {
    referenceTable: 'ref_asset_type',
    referenceAlias: 'rat',
    descriptionField: 'description_he',
  },
  [DistributionGroupType.Sector]: {
    referenceTable: 'ref_sectors',
    referenceAlias: 'rs',
    descriptionField: 'description_he',
  },
  [DistributionGroupType.TradeLocation]: {
    referenceTable: 'ref_trade_locations',
    referenceAlias: 'rtl',
    descriptionField: 'description_he',
  },
  [DistributionGroupType.Currency]: {
    referenceTable: 'ref_currency',
    referenceAlias: 'rc',
    descriptionField: 'description',
  },
};
