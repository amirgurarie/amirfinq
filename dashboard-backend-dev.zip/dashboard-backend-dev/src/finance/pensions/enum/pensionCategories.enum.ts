export const PensionCategoriesEnum = {
  EDUCATION: 'EDUCATION',
  COMPERHENSIVE: 'COMPERHENSIVE',
  SUPPLEMENTARY: 'SUPPLEMENTARY',
  MANAGERS: 'MANAGERS',
  PROVIDENT: 'PROVIDENT',
  INVESTMENT: 'INVESTMENT',
  CHILDSAVING: 'CHILDSAVING',
  PRIVATE: 'PRIVATE',
  COMPENSATION: 'COMPENSATION',
  INSURANCE: 'INSURANCE',
  OTHER: 'OTHER',
} as const;

export type PensionCategoriesEnum = (typeof PensionCategoriesEnum)[keyof typeof PensionCategoriesEnum];
