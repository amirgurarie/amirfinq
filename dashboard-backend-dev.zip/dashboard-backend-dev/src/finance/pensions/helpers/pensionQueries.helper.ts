import { FundPension } from 'src/entities/FundPension';
import { Brackets, SelectQueryBuilder } from 'typeorm';
import { ExposurePercentageEnum } from '../enum/pensionExposurePercentage.enum';
import { PensionCompanyDto } from '../dto/pensionCompany.dto';
import { PensionSubcategoryDto } from '../dto/pensionsSubCategory.dto';

export class PensionQueries {
  public static addExposurePercentageQuery(
    queryBuilder: SelectQueryBuilder<FundPension>,
    exposurePercentageTypes: ExposurePercentageEnum[],
    prefix = 'fund_pension',
  ) {
    if (exposurePercentageTypes && exposurePercentageTypes.length > 0) {
      const conditions: string[] = [];

      for (const exposurePercentageType of exposurePercentageTypes) {
        switch (exposurePercentageType) {
          case ExposurePercentageEnum.LOW:
            conditions.push(`(${prefix}.equity_exposure <= 0.3)`);
            break;

          case ExposurePercentageEnum.MID:
            conditions.push(`(${prefix}.equity_exposure >= 0.3 AND ${prefix}.equity_exposure <= 0.6)`);
            break;

          case ExposurePercentageEnum.HIGH:
            conditions.push(`(${prefix}.equity_exposure >= 0.6 AND ${prefix}.equity_exposure <= 1)`);
            break;
        }
      }

      if (conditions.length > 0) {
        const combinedCondition = conditions.join(' OR ');

        return queryBuilder.andWhere(`(${combinedCondition})`);
      }

      return queryBuilder;
    }
  }

  public static addCompaniesFilterQuery(
    queryBuilder: SelectQueryBuilder<FundPension>,
    filters: PensionSubcategoryDto,
    prefix = 'fund_pension',
  ) {
    if (filters.managedCompanies?.length) {
      return queryBuilder.andWhere(`${prefix}.parent_company_id IN (:...companies)`, {
        companies: filters.managedCompanies,
      });
    }

    return queryBuilder;
  }

  public static addCategoriesFilterQuery(
    queryBuilder: SelectQueryBuilder<FundPension>,
    filters: PensionCompanyDto,
    prefix = 'fund_pension',
  ) {
    if (filters.subcategories?.length || filters.secondaryCategories?.length) {
      const { subcategories, secondaryCategories } = filters;

      queryBuilder.andWhere(
        new Brackets((qb) => {
          let conditions = [];

          if (subcategories?.length) {
            conditions.push(`${prefix}.fund_sub_category IN (:...subcategories)`);
          }

          if (secondaryCategories?.length) {
            conditions.push(`${prefix}.secondary_category_id IN (:...secondaryCategories)`);
          }

          qb.where(conditions.join(' AND '), { subcategories, secondaryCategories });
        }),
      );
    }

    return queryBuilder;
  }

  public static addRiskLevelFilterQuery(
    queryBuilder: SelectQueryBuilder<FundPension>,
    riskLevel?: number,
    prefix = 'fund_pension',
  ) {
    if (riskLevel) {
      return queryBuilder.andWhere(`${prefix}.finq_risk_level = :riskLevel`, { riskLevel });
    }

    return queryBuilder;
  }
}
