import { RefPensionFeeTrack, PensionFeeOperatorType } from 'src/entities/RefPensionFeeTrack';
import { Brackets, SelectQueryBuilder } from 'typeorm';

/**
 * Helper class for building queries related to pension fee tracks
 */
export class PensionFeesQueriesHelper {
  /**
   * Builds a query for pension fee tracks based on provided parameters
   *
   * @param queryBuilder - The TypeORM query builder instance
   * @param companyId - The ID of the pension company
   * @param productCategory - Category of the pension product
   * @param subSpecialization - Optional sub-specialization of the product
   * @param totalSavings - Total accumulated savings amount
   * @param monthlyDeposit - Monthly deposit amount
   * @returns QueryBuilder configured with the appropriate conditions
   */
  public static buildTrackQuery(
    queryBuilder: SelectQueryBuilder<RefPensionFeeTrack>,
    companyId: string,
    productCategory: string,
    subSpecialization: string | null,
    totalSavings: number,
    salary: number,
  ): SelectQueryBuilder<RefPensionFeeTrack> {
    // Filter by company and product category
    queryBuilder
      .where('fee_track.company_id = :companyId', { companyId })
      .andWhere('fee_track.product_category = :productCategory', { productCategory });

    // Add sub specialization condition if provided
    if (subSpecialization) {
      queryBuilder.andWhere(
        '(fee_track.sub_specialization = :subSpecialization OR fee_track.sub_specialization IS NULL)',
        {
          subSpecialization,
        },
      );
    } else {
      queryBuilder.andWhere('fee_track.sub_specialization IS NULL');
    }

    // Handle conditions based on operator type (AND or OR)
    queryBuilder.andWhere(
      new Brackets((qb) => {
        // AND type: both accumulation and deposit conditions must match
        qb.where(
          'fee_track.operator_type = :andType AND ' +
            '(fee_track.min_accumulation IS NULL OR fee_track.min_accumulation <= :accumulation) AND ' +
            '(fee_track.max_accumulation IS NULL OR fee_track.max_accumulation >= :accumulation) AND ' +
            '(fee_track.min_salary IS NULL OR fee_track.min_salary <= :salary) AND ' +
            '(fee_track.max_salary IS NULL OR fee_track.max_salary >= :salary)',
          { andType: PensionFeeOperatorType.AND, accumulation: totalSavings, salary },
        );

        // OR type: either accumulation or salary conditions need to match
        qb.orWhere(
          'fee_track.operator_type = :orType AND (' +
            '((fee_track.min_accumulation IS NULL OR fee_track.min_accumulation <= :accumulation) AND ' +
            '(fee_track.max_accumulation IS NULL OR fee_track.max_accumulation >= :accumulation)) OR ' +
            '((fee_track.min_salary IS NULL OR fee_track.min_salary <= :salary) AND ' +
            '(fee_track.max_salary IS NULL OR fee_track.max_salary >= :salary))' +
            ')',
          { orType: PensionFeeOperatorType.OR, accumulation: totalSavings, salary },
        );
      }),
    );

    return queryBuilder;
  }
}
