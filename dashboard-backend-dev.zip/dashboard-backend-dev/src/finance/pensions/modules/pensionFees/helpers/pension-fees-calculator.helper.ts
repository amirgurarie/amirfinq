export class PensionFeeCalculatorHelper {
  /**
   * Calculate annual management fees using the formula:
   * Total DnHafkada (Total Deposit Fees) = 12 * DnHafkada (Deposit Fee Rate) * HAFKADA (Monthly Deposit)
   * Total Hafakada (Total Deposits) = HAFKADA * 12 - Total DnHafkada
   * Total DnZvira (Total Accumulation Fees) = DnZvira (Accumulation Fee Rate) * (ZVIRA (Total Savings) + Total Hafkada)
   * Total Dn (Total Fees) = Total DnHafkada + Total DnZvira
   *
   * @param depositFeeRate - Fee rate applied to monthly deposits (%)
   * @param accumulationFeeRate - Fee rate applied to accumulated savings (%)
   * @param totalSavings - Current total accumulated savings amount
   * @param monthlyDeposit - Monthly deposit amount
   * @returns Total annual management fees
   */
  static calculateAnnualFees(
    depositFeeRate: number,
    accumulationFeeRate: number,
    totalSavings: number,
    monthlyDeposit: number,
  ): number {
    const depositFeeRateDecimal = depositFeeRate / 100;
    const accumulationFeeRateDecimal = accumulationFeeRate / 100;

    const totalDepositFees = 12 * depositFeeRateDecimal * monthlyDeposit;
    const totalDeposit = monthlyDeposit * 12 - totalDepositFees;
    const totalAccumulationFees = accumulationFeeRateDecimal * (totalSavings + totalDeposit);

    return totalDepositFees + totalAccumulationFees;
  }

  /**
   * Compare two fee configurations to determine if current fees are better (lower) than offered fees
   *
   * @param currentDepositFee - Current deposit fee rate (%)
   * @param currentAccumulationFee - Current accumulation fee rate (%)
   * @param offeredDepositFee - Offered deposit fee rate (%)
   * @param offeredAccumulationFee - Offered accumulation fee rate (%)
   * @param totalSavings - Current total accumulated savings amount
   * @param monthlyDeposit - Monthly deposit amount
   * @returns true if current fees are lower or equal to offered fees
   */
  static areCurrentFeesBetter(
    currentDepositFee: number,
    currentAccumulationFee: number,
    offeredDepositFee: number,
    offeredAccumulationFee: number,
    totalSavings: number,
    monthlyDeposit: number,
  ): boolean {
    const currentAnnualFees = this.calculateAnnualFees(
      currentDepositFee,
      currentAccumulationFee,
      totalSavings,
      monthlyDeposit,
    );

    const offeredAnnualFees = this.calculateAnnualFees(
      offeredDepositFee,
      offeredAccumulationFee,
      totalSavings,
      monthlyDeposit,
    );

    return currentAnnualFees <= offeredAnnualFees;
  }
}
