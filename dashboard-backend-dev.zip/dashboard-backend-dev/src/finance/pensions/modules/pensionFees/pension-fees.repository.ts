// src/finance/pensions/modules/pension-fees/repositories/pension-fees.repository.ts
import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { RefPensionFeeTrack } from 'src/entities/RefPensionFeeTrack';
import { Repository } from 'typeorm';
import { PensionFeesQueriesHelper } from './helpers/pension-fees-queries.helper';

/**
 * Repository class for handling PensionFeeTrack entity database operations
 */
@Injectable()
export class PensionFeesRepository {
  private readonly logger = new Logger(PensionFeesRepository.name);

  constructor(
    @InjectRepository(RefPensionFeeTrack)
    private pensionFeeTrackRepository: Repository<RefPensionFeeTrack>,
  ) {}

  /**
   * Find all pension fee tracks that match the given criteria
   * @param companyId The company ID
   * @param productCategory The product category (e.g., 'pension')
   * @param subSpecialization The sub specialization (e.g., '49' for general pension)
   * @param accumulation The accumulation amount (total savings)
   * @param deposit The monthly deposit amount
   * @returns A promise that resolves to an array of matching pension fee tracks
   */
  async findMatchingFeeTracks(
    companyId: string,
    productCategory: string,
    subSpecialization: string | null,
    accumulation: number,
    salary: number,
  ): Promise<RefPensionFeeTrack[]> {
    try {
      // Build the query
      const queryBuilder = this.pensionFeeTrackRepository.createQueryBuilder('fee_track');

      PensionFeesQueriesHelper.buildTrackQuery(
        queryBuilder,
        companyId,
        productCategory,
        subSpecialization,
        accumulation,
        salary,
      );

      const result = await queryBuilder.getMany();
      this.logger.debug(`Found ${result.length} matching fee tracks for company ${companyId}`);

      return result;
    } catch (error) {
      this.logger.error(`Error finding matching fee tracks: ${error.message}`, error.stack);
      throw error;
    }
  }

  /**
   * Find fee tracks for multiple companies matching the given criteria
   * @param companyIds Array of company IDs
   * @param productCategory The product category
   * @param subSpecialization The sub specialization
   * @param accumulation The accumulation amount
   * @param deposit The deposit amount
   * @returns A promise that resolves to a map of company ID to matching fee tracks
   */
  async findMatchingFeeTracksForCompanies(
    companyIds: string[],
    productCategory: string,
    subSpecialization: string | null,
    accumulation: number,
    salary: number,
  ): Promise<Map<string, RefPensionFeeTrack[]>> {
    try {
      const result = new Map<string, RefPensionFeeTrack[]>();

      for (const companyId of companyIds) {
        const feeTracks = await this.findMatchingFeeTracks(
          companyId,
          productCategory,
          subSpecialization,
          accumulation,
          salary,
        );

        result.set(companyId, feeTracks);
      }

      return result;
    } catch (error) {
      this.logger.error(`Error finding matching fee tracks for companies: ${error.message}`, error.stack);
      throw error;
    }
  }
}
