import { Injectable, Logger } from '@nestjs/common';
import { FeeCalculationParams, FeeRates, FeeResult, OptimalFeeTrackResult } from './interfaces/pension-fees.interface';
import { RefPensionFeeTrack } from 'src/entities/RefPensionFeeTrack';
import { PensionFeesRepository } from './pension-fees.repository';
import { PensionFeesCalculator } from './services/pension-fees-calculator.service';

/**
 * Service for managing pension fees operations
 */
@Injectable()
export class PensionFeesService {
  private readonly logger = new Logger(PensionFeesService.name);

  constructor(
    private readonly pensionFeesRepository: PensionFeesRepository,
    protected readonly pensionFeesCalculator: PensionFeesCalculator,
  ) {}

  /**
   * Find all pension fee tracks that match the given criteria
   * @param params Fee calculation parameters
   * @returns A promise that resolves to an array of matching pension fee tracks
   */
  async findMatchingFeeTracks(params: FeeCalculationParams): Promise<RefPensionFeeTrack[]> {
    return this.pensionFeesRepository.findMatchingFeeTracks(
      params.companyId,
      params.productCategory,
      params.subSpecialization,
      params.accumulation,
      params.salary,
    );
  }

  /**
   * Calculate the annual management fees
   * @param accumulation The accumulation amount
   * @param deposit The deposit amount
   * @param depositFeeRate The deposit fee rate
   * @param accumulationFeeRate The accumulation fee rate
   * @returns The annual management fees and fee rates
   */
  calculateFees(accumulation: number, deposit: number, depositFeeRate: number, accumulationFeeRate: number): FeeResult {
    return this.pensionFeesCalculator.calculateFees(accumulation, deposit, depositFeeRate, accumulationFeeRate);
  }

  /**
   * Find the optimal fee track for a given user's pension data
   * @param params Fee calculation parameters
   * @returns A promise that resolves to the optimal fee track
   */
  async findOptimalFeeTrack(params: FeeCalculationParams): Promise<OptimalFeeTrackResult | null> {
    try {
      const matchingFeeTracks = await this.findMatchingFeeTracks(params);

      if (matchingFeeTracks.length === 0) {
        this.logger.debug(
          `No matching fee tracks found for company ${params.companyId} with product ${params.productCategory}`,
        );

        return null;
      }

      // Convert pension fee tracks to fee options for calculator
      const feeOptions: FeeRates[] = matchingFeeTracks.map((track) => ({
        depositFeeRate: track.depositFee,
        accumulationFeeRate: track.accumulationFee,
      }));

      // Find the option with lowest fees
      const optimalFeeResult = this.pensionFeesCalculator.findLowestFeeOption(
        params.accumulation,
        params.deposit,
        feeOptions,
      );

      if (!optimalFeeResult) {
        return null;
      }

      // Find the corresponding fee track
      const optimalTrack = matchingFeeTracks.find(
        (track) =>
          track.depositFee === optimalFeeResult.depositFee &&
          track.accumulationFee === optimalFeeResult.accumulationFee,
      );

      if (!optimalTrack) {
        return null;
      }

      return {
        feeTrack: {
          id: optimalTrack.id,
          companyId: optimalTrack.companyId,
          productCategory: optimalTrack.productCategory,
          subSpecialization: optimalTrack.subSpecialization,
          depositFee: optimalTrack.depositFee,
          accumulationFee: optimalTrack.accumulationFee,
        },
        annualFees: optimalFeeResult.annualFees,
      };
    } catch (error) {
      this.logger.error(`Error finding optimal fee track: ${error.message}`, error.stack);
      throw error;
    }
  }

  /**
   * Find optimal fee tracks for multiple companies
   * @param companyIds Array of company IDs to check
   * @param productCategory The product category
   * @param subSpecialization The sub specialization
   * @param accumulation The accumulation amount
   * @param deposit The deposit amount
   * @returns A promise that resolves to a map of company ID to optimal fee track
   */
  async findOptimalFeeTracksForCompanies(
    companyIds: string[],
    productCategory: string,
    subSpecialization: string | null,
    accumulation: number,
    deposit: number,
    salary: number,
  ): Promise<Map<string, OptimalFeeTrackResult | null>> {
    try {
      const result = new Map<string, OptimalFeeTrackResult | null>();

      for (const companyId of companyIds) {
        const params: FeeCalculationParams = {
          companyId,
          productCategory,
          subSpecialization,
          accumulation,
          deposit,
          salary,
        };

        const optimalResult = await this.findOptimalFeeTrack(params);
        result.set(companyId, optimalResult);
      }

      return result;
    } catch (error) {
      this.logger.error(`Error finding optimal fee tracks for companies: ${error.message}`, error.stack);
      throw error;
    }
  }
}
