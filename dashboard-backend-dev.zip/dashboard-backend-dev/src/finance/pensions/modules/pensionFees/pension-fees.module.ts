import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RefPensionFeeTrack } from '../../../../entities/RefPensionFeeTrack';
import { PensionFeesService } from './pension-fees.service';
import { PensionFeesCalculator } from './services/pension-fees-calculator.service';
import { PensionFeesManager } from './pension-fees.manager';
import { PensionFeesRepository } from './pension-fees.repository';

@Module({
  imports: [TypeOrmModule.forFeature([RefPensionFeeTrack])],
  providers: [PensionFeesService, PensionFeesManager, PensionFeesCalculator, PensionFeesRepository],
  exports: [PensionFeesService, PensionFeesManager],
})
export class PensionFeesModule {}
