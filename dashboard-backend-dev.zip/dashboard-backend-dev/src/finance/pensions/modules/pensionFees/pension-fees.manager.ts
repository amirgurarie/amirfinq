import { Injectable, Logger } from '@nestjs/common';
import { PensionFeesService } from './pension-fees.service';
import { FeeCalculationParams, FeesComparisonResult, OptimalFeeTrackResult } from './interfaces/pension-fees.interface';

/**
 * Manager for high-level pension fees operations and business logic
 */
@Injectable()
export class PensionFeesManager {
  private readonly logger = new Logger(PensionFeesManager.name);

  constructor(readonly pensionFeesService: PensionFeesService) {}

  /**
   * Compare current fees with the optimal fees available
   * @param params The fee calculation parameters
   * @param currentDepositFee The current deposit fee rate
   * @param currentAccumulationFee The current accumulation fee rate
   * @returns A promise that resolves to a comparison of current and optimal fees
   */
  async compareWithOptimalFees(
    params: FeeCalculationParams,
    currentDepositFee: number,
    currentAccumulationFee: number,
  ): Promise<FeesComparisonResult> {
    try {
      // Calculate current fees
      const currentFeesResult = this.pensionFeesService.calculateFees(
        params.accumulation,
        params.deposit,
        currentDepositFee,
        currentAccumulationFee,
      );

      // Find optimal fee track
      const optimalResult = await this.pensionFeesService.findOptimalFeeTrack(params);

      const optimalFees = optimalResult?.annualFees || Number.MAX_VALUE;
      const optimalFeeTrack = optimalResult?.feeTrack || null;

      // Determine if current fees should be kept
      // Current fees are kept if they are lower than what we can offer
      const shouldKeepCurrentFees = currentFeesResult.annualFees <= optimalFees;

      this.logger.debug(
        `Fee comparison for ${params.companyId}: current=${currentFeesResult.annualFees}, optimal=${optimalFees}, keep current=${shouldKeepCurrentFees}`,
      );

      return {
        currentFees: currentFeesResult.annualFees,
        optimalFees: optimalResult ? optimalFees : currentFeesResult.annualFees,
        optimalFeeTrack,
        shouldKeepCurrentFees,
      };
    } catch (error) {
      this.logger.error(`Error comparing with optimal fees: ${error.message}`, error.stack);
      throw error;
    }
  }

  /**
   * Find the best fees available across multiple companies
   * @param companies Array of company IDs to check
   * @param productCategory The product category
   * @param subSpecialization The sub specialization
   * @param accumulation The accumulation amount
   * @param deposit The deposit amount
   * @returns A promise that resolves to the company with best fees and its fee details
   */
  async findBestFeesAcrossCompanies(
    companies: string[],
    productCategory: string,
    subSpecialization: string | null,
    accumulation: number,
    deposit: number,
    salary: number,
  ): Promise<{ companyId: string; feeTrack: OptimalFeeTrackResult } | null> {
    try {
      if (companies.length === 0) {
        return null;
      }

      const optimalFeesMap = await this.pensionFeesService.findOptimalFeeTracksForCompanies(
        companies,
        productCategory,
        subSpecialization,
        accumulation,
        deposit,
        salary,
      );

      let bestCompanyId: string | null = null;
      let bestFeeTrack: OptimalFeeTrackResult | null = null;
      let lowestFees = Number.MAX_VALUE;

      optimalFeesMap.forEach((result, companyId) => {
        if (result && result.annualFees < lowestFees) {
          lowestFees = result.annualFees;
          bestCompanyId = companyId;
          bestFeeTrack = result;
        }
      });

      if (!bestCompanyId || !bestFeeTrack) {
        return null;
      }

      return {
        companyId: bestCompanyId,
        feeTrack: bestFeeTrack,
      };
    } catch (error) {
      this.logger.error(`Error finding best fees across companies: ${error.message}`, error.stack);
      throw error;
    }
  }

  /**
   * Check if current fees are better than what we can offer for any company
   * @param currentFees Current annual fees
   * @param currentDepositFee Current deposit fee rate
   * @param currentAccumulationFee Current accumulation fee rate
   * @param companies Array of company IDs to check
   * @param productCategory The product category
   * @param subSpecialization The sub specialization
   * @param accumulation The accumulation amount
   * @param deposit The deposit amount
   * @returns True if current fees are better than any company's optimal fees
   */
  async areCurrentFeesBetter(
    currentFees: number,
    currentDepositFee: number,
    currentAccumulationFee: number,
    companies: string[],
    productCategory: string,
    subSpecialization: string | null,
    accumulation: number,
    deposit: number,
    salary: number,
  ): Promise<boolean> {
    try {
      const bestFeesResult = await this.findBestFeesAcrossCompanies(
        companies,
        productCategory,
        subSpecialization,
        accumulation,
        deposit,
        salary,
      );

      // If we couldn't find any fee options, consider current fees better
      if (!bestFeesResult) {
        return true;
      }

      return currentFees < bestFeesResult.feeTrack.annualFees;
    } catch (error) {
      this.logger.error(`Error checking if current fees are better: ${error.message}`, error.stack);
      throw error;
    }
  }
}
