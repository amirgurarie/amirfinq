// src/finance/pensions/modules/pension-fees/services/pension-fees-calculator.service.ts
import { Injectable, Logger } from '@nestjs/common';
import { FeeRates, FeeResult } from '../interfaces/pension-fees.interface';

/**
 * Service for calculating pension management fees and finding optimal fee options
 */
@Injectable()
export class PensionFeesCalculator {
  private readonly logger = new Logger(PensionFeesCalculator.name);

  /**
   * Calculate the annual management fees based on the formula:
   * Total DnHafkada = 12 * DnHafkada * HAFKADA
   * Total Hafakada = HAFKADA * 12 - Total DnHafakada
   * Total DnZvira = DnZvira * (ZVIRA + Total Hafkada)
   * Total Dn = Total DnHafkada + Total DnZvira
   *
   * @param accumulation - The total accumulation amount (ZVIRA)
   * @param deposit - The monthly deposit amount (HAFKADA)
   * @param depositFeeRate - The deposit fee rate percentage (DnHafkada)
   * @param accumulationFeeRate - The accumulation fee rate percentage (DnZvira)
   * @returns FeeResult containing fee rates and calculated annual fees
   */
  calculateFees(accumulation: number, deposit: number, depositFeeRate: number, accumulationFeeRate: number): FeeResult {
    try {
      // Convert percentages to decimals
      const depositFeeRateDecimal = depositFeeRate / 100;
      const accumulationFeeRateDecimal = accumulationFeeRate / 100;

      // Calculate total deposit fees
      const totalDepositFees = 12 * depositFeeRateDecimal * deposit;

      // Calculate total deposits after fees
      const totalDeposits = deposit * 12 - totalDepositFees;

      // Calculate accumulation fees on total savings and deposits
      const totalAccumulationFees = accumulationFeeRateDecimal * (accumulation + totalDeposits);

      // Calculate total annual fees
      const annualFees = totalDepositFees + totalAccumulationFees;

      return {
        depositFee: depositFeeRate,
        accumulationFee: accumulationFeeRate,
        annualFees,
      };
    } catch (error) {
      this.logger.error(`Error calculating fees: ${error.message}`, error.stack);
      throw error;
    }
  }

  /**
   * Find the fee option with the lowest annual fees from a list of options
   *
   * @param accumulation - The total accumulation amount
   * @param deposit - The monthly deposit amount
   * @param feeOptions - Array of fee rate options to compare
   * @returns The fee option with the lowest annual fees, or null if no options provided
   */
  findLowestFeeOption(accumulation: number, deposit: number, feeOptions: FeeRates[]): FeeResult | null {
    try {
      if (!feeOptions || feeOptions.length === 0) {
        return null;
      }

      let lowestFees = Number.MAX_VALUE;
      let bestOption: FeeResult | null = null;

      for (const option of feeOptions) {
        const feeResult = this.calculateFees(accumulation, deposit, option.depositFeeRate, option.accumulationFeeRate);

        if (feeResult.annualFees < lowestFees) {
          lowestFees = feeResult.annualFees;
          bestOption = feeResult;
        }
      }

      return bestOption;
    } catch (error) {
      this.logger.error(`Error finding lowest fee option: ${error.message}`, error.stack);
      throw error;
    }
  }
}
