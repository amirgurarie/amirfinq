// src/finance/pensions/modules/pension-fees/interfaces/pension-fees.interface.ts
/**
 * Result of fee calculation containing fee rates and annual total
 */
export interface FeeResult {
  depositFee: number;
  accumulationFee: number;
  annualFees: number;
}

/**
 * Result of finding the optimal fee track
 */
export interface OptimalFeeTrackResult {
  feeTrack: {
    id: string;
    companyId: string;
    productCategory: string;
    subSpecialization: number | null;
    depositFee: number;
    accumulationFee: number;
  };
  annualFees: number;
}

/**
 * Result of comparing current fees with optimal fees
 */
export interface FeesComparisonResult {
  currentFees: number;
  optimalFees: number;
  optimalFeeTrack: {
    id: string;
    companyId: string;
    productCategory: string;
    subSpecialization: number | null;
    depositFee: number;
    accumulationFee: number;
  } | null;
  shouldKeepCurrentFees: boolean;
}

/**
 * Parameters for fee calculation
 */
export interface FeeCalculationParams {
  companyId: string;
  productCategory: string;
  subSpecialization: string | null;
  accumulation: number;
  deposit: number;
  salary: number;
}

/**
 * Fee rates as percentages
 */
export interface FeeRates {
  depositFeeRate: number;
  accumulationFeeRate: number;
}
