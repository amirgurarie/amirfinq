import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { Repository } from 'typeorm';
import { FundPensionFinqInterest } from '../../../../entities/FundPensionFinqInterest';

@Injectable()
export class PensionFinqInterestsService extends ServiceHelper<FundPensionFinqInterest> {
  constructor(
    @InjectRepository(FundPensionFinqInterest)
    private readonly fundPensionFinqInterestRepository: Repository<FundPensionFinqInterest>,
  ) {
    super(fundPensionFinqInterestRepository);
  }

  async getFundPensionCalculatedInterest(fundId: string) {
    const fundPensionFinqInterest = await this.fundPensionFinqInterestRepository.findOne({ fundId });

    return fundPensionFinqInterest?.standardizedFinqInterest;
  }
}
