import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoggerModule } from 'src/shared/middlewares/logger/logger.module';
import { FundPensionFinqInterest } from '../../../../entities/FundPensionFinqInterest';
import { PensionFinqInterestsService } from './pension-finq-interests.service';

@Module({
  imports: [TypeOrmModule.forFeature([FundPensionFinqInterest]), LoggerModule],
  providers: [PensionFinqInterestsService],
  exports: [PensionFinqInterestsService],
})
export class PensionFinqInterestsModule {}
