import { applyDecorators } from '@nestjs/common';
import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsOptional, IsString, IsUUID } from 'class-validator';

export class PollSingleQueryDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  @IsUUID()
  public readonly userId: string;
}

export function ApiPollSingleQueryFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'userId',
      required: false,
      type: String,
    }),
  );
}
