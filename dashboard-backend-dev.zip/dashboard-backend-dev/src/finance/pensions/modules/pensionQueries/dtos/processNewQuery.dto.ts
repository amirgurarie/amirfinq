import { applyDecorators } from '@nestjs/common';
import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsOptional, IsString, IsUUID } from 'class-validator';

export class ProcessNewQueryDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  @IsUUID()
  public readonly userId?: string;
}

export function ApiProcessNewQueryFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'userId',
      required: false,
      type: String,
    }),
  );
}
