import { Controller, Get, Post, Query, Req, UseGuards, UseInterceptors } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ApiBearerAuth, ApiExtraModels, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { CurrentAuthUser } from 'src/auth/currentAuthUser.decorator';
import { AbstractController } from 'src/shared';
import { ApiFailedHttpResponse } from 'src/shared/decorators/apiFailedHttpResponse.decorator';
import { ApiNotFoundHttpResponse } from 'src/shared/decorators/apiNotFoundHttpResponse.decorator';
import { LocalJwtAuthGuard } from 'src/shared/guards/localJwtAuth.guard';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';
import { ApiPollSingleQueryFilter, PollSingleQueryDto } from './dtos/pollSingleQuery.dto';
import { ApiProcessNewQueryFilter, ProcessNewQueryDto } from './dtos/processNewQuery.dto';
import { PensionQueriesManager } from './pensionQueries.manager';
import { Request } from 'express';

@ApiTags('Pension Queries')
@Controller('v1/pensions/queries')
export class PensionQueriesController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    protected readonly pensionQueriesManager: PensionQueriesManager,
  ) {
    super(configService);
  }

  // Polling
  @Get('check-status/single')
  @ApiOperation({ summary: 'Check the status of a specific Mislaka query' })
  @ApiResponse({ status: 200, description: 'Successfully retrieved the status of the Mislaka query.' })
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @ApiBearerAuth()
  @UseGuards(LocalJwtAuthGuard)
  @ApiPollSingleQueryFilter()
  @UseInterceptors(TransformInterceptor)
  async pollPensionQuery(
    @Req() req: Request,
    @Query() query: PollSingleQueryDto,
    @CurrentAuthUser() authUserPayload: AuthenticatedUser,
  ): Promise<void> {
    const userId = query.userId || authUserPayload?.user?.id;

    return this.pensionQueriesManager.processPendingSingleQuery(req, userId);
  }

  @Get('check-status')
  @ApiOperation({ summary: 'Check the status of Mislaka queries' })
  @ApiResponse({ status: 200, description: 'Successfully retrieved the status of Mislaka queries.' })
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @UseInterceptors(TransformInterceptor)
  async pollPensionQueries(@Req() req: Request): Promise<void> {
    return this.pensionQueriesManager.processPendingQueries(req);
  }

  // Process by user ID
  @Post('process')
  @ApiOperation({
    summary: 'Process Mislaka data based on user ID',
    description: 'This endpoint is used to process Mislaka data based on the authenticated user ID only ',
  })
  @ApiResponse({ status: 200, description: 'Successfully processed Mislaka data' })
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @ApiBearerAuth()
  @UseGuards(LocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  async processMislakaData(@CurrentAuthUser() authUserPayload: AuthenticatedUser) {
    await this.pensionQueriesManager.processSingleQuery(authUserPayload?.user?.id);

    return { message: 'Successfully processed Mislaka data' };
  }

  // XMLProcess
  @Post()
  @ApiOperation({ summary: 'Process user Mislaka data based on authenticated user ID' })
  @ApiResponse({ status: 200, description: 'Successfully processed Mislaka data' })
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @ApiProcessNewQueryFilter()
  @ApiBearerAuth()
  @UseGuards(LocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  async processUserMislakaData(
    @CurrentAuthUser() authUserPayload: AuthenticatedUser,
    @Query() query: ProcessNewQueryDto,
  ): Promise<void> {
    // const userId = query.userId || authUserPayload?.user?.id;
    await this.pensionQueriesManager.processNewQuery(authUserPayload.user.id);
  }
}
