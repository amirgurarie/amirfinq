import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserPensionMislakaQueries, UserPensionMislakaQueryExclusions } from 'src/entities';
import { FlowStageModule } from 'src/flow-stages/flowStage.module';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { AsyncEventEmitter } from 'src/shared/modules/flowGateway/utils/asyncEvent.util';
import { MislakaModule } from 'src/shared/modules/mislaka/mislaka.module';
import { UserProfileModule } from 'src/users/userProfile/user-profile.module';
import { PensionQueriesController } from './pensionQueries.controller';
import { PensionQueriesHelper } from './pensionQueries.helper';
import { PensionQueriesManager } from './pensionQueries.manager';
import { PensionQueriesService } from './pensionQueries.service';
import { PensionPortfolioPoliciesModule } from './../portfolio/modules/policies/policies.module';
import { PensionPortfolioExclusionsModule } from 'src/finance/pensions/modules/portfolio/modules/exclusions/exclusions.module';
import { FormallyDocumentModule } from 'src/shared/modules/formally/modules/formally-document.module';
import { PensionQueriesFormallyUploadsModule } from '../PensionQueriesFormallyUploads/pensionQueriesFormallyUploads.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([UserPensionMislakaQueries]),
    MislakaModule,
    FlowStageModule,
    UserProfileModule,
    PensionPortfolioPoliciesModule,
    forwardRef(() => PensionPortfolioExclusionsModule),
    FormallyDocumentModule,
    PensionQueriesFormallyUploadsModule,
  ],
  providers: [PensionQueriesService, PensionQueriesHelper, PensionQueriesManager, AsyncEventEmitter, LoggerService],
  exports: [PensionQueriesService, PensionQueriesHelper, PensionQueriesManager],
  controllers: [PensionQueriesController],
})
export class PensionQueriesModule {}
