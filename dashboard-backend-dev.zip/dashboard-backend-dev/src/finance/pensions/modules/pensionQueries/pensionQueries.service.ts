import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserPensionMislakaQueries } from 'src/entities/UserPensionMislakaQueries';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { FindCondition, Not, Repository } from 'typeorm';
import { PensionQueryStatus } from './types/pensionQueries.enum';

@Injectable()
export class PensionQueriesService extends ServiceHelper<UserPensionMislakaQueries> {
  constructor(
    @InjectRepository(UserPensionMislakaQueries)
    private readonly queriesRepository: Repository<UserPensionMislakaQueries>,
  ) {
    super(queriesRepository);
  }

  public async createOrUpdateQuery(details: Partial<UserPensionMislakaQueries>): Promise<UserPensionMislakaQueries> {
    const { userId, requestId } = details;
    const findOptions = { where: { userId, requestId } };

    if (!userId) {
      return this.queriesRepository.save(details);
    }

    if (requestId) {
      const existingUserQuery = await this.queriesRepository.findOne(findOptions);

      if (existingUserQuery) {
        const mergedDetails = this.queriesRepository.merge(existingUserQuery, details);

        return this.queriesRepository.save(mergedDetails);
      }
    }

    return this.queriesRepository.save(details);
  }

  public async findUserLastQuery(
    userId: FindCondition<string>,
    status: FindCondition<PensionQueryStatus> = PensionQueryStatus.COMPLETED,
  ): Promise<UserPensionMislakaQueries> {
    return this.queriesRepository.findOne({
      where: { userId, status },
      order: { lastTry: 'DESC' },
    });
  }

  public async findPendingQueries(): Promise<UserPensionMislakaQueries[]> {
    return this.queriesRepository
      .createQueryBuilder('pension_queries')
      .where('pension_queries.status NOT IN (:...statuses)', { statuses: [PensionQueryStatus.COMPLETED] })
      .getMany();
  }
}
