import { Injectable } from '@nestjs/common';
import { isNullOrUndefined } from 'src/shared/helpers/utils';
import { MislakaManager } from 'src/shared/modules/mislaka/mislaka.manager';
import { Aroya } from 'src/shared/modules/mislaka/integrations/Aroya/aroya.namespace';

@Injectable()
export class PensionQueriesHelper {
  constructor(private readonly mislakaManager: MislakaManager) {}

  public async startProcedure(userId: string, toalot: Aroya.BenefitsResponse): Promise<void> {
    if (isNullOrUndefined(toalot)) {
      return;
    }

    await this.mislakaManager.generateUserPensionDetails(userId, toalot);
    await this.mislakaManager.generateUserFinance(userId, toalot);
  }

  public async startPartialProcedure(userId: string, requestId: string): Promise<void> {
    // step - get toalot

    const toalot = await this.mislakaManager.getToalot({ userId, requestId });
    if (isNullOrUndefined(toalot)) {
      return;
    }
  }
}
