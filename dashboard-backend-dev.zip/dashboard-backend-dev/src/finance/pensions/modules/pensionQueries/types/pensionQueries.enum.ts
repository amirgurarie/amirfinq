export const PensionQueryDataType = {
  BENEFITS: 'BENEFITS',
  ZIP_FILE: 'ZIP_FILE',
} as const;

export type PensionQueryDataType = (typeof PensionQueryDataType)[keyof typeof PensionQueryDataType];

export const PensionQueryStatus = {
  PENDING: 'PENDING',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
} as const;

export type PensionQueryStatus = (typeof PensionQueryStatus)[keyof typeof PensionQueryStatus];
