import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import dayjs from 'dayjs';
import { Users } from 'src/entities';
import { UserPensionMislakaQueries } from 'src/entities/UserPensionMislakaQueries';
import { FlowStage } from 'src/flow-stages/flowStage.namespace';
import { NotFoundError } from 'src/shared/errors/notFound.error';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { FlowGatewayEventType } from 'src/shared/modules/flowGateway/enums/flowGateway.enum';
import { AsyncEventEmitter } from 'src/shared/modules/flowGateway/utils/asyncEvent.util';
import { MislakaManager } from 'src/shared/modules/mislaka/mislaka.manager';
import * as uuid from 'uuid';
import { PensionQueriesHelper } from './pensionQueries.helper';
import { PensionQueriesService } from './pensionQueries.service';
import { PensionQueryDataType, PensionQueryStatus } from './types/pensionQueries.enum';
import { Not } from 'typeorm';
import { PensionPortfolioExclusionsManager } from 'src/finance/pensions/modules/portfolio/modules/exclusions/exclusions.manager';
import { PensionQueriesFormallyUploadsManager } from '../PensionQueriesFormallyUploads/PensionQueriesFormallyUploads.manager';

@Injectable()
export class PensionQueriesManager {
  constructor(
    private readonly pensionQueriesService: PensionQueriesService,
    private readonly pensionQueriesHelper: PensionQueriesHelper,
    private readonly exclusionsManager: PensionPortfolioExclusionsManager,
    private readonly asyncEventEmitter: AsyncEventEmitter,
    private readonly mislakaManager: MislakaManager,
    private readonly loggerService: LoggerService,
    private readonly pensionQueriesFormallyUploadsManager: PensionQueriesFormallyUploadsManager,
  ) {}

  public async processNewQuery(userId: string, dataType = PensionQueryDataType.BENEFITS): Promise<void> {
    try {
      const requestId = uuid.v4();
      const lastTry = dayjs().toISOString();

      await this.pensionQueriesService.createOrUpdateQuery({
        userId,
        dataType,
        status: PensionQueryStatus.PENDING,
        requestId: requestId,
        startDate: lastTry,
        lastTry,
      });

      await this.mislakaManager.processMislaka({ userId, requestId });
    } catch (error) {
      console.error(error);
      this.loggerService.error(JSON.stringify(error), '🔁 [processQuery] Query failed');
      throw error;
    }
  }

  public async processPendingQueries(req: Request): Promise<void> {
    const queries = await this.pensionQueriesService.findPendingQueries();
    await Promise.allSettled(queries?.map((query) => this.handlePendingQuery(req, query)));
  }

  public async processPendingSingleQuery(req: Request, userId: string): Promise<void> {
    const latestPensionQuery = await this.pensionQueriesService.findUserLastQuery(
      userId,
      Not(PensionQueryStatus.COMPLETED),
    );

    if (latestPensionQuery) {
      await this.handlePendingQuery(req, latestPensionQuery);
    } else {
      throw new NotFoundError('No query found');
    }
  }

  public async handlePendingQuery(req: Request, pensionQuery: UserPensionMislakaQueries): Promise<void> {
    const lastTry = dayjs().toISOString();

    try {
      const toalot = await this.mislakaManager.getToalot({
        userId: pensionQuery.userId,
        requestId: pensionQuery.requestId,
      });
      if (!toalot) {
        await this.pensionQueriesService.createOrUpdateQuery({ ...pensionQuery, lastTry });

        return;
      }

      await this.pensionQueriesHelper.startProcedure(pensionQuery.userId, toalot);

      await this.pensionQueriesService.createOrUpdateQuery({
        ...pensionQuery,
        lastTry,
        status: PensionQueryStatus.COMPLETED,
        errorMessage: null,
      });

      const exclusions = await this.exclusionsManager.identify(pensionQuery.userId, pensionQuery.requestId);
      if (exclusions.length > 0) {
        await this.pensionQueriesFormallyUploadsManager.handleUploadFormally(
          req,
          pensionQuery.userId,
          pensionQuery.requestId,
        );
      }

      await this.emitStageUpdateEvent(
        req,
        { id: pensionQuery.userId } as Users,
        FlowStage.FlowKey.PENSIONS as FlowStage.FlowKey,
        FlowStage.StageKey.AWAITING_MISLAKA as FlowStage.StageKey,
        FlowStage.StageKey.COMPLETED_MISLAKA as FlowStage.StageKey,
      );
    } catch (error) {
      this.loggerService.error(error, '🔁 [handlePendingQuery] Query failed');
      await this.pensionQueriesService.createOrUpdateQuery({
        ...pensionQuery,
        lastTry,
        status: PensionQueryStatus.FAILED,
        errorMessage: `${error} Error caused to this ${pensionQuery.requestId}`,
      });
    }
  }

  public async processSingleQuery(userId: string): Promise<void> {
    try {
      const latestPensionQuery = await this.pensionQueriesService.findUserLastQuery(userId);

      if (latestPensionQuery) {
        await this.pensionQueriesHelper.startPartialProcedure(latestPensionQuery.userId, latestPensionQuery.requestId);
      } else {
        throw new NotFoundError('No query found');
      }
    } catch (error) {
      this.loggerService.error(JSON.stringify(error), '🔁 [processQuery] Query failed');
      throw error;
    }
  }

  private async emitStageUpdateEvent(
    req: Request,
    user: Users,
    flowKey: FlowStage.FlowKey,
    currentStage: FlowStage.StageKey,
    targetStage?: FlowStage.StageKey,
  ): Promise<void> {
    try {
      await this.asyncEventEmitter.emitAsync(FlowGatewayEventType.STAGE_UPDATED, {
        req,
        userId: user.id,
        user,
        flowKey,
        currentStage,
        targetStage,
        metadata: {
          source: 'KYC_PENSION_QUESTIONNAIRE',
          timestamp: new Date(),
        },
      });
    } catch (error) {
      console.error('Failed to emit stage update event:', error);

      // You might want to handle this error differently based on your requirements

      throw error;
    }
  }
}
