import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { PensionPortfolio } from '../portfolio.namespace';

export class PensionPortfolioCategoryMapper {
  public static toPortfolioCategory(value: string): PensionPortfolio.Categories | null {
    const category = value as PensionCategoriesEnum;

    if (!Object.values(PensionCategoriesEnum).includes(category)) {
      return PensionPortfolio.Categories.OTHER;
    }

    if (category === PensionCategoriesEnum.COMPERHENSIVE || category === PensionCategoriesEnum.SUPPLEMENTARY) {
      return PensionPortfolio.Categories.PENSION;
    }

    return PensionPortfolio.Categories[category];
  }

  public static toPensionCategory(value: PensionPortfolio.Categories): PensionCategoriesEnum | null {
    return PensionCategoriesEnum[value] || null;
  }
}
