import { applyDecorators, UseGuards } from '@nestjs/common';
import { AccessPortfolioGuard } from 'src/shared/guards/accessPortfolio.guard';
import { LocalJwtAuthGuard } from 'src/shared/guards/localJwtAuth.guard';

export function AccessPortfolioGuardDecorator() {
  return applyDecorators(UseGuards(LocalJwtAuthGuard, AccessPortfolioGuard));
}
