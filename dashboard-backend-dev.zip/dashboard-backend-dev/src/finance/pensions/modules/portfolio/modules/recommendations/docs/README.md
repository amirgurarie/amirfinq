# Pension Recommendations Module

## Overview

The Pension Recommendations Module is a sophisticated system designed to generate, manage, and process recommendations for pension portfolios. The module handles both static and dynamic recommendations, supporting both basic (0->1 | 1->1) and complex (N->N) relationship scenarios between current and target holdings.

## Types of Recommendations

### Static Recommendations

- Pre-calculated recommendations based on fixed parameters
- Can be either basic (simple one-to-one mappings) or complex (multiple-to-multiple mappings)
- Typically used for standard portfolio optimization scenarios
- Once generated, remain unchanged unless manually handled

### Dynamic Recommendations

- Interactive recommendations that can be modified by user selections
- Supports complex relationship scenarios
- Key feature: Real-time recalculation based on user toggles of current holdings
- Each toggle triggers a recalculation of target holdings to be recommended

## Recommendation Generation Flow

### 1. Creation Phase

- Retrieves user's latest pension data and portfolio information
- Creates initial recommendations using either internal or Aroya logic:
  - Internal logic strategy (primary)
  - Aroya logic strategy (fallback)
- Generates recommendations for both existing policies and new plans
- Each recommendation contains the basic structure needed for further processing

### 2. Consolidation Phase

- Groups recommendations by their pension category
- For each category:
  - Combines multiple recommendations into a single consolidated recommendation
  - Maps current holdings to target holdings
  - Determines if the recommendation should be static or dynamic
  - Creates new combinations with unique identifiers

### 3. Enrichment Phase

- Processes all created recommendations
- For each recommendation:
  - Matches appropriate funds to target holdings
  - Identifies required actions for current holdings
  - Calculates financial metrics (e.g, Accumulation amounts, Deposit amounts, Provision breakdowns)
- Updates recommendations with the enriched data

### 4. Simulation Phase

- Generates simulations for each recommendation
- Evaluates potential outcomes and performance
- Validates the feasibility of recommendations
- Stores simulation results for future reference

## Dynamic Recommendation Recalculation

### Overview

The recalculation feature enables users to interactively modify recommendations by toggling current holdings, triggering real-time updates to target holdings while maintaining portfolio strategy and constraints. This process specifically handles complex (N->N) relationship scenarios between current and target holdings.

### User Interaction Flow

1. User views a specific recommendation

   - Recommendation displays current holdings and their status (included/excluded)
   - Each holding shows its current state and potential impact
   - System maintains the relationship between current and target holdings

2. User can toggle which current holdings to include/exclude

   - Toggles are handled at the holding level
   - Each transaction can have multiple holdings
   - System maintains the integrity of transaction-holding relationships
   - Toggles can be made individually or in groups

3. Each toggle triggers an immediate recalculation

   - System validates the new selection against existing constraints
   - Recalculates target holdings based on new selection

4. Updated recommendation is presented to the user
   - Shows new target holdings and their metrics
   - Provides immediate feedback on the impact of selections

### Recalculation Process

1. Validates the new selection of current holdings
2. Recalculates target holdings based on:
   - Selected current holdings
   - Defined constraints and rules
3. Updates recommendation combinations
4. Re-runs necessary simulations
5. Returns updated recommendation to the user

### Key Features

- Real-time recalculation on user interaction
- Preserves defined constraints and rules
- Provides immediate feedback on selection changes

## Recommendation Entities

The recommendation system implements a hierarchical data model that orchestrates the complete lifecycle of pension recommendations.
This hierarchical structure enables efficient data management and clear separation of concerns, allowing for independent scaling of different components while maintaining data consistency.
The design's flexibility accommodates both straightforward portfolio adjustments and complex restructuring scenarios, ensuring consistent performance across all recommendation types.

### Entity Relationships

```ascii
UserPensionRecommendations (recommendation)
|── UserPensionRecommendationTransactions (transaction)
|    ├── UserPensionRecommendationHoldings (transaction holding)
|    │
|    └── UserPensionRecommendationCombinations (transaction combination)
|        ├── UserPensionRecommendationCombinationCurrentHoldings (combination current holding)
|        │   └── UserPensionRecommendationCombinationHoldingSimulations
|        │
|        └── UserPensionRecommendationCombinationTargetHoldings (combination target holding)
|            └── UserPensionRecommendationCombinationHoldingSimulations
|
└── ManagementFees
```

### Entity References

#### Core Entities

- **UserPensionRecommendations**: Root entity managing the recommendation lifecycle and versioning
- **UserPensionRecommendationTransactions**: Container for transaction data and state management
- **UserPensionRecommendationHoldings**: Manages individual holdings within transactions

#### Combination Entities

- **UserPensionRecommendationCombinations**: Manages different recommendation scenarios and variations
- **UserPensionRecommendationCombinationCurrentHoldings**: Tracks current portfolio state and selections
- **UserPensionRecommendationCombinationTargetHoldings**: Manages target allocations and fund matching

#### Supporting Entities

- **UserPensionRecommendationCombinationHoldingSimulations**: Handles performance projections and risk analysis
- **ManagementFees**: Manages fee calculations, tiers, and adjustments

## Design Documentation

### Specifications

- [General Pension Flow](https://docs.google.com/document/d/1emB7LYhWmtnomShy3RV8tOoqdIqdzElFzoLgZyLP1rg/edit?tab=t.0#heading=h.7bdwgainzjhe)

  - Process flows and state transitions
  - Integration points and data flows

- [Recommendations Logic](https://docs.google.com/document/d/1rjPPWi0qqXDYCnRFgt_77dsYtnL1rikbXl1_7GeEdnk/edit?tab=t.0#heading=h.thp38xf6pyrn)

  - Creation phases and handling strategies
  - Consolidation rules and optimizations

- [Fund Matching](https://docs.google.com/document/d/1ZmoKEIXnW6Sw_8WKp61MlfDs8EestBFfto2LrDo1W8Y/edit?tab=t.0#heading=h.ki90yvd05388)

  - Matching rules and algorithms
  - Performance and compliance requirements

- [Management Fees](https://docs.google.com/spreadsheets/d/1brpBMFFM87Mw2Jzu3s0J_Z5aKqT9RjIR/edit?gid=730941614#gid=730941614)
  - Fee structure and calculation rules
  - Special cases and integration points

### Architecture & Design Flows

- [Portfolio Recommendations Architecture](https://www.figma.com/board/YePTGXoOftXpKKWEgERI5w/Portfolio-Recommendations?node-id=0-1&p=f&t=UuAqvt6rHUp46hnb-0)
  - System architecture diagrams
  - Data flow diagrams
  - State transition diagrams
  - Integration flows
  - Component relationships

## Usage Guidelines

1. Follow the established recommendation flow: Creation → Consolidation → Enrichment → Simulation
2. Maintain clear separation between static and dynamic recommendations
3. Optimize for real-time recalculation performance
4. Implement robust error handling and validation

## Contributions

This documentation was created and maintained by the Finq Finance team. For any questions or suggestions, please contact the team.

_Documentation crafted with ❤️ by *Itamar Klein*_.

_Last updated: May 21, 2025_.
