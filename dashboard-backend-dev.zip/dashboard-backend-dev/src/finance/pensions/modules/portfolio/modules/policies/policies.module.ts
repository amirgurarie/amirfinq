import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserPensionMislakaPolicies } from 'src/entities/UserPensionMislakaPolicies';
import { UserPensionMislakaPolicyDeposits } from 'src/entities/UserPensionMislakaPolicyDeposits';
import { EnvironmentManager } from 'src/env/envManager.service';
import { PensionPortfolioPolicyDepositsModule } from '../deposits/deposits.module';
import { PensionPortfolioPoliciesService } from './policies.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([UserPensionMislakaPolicies, UserPensionMislakaPolicyDeposits]),
    PensionPortfolioPolicyDepositsModule,
  ],
  controllers: [],
  providers: [PensionPortfolioPoliciesService, EnvironmentManager],
  exports: [PensionPortfolioPoliciesService, TypeOrmModule, PensionPortfolioPolicyDepositsModule],
})
export class PensionPortfolioPoliciesModule {}
