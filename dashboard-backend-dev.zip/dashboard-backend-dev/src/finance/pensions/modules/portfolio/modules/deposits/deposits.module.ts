import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserPensionMislakaPolicyDeposits } from 'src/entities/UserPensionMislakaPolicyDeposits';
import { PensionPortfolioPolicyDepositsService } from './deposits.service';
import { DepositRepository } from './deposits.repository';
import { PolicyDepositStrategiesModule } from './strategies/depositStrategies.module';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';

@Module({
  imports: [TypeOrmModule.forFeature([UserPensionMislakaPolicyDeposits]), PolicyDepositStrategiesModule],
  providers: [
    PensionPortfolioPolicyDepositsService,
    {
      provide: 'IDepositRepository',
      useClass: DepositRepository,
    },
    LoggerService,
  ],
  exports: [PensionPortfolioPolicyDepositsService],
})
export class PensionPortfolioPolicyDepositsModule {}
