import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';

@Injectable()
export class AccessRecommendationsGuard implements CanActivate {
  public async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authUserPayload = request.user as AuthenticatedUser;
    const userIdFromQuery = request.query.userId;

    const allowedEmails = [
      'tomer@finqai.com',
      'itamar.klein+dev2@finqai.com',
      'amitg+tomash1@finqai.com',
      'einav@finqai.com',
    ];
    if (userIdFromQuery && !allowedEmails.includes(authUserPayload.user.email)) {
      throw new ForbiddenException('User is not allowed to take this action');
    }

    return true;
  }
}
