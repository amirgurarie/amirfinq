import { Injectable } from '@nestjs/common';
import { createHash } from 'crypto';
import { UserPensionRecommendationCombinations, UserPensionRecommendationTransactions } from 'src/entities';
import { UserPensionRecommendationCombinationCurrentHoldings } from 'src/entities/UserPensionRecommendationsCombinationsHoldings';
import { DeepPartial } from 'typeorm';
import { CoreEntitiesBuilder } from './entities.builder';

/**
 * The `CoreCombinationBuilder` service is responsible for constructing and calculating combinations for pension recommendations.
 * It provides methods to calculate salary deposits, total accumulations, monthly deposits, and hashes for combinations.
 *
 * The `CoreEntitiesBuilder` service is injected into this class to provide entity-building capabilities.
 * This service is used by external combination builder services (e.g., internal and Aroya logic) to construct
 * and manage entities related to pension recommendations.
 *
 * @class CoreCombinationBuilder
 * @Injectable
 */
@Injectable()
export class CoreCombinationBuilder {
  constructor(public readonly entitiesBuilder: CoreEntitiesBuilder) {}

  /**
   * Calculates the reported salary for target holdings based on the target monthly deposit amount and the total provision percentage.
   * This is used when creating target holding recommendations to determine the required salary level.
   * @param {number} targetMonthlyDepositAmount - The target monthly deposit amount for the holding.
   * @param {number} totalProvisionPercentage - The total provision percentage (sum of compensation, employer, and employee provisions).
   * @returns {number} The calculated reported salary needed to achieve the target monthly deposit.
   */
  calculateTargetHoldingReportedSalary(targetMonthlyDepositAmount: number, totalProvisionPercentage: number): number {
    return (targetMonthlyDepositAmount / totalProvisionPercentage) * 100 || 0;
  }

  /**
   * Calculates the total salary to deposit based on the current holdings.
   * @param {DeepPartial<UserPensionRecommendationCombinationCurrentHoldings>[]} currentHoldings - The list of current holdings.
   * @returns {number} The total salary to deposit.
   */
  calculateTotalSalaryToDeposit(
    currentHoldings: DeepPartial<UserPensionRecommendationCombinationCurrentHoldings>[],
  ): number {
    return (
      currentHoldings?.reduce((sum, h) => {
        const salary = h?.holding?.policy?.salary || 0;
        const hasEmployerProvision = h?.holding?.policy?.employerProvision;

        return sum + (hasEmployerProvision ? salary : 0);
      }, 0) || 0
    );
  }

  /**
   * Calculates the total accumulation amount based on the current holdings.
   * @param {DeepPartial<UserPensionRecommendationCombinationCurrentHoldings>[]} currentHoldings - The list of current holdings.
   * @returns {number} The total accumulation amount.
   */
  calculateTotalAccumulation(
    currentHoldings: DeepPartial<UserPensionRecommendationCombinationCurrentHoldings>[],
  ): number {
    return (
      currentHoldings?.reduce((sum, h) => {
        return sum + (h?.holding?.policy?.currentSavings || 0);
      }, 0) || 0
    );
  }

  /**
   * Calculates the total monthly deposit amount based on the compensation, employer, and employee provisions.
   * @param {number} compensationProvisionAmount - The compensation provision amount.
   * @param {number} employerProvisionAmount - The employer provision amount.
   * @param {number} employeeProvisionAmount - The employee provision amount.
   * @returns {number} The total monthly deposit amount.
   */
  calculateTotalMonthlyDeposit(
    compensationProvisionAmount: number,
    employerProvisionAmount: number,
    employeeProvisionAmount: number,
  ): number {
    return (compensationProvisionAmount || 0) + (employerProvisionAmount || 0) + (employeeProvisionAmount || 0);
  }

  /**
   * Calculates a deterministic SHA-256 hash for a given recommendation combination.
   * The hash is based on the `transactionId` and the sorted list of `currentHoldingIds`.
   * This can be used to identify duplicate or equivalent combinations.
   * @param transactionId - The transaction ID of the combination.
   * @param selectedHoldingIds - An array of selected holding IDs.
   * @returns {string} A SHA-256 hexadecimal hash string uniquely representing the combination.
   * @remarks
   * - If `selectedHoldingIds` is undefined, an empty array is used.
   * - Sorting ensures that the hash is order-insensitive for holdings.
   */
  calculateHash(transactionId: string, selectedHoldingIds: string[]): string {
    const hashData = {
      transactionId,
      currentHoldingIds: selectedHoldingIds?.sort() || [],
    };

    return createHash('sha256').update(JSON.stringify(hashData)).digest('hex');
  }

  /**
   * Checks if a combination hash is unique in a transaction.
   * @param {DeepPartial<UserPensionRecommendationTransactions>} transaction - The transaction containing the combinations.
   * @param {string} hash - The hash to check for uniqueness.
   * @returns {boolean} True if the hash is unique, false otherwise.
   */
  existsHash(transaction: DeepPartial<UserPensionRecommendationTransactions>, hash: string): boolean {
    return (transaction.combinations || []).some((c) => c.hash === hash);
  }

  /**
   * Adds a new combination to a transaction and ensures it is marked as selected.
   * If the transaction does not already have a combinations array, it initializes one.
   * All existing combinations in the transaction are marked as not selected (`isSelected = false`),
   * and the new combination is added to the array.
   * @param {DeepPartial<UserPensionRecommendationTransactions>} transaction - The transaction to which the combination will be added.
   * @param {DeepPartial<UserPensionRecommendationCombinations>} combination - The new combination to add to the transaction.
   */
  addNewCombination(
    transaction: DeepPartial<UserPensionRecommendationTransactions>,
    combination: DeepPartial<UserPensionRecommendationCombinations>,
  ): void {
    transaction.combinations = transaction.combinations || [];
    transaction.combinations.forEach((c) => (c.isSelected = false));
    transaction.combinations.push(combination);
    transaction.selectedCombination = combination;
  }

  /**
   * Selects an existing combination in a transaction.
   * Marks all other combinations as unselected and sets the specified combination as selected.
   * Also updates the transaction's selectedCombination reference.
   * @param {DeepPartial<UserPensionRecommendationTransactions>} transaction - The transaction containing the combinations.
   * @param {DeepPartial<UserPensionRecommendationCombinations>} combination - The combination to reselect.
   * @returns {boolean} True if the combination was found and selected, false otherwise.
   */
  selectExistingCombination(transaction: DeepPartial<UserPensionRecommendationTransactions>, hash: string): boolean {
    const combination = (transaction.combinations || []).find((c) => c.hash === hash);
    if (!combination) return false;

    transaction.combinations.forEach((c) => (c.isSelected = false));

    combination.isSelected = true;
    transaction.selectedCombination = combination;

    return true;
  }
}
