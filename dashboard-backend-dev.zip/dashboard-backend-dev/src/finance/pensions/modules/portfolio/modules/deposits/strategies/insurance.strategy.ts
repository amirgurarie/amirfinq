import { Injectable } from '@nestjs/common';
import _ from 'lodash';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { BaseDepositAggregator } from '../aggregators/baseDeposit.aggregator';
import { PolicyMonthlyDepositsResponseDto } from '../dto/policy-deposits.dto';
import { DepositFilters } from '../interfaces/deposit-repository.interface';
import { IDepositStrategy } from '../interfaces/deposit-strategy.interface';
import { RawDeposit } from '../types/deposit.types';

@Injectable()
export class PolicyDepositInsuranceStrategy implements IDepositStrategy {
  constructor(private readonly aggregator: BaseDepositAggregator) {}

  canHandle(category: PensionCategoriesEnum): boolean {
    return category === PensionCategoriesEnum.INSURANCE;
  }

  getFilters(): DepositFilters {
    return {
      category: PensionCategoriesEnum.INSURANCE,
      depositTypes: [], // TODO: Add deposit types if needed
    };
  }

  formatResponse(deposits: RawDeposit[], policyId: number): PolicyMonthlyDepositsResponseDto {
    const aggregatedDeposits = this.aggregator.aggregate(deposits, {
      groupBy: 'none',
    });

    return {
      policyId,
      productCategoryId: PensionCategoriesEnum.INSURANCE,
      deposits: aggregatedDeposits,
      summary: {
        total: {
          totalAmount: _.sumBy(aggregatedDeposits, 'totalAmount'),
          depositCount: _.sumBy(aggregatedDeposits, 'depositCount'),
        },
      } as any,
    };
  }
}
