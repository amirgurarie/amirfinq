import { Inject, Injectable } from '@nestjs/common';
import { IDepositStrategy } from '../interfaces/deposit-strategy.interface';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';

@Injectable()
export class DepositStrategyFactory {
  constructor(
    @Inject('DepositStrategies')
    private readonly strategies: IDepositStrategy[],
  ) {}

  getStrategy(category: PensionCategoriesEnum): IDepositStrategy {
    const strategy = this.strategies.find((s) => s.canHandle(category));
    if (!strategy) {
      throw new Error(`No strategy found for category: ${category}`);
    }

    return strategy;
  }
}
