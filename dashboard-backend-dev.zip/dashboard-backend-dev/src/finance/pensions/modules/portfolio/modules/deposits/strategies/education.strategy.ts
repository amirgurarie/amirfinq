import { Injectable } from '@nestjs/common';
import { IDepositStrategy } from '../interfaces/deposit-strategy.interface';
import { DepositTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { RawDeposit } from '../types/deposit.types';
import {
  PolicyMonthlyDepositsResponseDto,
  DepositSummaryDto,
  SummaryGroupDto,
  MonthlyDepositDto,
} from '../dto/policy-deposits.dto';
import _ from 'lodash';
import { DepositFilters } from '../interfaces/deposit-repository.interface';
import { BaseDepositAggregator } from '../aggregators/baseDeposit.aggregator';

@Injectable()
export class EducationStrategy implements IDepositStrategy {
  constructor(private readonly aggregator: BaseDepositAggregator) {}

  canHandle(category: PensionCategoriesEnum): boolean {
    return category === PensionCategoriesEnum.EDUCATION;
  }

  getFilters(): DepositFilters {
    return {
      category: PensionCategoriesEnum.EDUCATION,
      depositTypes: [DepositTypeEnum.KEREN_HISHTALMUT_OVED, DepositTypeEnum.KEREN_HISHTALMUT_MAAVID],
    };
  }

  formatResponse(deposits: RawDeposit[], policyId: number): PolicyMonthlyDepositsResponseDto {
    const employeeDeposits = deposits.filter((d) => d.depositType === DepositTypeEnum.KEREN_HISHTALMUT_OVED);
    const employerDeposits = deposits.filter((d) => d.depositType === DepositTypeEnum.KEREN_HISHTALMUT_MAAVID);

    const aggregatedEmployeeDeposits = this.aggregator.aggregate(employeeDeposits, {
      groupBy: 'month',
      groupingConfig: {
        mergeFields: ['depositType'],
        timeField: 'paymentMonth',
        accumulateFields: ['depositAmount', 'totalAmount', 'accumulatedAmount'],
      },
    });

    const aggregatedEmployerDeposits = this.aggregator.aggregate(employerDeposits, {
      groupBy: 'month',

      groupingConfig: {
        timeField: 'paymentMonth',
        mergeFields: ['depositType'],
        accumulateFields: ['depositAmount', 'totalAmount', 'accumulatedAmount'],
      },
    });

    const summary: SummaryGroupDto = {
      employee: this.calculateSummary(aggregatedEmployeeDeposits),
      employer: this.calculateSummary(aggregatedEmployerDeposits),
      total: {
        totalAmount: parseFloat(_.sumBy(deposits, 'depositAmount').toFixed(2)),
        depositCount: deposits.length,
      },
    };

    const mergedMonthlyDeposits = this.aggregator.mergeMonthlyDeposits(
      aggregatedEmployeeDeposits,
      aggregatedEmployerDeposits,
    );

    return {
      policyId,
      productCategoryId: PensionCategoriesEnum.EDUCATION,
      deposits: mergedMonthlyDeposits,
      summary,
    };
  }

  private calculateSummary(deposits: MonthlyDepositDto[]): DepositSummaryDto {
    return {
      totalAmount: parseFloat(_.sumBy(deposits, 'totalAmount').toFixed(2)),
      depositCount: _.sumBy(deposits, 'depositCount'),
    };
  }
}
