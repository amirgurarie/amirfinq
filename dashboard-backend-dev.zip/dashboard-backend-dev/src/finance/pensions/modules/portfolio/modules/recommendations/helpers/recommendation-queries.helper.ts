import dayjs from 'dayjs';
import { UserPensionRecommendationCombinationHoldingSimulations } from 'src/entities';
import { RefPensionCompanies } from 'src/entities/RefPensionCompanies';
import { RefPensionProductsSecondaryCategories } from 'src/entities/RefPensionProductsSecondaryCategories';
import { UserPensionRecommendations } from 'src/entities/UserPensionRecommendations';
import { PensionRecommendationTypes } from 'src/finance/pensions/modules/portfolio/modules/recommendations/types/recommendations.namespace';
import { SelectQueryBuilder } from 'typeorm';

export class RecommendationQueries {
  // =====================================================
  // BASE CONDITIONS
  // =====================================================

  public static addBaseConditions(
    queryBuilder: SelectQueryBuilder<UserPensionRecommendations>,
    userId: string,
  ): SelectQueryBuilder<UserPensionRecommendations> {
    return queryBuilder
      .where(`recommendations.userId = :userId`, { userId })
      .andWhere(
        `recommendations.created_at = (SELECT MAX(upr.created_at) FROM user_pension_recommendations upr WHERE upr.user_id = :userId)`,
        { userId },
      )
      .andWhere(`recommendations.expiredAt > :now`, { now: dayjs().toDate() });
  }

  // =====================================================
  // FILTERS
  // =====================================================

  public static addIdsFilter(
    queryBuilder: SelectQueryBuilder<UserPensionRecommendations>,
    recommendationIds: string[],
  ): SelectQueryBuilder<UserPensionRecommendations> {
    if (recommendationIds && recommendationIds.length > 0) {
      queryBuilder.andWhere(`recommendations.id IN (:...recommendationIds)`, { recommendationIds });
    }

    return queryBuilder;
  }

  public static addCategoryFilter(
    queryBuilder: SelectQueryBuilder<UserPensionRecommendations>,
    category: string,
  ): SelectQueryBuilder<UserPensionRecommendations> {
    if (category) {
      queryBuilder.andWhere(`recommendations.category = :category`, { category });
    }

    return queryBuilder;
  }

  // =====================================================
  // BASE JOINS (without nested relations)
  // =====================================================

  public static addBenefitsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder.leftJoinAndSelect(
      'recommendations.benefits',
      'benefits',
      `benefits.recommendationId = recommendations.id
        AND benefits.created_at = (
          SELECT MAX(ub.created_at) 
          FROM user_pension_recommendation_benefits ub 
          WHERE ub.recommendation_id = recommendations.id
        )`,
    );
  }

  public static addTransactionsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder.leftJoinAndSelect(
      `recommendations.transactions`,
      'transactions',
      'transactions.recommendationId = recommendations.id',
    );
  }

  public static addTransactionHoldingsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder.leftJoinAndSelect(
      'transactions.holdings',
      'transactionHoldings',
      'transactionHoldings.transactionId = transactions.id',
    );
  }

  public static addCombinationsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder.leftJoinAndSelect(
      'transactions.combinations',
      'combinations',
      'combinations.transactionId = transactions.id',
    );
  }

  public static addCurrentHoldingsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder.leftJoinAndSelect(
      `combinations.currentHoldings`,
      `currentHoldings`,
      `currentHoldings.combinationId = combinations.id`,
    );
  }

  public static addTargetHoldingsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder.leftJoinAndSelect(
      'combinations.targetHoldings',
      'targetHoldings',
      'targetHoldings.combinationId = combinations.id',
    );
  }

  // =====================================================
  // NESTED JOINS (with additional relations)
  // =====================================================

  public static addTransactionHoldingsRelationsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder
      .leftJoinAndSelect(
        'transactionHoldings.policy',
        'transactionHoldingPolicy',
        'transactionHoldingPolicy.id = transactionHoldings.policyId',
      )
      .leftJoinAndSelect(
        'transactionHoldingPolicy.fund',
        'transactionHoldingPolicyFund',
        'transactionHoldingPolicyFund.fundId = transactionHoldingPolicy.fundId',
      )
      .leftJoinAndSelect('transactionHoldingPolicy.company', 'transactionHoldingPolicyCompany');
  }

  public static addCurrentHoldingsRelationsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder
      .leftJoinAndSelect(`currentHoldings.holding`, 'holding', `holding.id = currentHoldings.holdingId`)
      .leftJoinAndSelect('holding.policy', 'policy', `policy.id = holding.policyId`)
      .leftJoinAndSelect('policy.fund', 'currentFund', `currentFund.fundId = policy.fundId`)
      .leftJoinAndSelect(
        'currentFund.investmentPlans',
        'investmentPlans',
        'investmentPlans.fund_id = currentFund.fund_id',
      )
      .leftJoinAndSelect('policy.company', 'company');
  }

  public static addTargetHoldingsRelationsJoin<T>(queryBuilder: SelectQueryBuilder<T>) {
    return queryBuilder
      .leftJoinAndSelect(`targetHoldings.fund`, 'targetFund', `targetFund.fundId = targetHoldings.fundId`)
      .leftJoinAndMapOne(
        'targetFund.pensionCompany',
        RefPensionCompanies,
        'ref_pension_companies',
        'targetFund.parent_company_id = ref_pension_companies.company_id',
      )
      .leftJoinAndMapOne(
        'targetFund.pensionSecondaryCategory',
        RefPensionProductsSecondaryCategories,
        'rfpsc',
        'targetFund.secondary_category_id = rfpsc.secondary_code ',
      );
  }

  // =====================================================
  // SIMULATION JOINS (can be added to any holding type)
  // =====================================================

  public static addSimulationsJoin<T>(queryBuilder: SelectQueryBuilder<T>, holdingType: string) {
    const holdingsAlias =
      holdingType === PensionRecommendationTypes.Holding.TypesEnum.CURRENT ? 'currentHoldings' : 'targetHoldings';

    const allSimulations = `${holdingsAlias}_simulations`;
    const latestSimulation = `${holdingsAlias}_latest_simulation`;

    return queryBuilder
      .leftJoinAndSelect(
        `${holdingsAlias}.simulations`,
        `${allSimulations}`,
        `${allSimulations}.combinationHoldingId = ${holdingsAlias}.id
          AND ${allSimulations}.combinationHoldingType = '${holdingType}'
          AND ${allSimulations}.created_at = (
            SELECT MAX(uas.created_at) 
            FROM user_pension_recommendation_combination_holding_simulations uas
            WHERE uas.combination_holding_id = ${holdingsAlias}.id
          )`,
      )
      .leftJoinAndMapOne(
        `${holdingsAlias}.latestSimulation`,
        UserPensionRecommendationCombinationHoldingSimulations,
        `${latestSimulation}`,
        `${latestSimulation}.combinationHoldingId = ${holdingsAlias}.id
          AND ${allSimulations}.combinationHoldingType = '${holdingType}'
          AND ${latestSimulation}.created_at = (
            SELECT MAX(uls.created_at) 
            FROM user_pension_recommendation_combination_holding_simulations uls
            WHERE uls.combination_holding_id = ${holdingsAlias}.id
          )`,
      );
  }

  // =====================================================
  // CONVENIENCE METHODS (combinations of joins)
  // =====================================================

  public static addFullJoins<T>(queryBuilder: SelectQueryBuilder<T>) {
    queryBuilder = this.addTransactionsJoin(queryBuilder);

    queryBuilder = this.addTransactionHoldingsJoin(queryBuilder);
    queryBuilder = this.addTransactionHoldingsRelationsJoin(queryBuilder);

    queryBuilder = this.addCombinationsJoin(queryBuilder);

    queryBuilder = this.addCurrentHoldingsJoin(queryBuilder);
    queryBuilder = this.addCurrentHoldingsRelationsJoin(queryBuilder);

    queryBuilder = this.addTargetHoldingsJoin(queryBuilder);
    queryBuilder = this.addTargetHoldingsRelationsJoin(queryBuilder);

    queryBuilder = this.addSimulationsJoin(queryBuilder, PensionRecommendationTypes.Holding.TypesEnum.CURRENT);
    queryBuilder = this.addSimulationsJoin(queryBuilder, PensionRecommendationTypes.Holding.TypesEnum.TARGET);

    return queryBuilder;
  }
}
