import { RawDeposit } from '../types/deposit.types';
import { MonthlyDepositDto } from '../dto/policy-deposits.dto';

export type GroupByOptions = 'none' | 'day' | 'week' | 'month' | 'year';

export interface GroupingConfig {
  timeField: keyof RawDeposit;
  mergeFields: (keyof RawDeposit)[];
  accumulateFields: string[];
}

export interface AggregationOptions {
  groupBy?: GroupByOptions;
  groupByFields?: (keyof MonthlyDepositDto)[];
  groupingConfig?: Partial<GroupingConfig>;
}

export interface IDepositAggregator {
  aggregate(deposits: RawDeposit[], options?: AggregationOptions): MonthlyDepositDto[];
}
