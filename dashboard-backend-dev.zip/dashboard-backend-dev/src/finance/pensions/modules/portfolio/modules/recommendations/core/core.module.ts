import { Module } from '@nestjs/common';
import { CoreCombinationBuilder } from './builders/combination.builder';
import { CoreEntitiesBuilder } from './builders/entities.builder';
import { CoreRecommendationBuilder } from './builders/recommendation.builder';

@Module({
  providers: [CoreRecommendationBuilder, CoreCombinationBuilder, CoreEntitiesBuilder],
  exports: [CoreRecommendationBuilder, CoreCombinationBuilder],
})
export class RecommendationsCoreModule {}
