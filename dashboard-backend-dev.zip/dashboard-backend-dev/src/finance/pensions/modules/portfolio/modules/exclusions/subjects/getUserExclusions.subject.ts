import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { PensionPortfolioExclusion } from 'src/finance/pensions/modules/portfolio/modules/exclusions/types/exclusions.enum';
import { DateToEpochTransform } from 'src/shared/decorators/subjects';

export class GetUserExclusionsSubject {
  @Expose()
  @ApiProperty()
  exception: PensionPortfolioExclusion;

  @Expose()
  @ApiProperty()
  @DateToEpochTransform()
  createdAt: number;
}
