import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { DepositFilters } from './deposit-repository.interface';
import { RawDeposit } from '../types/deposit.types';
import { PolicyMonthlyDepositsResponseDto } from '../dto/policy-deposits.dto';

export interface IDepositStrategy {
  canHandle(category: PensionCategoriesEnum): boolean;
  getFilters(): DepositFilters;
  formatResponse(
    deposits: RawDeposit[],
    policyId: number,
    productCategory: PensionCategoriesEnum,
  ): PolicyMonthlyDepositsResponseDto;
}
