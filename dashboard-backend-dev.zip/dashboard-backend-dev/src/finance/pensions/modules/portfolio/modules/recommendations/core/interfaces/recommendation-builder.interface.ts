import { UserPensionMislakaPolicies, UserPensionRecommendationTransactions } from 'src/entities';
import { UserPensionRecommendationCombinations } from 'src/entities/UserPensionRecommendationsCombinations';
import { PensionRecommendationTypes } from 'src/finance/pensions/modules/portfolio/modules/recommendations/types/recommendations.namespace';
import { DeepPartial } from 'typeorm';
import {
  BaseRecommendationEntityParams,
  BaseTransactionHoldingEntityParams,
} from './recommendation-entities.interface';

export interface IBuildNoChangeRecommendationParams extends Omit<BaseRecommendationEntityParams, 'category'> {
  policy: UserPensionMislakaPolicies;
}

export interface IBuildRecommendationParams extends BaseRecommendationEntityParams {
  transactions: IBuildTransactionParams[];
}

export interface IBuildTransactionParams {
  holdings: IBuildTransactionHoldingParams[];
  type: PensionRecommendationTypes.Transaction.TypesEnum;
  payload?: PensionRecommendationTypes.Transaction.Payload;

  defaultCombination: (
    transaction: DeepPartial<UserPensionRecommendationTransactions>,
  ) => Promise<DeepPartial<UserPensionRecommendationCombinations>>;
}

export interface IBuildTransactionHoldingParams {
  policy: BaseTransactionHoldingEntityParams['policy'];
  essentialAction: BaseTransactionHoldingEntityParams['essentialAction'];
  payload?: BaseTransactionHoldingEntityParams['payload'];
}

export type CombinationProvisionBreakdown = Pick<
  DeepPartial<UserPensionRecommendationCombinations>,
  | 'compensationProvisionAmount'
  | 'compensationProvisionPercentage'
  | 'employerProvisionAmount'
  | 'employerProvisionPercentage'
  | 'employeeProvisionAmount'
  | 'employeeProvisionPercentage'
>;
