import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserPensionMislakaQueryExclusions } from 'src/entities';
import { EnvironmentManager } from 'src/env/envManager.service';
import { PensionQueriesModule } from 'src/finance/pensions/modules/pensionQueries/pensionQueries.module';
import { PensionPortfolioPolicyDepositsModule } from 'src/finance/pensions/modules/portfolio/modules/deposits/deposits.module';
import { PensionPortfolioExclusionsController } from 'src/finance/pensions/modules/portfolio/modules/exclusions/exclusions.controller';
import { PensionPortfolioExclusionsManager } from 'src/finance/pensions/modules/portfolio/modules/exclusions/exclusions.manager';
import { PensionPortfolioExclusionsService } from 'src/finance/pensions/modules/portfolio/modules/exclusions/exclusions.service';
import { PensionPortfolioPoliciesModule } from 'src/finance/pensions/modules/portfolio/modules/policies/policies.module';
import { UserProfileModule } from 'src/users/userProfile/user-profile.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([UserPensionMislakaQueryExclusions]),
    forwardRef(() => PensionQueriesModule),
    PensionPortfolioPoliciesModule,
    PensionPortfolioPolicyDepositsModule,
    UserProfileModule,
  ],
  controllers: [PensionPortfolioExclusionsController],
  providers: [PensionPortfolioExclusionsManager, PensionPortfolioExclusionsService, EnvironmentManager],
  exports: [PensionPortfolioExclusionsManager, PensionPortfolioExclusionsService],
})
export class PensionPortfolioExclusionsModule {}
