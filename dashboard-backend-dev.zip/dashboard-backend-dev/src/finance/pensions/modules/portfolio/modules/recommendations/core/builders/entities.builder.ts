import { Injectable } from '@nestjs/common';
import dayjs from 'dayjs';
import { UserPensionRecommendations } from 'src/entities/UserPensionRecommendations';
import { UserPensionRecommendationCombinations } from 'src/entities/UserPensionRecommendationsCombinations';
import {
  UserPensionRecommendationCombinationCurrentHoldings,
  UserPensionRecommendationCombinationTargetHoldings,
} from 'src/entities/UserPensionRecommendationsCombinationsHoldings';
import { UserPensionRecommendationTransactions } from 'src/entities/UserPensionRecommendationsTransactions';
import { UserPensionRecommendationHoldings } from 'src/entities/UserPensionRecommendationsTransactionsHoldings';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { DeepPartial } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import {
  BaseCombinationCurrentHoldingEntityParams,
  BaseCombinationEntityParams,
  BaseCombinationTargetHoldingEntityParams,
  BaseRecommendationEntityParams,
  BaseTransactionEntityParams,
  BaseTransactionHoldingEntityParams,
} from '../interfaces/recommendation-entities.interface';

@Injectable()
export class CoreEntitiesBuilder {
  private readonly EXPIRATION_DAYS = 7;

  /**
   * Creates a base recommendation object with the necessary details.
   *
   * @param {BaseRecommendationEntityParams} params - The parameters for building the recommendation.
   * @returns {DeepPartial<UserPensionRecommendations>} The base recommendation object.
   */
  createBaseRecommendation(params: BaseRecommendationEntityParams): DeepPartial<UserPensionRecommendations> {
    return {
      id: uuidv4(),
      userId: params.userId,
      requestId: params.requestId,
      category: params.category,
      createdAt: params.createdAt,
      expiredAt: dayjs(params.createdAt as Date)
        .add(this.EXPIRATION_DAYS, 'days')
        .toDate(),
      isSelected: null,
      transactions: [],
    };
  }

  /**
   * Creates a base transaction object with the necessary details.
   *
   * @param {BaseTransactionEntityParams} params - The parameters for building the transaction.
   * @returns {DeepPartial<UserPensionRecommendationTransactions>} The base transaction object.
   */
  createBaseTransaction(params: BaseTransactionEntityParams): DeepPartial<UserPensionRecommendationTransactions> {
    return {
      id: uuidv4(),
      recommendationId: params.recommendationId,
      userId: params.userId,
      title: params.title,
      description: params.description,
      type: params.type,
      payload: params.payload,
      holdings: [],
      combinations: [],
    };
  }

  /**
   * Creates a transaction holding object with the necessary details, including the policy information.
   * The `policy` field is temporarily added for calculations but will be removed before saving.
   *
   * @param {BaseTransactionHoldingEntityParams} params - The parameters for building the holding.
   * @returns {DeepPartial<UserPensionRecommendationHoldings>} The created transaction holding object.
   */
  createTransactionHolding(params: BaseTransactionHoldingEntityParams): DeepPartial<UserPensionRecommendationHoldings> {
    const {
      id: policyId,
      salary: policyReportedSalary,
      productCategoryId,
      currentSavings,
      compensationProvision,
      employerProvision,
      employeeProvision,
      accManagementFees,
      depositManagementFees,
    } = params.policy;

    const monthlyDeposit =
      ((compensationProvision * (policyReportedSalary || 0) || 0) +
        (employerProvision * (policyReportedSalary || 0) || 0) +
        (employeeProvision * (policyReportedSalary || 0) || 0)) /
      100;

    return {
      id: uuidv4(),
      userId: params.userId,
      transactionId: params.transactionId,
      productCategoryId: productCategoryId as PensionCategoriesEnum,
      policyId: policyId,
      accumulationAmount: currentSavings ?? 0,
      monthlyDepositAmount: monthlyDeposit ?? 0,
      accumulationManagementFee: accManagementFees ?? 0,
      depositManagementFee: depositManagementFees ?? 0,
      reportedSalary: policyReportedSalary ?? 0,
      compensationProvisionPercentage: compensationProvision ?? 0,
      employerProvisionPercentage: employerProvision ?? 0,
      employeeProvisionPercentage: employeeProvision ?? 0,
      essentialAction: params.essentialAction,
      payload: !params.payload || Object.keys(params.payload)?.length === 0 ? null : params.payload,
      policy: params.policy, // temporarily added and will be removed before saving
    };
  }

  /**
   * Creates a base combination object with the necessary details.
   *
   * @param {BaseCombinationEntityParams} params - The parameters for building the combination.
   * @returns {DeepPartial<UserPensionRecommendationCombinations>} The base combination object.
   */
  createBaseCombination(params: BaseCombinationEntityParams): DeepPartial<UserPensionRecommendationCombinations> {
    return {
      id: uuidv4(),
      transactionId: params.transactionId,
      userId: params.userId,
      createdAt: dayjs().toDate(),
      isSelected: true,
      hash: null,
      currentHoldings: [],
      targetHoldings: [],
    };
  }

  /**
   * Creates a combination current holding object with the necessary details, including the transaction holding information.
   * The `holding` field is temporarily added for calculations but will be removed before saving.
   *
   * @param {BaseCombinationCurrentHoldingEntityParams} params - The parameters for building the holding.
   * @returns {DeepPartial<UserPensionRecommendationCombinationCurrentHoldings>} The created combination selected holding object.
   */
  createCombinationCurrentHolding(
    params: BaseCombinationCurrentHoldingEntityParams,
  ): DeepPartial<UserPensionRecommendationCombinationCurrentHoldings> {
    return {
      id: uuidv4(),
      userId: params.userId,
      combinationId: params.combinationId,
      holdingId: params.holding?.id,
      isSelected: params.isSelected ?? true,
      practicalAction: params.practicalAction ?? null, // will be filled in the enrich process in most cases
      holding: params.holding, // temporarily added and will be removed before saving
      simulations: [],
    };
  }

  /**
   * Creates a combination target holding object with the necessary details.
   *
   * @param {BaseCombinationTargetHoldingEntityParams} params - The parameters for building the holding.
   * @returns {DeepPartial<UserPensionRecommendationCombinationTargetHoldings>} The created combination target holding object.
   */
  createCombinationTargetHolding(
    params: BaseCombinationTargetHoldingEntityParams,
  ): DeepPartial<UserPensionRecommendationCombinationTargetHoldings> {
    return {
      id: uuidv4(),
      userId: params.userId,
      combinationId: params.combinationId,
      productCategoryId: params.productCategoryId as PensionCategoriesEnum,
      fundId: params.fundId,
      accumulationAmount: params.accumulationAmount ?? 0,
      monthlyDepositAmount: params.monthlyDepositAmount ?? 0,
      accumulationManagementFee: params.accumulationManagementFee ?? 0,
      depositManagementFee: params.depositManagementFee ?? 0,
      reportedSalary: params.reportedSalary ?? 0,
      compensationProvisionPercentage: params.compensationProvisionPercentage ?? 0,
      employerProvisionPercentage: params.employerProvisionPercentage ?? 0,
      employeeProvisionPercentage: params.employeeProvisionPercentage ?? 0,
      payload: !params.payload || Object.keys(params.payload)?.length === 0 ? null : params.payload,
      simulations: [],
    };
  }
}
