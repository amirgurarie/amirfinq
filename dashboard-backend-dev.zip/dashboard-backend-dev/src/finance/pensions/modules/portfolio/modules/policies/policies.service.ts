import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { UserPensionMislakaPolicies } from 'src/entities/UserPensionMislakaPolicies';
import { EnvironmentManager } from 'src/env/envManager.service';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { Repository } from 'typeorm';
import { PensionPortfolio } from '../../portfolio.namespace';
import { PensionPortfolioPolicyDepositsService } from '../deposits/deposits.service';
import { PolicyMonthlyDepositsResponseDto } from '../deposits/dto/policy-deposits.dto';
import { PensionPortfolioPoliciesDto } from './dto/policies.dto';
import { PensionPoliciesQueries } from './helper/policiesQueries.helper';

@Injectable()
export class PensionPortfolioPoliciesService extends ServiceHelper<UserPensionMislakaPolicies> {
  constructor(
    @InjectRepository(UserPensionMislakaPolicies)
    private readonly policiesRepository: Repository<UserPensionMislakaPolicies>,
    private readonly depositsService: PensionPortfolioPolicyDepositsService,
    private readonly env: EnvironmentManager,
  ) {
    super(policiesRepository);
  }

  public async getPolicies(userId: string, filter?: PensionPortfolioPoliciesDto, recommendation = false) {
    let queryBuilder = this.policiesRepository.createQueryBuilder('policies');

    // Add base conditions and joins
    queryBuilder = PensionPoliciesQueries.addBaseConditions(queryBuilder, userId);
    queryBuilder = PensionPoliciesQueries.addBenefitsJoin(queryBuilder);
    queryBuilder = PensionPoliciesQueries.addDepositsJoin(queryBuilder);
    queryBuilder = PensionPoliciesQueries.addInvestmentPlansJoin(queryBuilder);
    queryBuilder = PensionPoliciesQueries.addInsuranceCoveragesJoin(queryBuilder);

    if (filter?.category) {
      queryBuilder = PensionPoliciesQueries.addCategoryFilter(queryBuilder, filter.category);
    }

    const policies = await queryBuilder.getMany();

    if (!recommendation) {
      return policies;
    }

    return this.loadPolicyRecommendations(userId, policies);
  }

  public async getPolicyById(userId: string, policyId: number) {
    let queryBuilder = this.policiesRepository.createQueryBuilder('policies');

    queryBuilder = PensionPoliciesQueries.addBaseConditions(queryBuilder, userId);
    queryBuilder = PensionPoliciesQueries.addBenefitsJoin(queryBuilder);
    queryBuilder = PensionPoliciesQueries.addDepositsJoin(queryBuilder);
    queryBuilder = PensionPoliciesQueries.addInvestmentPlansJoin(queryBuilder);
    queryBuilder = PensionPoliciesQueries.addInsuranceCoveragesJoin(queryBuilder);
    queryBuilder = PensionPoliciesQueries.addIdsFilter(queryBuilder, [policyId]);

    return queryBuilder.getOne();
  }

  public async getPolicyMonthlyDeposits(policyId: number, userId: string): Promise<PolicyMonthlyDepositsResponseDto> {
    return this.depositsService.getPolicyMonthlyDeposits(policyId, userId);
  }

  private buildRecommendationCountMap(recommendationCounts: Array<{ product_category_id: string; count: string }>) {
    const recommendationCountMap = new Map<string, number>();
    recommendationCounts.forEach((row) => {
      const categoryId = row.product_category_id;
      const count = parseInt(row.count);

      if (categoryId === PensionCategoriesEnum.COMPERHENSIVE || categoryId === PensionCategoriesEnum.SUPPLEMENTARY) {
        const currentCount = recommendationCountMap.get(PensionPortfolio.Categories.PENSION) || 0;
        recommendationCountMap.set(PensionPortfolio.Categories.PENSION, currentCount + count);
      } else {
        recommendationCountMap.set(categoryId, count);
      }
    });

    return recommendationCountMap;
  }

  async getRawPolicyCategoriesWithRecommendations(userId: string) {
    let categoriesBuilder = this.policiesRepository.createQueryBuilder('policies');
    categoriesBuilder = PensionPoliciesQueries.addBaseConditions(categoriesBuilder, userId);
    categoriesBuilder = PensionPoliciesQueries.addPolicyCategoriesQuery(categoriesBuilder);
    const policyCategoriesQuery = await categoriesBuilder.getRawMany();

    const recommendationCountsQuery = await PensionPoliciesQueries.addRecommendationCountsQuery(
      this.policiesRepository.createQueryBuilder(),
      userId,
    ).getRawMany();

    const recommendationCountMap = this.buildRecommendationCountMap(recommendationCountsQuery);

    return policyCategoriesQuery.map((item) => ({
      category: item.category,
      recommendationsCount: recommendationCountMap.get(item.category) || 0,
    }));
  }

  private async fetchPolicyRecommendations(userId: string) {
    let queryBuilder = this.policiesRepository.createQueryBuilder('policies');

    queryBuilder = PensionPoliciesQueries.addBaseConditions(queryBuilder, userId);
    queryBuilder = PensionPoliciesQueries.addRecommendationsJoin(queryBuilder, userId);
    queryBuilder = PensionPoliciesQueries.addPolicyRecommendationsQuery(queryBuilder);

    return queryBuilder.getRawMany();
  }

  private buildPolicyRecommendationsMap(
    rawRecommendations: Array<{ policies_id: number; recommendation_id: string; recommendationsCount: string }>,
  ) {
    // First, filter out the null recommendation_ids
    const filteredRecommendations = rawRecommendations.filter((item) => item.recommendation_id !== null);

    const map = new Map();

    for (const item of filteredRecommendations) {
      const count = parseInt(item.recommendationsCount);
      map.set(item.policies_id, count > 0 ? item.recommendation_id : null);
    }

    return map;
  }

  private enrichPoliciesWithRecommendations(
    policies: UserPensionMislakaPolicies[],
    recommendationsMap: Map<number, string | null>,
  ) {
    return policies.map((policy) => ({
      ...policy,
      recommendationId:
        this.env.get('FORCE_USER_UNHAPPY_FLOW') === 'true' ? null : recommendationsMap.get(policy.id) || null,
    }));
  }

  private async loadPolicyRecommendations(userId: string, policies: UserPensionMislakaPolicies[]) {
    const policyRecommendations = await this.fetchPolicyRecommendations(userId);

    const recommendationsMap = this.buildPolicyRecommendationsMap(policyRecommendations);

    return this.enrichPoliciesWithRecommendations(policies, recommendationsMap);
  }
}
