import { DepositorTypeEnum, DepositTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';

export interface RawDeposit {
  month?: Date;
  totalAmount: string;
  depositCount: string;
  depositType: DepositTypeEnum;
  depositorType: DepositorTypeEnum;
  depositAmount: string;
  paymentMonth: Date;
  depositDate: Date;
}

export interface MonthlyDepositBase {
  month: Date;
  totalAmount: number;
  accumulatedAmount: number;
  depositCount: number;
  depositDate: Date;
}

export interface PolicyDepositBase {
  policyId: number;
  productCategoryId: PensionCategoriesEnum;
}
