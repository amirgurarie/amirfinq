import { CreatePaymentMethodTokenDto } from 'src/payments/PayMe/integration/dto/createPaymentMethodToken.dto';

export class JoinPensionManagedProductDto extends CreatePaymentMethodTokenDto {}
