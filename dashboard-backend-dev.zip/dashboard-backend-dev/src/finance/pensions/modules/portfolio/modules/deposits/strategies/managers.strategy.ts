import { Injectable } from '@nestjs/common';
import { IDepositStrategy } from '../interfaces/deposit-strategy.interface';
import { DepositTypeEnum, DepositorTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { RawDeposit } from '../types/deposit.types';
import {
  PolicyMonthlyDepositsResponseDto,
  DepositSummaryDto,
  SummaryGroupDto,
  MonthlyDepositDto,
} from '../dto/policy-deposits.dto';
import { BaseDepositAggregator } from '../aggregators/baseDeposit.aggregator';
import _ from 'lodash';
import { DepositFilters } from '../interfaces/deposit-repository.interface';
import dayjs from 'dayjs';
import { AggregationOptions } from '../interfaces/deposit-aggregator.interface';

@Injectable()
export class PolicyDepositManagersStrategy implements IDepositStrategy {
  constructor(private readonly aggregator: BaseDepositAggregator) {}

  canHandle(category: PensionCategoriesEnum): boolean {
    return category === PensionCategoriesEnum.MANAGERS;
  }

  getFilters(): DepositFilters {
    return {
      category: PensionCategoriesEnum.MANAGERS,
      depositTypes: [
        DepositTypeEnum.TAGMULIM_MAAVID,
        DepositTypeEnum.TAGMULIM_OVED,
        DepositTypeEnum.TAGMULIM_47,
        DepositTypeEnum.PITZUIM,
        DepositTypeEnum.OVDAN_KOSHER_AVODA,
        DepositTypeEnum.SHONOT_OVED,
        DepositTypeEnum.SHONOT_MAAVID,
      ],
    };
  }

  formatResponse(
    deposits: RawDeposit[],
    policyId: number,
    productCategory: PensionCategoriesEnum,
  ): PolicyMonthlyDepositsResponseDto {
    // Deduplicate deposits to avoid counting the same deposit multiple times
    const uniqueDeposits = _.uniqBy(
      deposits,
      (d) => `${d.depositDate}_${d.depositType}_${d.depositorType}_${d.depositAmount}_${d.paymentMonth}`,
    );

    // Employee deposits for compensation and various (SUG-MAFKID = 1 && SUG-HAFRASHA = 2/4/6)
    const employeeDeposits = uniqueDeposits.filter(
      (d) =>
        d.depositorType === DepositorTypeEnum.EMPLOYEE &&
        (
          [DepositTypeEnum.TAGMULIM_OVED, DepositTypeEnum.TAGMULIM_47, DepositTypeEnum.SHONOT_OVED] as DepositTypeEnum[]
        ).includes(d.depositType),
    );

    // Employer deposits for compensation (SUG-MAFKID = 2/3 && SUG-HAFRASHA = 1)
    const pitzuimDeposits = uniqueDeposits.filter(
      (d) =>
        ([DepositorTypeEnum.CURRENT_EMPLOYER, DepositorTypeEnum.PREVIOUS_EMPLOYER] as DepositorTypeEnum[]).includes(
          d.depositorType,
        ) && d.depositType === DepositTypeEnum.PITZUIM,
    );

    // Employer deposits for compensation and various (SUG-MAFKID = 2/3 && SUG-HAFRASHA = 3/7)
    const employerDeposits = uniqueDeposits.filter(
      (d) =>
        ([DepositorTypeEnum.CURRENT_EMPLOYER, DepositorTypeEnum.PREVIOUS_EMPLOYER] as DepositorTypeEnum[]).includes(
          d.depositorType,
        ) &&
        ([DepositTypeEnum.TAGMULIM_MAAVID, DepositTypeEnum.SHONOT_MAAVID] as DepositTypeEnum[]).includes(d.depositType),
    );

    // Employer deposits for loss of work capacity (SUG-MAFKID = 2/3 && SUG-HAFRASHA = 5)
    const ovdanKosherDeposits = uniqueDeposits.filter(
      (d) =>
        ([DepositorTypeEnum.CURRENT_EMPLOYER, DepositorTypeEnum.PREVIOUS_EMPLOYER] as DepositorTypeEnum[]).includes(
          d.depositorType,
        ) && d.depositType === DepositTypeEnum.OVDAN_KOSHER_AVODA,
    );

    // Consistent configuration for all aggregation calls
    const aggregationConfig = {
      groupBy: 'month' as const,
      groupingConfig: {
        mergeFields: ['depositType'] as string[],
        accumulateFields: ['depositAmount', 'totalAmount', 'accumulatedAmount'] as string[],
        timeField: 'depositDate' as keyof RawDeposit,
      },
    };

    // Aggregate deposits by month with consistent configuration
    const aggregatedEmployeeDeposits = this.aggregator.aggregate(
      employeeDeposits,
      aggregationConfig as AggregationOptions,
    );
    const aggregatedEmployerDeposits = this.aggregator.aggregate(
      employerDeposits,
      aggregationConfig as AggregationOptions,
    );
    const aggregatedPitzuimDeposits = this.aggregator.aggregate(
      pitzuimDeposits,
      aggregationConfig as AggregationOptions,
    );
    const aggregatedOvdanKosherDeposits = this.aggregator.aggregate(
      ovdanKosherDeposits,
      aggregationConfig as AggregationOptions,
    );

    // Ensure all deposits have month at the end of the month
    this.adjustDatesToMonthEnd(aggregatedEmployeeDeposits);
    this.adjustDatesToMonthEnd(aggregatedEmployerDeposits);
    this.adjustDatesToMonthEnd(aggregatedPitzuimDeposits);
    this.adjustDatesToMonthEnd(aggregatedOvdanKosherDeposits);

    // Merge deposits for the combined view
    const merged = this.mergeAllDeposits(
      aggregatedEmployeeDeposits,
      aggregatedEmployerDeposits,
      aggregatedPitzuimDeposits,
      aggregatedOvdanKosherDeposits,
    );

    // Aggregate all deposits for total calculation - use the same consistent configuration
    const totalDeposits = this.aggregator.aggregate(uniqueDeposits, aggregationConfig as AggregationOptions);
    this.adjustDatesToMonthEnd(totalDeposits);

    // Create summary
    const summary: SummaryGroupDto = {
      employee: this.calculateSummary(aggregatedEmployeeDeposits),
      employer: this.calculateSummary(aggregatedEmployerDeposits),
      pitzuim: this.calculateSummary(aggregatedPitzuimDeposits),
      AKA: this.calculateSummary(aggregatedOvdanKosherDeposits),
      total: this.calculateSummary(totalDeposits),
    };

    // Return formatted response
    return {
      policyId,
      productCategoryId: productCategory,
      deposits: merged,
      summary,
    };
  }

  /**
   * Adjust all dates to be at the end of the month
   */
  private adjustDatesToMonthEnd(deposits: MonthlyDepositDto[]): void {
    deposits.forEach((deposit) => {
      if (deposit.month) {
        // Set both month and depositDate to end of month for consistency
        const date = dayjs(deposit.month);
        const endOfMonth = date.endOf('month');
        deposit.month = endOfMonth.toDate();

        // Ensure depositDate is also set to the same end of month
        if (deposit.depositDate) {
          deposit.depositDate = endOfMonth.toDate();
        }
      }
    });
  }

  /**
   * Merge all deposit types into a single monthly summary array
   */
  private mergeAllDeposits(
    employeeDeposits: MonthlyDepositDto[],
    employerDeposits: MonthlyDepositDto[],
    pitzuimDeposits: MonthlyDepositDto[],
    ovdanKosherDeposits: MonthlyDepositDto[],
  ): Array<{
    month: Date;
    employerDepositsAmount: number;
    employeeDepositsAmount: number;
    pitzuimDepositsAmount: number;
    AKADepositsAmount: number; // Fixed typo in field name
    totalAmount: number;
  }> {
    // Get all unique months from all deposit arrays
    const allDeposits = [...employeeDeposits, ...employerDeposits, ...pitzuimDeposits, ...ovdanKosherDeposits];
    const allMonths = _.uniqBy(allDeposits, (d) => dayjs(d.month).format('YYYY-MM')).map((d) => d.month);
    const sortedMonths = _.sortBy(allMonths, (month) => month.getTime());

    return sortedMonths.map((month) => {
      const monthStr = dayjs(month).format('YYYY-MM');

      // Sum all deposits for this month from each category
      const employeeAmount = this.sumDepositsForMonth(employeeDeposits, monthStr);
      const employerAmount = this.sumDepositsForMonth(employerDeposits, monthStr);
      const pitzuimAmount = this.sumDepositsForMonth(pitzuimDeposits, monthStr);
      const akaAmount = this.sumDepositsForMonth(ovdanKosherDeposits, monthStr); // Renamed for clarity

      const totalAmount = parseFloat((employeeAmount + employerAmount + pitzuimAmount + akaAmount).toFixed(2));

      return {
        month,
        employerDepositsAmount: parseFloat(employerAmount.toFixed(2)),
        employeeDepositsAmount: parseFloat(employeeAmount.toFixed(2)),
        pitzuimDepositsAmount: parseFloat(pitzuimAmount.toFixed(2)),
        AKADepositsAmount: parseFloat(akaAmount.toFixed(2)), // Fixed field name
        totalAmount,
      };
    });
  }

  /**
   * Sum deposits for a specific month
   */
  private sumDepositsForMonth(deposits: MonthlyDepositDto[], monthStr: string): number {
    return (
      _(deposits)
        .filter((d) => dayjs(d.month).format('YYYY-MM') === monthStr)
        .sumBy('depositAmount') || 0
    );
  }

  /**
   * Calculate summary for a deposit category
   */
  private calculateSummary(deposits: MonthlyDepositDto[]): DepositSummaryDto {
    return {
      totalAmount: parseFloat(_.sumBy(deposits, 'depositAmount').toFixed(2)),
      depositCount: _.sumBy(deposits, 'depositCount'),
    };
  }
}
