import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { SelectRecommendationsBodyDto } from 'src/finance/pensions/modules/portfolio/modules/recommendations/dtos/selectRecommendations.dto';
import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';
import { RecommendationRepository } from '../recommendations.repository';

@Injectable()
export class SelectRecommendationsGuard implements CanActivate {
  constructor(private readonly recommendationRepository: RecommendationRepository) {}

  public async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const authUserPayload = request.user as AuthenticatedUser;
    const userIdFromQuery = request.query.userId;

    const allowedEmails = [
      'tomer@finqai.com',
      'itamar.klein+dev2@finqai.com',
      'amitg+tomash1@finqai.com',
      'einav@finqai.com',
    ];
    if (userIdFromQuery && !allowedEmails.includes(authUserPayload.user.email)) {
      throw new ForbiddenException('User is not allowed to take this action');
    }

    const { selections } = request.body as SelectRecommendationsBodyDto;
    const userId = userIdFromQuery || authUserPayload.user.id;

    const recommendationIds = await this.recommendationRepository.findIds(userId);
    const invalidIds = Object.keys(selections).filter((id) => !recommendationIds.includes(id));

    if (invalidIds.length > 0) {
      throw new ForbiddenException(`User is not allowed to take this action`);
    }

    return true;
  }
}
