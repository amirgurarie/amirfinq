import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { PensionPortfolio } from '../../../portfolio.namespace';

export class FilterOneRecommendationDto {
  @ApiProperty()
  @IsString()
  @IsUUID()
  public readonly id: string;
}

export class FilterManyRecommendationsDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  @IsEnum(PensionPortfolio.Categories)
  public readonly category?: PensionPortfolio.Categories;
}
