import { applyDecorators } from '@nestjs/common';
import { ApiBody, ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsObject, IsOptional, IsString, IsUUID } from 'class-validator';

export class SelectRecommendationsQueryDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  @IsUUID()
  public readonly userId?: string;
}

export class SelectRecommendationsBodyDto {
  @ApiProperty({
    example: { 'rec-id-1': true, 'rec-id-2': false, 'rec-id-3': null },
  })
  @IsObject()
  public readonly selections: Record<string, boolean>;
}

export function ApiSelectRecommendationsFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'userId',
      required: false,
      type: String,
    }),
    ApiBody({
      type: SelectRecommendationsBodyDto,
    }),
  );
}
