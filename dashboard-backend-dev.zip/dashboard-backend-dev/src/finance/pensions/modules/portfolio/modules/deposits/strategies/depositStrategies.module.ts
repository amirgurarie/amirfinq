import { Module } from '@nestjs/common';
import { BaseDepositAggregator } from '../aggregators/baseDeposit.aggregator';
import { ChildSavingStrategy } from './childSaving.strategy';
import { EducationStrategy } from './education.strategy';
import { PolicyDepositInsuranceStrategy } from './insurance.strategy';
import { PolicyDepositInvestmentsStrategy } from './investment.strategy';
import { PolicyDepositManagersStrategy } from './managers.strategy';
import { PolicyDepositPensionStrategy } from './pension.strategy';
import { PolicyDepositProvidentStrategy } from './provident.strategy';
import { DepositStrategyFactory } from './strategy.factory';

@Module({
  imports: [],
  providers: [
    ChildSavingStrategy,
    EducationStrategy,
    PolicyDepositPensionStrategy,
    PolicyDepositInvestmentsStrategy,
    DepositStrategyFactory,
    BaseDepositAggregator,
    PolicyDepositProvidentStrategy,
    PolicyDepositManagersStrategy,
    PolicyDepositInsuranceStrategy,
    {
      provide: 'DepositStrategies',
      useFactory: (
        childSavingStrategy: ChildSavingStrategy,
        educationStrategy: EducationStrategy,
        policyDepositPensionStrategy: PolicyDepositPensionStrategy,
        policyDepositInvestmentStrategy: PolicyDepositInvestmentsStrategy,
        providentStrategy: PolicyDepositProvidentStrategy,
        managersStrategy: PolicyDepositManagersStrategy,
        insuranceStrategy: PolicyDepositInsuranceStrategy,
      ) => [
        childSavingStrategy,
        educationStrategy,
        policyDepositPensionStrategy,
        policyDepositInvestmentStrategy,
        providentStrategy,
        managersStrategy,
        insuranceStrategy,
      ],
      inject: [
        ChildSavingStrategy,
        EducationStrategy,
        PolicyDepositPensionStrategy,
        PolicyDepositInvestmentsStrategy,
        PolicyDepositProvidentStrategy,
        PolicyDepositManagersStrategy,
        PolicyDepositInsuranceStrategy,
      ],
    },
  ],
  exports: [
    DepositStrategyFactory,
    ChildSavingStrategy,
    EducationStrategy,
    PolicyDepositPensionStrategy,
    PolicyDepositInvestmentsStrategy,
    PolicyDepositProvidentStrategy,
    PolicyDepositManagersStrategy,
    PolicyDepositInsuranceStrategy,
    BaseDepositAggregator,
    'DepositStrategies',
  ],
})
export class PolicyDepositStrategiesModule {}
