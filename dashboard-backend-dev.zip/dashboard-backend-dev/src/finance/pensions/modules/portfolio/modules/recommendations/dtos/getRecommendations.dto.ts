import { applyDecorators } from '@nestjs/common';
import { ApiProperty, ApiQuery } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { PensionPortfolio } from '../../../portfolio.namespace';

export class GetRecommendationsQueryDto {
  @ApiProperty()
  @IsOptional()
  @IsString()
  @IsUUID()
  public readonly userId?: string;

  @ApiProperty()
  @IsOptional()
  @IsString()
  @IsEnum(PensionPortfolio.Categories)
  public readonly category?: PensionPortfolio.Categories;
}

export function ApiGetRecommendationsFilter() {
  return applyDecorators(
    ApiQuery({
      name: 'userId',
      required: false,
      type: String,
    }),
    ApiQuery({
      name: 'category',
      required: false,
      enum: PensionPortfolio.Categories,
      description: `One of: ${Object.values(PensionPortfolio.Categories)}`,
    }),
  );
}
