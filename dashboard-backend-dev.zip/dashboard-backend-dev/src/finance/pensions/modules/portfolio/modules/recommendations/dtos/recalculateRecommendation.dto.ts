import { applyDecorators } from '@nestjs/common';
import { ApiBody, ApiParam, ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsBoolean, IsUUID, ValidateNested } from 'class-validator';

class HoldingDto {
  @ApiProperty()
  @IsUUID()
  holdingId: string;

  @ApiProperty()
  @IsBoolean()
  isSelected: boolean;
}

class TransactionDto {
  @ApiProperty()
  @IsUUID()
  transactionId: string;

  @ApiProperty({ type: [HoldingDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => HoldingDto)
  holdings: HoldingDto[];
}

export class RecalculateRecommendationDto {
  @ApiProperty({
    type: [TransactionDto],
    example: [
      {
        transactionId: 'tran_1',
        holdings: [
          { holdingId: 'hold_1', isSelected: true },
          { holdingId: 'hold_2', isSelected: false },
        ],
      },
    ],
    description: 'Array of transactions with their selected holdings',
  })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => TransactionDto)
  transactions: TransactionDto[];
}

export function ApiRecalcRecommendationFilter() {
  return applyDecorators(
    ApiParam({
      name: 'recommendationId',
      required: true,
      type: String,
    }),
    ApiBody({
      type: RecalculateRecommendationDto,
    }),
  );
}
