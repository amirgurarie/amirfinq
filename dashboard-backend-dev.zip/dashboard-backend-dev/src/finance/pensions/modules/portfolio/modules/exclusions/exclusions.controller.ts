import { Controller, Get, UseInterceptors } from '@nestjs/common';
import { ApiBearerAuth, ApiExtraModels, ApiTags } from '@nestjs/swagger';
import { ApiOperation } from '@nestjs/swagger';
import { AccessPortfolioGuardDecorator } from 'src/finance/pensions/modules/portfolio/decorators/accessPortfolioGuard.decorator';
import { ApiFailedHttpResponse } from 'src/shared/decorators/apiFailedHttpResponse.decorator';
import { ApiDataArrayResponse } from 'src/shared/decorators/dataResponse.decorator';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { CurrentAuthUser } from 'src/auth/currentAuthUser.decorator';
import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';
import { AbstractController } from 'src/shared';
import { ConfigService } from '@nestjs/config';
import { PensionPortfolioExclusionsService } from 'src/finance/pensions/modules/portfolio/modules/exclusions/exclusions.service';
import { GetUserExclusionsSubject } from 'src/finance/pensions/modules/portfolio/modules/exclusions/subjects/getUserExclusions.subject';

@ApiTags('Pension Portfolios')
@Controller('v1/pensions/portfolio')
@ApiBearerAuth()
@ApiExtraModels(GetUserExclusionsSubject)
@AccessPortfolioGuardDecorator()
export class PensionPortfolioExclusionsController extends AbstractController {
  constructor(
    private readonly exclusionsService: PensionPortfolioExclusionsService,
    protected readonly configService: ConfigService,
  ) {
    super(configService);
  }

  @Get('exclusions')
  @ApiOperation({ summary: 'Get user exclusions' })
  @ApiDataArrayResponse(GetUserExclusionsSubject, 'User Exclusions')
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  async getUserExclusions(@CurrentAuthUser() authUserPayload: AuthenticatedUser) {
    const res = await this.exclusionsService.getUserExclusions(authUserPayload.user.id);

    return this.transformToArray(res, GetUserExclusionsSubject);
  }
}
