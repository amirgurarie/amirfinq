import { Injectable } from '@nestjs/common';
import { IDepositStrategy } from '../interfaces/deposit-strategy.interface';
import { DepositorTypeEnum, DepositTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { RawDeposit } from '../types/deposit.types';
import { PolicyMonthlyDepositsResponseDto } from '../dto/policy-deposits.dto';
import _ from 'lodash';
import { DepositFilters } from '../interfaces/deposit-repository.interface';
import { BaseDepositAggregator } from '../aggregators/baseDeposit.aggregator';

@Injectable()
export class PolicyDepositInvestmentsStrategy implements IDepositStrategy {
  constructor(private readonly aggregator: BaseDepositAggregator) {}

  canHandle(category: PensionCategoriesEnum): boolean {
    return category === PensionCategoriesEnum.INVESTMENT;
  }

  getFilters(): DepositFilters {
    return {
      category: PensionCategoriesEnum.INVESTMENT,
      depositorTypes: [DepositorTypeEnum.EMPLOYEE],
      depositTypes: [DepositTypeEnum.TAGMULIM_OVED],
    };
  }

  formatResponse(deposits: RawDeposit[], policyId: number): PolicyMonthlyDepositsResponseDto {
    const aggregatedDeposits = this.aggregator.aggregate(deposits, {
      groupBy: 'none',
    });

    return {
      policyId,
      productCategoryId: PensionCategoriesEnum.INVESTMENT,
      deposits: aggregatedDeposits,
      summary: {
        total: {
          totalAmount: _.sumBy(aggregatedDeposits, 'totalAmount'),
          depositCount: _.sumBy(aggregatedDeposits, 'depositCount'),
        },
      } as any,
    };
  }
}
