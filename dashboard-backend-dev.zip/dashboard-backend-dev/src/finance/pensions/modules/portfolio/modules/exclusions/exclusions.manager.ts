import { Injectable } from '@nestjs/common';
import dayjs from 'dayjs';
import { UserPensionMislakaPolicies, UserPensionMislakaPolicyDeposits } from 'src/entities';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { PensionPortfolioCategoryMapper } from 'src/finance/pensions/modules/portfolio/mappers/pension-category.mapper';
import { PensionPortfolioExclusion } from 'src/finance/pensions/modules/portfolio/modules/exclusions/types/exclusions.enum';
import { PensionPortfolioExclusionsService } from 'src/finance/pensions/modules/portfolio/modules/exclusions/exclusions.service';
import { PensionPortfolioPoliciesService } from 'src/finance/pensions/modules/portfolio/modules/policies/policies.service';
import { PensionPortfolio } from 'src/finance/pensions/modules/portfolio/portfolio.namespace';
import { UserEmployeeStatus } from 'src/shared/enums';
import { DepositorTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { UserProfileService } from 'src/users/userProfile/user-profile.service';
import { EnvironmentManager } from 'src/env/envManager.service';

@Injectable()
export class PensionPortfolioExclusionsManager {
  constructor(
    private readonly pensionPortfolioExclusionsService: PensionPortfolioExclusionsService,
    private readonly portfolioPoliciesService: PensionPortfolioPoliciesService,
    private readonly userProfileService: UserProfileService,
    private readonly env: EnvironmentManager,
  ) {}

  public async identify(userId: string, requestId: string) {
    await this.pensionPortfolioExclusionsService.clearUserExclusions(userId, requestId);

    const [userPolicies, userProfile] = await Promise.all([
      this.portfolioPoliciesService.getPolicies(userId),
      this.userProfileService.getUserProfile(userId),
    ]);

    const exclusions: PensionPortfolioExclusion[] = [];

    if (this.env.get('FORCE_USER_UNHAPPY_FLOW') === 'true') {
      exclusions.push(PensionPortfolioExclusion.FORCE_USER_UNHAPPY_FLOW);
    }

    // --------- User details based exclusions
    if (userProfile.dateOfBirth) {
      const age = dayjs().diff(dayjs(userProfile.dateOfBirth as Date), 'years');

      if (age >= 60) {
        exclusions.push(PensionPortfolioExclusion.OVER_60);
      }
    }

    if (userProfile.employeeStatus !== UserEmployeeStatus.EMPLOYED) {
      exclusions.push(PensionPortfolioExclusion.EMPLOYEE_STATUS_NOT_EMPLOYED);
    }

    if (userProfile.healthChange === true) {
      exclusions.push(PensionPortfolioExclusion.HEALTH_CHANGE);
    }

    if (userProfile.recentEmploymentChange === true) {
      exclusions.push(PensionPortfolioExclusion.RECENT_EMPLOYMENT_CHANGE);
    }

    if (userProfile.children.some((child) => child.disability)) {
      exclusions.push(PensionPortfolioExclusion.CHILDREN_WITH_DISABILITY);
    }

    // --------- Policies based exclusions
    if (userPolicies.length === 0) {
      exclusions.push(PensionPortfolioExclusion.NO_DATA);
    }

    const providentPolicy = userPolicies.find((policy) => policy.productCategoryId === PensionCategoriesEnum.PROVIDENT);
    const managersPolicy = userPolicies.find((policy) => policy.productCategoryId === PensionCategoriesEnum.MANAGERS);

    if (managersPolicy?.productJoinDate) {
      const productJoinDate = dayjs(managersPolicy.productJoinDate);

      if (productJoinDate.isBefore(dayjs('2002-01-01'))) {
        exclusions.push(PensionPortfolioExclusion.MANAGERS_POLICY_JOIN_DATE_BEFORE_2002);
      } else if (managersPolicy.currentWealth && managersPolicy.currentAllowance) {
        exclusions.push(PensionPortfolioExclusion.MANAGERS_POLICY_WITH_WEALTH_AND_ALLOWANCE);
      }
    }

    // --------- Claims based exclusions
    const isPensionWithClaim = userPolicies.some(
      (policy) =>
        policy.claim &&
        [PensionCategoriesEnum.COMPERHENSIVE, PensionCategoriesEnum.SUPPLEMENTARY].includes(
          policy.productCategoryId as any,
        ),
    );

    if (isPensionWithClaim) {
      exclusions.push(PensionPortfolioExclusion.PENSION_WITH_CLAIM);
    }

    const isManagersWithClaim = userPolicies.some(
      (policy) => policy.claim && [PensionCategoriesEnum.MANAGERS].includes(policy.productCategoryId as any),
    );
    if (isManagersWithClaim) {
      exclusions.push(PensionPortfolioExclusion.MANAGERS_POLICY_WITH_CLAIM);
    }

    //פנסיה, ביטוח מנהלים, או גמל
    const hasPensionSavings = userPolicies.some((policy) =>
      [
        PensionPortfolio.Categories.PENSION,
        PensionPortfolio.Categories.INVESTMENT,
        PensionPortfolio.Categories.MANAGERS,
      ].includes(PensionPortfolioCategoryMapper.toPortfolioCategory(policy.productCategoryId) as any),
    );

    if (!hasPensionSavings) {
      exclusions.push(PensionPortfolioExclusion.NO_PENSION_SAVINGS);
    }

    const pensionPolicies = userPolicies.filter(
      (policy) =>
        PensionPortfolioCategoryMapper.toPortfolioCategory(policy.productCategoryId) ===
        PensionPortfolio.Categories.PENSION,
    );

    const multiEmployerMonths = this.checkDepositsForMultipleEmployers(pensionPolicies);
    if (multiEmployerMonths.length >= 3) {
      exclusions.push(PensionPortfolioExclusion.PENSION_WITH_MULTIPLE_EMPLOYERS_IN_LAST_3_MONTHS);
    }

    const sortedMultiEmployerMonths = multiEmployerMonths.sort();
    const lastMonth = sortedMultiEmployerMonths[sortedMultiEmployerMonths.length - 1];
    const prevMonth = sortedMultiEmployerMonths[sortedMultiEmployerMonths.length - 2];

    if (multiEmployerMonths.includes(lastMonth) || multiEmployerMonths.includes(prevMonth)) {
      exclusions.push(PensionPortfolioExclusion.PENSION_WITH_MULTIPLE_EMPLOYERS_IN_LAST_MONTH);
    }

    // const hasSalaryLayers = this.checkPensionPolicySalaryLayers(pensionPolicies);

    // if (hasSalaryLayers) {
    //   exclusions.push(PensionPortfolioExclusion.PENSION_POLICY_WITH_SALARY_LAYERS);
    // }

    // if (providentPolicy && !providentPolicy.compensationProvision) {
    //   exclusions.push(PensionPortfolioExclusion.PROVIDENT_POLICY_WITH_SALARY_LAYERS);
    // }

    // if (managersPolicy && !managersPolicy.compensationProvision) {
    //   exclusions.push(PensionPortfolioExclusion.MANAGERS_POLICY_WITH_SALARY_LAYERS);
    // }

    const createdAt = dayjs().toISOString();

    await this.pensionPortfolioExclusionsService.saveMany(
      exclusions.map((exception) => ({
        userId,
        requestId,
        exception,
        createdAt,
      })),
    );

    return exclusions;
  }

  private checkDepositsForMultipleEmployers(policies: UserPensionMislakaPolicies[]) {
    for (const policy of policies) {
      // Take only deposits from current employer (SUG-HAFKADA = 2)
      const employerDeposits = policy.deposits.filter((d) => d.depositorType === DepositorTypeEnum.CURRENT_EMPLOYER);

      // Group deposits by salary month
      const byMonth = employerDeposits.reduce((acc, d) => {
        const month = dayjs(d.salaryMonth).format('YYYY-MM');
        acc[month] = acc[month] || [];
        acc[month].push(d);

        return acc;
      }, {} as Record<string, UserPensionMislakaPolicyDeposits[]>);

      // Find months with multiple employers
      const multiEmployerMonths = Object.entries(byMonth).reduce((acc, [month, deposits]) => {
        const uniqueEmployers = new Set(deposits.map((d) => d.employerId));
        if (uniqueEmployers.size > 1) {
          acc.push(month);
        }

        return acc;
      }, [] as string[]);

      return multiEmployerMonths;
    }

    return [];
  }

  private checkPensionPolicySalaryLayers(policies: UserPensionMislakaPolicies[]) {
    for (const policy of policies) {
      // Filter deposits from current employer
      const employerDeposits = policy.deposits.filter((d) => d.depositorType === DepositorTypeEnum.CURRENT_EMPLOYER);

      // Group deposits by policyId
      const byPolicy = employerDeposits.reduce((acc, deposit) => {
        if (!acc[deposit.policyId]) acc[deposit.policyId] = [];
        acc[deposit.policyId].push(deposit);

        return acc;
      }, {} as Record<string, UserPensionMislakaPolicyDeposits[]>);

      // For each policy, check for multiple salary layers
      for (const [policyId, deposits] of Object.entries(byPolicy)) {
        // Group deposits by salaryMonth + depositType + employerId
        const map: Record<string, UserPensionMislakaPolicyDeposits[]> = {};

        for (const deposit of deposits) {
          const key = `${deposit.salaryMonth}_${deposit.depositType}_${deposit.employerId}`;
          if (!map[key]) map[key] = [];
          map[key].push(deposit);
        }

        // Check if there is a group with more than one element
        for (const [key, arr] of Object.entries(map)) {
          if (arr.length > 1) {
            return true;
          }
        }
      }
    }

    return false;
  }
}
