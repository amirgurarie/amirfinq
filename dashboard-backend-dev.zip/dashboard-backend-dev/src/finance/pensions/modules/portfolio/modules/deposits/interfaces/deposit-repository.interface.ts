import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { RawDeposit } from '../types/deposit.types';
import { DepositorTypeEnum, DepositTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';

export interface IDepositRepository {
  findPolicyDeposits(policyId: number, userId: string, filters?: DepositFilters): Promise<RawDeposit[]>;
  findPolicyCategory(policyId: number): Promise<PensionCategoriesEnum>;
}

export interface DepositFilters {
  depositorTypes?: DepositorTypeEnum[];
  depositTypes?: DepositTypeEnum[];
  category?: PensionCategoriesEnum;
}
