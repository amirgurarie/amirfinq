import { Module } from '@nestjs/common';
import { BaseDepositAggregator } from './baseDeposit.aggregator';

@Module({
  providers: [BaseDepositAggregator],
  exports: [BaseDepositAggregator],
})
export class PolicyDepositAggregatorModule {}
