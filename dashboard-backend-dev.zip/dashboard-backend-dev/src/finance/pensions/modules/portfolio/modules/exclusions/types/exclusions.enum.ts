export const PensionPortfolioExclusion = {
  /** No data available / אין נתונים זמינים */
  NO_DATA: 'NO_DATA',

  /** Client is over 60 / גיל הלקוח מעל גיל 60 */
  OVER_60: 'OVER_60',

  /** Employee status not 'employed' / המצב התעסוקתי של הלקוח הוא לא ״שכיר״ */
  EMPLOYEE_STATUS_NOT_EMPLOYED: 'EMPLOYEE_STATUS_NOT_EMPLOYED',

  /** Recent health change / הלקוח הצהיר שיש שינוי במצב הבריאותי שלו  */
  HEALTH_CHANGE: 'HEALTH_CHANGE',

  /** Has children with disability / יש ללקוח ילדים עם מצב בריאותי מסוים */
  CHILDREN_WITH_DISABILITY: 'CHILDREN_WITH_DISABILITY',

  /** No pension savings / נראה שאין ללקוח חיסכון פנסיוני (פנסיה, ביטוח מנהלים, או גמל) פעיל. */
  NO_PENSION_SAVINGS: 'NO_PENSION_SAVINGS',

  /** Managers policy join date before 2002 / יש ללקוח/ה פוליסת ביטוח מנהלים לפני ינואר 2002*/
  MANAGERS_POLICY_JOIN_DATE_BEFORE_2002: 'MANAGERS_POLICY_JOIN_DATE_BEFORE_2002',

  /** Managers policy with wealth & allowance / יש ללקוח/ה פוליסת ביטוח מנהלים אחרי ינואר 2002 עם קצבה והון באותה פוליסה. */
  MANAGERS_POLICY_WITH_WEALTH_AND_ALLOWANCE: 'MANAGERS_POLICY_WITH_WEALTH_AND_ALLOWANCE',

  /** Recent employment change / נראה שהלקוח עזב מקום עבודה בחצי שנה האחרונה */
  RECENT_EMPLOYMENT_CHANGE: 'RECENT_EMPLOYMENT_CHANGE',

  /** Pension with multiple employers in last 3 months / נראה שיש ללקוח ריבוי מעסיקים בשלושה חודשים האחרונים*/
  PENSION_WITH_MULTIPLE_EMPLOYERS_IN_LAST_3_MONTHS: 'PENSION_WITH_MULTIPLE_EMPLOYERS_IN_LAST_3_MONTHS',

  /** Pension with multiple employers in last month / נראה שיש ללקוח ריבוי מעסיקים בחודש האחרון */
  PENSION_WITH_MULTIPLE_EMPLOYERS_IN_LAST_MONTH: 'PENSION_WITH_MULTIPLE_EMPLOYERS_IN_LAST_MONTH',

  /** Pension with multiple salary layers / נראה שיש ללקוח רבדי שכר בפנסיה */
  PENSION_POLICY_WITH_SALARY_LAYERS: 'PENSION_POLICY_WITH_SALARY_LAYERS',

  /** Pension with multiple salary layers in managers policy / נראה שיש ללקוח רבדי שכר בביטוח מנהלים */
  MANAGERS_POLICY_WITH_SALARY_LAYERS: 'MANAGERS_POLICY_WITH_SALARY_LAYERS',

  /** Pension with multiple salary layers in pension policy / נראה שיש ללקוח רבדי שכר בקופת גמל */
  PROVIDENT_POLICY_WITH_SALARY_LAYERS: 'PROVIDENT_POLICY_WITH_SALARY_LAYERS',

  /** Pension with claim / נראה שיש חוב בפנסיה */
  PENSION_WITH_CLAIM: 'PENSION_WITH_CLAIM',

  /** Pension with claim / נראה שיש חוב במנהלים */
  MANAGERS_POLICY_WITH_CLAIM: 'MANAGERS_POLICY_WITH_CLAIM',

  /** Force user to un-happy flow / הסביבה הנוכחית מעבירה את הלקוח לפלואו לא תקין  */
  FORCE_USER_UNHAPPY_FLOW: 'FORCE_USER_UNHAPPY_FLOW',
} as const;

export type PensionPortfolioExclusion = (typeof PensionPortfolioExclusion)[keyof typeof PensionPortfolioExclusion];
