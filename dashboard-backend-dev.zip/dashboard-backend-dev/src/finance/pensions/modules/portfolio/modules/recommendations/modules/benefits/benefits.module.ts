import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserPensionRecommendationCombinationHoldingSimulations } from 'src/entities';
import { UserPensionRecommendationBenefits } from 'src/entities/UserPensionRecommendationsBenefits';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { ForecastRepository } from '../simulation/simulation.repository';
import { BenefitsManager } from './benefits.manager';
import { BenefitsService } from './benefits.service';
import { BenefitsHoldingLevelHelper } from './helpers/holding-benefits.helper';
import { BenefitsRecommendationLevelHelper } from './helpers/recommendation-benefits.helper';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      UserPensionRecommendationBenefits,
      UserPensionRecommendationCombinationHoldingSimulations,
    ]),
  ],
  providers: [
    ForecastRepository,
    BenefitsService,
    BenefitsHoldingLevelHelper,
    BenefitsRecommendationLevelHelper,
    BenefitsManager,
    LoggerService,
  ],
  exports: [BenefitsManager],
})
export class RecommendationsBenefitsModule {}
