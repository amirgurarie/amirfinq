import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { Repository } from 'typeorm';
import { UserPensionMislakaQueryExclusions } from 'src/entities';
import { PensionQueriesService } from 'src/finance/pensions/modules/pensionQueries/pensionQueries.service';

@Injectable()
export class PensionPortfolioExclusionsService extends ServiceHelper<UserPensionMislakaQueryExclusions> {
  constructor(
    @InjectRepository(UserPensionMislakaQueryExclusions)
    protected readonly exclusionsRepository: Repository<UserPensionMislakaQueryExclusions>,
    private readonly pensionQueriesService: PensionQueriesService,
  ) {
    super(exclusionsRepository);
  }

  public async getUserExclusions(userId: string) {
    const latestPensionQuery = await this.pensionQueriesService.findUserLastQuery(userId);

    if (!latestPensionQuery) {
      return [];
    }

    return this.findAll({
      where: {
        userId,
        requestId: latestPensionQuery.requestId,
      },
    });
  }

  public clearUserExclusions(userId: string, requestId: string) {
    return this.delete({ userId, requestId });
  }
}
