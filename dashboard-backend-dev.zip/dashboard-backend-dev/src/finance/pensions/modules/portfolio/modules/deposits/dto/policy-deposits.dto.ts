import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Expose, Type } from 'class-transformer';
import { DepositorTypeEnum, DepositTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';

export class DepositSummaryDto {
  @Expose()
  @ApiProperty()
  totalAmount: number;

  @Expose()
  @ApiProperty()
  depositCount: number;
}

export class MonthlyDepositDto {
  @Expose()
  @ApiProperty()
  depositDate?: Date;

  @Expose()
  @ApiProperty()
  month?: Date;

  @Expose()
  @ApiProperty()
  date?: Date;

  @Expose()
  @ApiProperty()
  totalAmount: number;

  @Expose()
  @ApiProperty()
  accumulatedAmount?: number;

  @Expose()
  @ApiProperty()
  depositCount?: number;

  @Expose()
  @ApiProperty({ enum: DepositorTypeEnum })
  depositorType?: DepositorTypeEnum;

  @Expose()
  @ApiProperty({ enum: DepositorTypeEnum })
  depositType?: DepositTypeEnum;

  @Expose()
  @ApiProperty()
  depositAmount?: number;

  // @Expose()
  // @ApiProperty()
  // totalAmount?: number;
}

export class SummaryGroupDto {
  @Expose()
  @ApiProperty({ type: DepositSummaryDto })
  employee: DepositSummaryDto;

  @Expose()
  @ApiProperty({ type: DepositSummaryDto })
  employer: DepositSummaryDto;

  @Expose()
  @ApiPropertyOptional({ type: DepositSummaryDto })
  pitzuim?: DepositSummaryDto;

  @Expose()
  @ApiPropertyOptional({ type: DepositSummaryDto })
  AKA?: DepositSummaryDto;

  @Expose()
  @ApiPropertyOptional({ type: DepositSummaryDto })
  shonotMavid?: DepositSummaryDto;

  @Expose()
  @ApiProperty({ type: DepositSummaryDto })
  total: DepositSummaryDto;
}

export class PolicyMonthlyDepositsResponseDto {
  @Expose()
  @ApiProperty()
  policyId: number;

  @Expose()
  @ApiProperty({ enum: PensionCategoriesEnum })
  productCategoryId: PensionCategoriesEnum;

  @Expose()
  @Type(() => MonthlyDepositDto)
  @ApiProperty({ type: [MonthlyDepositDto] })
  employeeDeposits?: MonthlyDepositDto[];

  @Expose()
  @Type(() => MonthlyDepositDto)
  @ApiProperty({ type: [MonthlyDepositDto] })
  employerDeposits?: MonthlyDepositDto[];

  @Expose()
  @Type(() => MonthlyDepositDto)
  @ApiProperty({ type: [MonthlyDepositDto] })
  pitzuim?: MonthlyDepositDto[];

  @Expose()
  @Type(() => MonthlyDepositDto)
  @ApiProperty({ type: [MonthlyDepositDto] })
  AKADeposits?: MonthlyDepositDto[];

  @Expose()
  @Type(() => MonthlyDepositDto)
  @ApiProperty({ type: [MonthlyDepositDto] })
  deposits?: MonthlyDepositDto[];

  @Expose()
  @Type(() => MonthlyDepositDto)
  @ApiProperty({ type: [MonthlyDepositDto] })
  totalDeposits?: MonthlyDepositDto[];

  @Expose()
  @Type(() => SummaryGroupDto)
  @ApiProperty({ type: SummaryGroupDto })
  summary?: SummaryGroupDto;
}
