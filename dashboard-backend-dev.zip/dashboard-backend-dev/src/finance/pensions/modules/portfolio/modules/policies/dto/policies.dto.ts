import { applyDecorators } from '@nestjs/common';
import { OmitType } from '@nestjs/mapped-types';
import { ApiPensionPortfolioFilter, PensionPortfolioDto } from '../../../dto/portfolio.dto';

export class PensionPortfolioPoliciesDto extends OmitType(PensionPortfolioDto, ['userId']) {}

export function ApiPensionPortfolioPoliciesFilter() {
  return applyDecorators(ApiPensionPortfolioFilter());
}
