import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserPensionMislakaPolicyDeposits } from 'src/entities/UserPensionMislakaPolicyDeposits';
import { IDepositRepository, DepositFilters } from './interfaces/deposit-repository.interface';
import { RawDeposit } from './types/deposit.types';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import dayjs from 'dayjs';

@Injectable()
export class DepositRepository implements IDepositRepository {
  constructor(
    @InjectRepository(UserPensionMislakaPolicyDeposits)
    private readonly repository: Repository<UserPensionMislakaPolicyDeposits>,
  ) {}

  async findPolicyCategory(policyId: number): Promise<PensionCategoriesEnum> {
    const result = await this.repository
      .createQueryBuilder('deposit')
      .select('policy.productCategoryId', 'categoryId')
      .innerJoin('user_pension_mislaka_policies', 'policy', 'policy.id = deposit.policy_id')
      .where('deposit.policy_id = :policyId', { policyId })
      .getRawOne();

    if (!result) {
      throw new Error(`Policy not found: ${policyId}`);
    }

    return result.categoryId;
  }

  async findPolicyDeposits(policyId: number, userId: string, filters?: DepositFilters): Promise<RawDeposit[]> {
    const query = this.repository
      .createQueryBuilder('deposit')
      .select([
        'deposit.deposit_type as "depositType"',
        'deposit.depositor_type as "depositorType"',
        'deposit.amount as "depositAmount"',
        'deposit.payment_month as "paymentMonth"',
        'deposit.deposit_date as "depositDate"',
        'deposit.created_at as "createdAt"',
      ])
      .leftJoin('deposit.policy', 'policy')
      .where('deposit.policy_id = :policyId', { policyId })
      // .andWhere('policy.user_id = :userId', { userId })
      .andWhere((qb) => {
        const subQuery = qb
          .subQuery()
          .select('MAX(subDeposit.created_at)')
          .from(UserPensionMislakaPolicyDeposits, 'subDeposit')
          .where('subDeposit.policy_id = deposit.policy_id')
          .getQuery();

        return 'deposit.created_at = (' + subQuery + ')';
      });

    if (filters?.depositorTypes?.length) {
      query.andWhere('deposit.depositor_type IN (:...depositorTypes)', {
        depositorTypes: filters.depositorTypes,
      });
    }

    if (filters?.depositTypes?.length) {
      query.andWhere('deposit.deposit_type IN (:...depositTypes)', {
        depositTypes: filters.depositTypes,
      });
    }

    // Filter by yearly deposits
    const latestDeposit = await this.repository
      .createQueryBuilder('latestDeposit')
      .select('MAX(latestDeposit.deposit_date)', 'latestMonth')
      .where('latestDeposit.policy_id = :policyId', { policyId })
      .andWhere('latestDeposit.deposit_date IS NOT NULL')
      .getRawOne();

    if (latestDeposit?.latestMonth) {
      const latestMonth = dayjs(latestDeposit.latestMonth);
      const startMonth = latestMonth.subtract(12, 'month').add(1, 'day').toDate();
      const endMonth = latestMonth.toDate();

      query
        .andWhere('deposit.deposit_date >= :startMonth', { startMonth })
        .andWhere('deposit.deposit_date <= :endMonth', { endMonth })
        .andWhere('deposit.deposit_date IS NOT NULL');
    }

    return query.getRawMany();
  }
}
