import {
  UserPensionRecommendationCombinationCurrentHoldings,
  UserPensionRecommendationCombinations,
  UserPensionRecommendationCombinationTargetHoldings,
  UserPensionRecommendationHoldings,
  UserPensionRecommendations,
  UserPensionRecommendationTransactions,
} from 'src/entities';
import { DeepPartial } from 'typeorm';

// Utilities for properties selection
type RequiredKeys<T, K extends keyof T> = Required<Pick<T, K>>;

type PartialKeys<T, K extends keyof T> = Partial<Pick<T, K>>;

type ChangeKeyType<T, K extends keyof T, NewType> = Omit<T, K> & { [P in K]: NewType };

/**
 * Parameters for creating a base recommendation
 */
export type BaseRecommendationEntityParams = RequiredKeys<
  UserPensionRecommendations,
  'userId' | 'requestId' | 'category' | 'createdAt'
>;

/**
 * Parameters for creating a base transaction
 */
export type BaseTransactionEntityParams = RequiredKeys<
  UserPensionRecommendationTransactions,
  'recommendationId' | 'userId' | 'type'
> &
  PartialKeys<UserPensionRecommendationTransactions, 'title' | 'description' | 'payload'>;

/**
 * Parameters for creating a transaction holding
 */
export type BaseTransactionHoldingEntityParams = RequiredKeys<
  UserPensionRecommendationHoldings,
  'transactionId' | 'userId' | 'essentialAction' | 'policy'
> &
  PartialKeys<UserPensionRecommendationHoldings, 'payload'>;

/**
 * Parameters for creating a base combination
 */
export type BaseCombinationEntityParams = RequiredKeys<
  UserPensionRecommendationCombinations,
  'transactionId' | 'userId'
>;

/**
 * Parameters for creating a combination current holding
 */
export type BaseCombinationCurrentHoldingEntityParams = RequiredKeys<
  UserPensionRecommendationCombinationCurrentHoldings,
  'combinationId' | 'userId'
> &
  PartialKeys<UserPensionRecommendationCombinationCurrentHoldings, 'isSelected' | 'practicalAction'> & {
    holding: DeepPartial<UserPensionRecommendationCombinationCurrentHoldings['holding']>;
  };

/**
 * Parameters for creating a combination target holding
 */
export type BaseCombinationTargetHoldingEntityParams = RequiredKeys<
  UserPensionRecommendationCombinationTargetHoldings,
  'combinationId' | 'userId'
> &
  PartialKeys<
    UserPensionRecommendationCombinationTargetHoldings,
    | 'fundId'
    | 'accumulationAmount'
    | 'monthlyDepositAmount'
    | 'accumulationManagementFee'
    | 'depositManagementFee'
    | 'reportedSalary'
    | 'compensationProvisionPercentage'
    | 'employerProvisionPercentage'
    | 'employeeProvisionPercentage'
    | 'payload'
  > & {
    productCategoryId: string;
  };
