import { Injectable } from '@nestjs/common';
import { AggregationOptions, IDepositAggregator } from '../interfaces/deposit-aggregator.interface';
import { RawDeposit } from '../types/deposit.types';
import { MonthlyDepositDto, PolicyMonthlyDepositsResponseDto } from '../dto/policy-deposits.dto';
import _ from 'lodash';
import dayjs from 'dayjs';

@Injectable()
export class BaseDepositAggregator implements IDepositAggregator {
  private readonly DEFAULT_GROUP_BY: AggregationOptions['groupBy'] = 'none';

  /**
   * Returns the appropriate date format based on grouping option
   */
  private getDateFormat(groupBy: AggregationOptions['groupBy']): string {
    const formats: Record<Exclude<AggregationOptions['groupBy'], 'none'>, string> = {
      month: 'YYYY-MM',
      year: 'YYYY',
      week: 'YYYY-[W]WW',
      day: 'YYYY-MM-DD',
    };

    return formats[groupBy];
  }

  /**
   * Processes a group of deposits and returns aggregated data
   */
  private processDepositGroup(deposits: RawDeposit[], dateStr: string): MonthlyDepositDto {
    // Group by depositType and depositorType
    const subGroups = _.groupBy(deposits, (d) => `${d.depositType}_${d.depositorType}`);

    let totalAmount = 0;
    let depositCount = 0;

    // Sum up amounts from all subgroups
    Object.values(subGroups).forEach((groupDeposits) => {
      const groupAmount = _.sumBy(groupDeposits, (d) => parseFloat(d.depositAmount || '0'));
      totalAmount += groupAmount;
      depositCount += groupDeposits.length;
    });

    const latestDeposit = _.maxBy(deposits, 'createdAt');

    return {
      month: dayjs(dateStr).toDate(),
      depositDate: latestDeposit ? dayjs(latestDeposit.depositDate).toDate() : dayjs(dateStr).toDate(),
      totalAmount: parseFloat(totalAmount.toFixed(2)),
      depositAmount: parseFloat(totalAmount.toFixed(2)),
      depositCount,
      depositorType: latestDeposit?.depositorType,
      depositType: latestDeposit?.depositType,
      accumulatedAmount: 0,
    };
  }

  /**
   * Processes a single deposit entry
   */
  private processSingleDeposit(deposit: RawDeposit): MonthlyDepositDto {
    const amount = parseFloat(deposit.depositAmount || '0');

    return {
      month: dayjs(deposit.paymentMonth).toDate(),
      depositDate: dayjs(deposit.depositDate).toDate(),
      totalAmount: amount,
      depositAmount: amount,
      depositCount: 1,
      depositorType: deposit.depositorType,
      depositType: deposit.depositType,
      accumulatedAmount: 0,
    };
  }

  /**
   * Calculates accumulated amounts for the deposit list
   */
  private calculateAccumulatedAmounts(deposits: MonthlyDepositDto[]): MonthlyDepositDto[] {
    let accumulator = 0;

    return _(deposits)
      .sortBy('month')
      .map((deposit) => {
        accumulator += deposit.depositAmount || 0;

        return {
          ...deposit,
          accumulatedAmount: parseFloat(accumulator.toFixed(2)),
        };
      })
      .value();
  }

  /**
   * Groups and processes deposits based on the specified time period
   */
  private groupAndProcessDeposits(
    deposits: RawDeposit[],
    groupBy: Exclude<AggregationOptions['groupBy'], 'none'>,
    options: AggregationOptions = {},
  ): MonthlyDepositDto[] {
    const dateFormat = this.getDateFormat(groupBy);
    const timeField = options.groupingConfig?.timeField || 'paymentMonth';

    // First group by month
    const byMonth = _.groupBy(deposits, (d) => dayjs(d[timeField]).format(dateFormat));

    // For each month, process all deposit types
    const processedDeposits = Object.entries(byMonth).flatMap(([dateStr, monthDeposits]) => {
      if (options.groupingConfig?.mergeFields?.includes('depositType')) {
        // If merging deposit types, process all together
        return [this.processDepositGroup(monthDeposits, dateStr)];
      } else {
        // Otherwise, group by deposit type first
        const byType = _.groupBy(monthDeposits, 'depositType');

        return Object.values(byType).map((typeDeposits) => this.processDepositGroup(typeDeposits, dateStr));
      }
    });

    return processedDeposits;
  }

  /**
   * Merges deposit response into a simplified summary
   */
  mergeSummary(response: PolicyMonthlyDepositsResponseDto): Record<string, number> {
    const employerAmount = _.sumBy(response.employerDeposits, 'depositAmount') || 0;
    const employeeAmount = _.sumBy(response.employeeDeposits, 'depositAmount') || 0;
    const pitzuimAmount = _.sumBy(response.pitzuim, 'depositAmount') || 0;
    const akaAmount = _.sumBy(response.AKADeposits, 'depositAmount') || 0;
    const totalAmount = employerAmount + employeeAmount + pitzuimAmount + akaAmount;

    return {
      employerDepositAmount: parseFloat(employerAmount.toFixed(2)),
      employeeDepositAmount: parseFloat(employeeAmount.toFixed(2)),
      pitzuimDepositAmount: parseFloat(pitzuimAmount.toFixed(2)),
      akaDepositAmount: parseFloat(akaAmount.toFixed(2)),
      totalDepositAmount: parseFloat(totalAmount.toFixed(2)),
    };
  }

  /**
   * Merges employee and employer deposits into monthly summaries
   */
  mergeMonthlyDeposits(
    employeeDeposits: MonthlyDepositDto[],
    employerDeposits: MonthlyDepositDto[],
    pitzuimDeposits?: MonthlyDepositDto[],
    akaDeposits?: MonthlyDepositDto[],
  ): Array<{
    month: Date;
    employerDepositsAmount: number;
    employeeDepositsAmount: number;
    pitzuimDepositsAmount: number;
    AKADepositsAmount?: number;
    totalAmount: number;
  }> {
    // Collect all deposits to get unique months
    let allDeposits = [...employeeDeposits, ...employerDeposits];
    if (pitzuimDeposits?.length) {
      allDeposits = [...allDeposits, ...pitzuimDeposits];
    }
    if (akaDeposits?.length) {
      allDeposits = [...allDeposits, ...akaDeposits];
    }

    const allMonths = _.uniqBy(allDeposits, (d) => dayjs(d.month).format('YYYY-MM')).map((d) => d.month);

    const sortedMonths = _.sortBy(allMonths, (month) => month.getTime());

    return sortedMonths.map((month) => {
      const monthStr = dayjs(month).format('YYYY-MM');

      // Sum all employee deposits for this month
      const employeeAmount =
        _(employeeDeposits)
          .filter((d) => dayjs(d.month).format('YYYY-MM') === monthStr)
          .sumBy('depositAmount') || 0;

      // Sum all employer deposits for this month
      const employerAmount =
        _(employerDeposits)
          .filter((d) => dayjs(d.month).format('YYYY-MM') === monthStr)
          .sumBy('depositAmount') || 0;

      // Sum all pitzuim deposits for this month
      const pitzuimAmount =
        pitzuimDeposits && pitzuimDeposits.length
          ? _(pitzuimDeposits)
              .filter((d) => dayjs(d.month).format('YYYY-MM') === monthStr)
              .sumBy('depositAmount') || 0
          : 0;

      // Sum all AKA deposits for this month
      const akaAmount =
        akaDeposits && akaDeposits.length
          ? _(akaDeposits)
              .filter((d) => dayjs(d.month).format('YYYY-MM') === monthStr)
              .sumBy('depositAmount') || 0
          : 0;

      const totalAmount = parseFloat((employerAmount + employeeAmount + pitzuimAmount + akaAmount).toFixed(2));

      const result: any = {
        month,
        employerDepositsAmount: parseFloat(employerAmount.toFixed(2)),
        employeeDepositsAmount: parseFloat(employeeAmount.toFixed(2)),
        pitzuimDepositsAmount: parseFloat(pitzuimAmount.toFixed(2)),
        totalAmount,
      };

      // Only add AKADepositsAmount if AKA deposits were provided
      if (akaDeposits && akaDeposits.length) {
        result.AKADepositsAmount = parseFloat(akaAmount.toFixed(2));
      }

      return result;
    });
  }

  /**
   * Merges and accumulates multiple arrays of deposits
   */
  private mergeAndAccumulateArrays(arrays: MonthlyDepositDto[][]): MonthlyDepositDto[] {
    const combinedDeposits = arrays.flat();

    // Group by month
    const groupedByMonth = _.groupBy(combinedDeposits, (deposit) => dayjs(deposit.month).format('YYYY-MM'));

    // Process each month group
    const mergedDeposits = Object.entries(groupedByMonth).map(([monthStr, monthDeposits]) => {
      // Sum up all amounts for the month
      const totalDepositAmount = _.sumBy(monthDeposits, 'depositAmount');
      const totalCount = _.sumBy(monthDeposits, 'depositCount');

      // Get the most recent deposit for reference
      const latestDeposit = _.maxBy(monthDeposits, (d) => dayjs(d.depositDate || d.month).unix());

      return {
        month: dayjs(monthStr).toDate(),
        depositDate: latestDeposit?.depositDate || dayjs(monthStr).toDate(),
        totalAmount: parseFloat(totalDepositAmount.toFixed(2)),
        depositAmount: parseFloat(totalDepositAmount.toFixed(2)),
        depositCount: totalCount,
        depositorType: latestDeposit?.depositorType,
        depositType: latestDeposit?.depositType,
        accumulatedAmount: 0, // Will be calculated later
      };
    });

    return _.sortBy(mergedDeposits, 'month');
  }

  /**
   * Aggregates deposits based on provided options
   */
  aggregate(deposits: RawDeposit[] | RawDeposit[][], options: AggregationOptions = {}): MonthlyDepositDto[] {
    if (!deposits.length) return [];

    const groupBy = options.groupBy ?? this.DEFAULT_GROUP_BY;

    // Handle array of arrays
    if (Array.isArray(deposits[0]) && !('depositAmount' in deposits[0])) {
      const processedArrays = (deposits as RawDeposit[][]).map((depositArray) =>
        this.aggregate(depositArray, { ...options }),
      );
      const merged = this.mergeAndAccumulateArrays(processedArrays);

      return this.calculateAccumulatedAmounts(merged);
    }

    const singleArrayDeposits = deposits as RawDeposit[];
    let processedDeposits: MonthlyDepositDto[] = [];

    if (groupBy === 'none') {
      processedDeposits = singleArrayDeposits.map((deposit) => this.processSingleDeposit(deposit));
    } else {
      processedDeposits = this.groupAndProcessDeposits(singleArrayDeposits, groupBy, options);
    }

    return this.calculateAccumulatedAmounts(processedDeposits);
  }

  /**
   * Groups deposits by custom parameters
   */
  groupByParams(deposits: MonthlyDepositDto[], params: string[]): Record<string, number> {
    const result: Record<string, number> = {};

    params.forEach((param) => {
      switch (param) {
        case 'depositType':
          const groupedByType = _.groupBy(deposits, 'depositType');
          Object.entries(groupedByType).forEach(([type, typeDeposits]) => {
            result[`${type}Amount`] = parseFloat(_.sumBy(typeDeposits, 'depositAmount').toFixed(2));
          });
          break;

        case 'depositorType':
          const groupedByDepositor = _.groupBy(deposits, 'depositorType');
          Object.entries(groupedByDepositor).forEach(([type, typeDeposits]) => {
            result[`${type}Amount`] = parseFloat(_.sumBy(typeDeposits, 'depositAmount').toFixed(2));
          });
          break;

        case 'total':
          result.totalAmount = parseFloat(_.sumBy(deposits, 'depositAmount').toFixed(2));
          break;
      }
    });

    return result;
  }
}
