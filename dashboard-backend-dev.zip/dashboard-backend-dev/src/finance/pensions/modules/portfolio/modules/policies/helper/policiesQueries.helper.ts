import { UserPensionMislakaPolicies } from 'src/entities/UserPensionMislakaPolicies';
import { SelectQueryBuilder } from 'typeorm';
import { PensionPortfolio } from '../../../portfolio.namespace';

export class PensionPoliciesQueries {
  /**
   * Adds common base conditions for pension policies queries.
   * This method sets up the basic joins and conditions that are commonly used across pension policy queries.
   * It joins the company and fund relations and ensures we're getting the latest records for a specific user.
   *
   * @param queryBuilder - The TypeORM query builder instance to add conditions to
   * @param userId - The ID of the user whose policies we're querying
   * @returns Modified query builder with base joins and conditions
   *
   * @example
   * let queryBuilder = repository.createQueryBuilder('policies');
   * queryBuilder = PensionPoliciesQueries.addBaseConditions(queryBuilder, userId);
   */
  public static addBaseConditions(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
    userId: string,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder
      .innerJoin(
        'pension_mislaka_queries',
        'queries',
        'queries.user_id = :userId AND queries.status = :status AND queries.last_try = (SELECT MAX(last_try) FROM pension_mislaka_queries WHERE user_id = :userId AND status = :status)',
        { userId, status: 'COMPLETED' },
      )
      .leftJoinAndSelect('policies.company', 'company')
      .leftJoinAndSelect(
        'policies.fund',
        'fund',
        'fund.fund_id = policies.fund_id AND fund.company_id = policies.company_id',
      )
      .where('policies.userId = :userId', { userId })
      .andWhere('policies.requestId = queries.request_id')
      .andWhere(
        'policies.createdAt = (SELECT MAX(p.created_at) FROM user_pension_mislaka_policies p WHERE p.user_id = :userId AND p.request_id = queries.request_id)',
        { userId },
      );
  }

  /**
   * Adds benefit joins to the query.
   * This method joins the benefits relation while ensuring we only get the latest benefit record for each policy.
   * Benefits are important policy attributes that may change over time, so we need to track their history.
   *
   * @param queryBuilder - The TypeORM query builder instance to add the benefits join to
   * @returns Modified query builder with benefits join
   */
  public static addBenefitsJoin(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder.leftJoinAndSelect(
      'policies.benefits',
      'benefits',
      'benefits.created_at = (SELECT MAX(b.created_at) FROM user_pension_mislaka_policy_benefits b WHERE b.policy_id = policies.id)',
    );
  }

  /**
   * Adds deposits joins to the query.
   * This method joins the deposits relation while ensuring we only get the latest deposit record for each policy.
   * Deposits represent the financial contributions made to the policy and their history needs to be tracked.
   *
   * @param queryBuilder - The TypeORM query builder instance to add the deposits join to
   * @returns Modified query builder with deposits join
   */
  public static addDepositsJoin(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder.leftJoinAndSelect(
      'policies.deposits',
      'deposits',
      'deposits.created_at = (SELECT MAX(d.created_at) FROM user_pension_mislaka_policy_deposits d WHERE d.policy_id = policies.id)',
    );
  }

  /**
   * Adds investment plans joins to the query.
   * This method joins the investment plans relation and its related entities (fund and pension company).
   * Investment plans determine how the policy money is invested and may change over time.
   * We ensure we get the latest investment plan record along with its associated fund and company details.
   *
   * @param queryBuilder - The TypeORM query builder instance to add investment plans joins to
   * @returns Modified query builder with investment plans and related joins
   */
  public static addInvestmentPlansJoin(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder
      .leftJoinAndSelect(
        'policies.investmentPlans',
        'investmentPlans',
        'investmentPlans.created_at = (SELECT MAX(ip.created_at) FROM user_pension_mislaka_policy_investments_plan ip WHERE ip.policy_id = policies.id)',
      )
      .leftJoinAndSelect('investmentPlans.fund', 'investmentPlansFund')
      .leftJoinAndSelect('investmentPlansFund.pensionCompany', 'investmentPlansCompany');
  }

  /**
   * Adds insurance coverage joins to the query.
   * This method joins both pension-specific and general insurance coverages relations.
   * Insurance coverages represent the different types of protection included in the policy.
   * We track both pension-specific coverages and general insurance coverages separately,
   * ensuring we get the latest records for both types.
   *
   * @param queryBuilder - The TypeORM query builder instance to add insurance coverage joins to
   * @returns Modified query builder with insurance coverage joins
   */
  public static addInsuranceCoveragesJoin(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder
      .leftJoinAndSelect(
        'policies.pensionInsuranceCoverages',
        'pensionInsuranceCoverages',
        'pensionInsuranceCoverages.created_at = (SELECT MAX(pic.created_at) FROM user_pension_mislaka_policy_pension_insurance_coverages pic WHERE pic.policy_id = policies.id)',
      )
      .leftJoinAndSelect(
        'policies.insuranceCoverages',
        'insuranceCoverages',
        'insuranceCoverages.created_at = (SELECT MAX(ic.created_at) FROM user_pension_mislaka_policy_insurance_coverages ic WHERE ic.policy_id = policies.id)',
      )
      .leftJoinAndSelect(
        'policies.basicInsuranceCoverages',
        'basicInsuranceCoverages',
        'basicInsuranceCoverages.created_at = (SELECT MAX(bic.created_at) FROM user_pension_mislaka_policy_basic_insurance_coverages bic WHERE bic.policy_id = policies.id)',
      );
  }

  /**
   * Adds ids filter to the query.
   * This method filters policies based on their ids.
   *
   * @param queryBuilder - The TypeORM query builder instance to add ids filter to
   * @param ids - The ids to filter by
   * @returns Modified query builder with ids filter
   */
  public static addIdsFilter(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
    ids: number[],
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder.andWhere('policies.id in (:...ids)', { ids });
  }

  /**
   * Adds category filter to the query.
   * This method filters policies based on their category using predefined category groupings.
   * Categories help organize policies into logical groups (e.g., PENSION, COMPERHENSIVE, etc.).
   * The filtering uses category groupings defined in PensionPortfolio.CategoriesGrouping.
   *
   * @param queryBuilder - The TypeORM query builder instance to add category filter to
   * @param category - The category to filter by (must exist in PensionPortfolio.CategoriesGrouping)
   * @returns Modified query builder with category filter
   */
  public static addCategoryFilter(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
    category: string,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder.andWhere('policies.productCategoryId in (:...categories)', {
      categories: PensionPortfolio.CategoriesGrouping[category],
    });
  }

  /**
   * Adds joins for policy recommendations.
   * This method sets up the query to join with recommendation-related tables.
   * It establishes the relationship between policies and their recommendations
   * through transition records that link policies to recommendation transactions.
   *
   * @param queryBuilder - The TypeORM query builder instance to add recommendation joins to
   * @param userId - The ID of the user whose recommendations we're querying
   * @returns Modified query builder with recommendation joins
   */
  public static addRecommendationsJoin(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
    userId: string,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder
      .leftJoin(
        'user_pension_recommendation_transaction_holdings',
        'holdings',
        `(
          (
            CASE
              WHEN policies.productCategoryId IN ('COMPERHENSIVE', 'SUPPLEMENTARY')
              THEN holdings.product_category_id IN ('COMPERHENSIVE', 'SUPPLEMENTARY')
              ELSE policies.productCategoryId = holdings.product_category_id
            END
          ) AND
          holdings.policy_id = policies.id
        )`,
      )
      .leftJoin(
        'user_pension_recommendation_transactions',
        'transactions',
        'transactions.transaction_id = holdings.transaction_id',
      )
      .leftJoin(
        'user_pension_recommendations',
        'recommendations',
        `recommendations.id = transactions.recommendation_id AND
         recommendations.user_id = :userId AND
         recommendations.created_at = (
           SELECT MAX(r.created_at)
           FROM user_pension_recommendations r
           WHERE r.user_id = :userId
         )`,
        { userId },
      );
  }

  /**
   * Adds total amount query conditions.
   * This method sets up the query to calculate the total savings amount across policies.
   * It excludes policies in the 'OTHER' category and ensures we're using the latest
   * policy records for the calculation.
   *
   * @param queryBuilder - The TypeORM query builder instance to add total amount conditions to
   * @param userId - The ID of the user whose policy amounts we're summing
   * @returns Modified query builder with total amount selection and conditions
   */
  public static addTotalAmountQuery(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
    userId: string,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder
      .select('SUM(policies.currentSavings)', 'totalAmount')
      .innerJoin(
        'pension_mislaka_queries',
        'queries',
        'queries.user_id = :userId AND queries.status = :status AND queries.last_try = (SELECT MAX(last_try) FROM pension_mislaka_queries WHERE user_id = :userId AND status = :status)',
        { userId, status: 'COMPLETED' },
      )
      .where('policies.userId = :userId', { userId })
      .andWhere('policies.requestId = queries.request_id')
      .andWhere('policies.productCategoryId NOT IN (:...categories)', {
        categories: ['OTHER'],
      })
      .andWhere(
        'policies.createdAt = (SELECT MAX(p.created_at) FROM user_pension_mislaka_policies p WHERE p.user_id = :userId AND p.request_id = queries.request_id AND p.id = policies.id)',
        { userId },
      );
  }

  /**
   * Adds policy categories selection and grouping.
   * This method sets up the query to retrieve and group policies by their categories.
   * It handles special cases where multiple categories (COMPERHENSIVE, SUPPLEMENTARY)
   * are grouped into a single category (PENSION). The results are ordered to always
   * show PENSION first, followed by other categories alphabetically, and INSURANCE last.
   *
   * @param queryBuilder - The TypeORM query builder instance to add category grouping to
   * @returns Modified query builder with category selection and grouping
   */
  public static addPolicyCategoriesQuery(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    const categoryCase = `CASE 
            WHEN policies.productCategoryId IN ('COMPERHENSIVE', 'SUPPLEMENTARY') THEN 'PENSION'
            ELSE policies.productCategoryId 
        END`;

    return queryBuilder
      .select([`${categoryCase} as category`])
      .andWhere('policies.productCategoryId NOT IN (:...categories)', {
        categories: ['OTHER'],
      })
      .groupBy(categoryCase)
      .orderBy(
        `CASE 
                    WHEN (${categoryCase}) = 'PENSION' THEN 0
                    WHEN (${categoryCase}) = 'INSURANCE' THEN 2
                    ELSE 1 
                END`,
      )
      .addOrderBy('category', 'ASC');
  }

  /**
   * Adds recommendation counts query conditions.
   * This method sets up the query to count recommendations per category.
   * It joins the necessary recommendation-related tables and groups the results
   * by product category. This is used to show how many recommendations exist
   * for each policy category.
   *
   * @param queryBuilder - The TypeORM query builder instance to add recommendation counting to
   * @param userId - The ID of the user whose recommendation counts we're querying
   * @returns Modified query builder with recommendation counting conditions
   */
  public static addRecommendationCountsQuery(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
    userId: string,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    queryBuilder
      .select(['holdings.product_category_id', 'COUNT(DISTINCT transactions.transaction_id) as count'])
      .from('user_pension_recommendations', 'recommendations')
      .innerJoin(
        'user_pension_recommendation_transactions',
        'transactions',
        'transactions.recommendation_id = recommendations.id',
      )
      .innerJoin(
        'user_pension_recommendation_transaction_holdings',
        'holdings',
        'holdings.transaction_id = transactions.transaction_id',
      )
      .where('recommendations.user_id = :userId', { userId })
      .andWhere(
        'recommendations.created_at = (SELECT MAX(r.created_at) FROM user_pension_recommendations r WHERE r.user_id = :userId)',
        { userId },
      )
      .groupBy('holdings.product_category_id');

    return queryBuilder;
  }

  /**
   * Adds policy recommendations selection and conditions.
   * This method sets up the query to select policy IDs along with their recommendation counts.
   * It includes complex logic to handle special cases where recommendations might span
   * multiple categories (COMPERHENSIVE, SUPPLEMENTARY). The results are grouped by both
   * policy and recommendation to maintain data integrity.
   *
   * @param queryBuilder - The TypeORM query builder instance to add policy recommendations selection to
   * @returns Modified query builder with policy recommendations selection
   */
  public static addPolicyRecommendationsQuery(
    queryBuilder: SelectQueryBuilder<UserPensionMislakaPolicies>,
  ): SelectQueryBuilder<UserPensionMislakaPolicies> {
    return queryBuilder
      .select([
        'policies.id as policies_id',
        'recommendations.id as recommendation_id',
        `COUNT(DISTINCT 
                    CASE 
                        WHEN (CASE 
                                WHEN policies.productCategoryId IN ('COMPERHENSIVE', 'SUPPLEMENTARY') 
                                THEN holdings.product_category_id IN ('COMPERHENSIVE', 'SUPPLEMENTARY')
                                ELSE policies.productCategoryId = holdings.product_category_id
                              END)
                        THEN holdings.holding_id 
                    END
                ) as "recommendationsCount"`,
      ])
      .groupBy('policies.id')
      .addGroupBy('recommendations.id');
  }
}
