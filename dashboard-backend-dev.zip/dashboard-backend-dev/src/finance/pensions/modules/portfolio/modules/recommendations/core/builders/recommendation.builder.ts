import { Injectable } from '@nestjs/common';
import { cloneDeep, map } from 'lodash';
import { UserPensionRecommendationTransactions } from 'src/entities';
import { UserPensionRecommendations } from 'src/entities/UserPensionRecommendations';
import { DeepPartial } from 'typeorm';
import { v4 as uuidv4 } from 'uuid';
import { PensionPortfolioCategoryMapper } from '../../../../mappers/pension-category.mapper';
import { PensionRecommendationTypes } from '../../types/recommendations.namespace';
import {
  IBuildNoChangeRecommendationParams,
  IBuildRecommendationParams,
  IBuildTransactionParams,
} from '../interfaces/recommendation-builder.interface';
import { CoreCombinationBuilder } from './combination.builder';
import { CoreEntitiesBuilder } from './entities.builder';

/**
 * The `CoreRecommendationBuilder` service is responsible for constructing and managing pension recommendations for users.
 * It handles the creation and cloning of recommendations, ensuring that all necessary details
 * (such as transactions, holdings, and combinations) are correctly structured and calculated.
 *
 * The service follows a modular approach, with separate methods for creating base entities (recommendations, transactions, combinations)
 * and extending them with additional details. This ensures that the code is maintainable, reusable, and easy to extend.
 *
 * ### Key Processes:
 * 1. **Recommendation Creation**: Builds a recommendation by creating base entities and extending them with transactions, holdings, and combinations.
 * 2. **Transaction Creation**: Constructs transactions by adding holdings and combinations, then cleans the transaction before saving.
 * 3. **Combination Creation**: Constructs combinations by adding current and target holdings, calculating extended details, and cleaning the combination before saving.
 *
 * @class CoreRecommendationBuilder
 * @Injectable
 */
@Injectable()
export class CoreRecommendationBuilder {
  constructor(
    private readonly combinationBuilder: CoreCombinationBuilder,
    private readonly entitiesBuilder: CoreEntitiesBuilder,
  ) {}

  /**
   * Clones a recommendation, generating new IDs for the recommendation, its transactions, holdings, and combinations.
   * This method ensures that all foreign key relationships (e.g., `recommendationId`, `transactionId`, `combinationId`)
   * are correctly updated to reference the new IDs.
   * @param {UserPensionRecommendations} recommendation - The recommendation to clone.
   * @returns {DeepPartial<UserPensionRecommendations>} The cloned recommendation with updated IDs and foreign key relationships.
   */
  cloneRecommendation(recommendation: UserPensionRecommendations): DeepPartial<UserPensionRecommendations> {
    const clonedRecommendation = cloneDeep(recommendation);

    clonedRecommendation.id = uuidv4();

    clonedRecommendation.transactions = map(clonedRecommendation.transactions, (transaction) => {
      transaction.id = uuidv4();
      transaction.recommendationId = clonedRecommendation.id;

      // Create a mapping of original holding IDs to new holding IDs to maintain relation between transaction holdings and combination current holdings
      const newHoldingIdMap = new Map<string, string>();

      // Update holdings
      transaction.holdings = map(transaction.holdings, (holding) => {
        const newHoldingId = uuidv4();
        newHoldingIdMap.set(holding.id, newHoldingId);

        return {
          ...holding,
          id: newHoldingId,
          transactionId: transaction.id,
        };
      });

      // Update combinations and their holdings
      transaction.combinations = map(transaction.combinations, (combination) => {
        combination.id = uuidv4();
        combination.transactionId = transaction.id;

        combination.currentHoldings = map(combination.currentHoldings, (holding) => ({
          ...holding,
          id: uuidv4(),
          combinationId: combination.id,
        }));

        combination.targetHoldings = map(combination.targetHoldings, (holding) => ({
          ...holding,
          id: uuidv4(),
          combinationId: combination.id,
        }));

        combination.hash = this.combinationBuilder.calculateHash(
          combination.transactionId,
          combination.currentHoldings.map((h) => h.holding.id),
        );

        return combination;
      });

      return transaction;
    });

    return clonedRecommendation;
  }

  //#region helpers
  /**
   * Builds a recommendation based on the provided params.
   * This includes creating transactions and cleaning the recommendation before saving.
   * If a transaction cannot be built, an error will be thrown.
   * @param {IBuildRecommendationParams} params - Parameters for building the recommendation.
   * @returns {Promise<DeepPartial<UserPensionRecommendations>>} - The built recommendation object, ready for saving.
   * @throws {Error} - If the recommendation cannot be built or a transaction cannot be added.
   */
  async buildRecommendation(params: IBuildRecommendationParams): Promise<DeepPartial<UserPensionRecommendations>> {
    const recommendation = this.entitiesBuilder.createBaseRecommendation({
      userId: params.userId,
      requestId: params.requestId,
      category: params.category,
      createdAt: params.createdAt,
    });

    recommendation.transactions = await Promise.all(
      params.transactions.map((transactionParams) => this.buildTransaction(recommendation, transactionParams)),
    );

    return this.cleanRecommendationForSaving(recommendation);
  }

  /**
   * Builds a transaction object based on the provided params.
   * This includes creating holdings and default combination.
   * If the combination cannot be built (e.g., due to a duplicate hash or unsupported category), an error will be thrown.
   * @param {DeepPartial<UserPensionRecommendations>} recommendation - The recommendation to which the transaction belongs.
   * @param {IBuildTransactionParams} params - The configuration for building the transaction.
   * @returns {Promise<DeepPartial<UserPensionRecommendationTransactions>>} The built transaction object.
   * @throws {Error} If the transaction cannot be built or a combination cannot be added.
   */
  private async buildTransaction(
    recommendation: DeepPartial<UserPensionRecommendations>,
    params: IBuildTransactionParams,
  ): Promise<DeepPartial<UserPensionRecommendationTransactions>> {
    const transaction = this.entitiesBuilder.createBaseTransaction({
      recommendationId: recommendation.id,
      userId: recommendation.userId,
      type: params.type,
    });

    if (params.holdings) {
      transaction.holdings = params.holdings.map((holdingParams) =>
        this.entitiesBuilder.createTransactionHolding({
          transactionId: transaction.id,
          userId: transaction.userId,
          essentialAction: holdingParams.essentialAction,
          policy: holdingParams.policy,
          payload: holdingParams.payload,
        }),
      );
    }

    if (!params.defaultCombination) {
      return Promise.reject(`Failed to build transaction with no combination`);
    }

    const combination = await params.defaultCombination(transaction);
    this.combinationBuilder.addNewCombination(transaction, combination);

    return transaction;
  }

  /**
   * Cleans the recommendation object by removing temporary relation fields (such as `policy` and `holding`) from all transactions and combinations.
   * This ensures that the recommendation object is clean and ready for persistence.
   * @param {DeepPartial<UserPensionRecommendations>} recommendation - The recommendation to clean.
   * @returns {DeepPartial<UserPensionRecommendations>} The cleaned recommendation object.
   */
  private cleanRecommendationForSaving(
    recommendation: DeepPartial<UserPensionRecommendations>,
  ): DeepPartial<UserPensionRecommendations> {
    recommendation.transactions?.forEach(({ holdings, combinations }) => {
      holdings?.forEach((holding) => delete holding.policy);
      combinations?.forEach(({ currentHoldings }) => {
        currentHoldings?.forEach((currentHolding) => delete currentHolding.holding);
      });
    });

    return recommendation;
  }
  //#endregion
}
