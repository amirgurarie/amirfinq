import { Injectable } from '@nestjs/common';
import { IDepositStrategy } from '../interfaces/deposit-strategy.interface';
import { DepositTypeEnum } from 'src/shared/modules/mislaka/integrations/Aroya/types/aroya.enum';
import { PensionCategoriesEnum } from 'src/finance/pensions/enum/pensionCategories.enum';
import { RawDeposit } from '../types/deposit.types';
import {
  PolicyMonthlyDepositsResponseDto,
  DepositSummaryDto,
  SummaryGroupDto,
  MonthlyDepositDto,
} from '../dto/policy-deposits.dto';
import { BaseDepositAggregator } from '../aggregators/baseDeposit.aggregator';
import _ from 'lodash';
import { DepositFilters } from '../interfaces/deposit-repository.interface';

@Injectable()
export class PolicyDepositProvidentStrategy implements IDepositStrategy {
  constructor(private readonly aggregator: BaseDepositAggregator) {}

  canHandle(category: PensionCategoriesEnum): boolean {
    return category === PensionCategoriesEnum.PROVIDENT;
  }

  getFilters(): DepositFilters {
    return {
      category: PensionCategoriesEnum.PROVIDENT,
      depositTypes: [DepositTypeEnum.TAGMULIM_MAAVID, DepositTypeEnum.TAGMULIM_OVED, DepositTypeEnum.PITZUIM],
    };
  }

  formatResponse(
    deposits: RawDeposit[],
    policyId: number,
    productCategory: PensionCategoriesEnum,
  ): PolicyMonthlyDepositsResponseDto {
    const employeeDeposits = deposits.filter((d) => d.depositType === DepositTypeEnum.TAGMULIM_OVED);
    const employerDeposits = deposits.filter((d) => d.depositType === DepositTypeEnum.TAGMULIM_MAAVID);
    const pizueimDeposits = deposits.filter((d) => d.depositType === DepositTypeEnum.PITZUIM);

    const aggregatedEmployeeDeposits = this.aggregator.aggregate(employeeDeposits, {
      groupBy: 'month',
      groupingConfig: {
        // timeField: 'paymentMonth',
        mergeFields: ['depositType'],
        accumulateFields: ['depositAmount', 'totalAmount', 'accumulatedAmount'],
      },
    });
    const aggregatedEmployerDeposits = this.aggregator.aggregate(employerDeposits, {
      groupBy: 'month',
      groupingConfig: {
        mergeFields: ['depositType', 'depositorType'],
        accumulateFields: ['depositAmount', 'totalAmount', 'accumulatedAmount'],
      },
    });

    const aggregatedPitzuimDeposits = this.aggregator.aggregate(pizueimDeposits, {
      groupBy: 'month',
      groupingConfig: {
        mergeFields: ['depositType'],
        accumulateFields: ['depositAmount', 'totalAmount', 'accumulatedAmount'],
      },
    });

    const merged = this.aggregator.mergeMonthlyDeposits(
      aggregatedEmployeeDeposits,
      aggregatedEmployerDeposits,
      aggregatedPitzuimDeposits,
    );

    const totalDeposits = this.aggregator.aggregate(deposits, {
      groupBy: 'month',
      groupingConfig: {
        mergeFields: ['depositType'],
        accumulateFields: ['depositAmount', 'totalAmount', 'accumulatedAmount'],
      },
    });

    const summary: SummaryGroupDto = {
      employee: this.calculateSummary(aggregatedEmployeeDeposits),
      employer: this.calculateSummary(aggregatedEmployerDeposits),
      pitzuim: this.calculateSummary(aggregatedPitzuimDeposits),
      total: this.calculateSummary(totalDeposits),
    };

    return {
      policyId,
      productCategoryId: productCategory,
      deposits: merged,
      summary,
    };
  }

  private calculateSummary(deposits: MonthlyDepositDto[]): DepositSummaryDto {
    return {
      totalAmount: parseFloat(_.sumBy(deposits, 'totalAmount').toFixed(2)),
      depositCount: _.sumBy(deposits, 'depositCount'),
    };
  }
}
