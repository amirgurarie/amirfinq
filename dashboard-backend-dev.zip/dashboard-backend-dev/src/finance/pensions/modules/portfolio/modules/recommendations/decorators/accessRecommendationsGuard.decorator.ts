import { applyDecorators, UseGuards } from '@nestjs/common';
import { LocalJwtAuthGuard } from 'src/shared/guards/localJwtAuth.guard';
import { AccessRecommendationsGuard } from '../guards/accessRecommendations.guard';

export function AccessRecommendationsGuardDecorator() {
  return applyDecorators(UseGuards(LocalJwtAuthGuard, AccessRecommendationsGuard));
}
