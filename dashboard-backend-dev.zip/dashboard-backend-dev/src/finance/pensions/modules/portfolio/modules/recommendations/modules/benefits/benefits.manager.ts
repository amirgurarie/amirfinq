import { Injectable } from '@nestjs/common';
import {
  UserPensionRecommendationCombinationCurrentHoldings,
  UserPensionRecommendationCombinationTargetHoldings,
} from 'src/entities';
import { UserPensionRecommendations } from 'src/entities/UserPensionRecommendations';
import { UserPensionRecommendationBenefits } from 'src/entities/UserPensionRecommendationsBenefits';
import { Users } from 'src/entities/Users';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { DeepPartial } from 'typeorm';
import { BenefitsService } from './benefits.service';
import { BenefitsHoldingLevelHelper } from './helpers/holding-benefits.helper';
import { BenefitsRecommendationLevelHelper } from './helpers/recommendation-benefits.helper';

@Injectable()
export class BenefitsManager {
  constructor(
    private readonly recommendationBenefitsHelper: BenefitsRecommendationLevelHelper,
    private readonly holdingBenefitsHelper: BenefitsHoldingLevelHelper,
    private readonly benefitsService: BenefitsService,
    private readonly logger: LoggerService,
  ) {}

  async generateBenefits(
    user: Users,
    recommendations: UserPensionRecommendations[],
  ): Promise<UserPensionRecommendationBenefits[]> {
    try {
      const allBenefits = await Promise.all(
        recommendations.map((recommendation) => this.processRecommendation(user, recommendation)),
      );

      const savedBenefits = await this.benefitsService.saveMany(allBenefits.flat());
      this.logger.log(`Completed generate benefits for user ${user.id}`);

      return savedBenefits;
    } catch (error) {
      this.logger.error(`Error generating benefits for user ${user.id}`, error);

      return [];
    }
  }

  private async processRecommendation(
    user: Users,
    recommendation: UserPensionRecommendations,
  ): Promise<DeepPartial<UserPensionRecommendationBenefits>[]> {
    const holdingBenefits = this.createHoldingLevelBenefits(user, recommendation);
    const recommendationBenefits = await this.createRecommendationLevelBenefits(user, recommendation, holdingBenefits);

    this.logger.debug(
      `Generated ${recommendationBenefits.length} recommendation-level benefits and ${holdingBenefits.length} holding-level benefits for recommendation #${recommendation.id}`,
    );

    return [...holdingBenefits, ...recommendationBenefits];
  }

  private createHoldingLevelBenefits(
    user: Users,
    recommendation: UserPensionRecommendations,
  ): DeepPartial<UserPensionRecommendationBenefits>[] {
    const benefits: DeepPartial<UserPensionRecommendationBenefits>[] = [];

    for (const transaction of recommendation.transactions) {
      for (const combination of transaction.combinations) {
        if (!combination.isSelected) continue;

        for (const currentHolding of combination.currentHoldings) {
          const holdingBenefits = this.tryCreateHoldingBenefits(
            user,
            recommendation,
            currentHolding,
            combination.targetHoldings,
          );

          benefits.push(...holdingBenefits);
        }
      }
    }

    return benefits;
  }

  private tryCreateHoldingBenefits(
    user: Users,
    recommendation: UserPensionRecommendations,
    currentHolding: UserPensionRecommendationCombinationCurrentHoldings,
    targetHoldings: UserPensionRecommendationCombinationTargetHoldings[],
  ): DeepPartial<UserPensionRecommendationBenefits>[] {
    const benefits = [
      this.holdingBenefitsHelper.analyzeRiskLevelBenefits(user, recommendation, currentHolding, targetHoldings),
      this.holdingBenefitsHelper.analyzeManagementFeeBenefit(user, recommendation, currentHolding, targetHoldings),
      this.holdingBenefitsHelper.analyzeInvestmentPlan(user, recommendation, currentHolding, targetHoldings),
      this.holdingBenefitsHelper.analyzeTransferBenefits(user, recommendation, currentHolding, targetHoldings),
    ];

    return benefits.flat().filter(Boolean);
  }

  private async createRecommendationLevelBenefits(
    user: Users,
    recommendation: UserPensionRecommendations,
    holdingBenefits: DeepPartial<UserPensionRecommendationBenefits>[],
  ): Promise<DeepPartial<UserPensionRecommendationBenefits>[]> {
    const benefits = await Promise.all([
      this.recommendationBenefitsHelper.analyzeForecastBenefits(user, recommendation),
      this.recommendationBenefitsHelper.analyzeRiskLevelBenefits(user, recommendation),
      this.recommendationBenefitsHelper.analyzeManagementFeeBenefit(user, recommendation),
      this.recommendationBenefitsHelper.analyzeTransferBenefits(user, recommendation, holdingBenefits),
    ]);

    return benefits.flat().filter(Boolean);
  }
}
