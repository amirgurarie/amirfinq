import { Injectable, Inject } from '@nestjs/common';
import { IDepositRepository } from './interfaces/deposit-repository.interface';
import { DepositStrategyFactory } from './strategies/strategy.factory';
import { PolicyMonthlyDepositsResponseDto } from './dto/policy-deposits.dto';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';

@Injectable()
export class PensionPortfolioPolicyDepositsService {
  constructor(
    @Inject('IDepositRepository')
    private readonly repository: IDepositRepository,
    private readonly strategyFactory: DepositStrategyFactory,
    private readonly logger: LoggerService,
  ) {}

  async getPolicyMonthlyDeposits(policyId: number, userId: string): Promise<PolicyMonthlyDepositsResponseDto> {
    try {
      const category = await this.repository.findPolicyCategory(policyId);
      const strategy = this.strategyFactory.getStrategy(category);

      const deposits = await this.repository.findPolicyDeposits(policyId, userId, strategy.getFilters());

      if (!deposits.length) {
        throw new Error(`No deposits found`);
      }

      return strategy.formatResponse(deposits, policyId, category);
    } catch (error) {
      this.logger.error(`Error retrieving deposits for policy: ${policyId}`, error);
      throw new Error(`Unable to retrieve deposits information`);
    }
  }
}
