import { Controller, Get, Req, UseInterceptors } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { ConfigService } from '@nestjs/config';
import { ApiNotFoundHttpResponse } from 'src/shared/decorators/apiNotFoundHttpResponse.decorator';
import { AbstractController } from 'src/shared';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { ApiFailedHttpResponse } from 'src/shared/decorators/apiFailedHttpResponse.decorator';
import { PensionQueriesFormallyUploadsManager } from './PensionQueriesFormallyUploads.manager';

@ApiTags('Pension Queries')
@Controller('v1/pensions/queries/formally-uploads')
export class PensionQueriesFormallyUploadsController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    protected readonly pensionQueriesFormallyUploadsManager: PensionQueriesFormallyUploadsManager,
  ) {
    super(configService);
  }

  @Get('check-status')
  @ApiOperation({ summary: 'Check the status of pention uploads to formally' })
  @ApiResponse({
    status: 200,
    description: 'Successfully retrieved the status of Mislaka queries uploads to formally.',
  })
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @UseInterceptors(TransformInterceptor)
  async pollPensionQueriesUploads(@Req() req: Request): Promise<void> {
    return this.pensionQueriesFormallyUploadsManager.processFailedUploads(req);
  }
}
