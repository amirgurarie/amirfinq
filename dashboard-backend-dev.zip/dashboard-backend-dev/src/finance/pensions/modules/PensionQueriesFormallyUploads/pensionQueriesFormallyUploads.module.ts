import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserPensionMislakaQueriesFormallyUploads } from 'src/entities/UserPensionMislakaQueriesFormallyUploads';
import { PensionQueriesFormallyUploadsService } from './PensionQueriesFormallyUploads.service';
import { FormallyDocumentModule } from 'src/shared/modules/formally/modules/formally-document.module';
import { PensionQueriesFormallyUploadsController } from './PensionQueriesFormallyUploads.controller';
import { PensionQueriesFormallyUploadsManager } from './PensionQueriesFormallyUploads.manager';

@Module({
  imports: [TypeOrmModule.forFeature([UserPensionMislakaQueriesFormallyUploads]), FormallyDocumentModule],
  providers: [PensionQueriesFormallyUploadsService, PensionQueriesFormallyUploadsManager],
  exports: [PensionQueriesFormallyUploadsManager],
  controllers: [PensionQueriesFormallyUploadsController],
})
export class PensionQueriesFormallyUploadsModule {}
