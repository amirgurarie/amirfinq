export const PensionQueryUploadFormallyStatus = {
  UPLOADED: 'UPLOADED',
  FAILED: 'FAILED',
} as const;

export type PensionQueryUploadFormallyStatus =
  (typeof PensionQueryUploadFormallyStatus)[keyof typeof PensionQueryUploadFormallyStatus];
