import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { Repository } from 'typeorm';
import { UserPensionMislakaQueriesFormallyUploads } from 'src/entities/UserPensionMislakaQueriesFormallyUploads';
import { PensionQueryUploadFormallyStatus } from './types/pensionQueriesFormallyStatus.enum';

@Injectable()
export class PensionQueriesFormallyUploadsService extends ServiceHelper<UserPensionMislakaQueriesFormallyUploads> {
  constructor(
    @InjectRepository(UserPensionMislakaQueriesFormallyUploads)
    private readonly uploadQueriesRespository: Repository<UserPensionMislakaQueriesFormallyUploads>,
  ) {
    super(uploadQueriesRespository);
  }

  public async createOrUpdateQuery(
    details: Partial<UserPensionMislakaQueriesFormallyUploads>,
  ): Promise<UserPensionMislakaQueriesFormallyUploads> {
    const { userId, requestId } = details;
    const findOptions = { where: { userId, requestId } };

    if (!userId) {
      return this.uploadQueriesRespository.save(details);
    }

    if (requestId) {
      const existingUserQuery = await this.uploadQueriesRespository.findOne(findOptions);

      if (existingUserQuery) {
        const mergedDetails = this.uploadQueriesRespository.merge(existingUserQuery, details);

        return this.uploadQueriesRespository.save(mergedDetails);
      }
    }

    return this.uploadQueriesRespository.save(details);
  }

  public async findFailedQueries(): Promise<UserPensionMislakaQueriesFormallyUploads[]> {
    return this.uploadQueriesRespository
      .createQueryBuilder('formally_uploads')
      .where('formally_uploads.status = :status', { status: PensionQueryUploadFormallyStatus.FAILED })
      .getMany();
  }
}
