import { Injectable } from '@nestjs/common';
import { Request } from 'express';
import { PensionQueriesFormallyUploadsService } from './PensionQueriesFormallyUploads.service';
import dayjs from 'dayjs';
import { FormallyDocumentService } from 'src/shared/modules/formally/modules/formally-document.service';
import { PensionQueryUploadFormallyStatus } from './types/pensionQueriesFormallyStatus.enum';

@Injectable()
export class PensionQueriesFormallyUploadsManager {
  constructor(
    private readonly pensionQueriesFormallyUploadsService: PensionQueriesFormallyUploadsService,
    private readonly formallyDocumentedService: FormallyDocumentService,
  ) {}

  public async processFailedUploads(req: Request): Promise<void> {
    const queries = await this.pensionQueriesFormallyUploadsService.findFailedQueries();
    await Promise.allSettled(queries?.map((query) => this.handleUploadFormally(req, query.userId, query.requestId)));
  }

  public async handleUploadFormally(req: Request, userId: string, requestId: string): Promise<void> {
    const uploadAttempt = {
      userId,
      requestId,
      lastTry: dayjs().toISOString(),
      status: null as PensionQueryUploadFormallyStatus | null,
      errorMessage: null as string | null,
    };
    try {
      await this.formallyDocumentedService.uploadToFormally(userId);
      uploadAttempt.status = PensionQueryUploadFormallyStatus.UPLOADED;
    } catch (error) {
      uploadAttempt.status = PensionQueryUploadFormallyStatus.FAILED;
      uploadAttempt.errorMessage = error.message;
    } finally {
      await this.pensionQueriesFormallyUploadsService.createOrUpdateQuery(uploadAttempt);
    }
  }
}
