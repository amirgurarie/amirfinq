import { Injectable } from '@nestjs/common';
import { Formally } from '../types/formally.namespace';
import { DeepPartial } from 'typeorm';
import {
  ChangesCode,
  ChangesDesc,
  EmployeeType,
  EmployeeTypeProduct,
  ProcessType,
  ProcessTypeDesc,
  ProductType,
  ProductTypeDesc,
} from '../types/formally.enum';
import {
  UserPensionRecommendationCombinationCurrentHoldings,
  UserPensionRecommendationCombinationTargetHoldings,
} from 'src/entities/UserPensionRecommendationsCombinationsHoldings';
import { FundPension } from 'src//entities/FundPension';
import { UserPensionMislakaPolicies } from 'src/entities/UserPensionMislakaPolicies';
import { UserDetails } from 'src/entities/UserDetails';
import { pensionCompaniesSettings } from '../helpers/formally.pensionCompaniesSettings';
import { UserPensionRecommendationTransactions } from '../../../../../entities';
import { PensionPortfolio } from '../../portfolio/portfolio.namespace';
import { PensionCategoriesEnum } from '../../../enum/pensionCategories.enum';
import { PensionRecommendationTypes } from '../../portfolio/modules/recommendations/types/recommendations.namespace';
import EssentialActionsEnum = PensionRecommendationTypes.Holding.EssentialActionsEnum;
import PracticalActionsEnum = PensionRecommendationTypes.Holding.PracticalActionsEnum;

@Injectable()
export class FormallyProcessDataMapper {
  constructor(
    private readonly currentCategory: PensionPortfolio.Categories,
    private readonly currentTransaction: UserPensionRecommendationTransactions,
    private readonly userDetails: DeepPartial<UserDetails>,
  ) {
    this.currentCategory = currentCategory;
    this.currentTransaction = currentTransaction;
    this.userDetails = userDetails;
  }

  getFormallyData(): Formally.ProcessData[] | null {
    const processList = [];
    const currentHoldings = this.currentTransaction.selectedCombination
      .currentHoldings as UserPensionRecommendationCombinationCurrentHoldings[];
    const targetHoldings = this.currentTransaction.selectedCombination
      .targetHoldings as UserPensionRecommendationCombinationTargetHoldings[];

    if (this.currentCategory !== PensionPortfolio.Categories.PENSION) {
      const targetHolding = targetHoldings[0];
      const currentHolding = currentHoldings[0];

      const financeMainData = this.getMainProductData(targetHolding);

      const editActionAdditional =
        currentHolding?.practicalAction === 'CHANGE' || currentHolding?.practicalAction === 'NO_CHANGE'
          ? this.getChangeDescription(currentHolding?.holding.essentialAction)
          : {};

      financeMainData.FormsDataFields = {
        field: [
          ...this.mapMainAdditionalFields(targetHolding.fund, currentHolding),
          ...this.mapFinanceAdditionalFields(targetHolding.fund),
        ],
      };

      const transferData = this.mapProcessDataTransfer(currentHolding.holding.policy);

      processList.push({
        ...this.getProcessMeta(currentHolding?.practicalAction),
        MainProductData: { ...editActionAdditional, ...financeMainData },
        TransferProductData: transferData,
      });
    } else {
      const supplementaryHoldings = targetHoldings.find(
        (item) => item.productCategoryId === PensionCategoriesEnum.SUPPLEMENTARY,
      );

      const comprehensiveHoldings = targetHoldings.find(
        (item) => item.productCategoryId === PensionCategoriesEnum.COMPERHENSIVE,
      );

      const supplementaryProductData = this.getMainProductData(supplementaryHoldings);
      const comprehensiveProductData = this.getMainProductData(comprehensiveHoldings);

      let hasSupplementaryHolding = false;

      for (const currentHolding of currentHoldings) {
        const { holding, practicalAction } = currentHolding;
        const { policy, productCategoryId } = holding || {};

        const isSupplementary = productCategoryId === PensionCategoriesEnum.SUPPLEMENTARY;
        const productData = isSupplementary ? supplementaryProductData : comprehensiveProductData;
        const fund = isSupplementary ? supplementaryHoldings?.fund : comprehensiveHoldings?.fund;
        const isChangeAction = ['CHANGE', 'NO_CHANGE'].includes(practicalAction);
        const editActionAdditional = isChangeAction ? this.getChangeDescription(holding?.essentialAction) : {};

        const formDataFields = {
          field: [
            ...this.mapMainAdditionalFields(fund, currentHolding),
            ...this.mapPensionAdditionalFields(productCategoryId, fund, isChangeAction),
          ],
        };

        if (isSupplementary) hasSupplementaryHolding = true;

        processList.push({
          ...this.getProcessMeta(practicalAction),
          MainProductData: {
            ...editActionAdditional,
            ...productData,
            FormsDataFields: formDataFields,
          },
          TransferProductData: this.mapProcessDataTransfer(policy, null, true),
        });
      }

      // Append supplementary product if none exist in currentHoldings
      if (!hasSupplementaryHolding && supplementaryProductData) {
        processList.push({
          ...this.getProcessMeta('NEW'),
          MainProductData: supplementaryProductData,
        });
      }
    }

    return processList;
  }

  private getMainProductData(
    targetHolding: UserPensionRecommendationCombinationTargetHoldings,
  ): Formally.ProcessDataFinance | Formally.ProcessDataPension {
    if (!targetHolding) {
      return null;
    }
    const holdingFund = targetHolding.fund;
    if (!holdingFund) return null;

    const isPension =
      targetHolding.productCategoryId === PensionCategoriesEnum.MANAGERS ||
      targetHolding.productCategoryId === PensionCategoriesEnum.COMPERHENSIVE ||
      targetHolding.productCategoryId === PensionCategoriesEnum.SUPPLEMENTARY;

    return isPension ? this.mapProcessDataPension(holdingFund) : this.mapProcessDataFinancial(holdingFund);
  }

  private getChangeDescription(essential: PensionRecommendationTypes.Holding.EssentialActionsEnum): any {
    return {
      ChangesDescCode: ChangesCode[essential],
      ChangesDesc: ChangesDesc[essential],
    };
  }

  private getProcessMeta(action: string): any {
    return {
      ProcessType: ProcessType[action as keyof typeof ProcessType] || ProcessType.NEW,
      ProcessTypeDesc: ProcessTypeDesc[action as keyof typeof ProcessTypeDesc] || ProcessTypeDesc.NEW,
    };
  }

  private mapProcessDataFinancial(
    fundPension: FundPension,
    currentPolicy?: UserPensionMislakaPolicies,
  ): Formally.ProcessDataFinance {
    const employeeStatus =
      fundPension.finqCategory === 'INVESTMENT' ? 2 : EmployeeTypeProduct[this.userDetails.employeeStatus];

    return {
      ProductType: ProductType[fundPension?.finqCategory],
      ProductTypeDesc: ProductTypeDesc[fundPension?.finqCategory],
      ProductGufMenahel: fundPension?.companyName,
      ProductHPGufMenahel: fundPension?.originalCompanyId,
      ProductSplitInvestments: 0,
      ProductFundName: fundPension?.fundShortName,
      ProductFundNumber: fundPension?.fundId,
      InvestPercent: '100%',
      ProductCustType: employeeStatus,
      ProductAmitPaeil: '1',
      Salary: currentPolicy?.salary,
      PizuimMaavid: currentPolicy?.salary,
      TagmulimMaavid: currentPolicy?.employeeDeposits,
      Tagmulim45Oved: currentPolicy?.employerDeposits,
      ThilatBituah: new Date().toLocaleString(),
      DMN_Chisachon: fundPension.avgAnnualManagementFee,
      DMN_Hafkadot: fundPension.avgDepositFee,
    };
  }

  private mapProcessDataPension(
    fundPension: FundPension,
    currentPolicy?: UserPensionMislakaPolicies,
  ): Formally.ProcessDataPension {
    if (!fundPension) {
      return null;
    }
    const investmentName = fundPension?.routeName;
    const investmentNumber = fundPension?.fundId;

    const employeeStatus =
      fundPension.finqCategory === 'INVESTMENT' ? 2 : EmployeeType[this.userDetails.employeeStatus];

    return {
      ProductType: ProductType[fundPension?.finqCategory],
      ProductTypeDesc: ProductTypeDesc[fundPension?.finqCategory],
      ProductGufMenahel: fundPension?.companyName,
      ProductHPGufMenahel: fundPension?.originalCompanyId,
      ProductFundName: fundPension?.fundShortName,
      ProductFundNumber: fundPension?.taxConfirmation,
      ProductSplitInvestments: 0,
      ProductCustType: employeeStatus,
      ProductAmitPaeil: '1',
      MaslulPizuimOzar: investmentName,
      KodMaslulPizuimOzar: investmentNumber,
      KodMaslulTagmulimOzar: investmentNumber,
      TagmulimDesc: investmentName,
      MaslulBituahOzar: '117',
      InsuranceRouteCode: '117',
      KodMaslulBituahOzar: 1,
      Salary: currentPolicy?.salary,
      PizuimMaavid: currentPolicy?.currentSavingsInfo?.allowance?.currentEmployerCompensation,
      TagmulimMaavid: currentPolicy?.employeeDeposits,
      Tagmulim45Oved: currentPolicy?.employerDeposits,
      ThilatBituah: new Date().toLocaleString(),
      DMN_Chisachon: fundPension?.avgAnnualManagementFee,
      DMN_Hafkadot: fundPension.avgDepositFee,
    };
  }

  private mapProcessDataTransfer(
    currentPolicy: UserPensionMislakaPolicies,
    fundPension?: FundPension,
    isPension?: boolean,
  ): Formally.TransferProductData {
    const fund = currentPolicy?.fund || fundPension;

    const employeeStatus =
      fundPension.finqCategory === 'INVESTMENT' ? 2 : EmployeeTypeProduct[this.userDetails.employeeStatus];

    return {
      ProductType: ProductType[fund.finqCategory],
      ProductTypeDesc: ProductTypeDesc[fund.finqCategory],
      ProductGufMenahel: fund?.companyName,
      ProductHPGufMenahel: fund.originalCompanyId,
      ProductProgName: fund.fundShortName,
      ProductFundName: fund.fundName,
      ProductFundNumber: isPension ? fund.taxConfirmation : fund.fundId,
      ProductPolicyNumber: currentPolicy?.policyNumberId || '',
      TransferSalary: currentPolicy?.salary || 0,
      TransferPizuimMaavid: currentPolicy?.currentSavingsInfo?.allowance?.currentEmployerCompensation || 0,
      TransferTagmulimMaavid: currentPolicy?.employeeDeposits || 0,
      TransferTagmulim45Oved: currentPolicy?.employerDeposits || 0,
      NumberAccountTransfer: 0,
      ProductWithAKA: 1,
      ProductWithRisk: 0,
      ProductWithRizoko: 0,
      TransferThilatBituah: new Date().toLocaleString(),
      TransferDMN_Chisachon: fund.avgAnnualManagementFee,
      TransferDMN_Hafkadot: fund.avgDepositFee,
      TransferFundNumber: fund.fundId,
      TransferFundNameDesc: fund.fundName,
      TransferPolicyNumber: fund.product,
      TransferExistAmitPaeil: 1,
      TransferNewCustType: employeeStatus,
      FormsDataFields: {
        field: [
          {
            _name: 'GufMenahel',
            value: fund?.companyName,
          },
          {
            _name: 'TransferExistAmitPaeil',
            value: '1',
          },
        ],
      },
    };
  }

  private mapMainAdditionalFields(
    fundPension: FundPension,
    currentHolding?: UserPensionRecommendationCombinationCurrentHoldings,
  ): Formally.FormsDataFields[] {
    const codingNumber =
      fundPension.originalCompanyId +
      this.padDigits(fundPension.taxConfirmation, 14) +
      this.padDigits(fundPension.fundId, 7);

    const employeeStatus =
      fundPension.finqCategory === 'INVESTMENT' ? 2 : EmployeeType[this.userDetails.employeeStatus];

    return [
      { _name: 'TransferAll', value: '1' },
      { _name: 'InvestmentTracks', value: '0' },
      { _name: 'Earning', value: '0' },
      {
        _name: 'NewFundAgentNumber',
        value: this.getAgentNumber(fundPension?.finqCategory as PensionCategoriesEnum, fundPension?.originalCompanyId),
      },
      { _name: 'NewCustType', value: employeeStatus },
      { _name: 'OneTimeDepositingSum', value: '20000' },
      { _name: 'DepositsType_2', value: '2' },
      { _name: 'ManagementFeeFromSaving', value: fundPension.avgAnnualManagementFee },
      { _name: 'ManagementFeeFromPremium', value: fundPension.avgDepositFee },
      { _name: 'DepositsType_1', value: '1' },
      { _name: 'Check Box2_02', value: '1' },
      { _name: 'Reasoning', value: '1' },
      { _name: 'PowerOfAttorney', value: '1' },
      { _name: 'IdentityCard', value: '1' },
      { _name: 'CurrentDepositingSum', value: '500' },
      { _name: 'UserType', value: '2' },
      { _name: 'PaymentMethodTypeID', value: '0' },
      // { _name: 'PolicyAccountNumber0', value: currentHolding?.holding.policy?.policyNumberId },
      { _name: 'CodingNumber0', value: codingNumber },
      { _name: 'cancelAgentAuthorizationExceptFromDataReq', value: '2' },
      { _name: 'NewFundNumberCheckBox', value: fundPension?.fundId },
      { _name: 'AuthorizationPeriod', value: '10' },
      { _name: 'IsMarketingInformation', value: '0' },
      { _name: 'IsClientSecuredEmailDelivery', value: '1' },
      { _name: 'IsClientMarketingDeclaration', value: '1' },
      { _name: 'IsClientSecuredEmailDel', value: 'true' },
      { _name: 'MailPermit', value: '1' },
    ];
  }

  private mapPensionAdditionalFields(
    productCategoryId: PensionCategoriesEnum,
    fundPension: FundPension,
    isChangeAction: boolean,
  ): Formally.FormsDataFields[] {
    const pensionFields = this.getDynamicPensionFields(
      productCategoryId,
      fundPension.originalCompanyId,
      fundPension.fundId,
      isChangeAction,
    );

    return [
      { _name: 'PensionCompensation', value: '8.33' },
      { _name: 'PensionEmployerReward', value: '6.5' },
      { _name: 'PensionSalary', value: '10000' },
      { _name: 'EndAge_117', value: '67' },
      { _name: 'FemaleEndAge_117', value: '67' },
      { _name: 'MoneyTransferMaslima', value: '1' },
      { _name: 'PensionPath_117', value: 'true' },
      { _name: 'PensionPath', value: '117' },
      ...pensionFields,
    ];
  }

  private getAgentNumber(productCategoryId: PensionCategoriesEnum, companyId: string): string {
    const companyKeys = pensionCompaniesSettings[companyId]?.AgentKey;
    if (!companyKeys) {
      return 'UNKNOWN';
    }

    return companyKeys[productCategoryId] || companyKeys['default'];
  }

  private getDynamicPensionFields(
    productCategoryId: PensionCategoriesEnum,
    companyId: string,
    fundId: string,
    isChangeAction: boolean,
  ): Formally.FormsDataFields[] {
    const defaultKeys = {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'InvestPercent',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    };

    const companySettings = pensionCompaniesSettings[companyId];
    const keySet = isChangeAction
      ? companySettings?.ChangeFundKeys || defaultKeys
      : companySettings?.FundKeys || defaultKeys;

    const pensionPrefix = keySet.PensionFundKey;
    const pensionAmountPrefix = keySet.PensionFundAmount;
    const compensationPrefix = keySet.CompensationFundKey;
    const compensationAmountPrefix = keySet.CompensationFundAmount;
    const keyToAppend = companySettings?.Products?.[productCategoryId]?.[fundId] || fundId;

    const valueToAppend = companySettings?.ShouldAppendKey ? keyToAppend : 'true';

    return [
      { _name: `ComponentChange_${keyToAppend}`, value: valueToAppend },
      { _name: `${pensionPrefix}_${keyToAppend}`, value: valueToAppend },
      { _name: `${compensationPrefix}_${keyToAppend}`, value: valueToAppend },
      { _name: `${pensionPrefix}`, value: keyToAppend },
      { _name: `${compensationPrefix}`, value: keyToAppend },
      { _name: `${pensionAmountPrefix}_${keyToAppend}`, value: '100%' },
      { _name: `${compensationAmountPrefix}_${keyToAppend}`, value: '100%' },
    ];
  }

  private mapFinanceAdditionalFields(fundPension: FundPension): Formally.FormsDataFields[] {
    return [
      { _name: 'MonthDeposit', value: '0' },
      { _name: 'NonDepositFunds', value: '0' },
      { _name: 'RegisterType', value: '1' },
      { _name: 'divurDigitalCode', value: '5' },
      { _name: 'GemelLaunderingTax', value: '1' },
      ...this.getDynamicFundDetails(fundPension.fundId),
    ];
  }

  private getDynamicFundDetails(fundID: string): Formally.FormsDataFields[] {
    return [
      { _name: `To_FundNumber_${fundID}`, value: fundID },
      { _name: `TransferPercent_${fundID}`, value: '100%' },
      { _name: `TransferSum_${fundID}`, value: '100%' },
      { _name: `NewFundNumber_${fundID}`, value: fundID },
      { _name: `InvestPercent_${fundID}`, value: '100%' },
      { _name: `Pitzuim_${fundID}`, value: fundID },
      { _name: `InvestPercent_Pitzuim_${fundID}`, value: '100%' },
    ];
  }

  private padDigits(value: number | string, totalLength: number): string {
    const stringValue = value.toString();

    return stringValue.padStart(totalLength, '0');
  }

  getFormallyDataSimulation(
    holdingFund: FundPension,
    category: PensionCategoriesEnum,
    action: PracticalActionsEnum,
    changeAction: EssentialActionsEnum,
    transferFund?: FundPension,
  ): any {
    const isPension =
      category === PensionCategoriesEnum.MANAGERS ||
      category === PensionCategoriesEnum.COMPERHENSIVE ||
      category === PensionCategoriesEnum.SUPPLEMENTARY;
    const mainData = isPension ? this.mapProcessDataPension(holdingFund) : this.mapProcessDataFinancial(holdingFund);

    let formDataFields: { field: Formally.FormsDataFields[] };
    if (!isPension) {
      formDataFields = {
        field: [...this.mapMainAdditionalFields(holdingFund), ...this.mapFinanceAdditionalFields(holdingFund)],
      };
    } else {
      formDataFields = {
        field: [
          ...this.mapMainAdditionalFields(holdingFund),
          ...this.mapPensionAdditionalFields(category, holdingFund, action === 'CHANGE'),
        ],
      };
    }

    const editActionAdditional = action === PracticalActionsEnum.CHANGE ? this.getChangeDescription(changeAction) : {};

    const transferData =
      action !== PracticalActionsEnum.NEW ? this.mapProcessDataTransfer(null, transferFund, isPension) : {};

    return {
      ...this.getProcessMeta(action),
      MainProductData: {
        ...editActionAdditional,
        ...mainData,
        FormsDataFields: formDataFields,
      },
      TransferProductData: transferData,
    };
  }
}
