import { Injectable } from '@nestjs/common';
import { Formally } from '../types/formally.namespace';
import { DeepPartial } from 'typeorm';
import {
  EmployeeType,
  EmployeeTypeProduct,
  GenderEnum,
  MaritalDescription,
  MaritalID,
  SmokingStatus,
  TypeIdent,
} from '../types/formally.enum';
import * as uuid from 'uuid';
import { UserDetails } from 'src/entities/UserDetails';
import { UserSpouseDetails } from 'src/entities/UserSpouseDetails';
import { UserChildrenDetails } from 'src/entities/UserChildrenDetails';
import { UserBeneficiariesDetails } from 'src/entities/UserBeneficiariesDetails';
import { UserEmployerDetails } from 'src/entities/UserEmployerDetails';
import dayjs from 'dayjs';
import { AddressService } from 'src/address/address.service';

@Injectable()
export class FormallyMapper {
  constructor(private readonly addressService: AddressService) {}

  async mapToFormallyData(userDetails: DeepPartial<UserDetails>): Promise<Formally.FormallyData> {
    return {
      ProcessGuid: uuid.v4(),
      CustomerDetails: await this.mapCustomerDetails(userDetails),
      CompanyDetails: this.mapCompanyDetails(),
      UserDetails: this.mapUserDetails(),
      Spouse: this.mapSpouseDetails(userDetails.spouse as UserSpouseDetails),
      Children: { Child: this.mapChildrenDetails(userDetails.children as UserChildrenDetails[]) },
      Beneficiaries: {
        Beneficiary: this.mapBeneficiariesDetails(userDetails.beneficiaries as UserBeneficiariesDetails[]),
      },
      MaasikDetails: this.mapMaasikDetails(userDetails.employer as UserEmployerDetails),
      Hanmaka: this.mapHanmakaDetails(),
      BankDetails: {},
    };
  }

  private mapUserDetails(): Formally.UserDetails {
    return {
      NewFundAgentNumber: 'FINQ-TBD', //Optional
      OpportunityCode: 'FINQ-TBD', //Optional
      FirstName: 'Kobi',
      LastName: 'Ohana',
      FullName: 'Kobi Ohana',
      UserSignature: 'FINQ-TBD', //Optional
      Email: 'hello@finqai.co.il',
      UserEmail: 'hello@finqai.co.il',
      Phone: 'FINQ-TBD', //Optional
      Mobile: 'FINQ-TBD', //Optional
      idNumber: 'FINQ-TBD', //Optional
      MefakachName: 'FINQ-TBD', //Optional
      MefakachNum: 'FINQ-TBD', //Optional
      ShemSochnut: 'FINQ-TBD', //Optional
    };
  }

  private async mapCustomerDetails(user: DeepPartial<UserDetails>): Promise<Formally.CustomerDetails> {
    const smoker = this.getSmokeStatus(user?.smoking);
    const userCity = await this.addressService.findAddressByCityId(Number(user?.city));
    const userStreet = await this.addressService.findStreetById(Number(user?.street));

    return {
      DontReturnURL: 0,
      CustType: EmployeeTypeProduct[user?.employeeStatus],
      FirstName: user?.firstName,
      LastName: user?.lastName,
      FullName: user?.firstName + ' ' + user?.lastName,
      TypeIdent: TypeIdent.ID,
      Zeut: user?.idNumber,
      IssueDateZeut: this.formatDate(user?.dateOfIssue as Date),
      BirthDate: this.formatDate(user?.dateOfBirth as Date),
      ClientAge: this.getAge(user?.dateOfBirth as Date),
      GenderID: this.getGenderId(user?.gender),
      GenderIDCheckBox: this.getGenderIdCheckBox(user?.gender),
      Email: user?.email,
      Cel: user?.phoneNumber,
      Street: userStreet?.descriptionHe,
      House: user?.houseNumber,
      City: userCity?.descriptionHe,
      PoBox: '0',
      AppartmentNumber: '0',
      Zip: '0',
      FullAddress: userStreet?.descriptionHe + ' ' + user?.houseNumber + ', ' + userCity?.descriptionHe,
      MaritalID: MaritalDescription[user?.familyStatus],
      MaritalIDCheckBox: MaritalID[user?.familyStatus],
      Miktzoa: user?.jobOccupation,
      Isuk: user?.jobOccupation,
      SmokingDetails: {
        SmokingStatus: smoker,
        SmokedLast3Years: smoker,
      },
    };
  }

  private mapCompanyDetails(): Formally.CompanyDetails {
    return {
      CompanyGuid: 'FINQ-TBD',
      CompanyName: 'פינק סוכנות לביטוח פנסיוני (2024) בע"מ',
      CompanyHP: '516321064',
      CompanyEmail: 'hello@finqai.co.il',
      CompanyPhone: 'FINQ-TBD',
      CompanyMobile: 'FINQ-TBD',
      CompanyFax: 'FINQ-TBD',
      CompanyStreet: 'FINQ-TBD',
      CompanyAppartment: 'FINQ-TBD',
      CompanyCity: 'FINQ-TBD',
      CompanyZip: 'FINQ-TBD',
      CompanyFullAddress: 'FINQ-TBD',
    };
  }

  private mapSpouseDetails(spouse: UserSpouseDetails): Formally.SpouseDetails {
    return {
      FirstName2: spouse?.firstName,
      LastName2: spouse?.lastName,
      FullName2: spouse?.firstName + ' ' + spouse?.lastName,
      TypeIdent: TypeIdent.ID,
      Zeut2: spouse?.idNumber,
      BirthDate2: this.formatDate(spouse?.dateOfBirth as Date),
      SpouseAge: this.getAge(spouse?.dateOfBirth),
      GenderID2: this.getGenderId(spouse?.gender),
      GenderID2CheckBox: this.getGenderIdCheckBox(spouse?.gender),
      Cel2: spouse?.phoneNumber,
    };
  }

  private mapChildrenDetails(children: UserChildrenDetails[]): Formally.ChildrenDetails[] {
    return children.map((child) => {
      const age = this.getAge(child?.dateOfBirth);

      return {
        FNameY: child?.firstName,
        LNameY: child?.lastName,
        NameY: child?.firstName + ' ' + child?.lastName,
        ZeutY: child?.idNumber,
        BirthDateY: this.formatDate(child?.dateOfBirth as Date),
        TypeIdent: TypeIdent.ID,
        ChildAge: age,
        Under_10: age < 10,
        GenderIDY: this.getGenderId(child?.gender),
        GenderIDYCheckBox: this.getGenderIdCheckBox(child?.gender),
      };
    });
  }

  private mapBeneficiariesDetails(beneficiaries: UserBeneficiariesDetails[]): Formally.BeneficiariesDetails[] {
    return beneficiaries.map((beneficiary) => ({
      FirstNameMutav: beneficiary?.firstName,
      LastNameMutav: beneficiary?.lastName,
      NameMutav: beneficiary?.firstName + ' ' + beneficiary?.lastName,
      KirvaMutav: beneficiary?.beneficiaryRelation,
      ZeutMutav: beneficiary?.idNumber,
      FullAddressMutav: beneficiary?.address,
      MinMutav: beneficiary?.gender,
      BirthDateMutav: this.formatDate(beneficiary?.dateOfBirth as Date),
      AhuzMutv: String(beneficiary?.beneficiaryPercentage),
      TypeIdent: TypeIdent.ID,
    }));
  }

  private mapMaasikDetails(employer: UserEmployerDetails): Formally.MaasikDetails {
    return {
      NameMasik: employer?.employerName,
      HP: employer?.employerIdentificationNumber,
      TelMasik: employer?.employerContactPhone,
      EmailMasik: employer?.employerContactEmail,
      FullAddressMasik: employer?.employerAddress,
    };
  }

  private mapHanmakaDetails(): Formally.HanmakaDetails | {} {
    return {};
  }

  private getAge(dateOfBirth: Date): number {
    if (!dateOfBirth) return;

    return dayjs().diff(dayjs(dateOfBirth), 'year');
  }

  private getSmokeStatus(smokerStatus: boolean): SmokingStatus {
    return smokerStatus ? SmokingStatus.Smoker : SmokingStatus.NonSmoker;
  }

  private getGenderId(gender: string): string {
    return gender === 'M' ? 'זכר' : 'נקבה';
  }

  private getGenderIdCheckBox(gender: string): GenderEnum {
    return gender === 'M' ? GenderEnum.Male : GenderEnum.Female;
  }

  private formatDate(date: Date): string {
    if (!date) return dayjs().format('DD/MM/YYYY');

    return dayjs(date).format('DD/MM/YYYY');
  }
}
