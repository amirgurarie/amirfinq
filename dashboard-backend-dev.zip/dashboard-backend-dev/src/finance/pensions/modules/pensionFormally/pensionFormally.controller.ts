import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import {
  Body,
  Controller,
  Get,
  Headers,
  Post,
  UnauthorizedException,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { AbstractController } from '../../../../shared';
import { ConfigService } from '@nestjs/config';
import { ApiFailedHttpResponse } from 'src/shared/decorators/apiFailedHttpResponse.decorator';
import { ApiNotFoundHttpResponse } from 'src/shared/decorators/apiNotFoundHttpResponse.decorator';
import { LocalJwtAuthGuard } from 'src/shared/guards/localJwtAuth.guard';
import { TransformInterceptor } from 'src/shared/interceptors/transform.interceptor';
import { AuthenticatedUser } from 'src/shared/types/authenticatedUser.interface';
import { CurrentAuthUser } from 'src/auth/currentAuthUser.decorator';
import { PensionFormallyManager } from './pensionFormally.manager';
import { UpdateUserFormDto } from './dtos/UpdateUserForm.dto';

@ApiTags('Pension Formally')
@Controller('v1/users/pensions/formally')
@ApiBearerAuth()
export class PensionFormallyController extends AbstractController {
  constructor(
    protected readonly configService: ConfigService,
    protected readonly pensionFormallyManager: PensionFormallyManager,
  ) {
    super(configService);
  }

  @Get('send-to-formally')
  @ApiOperation({ summary: 'Send selected recommendations to Formally' })
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @UseGuards(LocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  async sendRecommendationsToFormally(@CurrentAuthUser() authUserPayload: AuthenticatedUser) {
    const user = authUserPayload?.user;
    await this.pensionFormallyManager.sendRecommendationsToFormally(user);
  }

  @Post('user-form-kits')
  @ApiOperation({ summary: 'Update user forms link from Formally' })
  async saveUserFormsKit(
    @Headers('authorization') authorization: string,
    @Body() updateUserFormDto: UpdateUserFormDto,
  ): Promise<void> {
    if (authorization !== this.configService.get('FORMALLY_AUTH_IDENTIFIER')) {
      throw new UnauthorizedException('User is not authenticated');
    }

    await this.pensionFormallyManager.saveUserFormsKit(updateUserFormDto);
  }

  @Get('formally-simulations')
  @ApiFailedHttpResponse()
  @ApiNotFoundHttpResponse()
  @UseGuards(LocalJwtAuthGuard)
  @UseInterceptors(TransformInterceptor)
  async buildFormallySimulations(@CurrentAuthUser() authUserPayload: AuthenticatedUser): Promise<any[]> {
    const user = authUserPayload?.user;

    return await this.pensionFormallyManager.buildFormallySimulations(user);
  }
}
