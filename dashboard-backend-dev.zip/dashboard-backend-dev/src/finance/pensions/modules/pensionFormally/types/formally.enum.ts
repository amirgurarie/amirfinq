export const EmployeeType = {
  employed: 2,
  self_employed: 1,
  controlling: 8,
  employed_and_self_employed: 9,
} as const;

export type EmployeeType = (typeof EmployeeType)[keyof typeof EmployeeType];

export const EmployeeTypeProduct = {
  employed: 1,
  self_employed: 2,
  controlling: 1,
  employed_and_self_employed: 2,
} as const;

export type EmployeeTypeProduct = (typeof EmployeeTypeProduct)[keyof typeof EmployeeTypeProduct];

export const TypeIdent = {
  ID: 0,
  Passport: 1,
} as const;

export type TypeIdent = (typeof TypeIdent)[keyof typeof TypeIdent];

export const GenderEnum = {
  Male: 1,
  Female: 2,
} as const;

export type GenderEnum = (typeof GenderEnum)[keyof typeof GenderEnum];

export const MaritalID = {
  single: 1,
  married: 2,
  divorced: 3,
  widower: 4,
  publicly_known: 5,
} as const;

export type MaritalID = (typeof MaritalID)[keyof typeof MaritalID];

export const MaritalDescription = {
  single: 'רווק',
  married: 'נשוי',
  divorced: 'גרוש',
  widower: 'אלמן',
  publicly_known: 'ידוע בציבור',
} as const;

export type MaritalDescription = (typeof MaritalDescription)[keyof typeof MaritalDescription];

export const SmokingStatus = {
  NonSmoker: 0,
  Smoker: 1,
} as const;

export type SmokingStatus = (typeof SmokingStatus)[keyof typeof SmokingStatus];

export const SmokedLast3Years = {
  No: 0,
  Yes: 1,
} as const;

export type SmokedLast3Years = (typeof SmokedLast3Years)[keyof typeof SmokedLast3Years];

export const ProcessType = {
  NEW: 1,
  CHANGE: 3,
  NO_CHANGE: 3,
  TRANSFER: 2,
} as const;

export type ProcessType = (typeof ProcessType)[keyof typeof ProcessType];

export const ProcessTypeDesc = {
  NEW: 'הצטרפות',
  TRANSFER: 'ניוד',
  CHANGE: 'שינויים במוצר קיים',
  NO_CHANGE: 'שינויים במוצר קיים',
} as const;

export type ProcessTypeDesc = (typeof ProcessTypeDesc)[keyof typeof ProcessTypeDesc];

export const ProductType = {
  COMPERHENSIVE: 8,
  SUPPLEMENTARY: 8,
  INVESTMENT: 1,
  EDUCATION: 3,
  CHILDSAVING: 5,
  PROVIDENT: 2,
  COMPENSATION: '',
  MANAGERS: 4,
  PRIVATE: 'PRIVATE',
  OTHER: 'OTHER',
} as const;

export type ProductType = (typeof ProductType)[keyof typeof ProductType];

export const ProductTypeDesc = {
  COMPERHENSIVE: 'פנסיה מקיפה',
  SUPPLEMENTARY: 'פנסיה משלימה',
  INVESTMENT: 'גמל השקעה',
  EDUCATION: 'קרן השתלמות',
  CHILDSAVING: 'חיסכון לילד',
  PROVIDENT: 'קופת גמל',
  COMPENSATION: 'פיצויים',
  MANAGERS: 'ביטוח מנהלים',
  PRIVATE: 'ביטוח פרטי',
  OTHER: 'אחר',
} as const;

export type ProductTypeDesc = (typeof ProductTypeDesc)[keyof typeof ProductTypeDesc];

//       CHANGE_INVESTMENT_PLAN: 'CHANGE_INVESTMENT_PLAN',
//       CHANGE_INSURANCE_PLAN: 'CHANGE_INSURANCE_PLAN',
//       CHANGE_MANAGEMENT_FEE: 'CHANGE_MANAGEMENT_FEE',
//       ADD_PROGRESSIVE_DISABILITY: 'ADD_PROGRESSIVE_DISABILITY',
//       ADD_SURVIVORS_WAIVER: 'ADD_SURVIVORS_WAIVER',
//       REMOVE_SURVIVORS_WAIVER: 'REMOVE_SURVIVORS_WAIVER',
//       NO_CHANGE: 'NO_CHANGE'
//       ,
export const ChangesCode = {
  NO_CHANGE: 0,
  CHANGE_INSURANCE_PLAN: 8,
  CHANGE_INVESTMENT_PLAN: 9,
  CHANGE_MANAGEMENT_FEE: 2,
  //TODO
  PROMOTION: 1,
  SALARY_WITHDRAWAL: 3,
  POLICY_TERMINATION: 4,
  PENSION_RECEIVE: 5,
  INSURANCE_SUM_DECREASE: 6,
  INSURANCE_SUM_INCREASE: 7,
  SALARY_UPDATE: 10,
  TEMPORARY_RISK: 11,
  JOB_CHANGE: 12,
  PERSONAL_DETAILS_UPDATE: 13,
  CHANGE_BENEFICIARIES: 14,
  CANCEL_MONEY_WITHDRAW: 15,
  CANCEL_TRANSFER: 16,
  GENERAL_CHANGES: 17,
  EMPLOYMENT_TERMINATION: 20,
} as const;

export type ChangesCode = (typeof ChangesCode)[keyof typeof ChangesCode];

export const ChangesDesc = {
  NO_CHANGE: 'לא שינוי',
  CHANGE_INSURANCE_PLAN: 'שינוי מסלול ביטוח',
  CHANGE_INVESTMENT_PLAN: 'שינוי מסלול השקעה',
  CHANGE_MANAGEMENT_FEE: 'שינוי דמי ניהול',
  //TODO
  PROMOTION: 'קבלה בעלות',
  SALARY_WITHDRAWAL: 'משיכת כספים',
  POLICY_TERMINATION: 'ביטול/הקפאת פוליסה',
  PENSION_RECEIVE: 'קבלת קצבה',
  INSURANCE_SUM_DECREASE: 'הקטנת סכום ביטוח',
  INSURANCE_SUM_INCREASE: 'הגדלת סכום ביטוח',
  SALARY_UPDATE: 'שינוי שיעור הפקה/עדכון שכר',
  TEMPORARY_RISK: 'ריסק זמני',
  JOB_CHANGE: 'עזיבת עבודה',
  PERSONAL_DETAILS_UPDATE: 'שינוי כתובת/פרטים אישיים',
  CHANGE_BENEFICIARIES: 'שינוי מוטבים',
  CANCEL_MONEY_WITHDRAW: 'ביטול משיכת כספים',
  CANCEL_TRANSFER: 'ביטול ניוד לאחר שימור',
  GENERAL_CHANGES: 'שינויים כלליים',
  EMPLOYMENT_TERMINATION: 'סיום עבודה',
} as const;

export type ChangesDesc = (typeof ChangesDesc)[keyof typeof ChangesDesc];
