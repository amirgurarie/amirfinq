import {
  EmployeeType,
  GenderEnum,
  MaritalDescription,
  MaritalID,
  ProcessType,
  ProductType,
  ProductTypeDesc,
  SmokedLast3Years,
  SmokingStatus,
  TypeIdent,
} from './formally.enum';

export namespace Formally {
  export const status = {
    SENT: 'SENT',
    RECEIVED: 'RECEIVED',
  };
  export type status = keyof typeof status;

  export interface FormallyData {
    ProcessGuid: string;
    CompanyDetails: CompanyDetails;
    UserDetails: UserDetails;
    CustomerDetails: CustomerDetails;
    Spouse?: SpouseDetails;
    Children?: { Child: ChildrenDetails[] };
    Beneficiaries?: { Beneficiary: BeneficiariesDetails[] };
    MaasikDetails: MaasikDetails;
    Hanmaka: HanmakaDetails | {};
    BankDetails: any;
    ProcessList?: { ProcessData: ProcessData[] };
  }

  export interface ProcessData {
    ProcessType: ProcessType;
    ProcessTypeDesc: string;
    MainProductData: ProcessDataPension[] | ProcessDataFinance[];
    TransferProductData?: TransferProductData;
  }

  export interface MainProcessData {
    MainProductData: ProcessDataPension[] | ProcessDataFinance[];
    TransferProductData?: TransferProductData;
  }

  export interface ProcessDataPension {
    ProductType: ProductType;
    ProductTypeDesc: ProductTypeDesc;
    ProductGufMenahel: string;
    ProductHPGufMenahel: string;
    ProductFundName: string;
    ProductFundNumber: string;
    ProductCustType: EmployeeType;
    ProductAmitPaeil: string;
    MaslulPizuimOzar: string;
    KodMaslulPizuimOzar: string;
    KodMaslulTagmulimOzar: string;
    TagmulimDesc: string;
    MaslulBituahOzar: string;
    InsuranceRouteCode: string;
    ProductSplitInvestments: number;
    KodMaslulBituahOzar: number;
    Salary: number;
    PizuimMaavid: number;
    TagmulimMaavid: number;
    Tagmulim45Oved: number;
    ThilatBituah: string;
    DMN_Chisachon: number;
    DMN_Hafkadot: number;
    FormsDataFields?: { field: FormsDataFields[] };
  }

  export interface TagmulimFunds {
    FundName: string;
    FundNumber: number;
    InvestPercent: number;
  }

  export interface PizuimFunds {
    FundName: string;
    FundNumber: number;
    InvestPercent: number;
  }

  export interface ProcessDataFinance {
    ProductType: ProductType;
    ProductTypeDesc: ProductTypeDesc;
    ProductGufMenahel: string;
    ProductHPGufMenahel: string;
    ProductSplitInvestments: number;
    ProductFundName: string;
    ProductFundNumber: string;
    InvestPercent: string;
    ProductCustType: EmployeeType;
    ProductAmitPaeil: string;
    TagmulimFunds?: { NewPolicy: TagmulimFunds[] };
    PizuimFunds?: { NewPolicyPizuim: PizuimFunds[] };
    Salary: number;
    PizuimMaavid: number;
    TagmulimMaavid: number;
    Tagmulim45Oved: number;
    ThilatBituah: string;
    DMN_Chisachon: number;
    DMN_Hafkadot: number;
    NewFundAgentNumber?: number;
    FormsDataFields?: { field: FormsDataFields[] };
  }

  export interface FormsDataFields {
    value: string;
    _name: string;
  }

  export interface TransferProductData {
    ProductType: ProductType;
    ProductTypeDesc: ProductTypeDesc;
    ProductGufMenahel: string;
    ProductHPGufMenahel: string;
    ProductFundName: string;
    ProductFundNumber: string;
    ProductPolicyNumber: string;
    ProductProgName?: string;
    ProductWithAKA?: number;
    ProductWithRisk?: number;
    ProductWithRizoko?: number;
    TransferSalary?: number;
    TransferPizuimMaavid?: number;
    TransferTagmulimMaavid?: number;
    TransferTagmulim45Oved?: number;
    TransferThilatBituah: string;
    TransferExistAmitPaeil: number;
    NumberAccountTransfer: number;
    TransferFundNameDesc: string;
    TransferFundNumber: string;
    TransferDMN_Chisachon: number;
    TransferDMN_Hafkadot: number;
    TransferPolicyNumber: string;
    TransferNewCustType: EmployeeType;
    FormsDataFields?: { field: FormsDataFields[] };
  }

  export interface CompanyDetails {
    CompanyGuid?: string;
    CompanyName: string;
    CompanyHP: string;
    CompanyEmail?: string;
    CompanyPhone?: string;
    CompanyMobile?: string;
    CompanyFax?: string;
    CompanyStreet?: string;
    CompanyAppartment?: string;
    CompanyCity?: string;
    CompanyZip?: string;
    CompanyFullAddress?: string;
  }

  export interface UserDetails {
    NewFundAgentNumber?: string;
    OpportunityCode?: string;
    FirstName: string;
    LastName: string;
    FullName: string;
    UserSignature?: string;
    Email?: string;
    UserEmail?: string;
    Phone?: string;
    Mobile?: string;
    idNumber?: string;
    MefakachName?: string;
    MefakachNum?: string;
    ShemSochnut?: string;
  }

  export interface CustomerDetails {
    ZeutAttachment?: string;
    CustGuid?: string;
    CustID?: string;
    CustType: EmployeeType;
    FirstName: string;
    LastName: string;
    FullName: string;
    TypeIdent: TypeIdent;
    Zeut: string;
    IssueDateZeut?: string;
    BirthDate: string;
    DontReturnURL: number;
    ClientAge?: number;
    GenderID?: string;
    GenderIDCheckBox: GenderEnum;
    Email: string;
    TelHouse?: string;
    Cel: string;
    Street: string;
    House: string;
    PoBox: string;
    AppartmentNumber?: string;
    City: string;
    CustomerCityCode?: string;
    Zip?: string;
    FullAddress: string;
    MaritalID?: MaritalDescription;
    MaritalIDCheckBox: MaritalID;
    Fax?: string;
    Miktzoa?: string;
    Isuk?: string;
    IsukKod?: string;
    TelWork?: string;
    HobbiesDetailsCode?: string;
    HobbiesDetails?: string;
    BirthCountry?: string;
    BirthCountryDesc?: string;
    IsMainMashlimShaban?: boolean;
    SmokingDetails?: SmokingDetails;
  }

  export interface SmokingDetails {
    SmokingStatus: SmokingStatus;
    SmokedLast3Years: SmokedLast3Years;
  }

  export interface SpouseDetails {
    CustType?: EmployeeType;
    FirstName2: string;
    LastName2: string;
    FullName2: string;
    TypeIdent: TypeIdent;
    Zeut2: string;
    IssueDateZeut2?: string;
    BirthDate2: string;
    SpouseAge: number;
    GenderID2?: string;
    GenderID2CheckBox: GenderEnum;
    Email2?: string;
    TelHouse2?: string;
    Cel2?: string;
    Street2?: string;
    House2?: string;
    AppartmentNumber2?: string;
    City2?: string;
    CustomerCityCode2?: string;
    Zip2?: string;
    FullAddress2?: string;
    MaritalID2?: MaritalID;
    MaritalIDCheckBox2?: MaritalID;
    Fax2?: string;
    Miktzoa2?: string;
    HobbiesDetailsCode2?: string;
    HobbiesDetails2?: string;
    Isuk2?: string;
    IsukKod2?: string;
    TelWork?: string;
  }

  export interface ChildrenDetails {
    FNameY: string;
    LNameY: string;
    NameY: string;
    GenderIDY?: string;
    GenderIDYCheckBox: GenderEnum;
    ZeutY: string;
    BirthDateY: string;
    TypeIdent: TypeIdent;
    BasicMedicalInsurerY?: string;
    BasicMedicalInsurerYDesc?: string;
    SupplementaryInsuranceY?: string;
    IsChildMashlimShaban?: boolean;
    ChildAge: number;
    Under_10: boolean;
    ChildInYourPossession?: boolean;
  }

  export interface BeneficiariesDetails {
    FirstNameMutav: string;
    LastNameMutav: string;
    NameMutav: string;
    KirvaMutav: string;
    FullAddressMutav: string;
    MinMutav: string;
    BirthDateMutav: string;
    ZeutMutav: string;
    AhuzMutv?: string;
    TypeIdent?: TypeIdent;
    MinMutavCheckBox?: string;
    RelationCode?: string;
  }

  export interface MaasikDetails {
    NameMasik: string;
    HP: string;
    TelMasik?: string;
    FaxMasik?: string;
    NayadMasik?: string;
    EmailMasik?: string;
    Address?: string;
    AddressNum?: string;
    CitiMasik?: string;
    MaasikCityCode?: string;
    ZipMasik?: string;
    FullAddressMasik?: string;
    IshKesher?: string;
    SignatureMaasik?: string;
  }

  export interface HanmakaDetails {
    Hanmaka: {
      ProcessListPartA: {
        ProcessDataPartA: ProcessDataPartA[];
      };
      ProcessListKisuim: {
        ProcessDataKisuim: ProcessDataKisuim[];
      };
      Settings: Settings;
      SummeryTablePart4: SummeryTablePart4;
    };
  }

  export interface ProcessDataPartA {
    ProductDataPartA: ProcessListPartA | ProcessListPartA[];
  }

  export interface ProcessListPartA {
    ProdType: string;
    ProdTypeDesc: string;
    ProdGufMosdi: string;
    ProdSplitInvestments: string;
    ProdSplitInvestmentsFunds?: {
      ProdSplitInvestment: SplitInvestment[];
    };
    ProdFundName: string;
    ProdFundNumber: string;
    ProdCustType: string;
    ProdPizuimInvestName: string;
    ProdPizuimInvestCode: string;
    ProdTagmulimInvestName: string;
    ProdTagmulimInvestCode: string;
    ProdHavtachatTsua: string;
    ProdTsuaMemutzatPizuim: string;
    ProdTsuaMemutzatTagmulim: string;
    ProdDMN_Hafkadot: string;
    ProdDMN_Chisachon: string;
    ProdRamatSikunPizuim?: string;
    ProdRamatSikunTagmulim?: string;
    ProdChisachon_Mitztaber: string;
    ProdOneTimeDeposit: string;
    ProdSchumTzafuy: string;
    ProdKitzvaTzafuy: string;
    ProdHamlaza: string;
    ProdConsiderationsList?: {
      ProdConsideration: string[] | string;
    };
    ProdCommentsList?: {
      ProdComment: string[] | string;
    };
  }

  export interface SplitInvestment {
    SplitInvestmentName: string;
    SplitInvestmentNumber: string;
    SplitInvestmentPercentTagmulim: string;
    SplitInvestmentPercentPizuim: string;
    SplitInvestmentTzua: string;
    SplitInvestmentRamatSikun: string;
  }

  export interface ProcessDataKisuim {
    ProductDataKisuim: ProductDataKisuim | ProductDataKisuim[];
  }

  export interface ProductDataKisuim {
    ProdType: string;
    ProdTypeDesc: string;
    KisuyHamlaza: string;
    ProdGufMosdi: string;
    ProdFundName: string;
    ProdFundNumber: string;
    ProdMaslulBituahList: {
      MaslulBituahData: MaslulBituahData[];
    };
    IncludeInPensyoni: string;
    KisuyConsiderationsList?: {
      KisuyConsideration: string[];
    };
  }

  export interface MaslulBituahData {
    MaslulBituahDescription: string;
    MaslulBituahSum: string;
    MaslulBituahAlut: string;
  }

  export interface Settings {
    GiluyNahotList: {
      Ishtalmut?: FundListSetting;
      Gemel?: FundSetting;
      Bituach?: FundSetting;
      Pensia?: FundListSetting;
    };
  }

  export interface FundListSetting {
    Fund: FundSetting[];
  }

  export interface FundSetting {
    DisplayOrder: string;
    FundName: string;
    DisplayPercent: string;
  }

  export interface SummeryTablePart4 {
    ExsitsTableSummery: {
      Fund: SummaryFund[];
    };
    NewTableSummery: {
      Fund: SummaryFund[];
    };
  }

  export interface SummaryFund {
    SugMutzar: string;
    GufMosdi: string;
    ProductDescription: string;
    MaslulDescription: string;
  }

  export interface ProductFundConfig {
    CompanyName: string;
    ShouldAppendKey?: boolean;
    Products?: {
      [productId: string]: Record<string, string>;
    };
    FundKeys?: FundMapping;
    ChangeFundKeys?: FundMapping;
    AgentKey?: {
      [product: string]: string;
    };
  }

  export interface FundMapping {
    PensionFundKey?: string;
    PensionFundAmount?: string;
    CompensationFundKey?: string;
    CompensationFundAmount?: string;
  }

  export interface pensionCompaniesSettingsData {
    [companyId: string]: ProductFundConfig;
  }
}
