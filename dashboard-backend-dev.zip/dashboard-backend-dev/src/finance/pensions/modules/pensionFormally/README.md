Here's the complete text for your readme.md file:

# PensionFormallyModule
## Overview
The `PensionFormallyModule` facilitates the integration of user recommendations with the Formally external service.
It handles the extraction, transformation, and submission of pension data, enabling users to fulfill their recommendations
or designate FINQ as their pension agent.

### Controllers and Managers
- **PensionFormallyController**: REST API endpoint protected by JWT authentication
- **PensionFormallyManager**: Orchestrates the entire process flow
- **FormallyManager**: Handles external API communication

### Mappers
- **FormallyProcessDataMapper**: Converts holdings and transaction data
- **FormallyMapper**: Transforms user profile information

### Services
- **UserProfileService**: Retrieves user identity details
- **PensionRecommendationsManager**: Provides investment recommendation data
- **PensionFormallyService**: Handles persistence of interaction logs

## Architecture Diagram

```
┌───────────────────────────────────────────────────────┐
│                   Client Request (Frontend)           │
└───────────────────────────────────────────────────────┘
│
▼
[GET] /v1/users/pensions/formally/send-to-formally
│
▼
┌───────────────────────────────────────────────────────┐
│           PensionFormallyController (REST API)        │◄─── Guard: LocalJwtAuthGuard
└───────────────────────────────────────────────────────┘
│
▼
┌───────────────────────────────────────────────────────┐
│            PensionFormallyManager (Orchestration)     │
└───────────────────────────────────────────────────────┘
│                  │                  │
▼                  ▼                  ▼
UserProfileService  RecommendationsManager  FormallyManager
│                  │                  │
▼                  ▼                  ▼
UserDetails        Pension Recommendations  FormsKit API
│
▼
┌────────────────────────────────────┐
│ FormallyProcessDataMapper          │
└────────────────────────────────────┘
│
▼
┌────────────────────────────────────┐
│ FormallyMapper                     │
└────────────────────────────────────┘
│
▼
┌────────────────────────────────────┐
│ PensionFormallyService             │
└────────────────────────────────────┘
│
▼
┌──────────────────────────────────────────────┐
│ Database: UserPensionRecommendationsFormally │
└──────────────────────────────────────────────┘
```

## Process Flow

1. **Authentication**: User request is validated through JWT authentication
2. **Data Collection**: System gathers user profile and pension recommendation data
3. **Transformation**: Data is mapped to Formally-compatible structures
4. **Submission**: Transformed data is sent to Formally's FormsKit API
5. **Logging**: Response and transaction details are persisted for tracking

## Sequence Diagram
![img.png](img.png)


```mermaid
title Formally Flow

participant "Frontend" as FE
participant "Backend Server" as BE
participant "Database" as DB
participant "Formally" as Formally

note right of FE: Finish KYC3

FE->BE: POST /v1/users/pensions/formally/send-to-formally

BE->DB: Pull user details and selected recommendations

    BE->BE: Build JSON payload for Formally

    BE->Formally: POST /api/v1/pensions\n(JSON with recommendations)
    Formally->BE: 200 OK\n(Response with reference ID, status, etc.)

    BE->DB: Save formally response\n(FormallySubmission.save())
end

```

## Entities Involved

| Entity                                                | Purpose                                      |
| ----------------------------------------------------- | -------------------------------------------- |
| `UserPensionRecommendationsFormally`                  | Stores interaction log with Formally service |
| `UserPensionRecommendations`                          | Contains user recommendation strategies      |
| `UserPensionRecommendationCombinationCurrentHoldings` | Current state of user's holdings             |
| `UserPensionRecommendationCombinationTargetHoldings`  | Target state of user's holdings              |
| `UserDetails`                                         | Profile and identity details of the user     |

## Dependencies

- `UserProfileModule`
- `PensionRecommendationsModule`
- `FormallyModule`
- `TypeOrmModule`


