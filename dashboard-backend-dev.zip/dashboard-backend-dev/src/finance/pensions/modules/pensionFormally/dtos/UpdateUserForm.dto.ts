import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class UpdateUserFormDto {
  @ApiProperty()
  @IsString()
  public readonly formLink: string;

  @ApiProperty()
  @IsString()
  public readonly idNumber: string;
}
