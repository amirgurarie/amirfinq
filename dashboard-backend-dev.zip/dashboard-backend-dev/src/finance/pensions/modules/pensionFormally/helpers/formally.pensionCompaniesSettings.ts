import { Formally } from '../types/formally.namespace';

// `pensionCompaniesSettings` is a configuration object that maps company IDs to their respective settings.
// Each company has properties such as `CompanyName`, `AgentKey`, `FundKeys`, `ChangeFundKeys`, and `Products`.
// These settings are used to define specific attributes and mappings for pension-related operations.

export const pensionCompaniesSettings = {
  '512244146': {
    CompanyName: 'כלל פנסיה וגמל בע"מ',
    AgentKey: {
      default: 'TBD',
    },
    ShouldAppendKey: true,
    FundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'InvestPercent',
      CompensationFundKey: 'PensionNumberPitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
    ChangeFundKeys: {
      PensionFundKey: 'To_FundNumber',
      PensionFundAmount: 'TransferSum',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
    Products: {
      COMPERHENSIVE: {
        '9654': '5',
        '9655': '6',
        '9656': '7',
        '9648': '9',
        '9647': '8',
        '2004': '3',
        '13213': '4',
      },
      SUPPLEMENTARY: {
        '9633': '2',
        '9634': '3',
        '9635': '4',
        '13698': '44',
      },
    },
  },
  '512237744': {
    CompanyName: 'מגדל מקפת קרנות פנסיה וקופות גמל בע"מ',
    AgentKey: {
      default: '168488',
      PROVIDENT: '48001906',
      INVESTMENT: '48001906',
    },
    FundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'InvestPercent',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
    ChangeFundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'InvestPercent',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
    Products: {
      COMPERHENSIVE: {
        '2149': '2',
        '2146': '3',
        '2147': '4',
        '2148': '5',
        '9453': '6',
        '9454': '7',
        '9455': '8',
        '2145': '1',
      },
      SUPPLEMENTARY: {
        '2149': '2',
        '2146': '3',
        '2147': '4',
        '2148': '5',
        '9453': '6',
        '9454': '7',
        '9455': '8',
        '2145': '1',
      },
    },
  },
  '512245812': {
    CompanyName: 'מנורה מבטחים פנסיה וגמל בע"מ',
    AgentKey: {
      default: '417131',
    },
    ShouldAppendKey: true,
    FundKeys: {
      PensionFundKey: 'PensionNewFundNumber',
      PensionFundAmount: 'PensionNewFundNumber',
      CompensationFundKey: 'Pitzuim_PensionNewFundNumber',
      CompensationFundAmount: 'Pitzuim_PensionNewFundNumber',
    },
    ChangeFundKeys: {
      PensionFundKey: 'PensionNewFundNumber',
      PensionFundAmount: 'PensionNewFundNumber',
      CompensationFundKey: 'Pitzuim_PensionNewFundNumber',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
  },
  '512065202': {
    CompanyName: 'מיטב גמל ופנסיה בע"מ',
    AgentKey: {
      default: '2-12492',
    },
    FundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'InvestPercent',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
    ChangeFundKeys: {
      PensionFundKey: 'Rewards',
      PensionFundAmount: 'TransferPercent',
      CompensationFundKey: 'CompensationPercent',
      CompensationFundAmount: 'CompensationPercentM',
    },
  },
  '513026484': {
    CompanyName: 'הפניקס פנסיה וגמל בע"מ',
    AgentKey: {
      default: '26439',
    },
    FundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'Rewards',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'CompensationPercent',
    },
    ChangeFundKeys: {
      PensionFundKey: 'Rewards',
      PensionFundAmount: 'RewardsM',
      CompensationFundKey: 'CompensationPercent',
      CompensationFundAmount: 'CompensationPercentM',
    },
  },
  '512267592': {
    CompanyName: 'הראל פנסיה וגמל בע"מ',
    AgentKey: {
      default: '29720',
    },
    ShouldAppendKey: true,
    FundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'Rewards',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'CompensationPercent',
    },
    ChangeFundKeys: {
      PensionFundKey: 'PensionNewFundNumber',
      PensionFundAmount: 'InvestPercent',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
  },
  '513173393': {
    CompanyName: 'אלטשולר שחם גמל ופנסיה בע"מ',
    AgentKey: {
      default: '18868',
    },
    ShouldAppendKey: true,
    FundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'Rewards',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'CompensationPercent',
    },
    ChangeFundKeys: {
      PensionFundKey: 'Rewards',
      PensionFundAmount: 'RewardsM',
      CompensationFundKey: 'Compensation',
      CompensationFundAmount: 'CompensationM',
    },
  },
  '514956465': {
    CompanyName: 'מור גמל ופנסיה בע"מ',
    AgentKey: {
      default: '24376',
    },
    ShouldAppendKey: true,
    FundKeys: {
      PensionFundKey: 'PensionNumber',
      PensionFundAmount: 'InvestPercent',
      CompensationFundKey: 'Pitzuim',
      CompensationFundAmount: 'InvestPercent_Pitzuim',
    },
    ChangeFundKeys: {
      PensionFundKey: 'InvestPercent',
      PensionFundAmount: 'RewardsM',
      CompensationFundKey: 'InvestPercent_Pitzuim',
      CompensationFundAmount: 'CompensationPercentM',
    },
  },
  '520030677': {
    CompanyName: 'איילון חברה לביטוח בע"מ',
    AgentKey: {
      default: '12144',
    },
  },
  '513621110': {
    CompanyName: 'אינפיניטי השתלמות, גמל ופנסיה בע"מ',
    AgentKey: {
      default: '1301/1982',
    },
  },
  '511880460': {
    CompanyName: 'אנליסט קופות גמל בע"מ',
    AgentKey: {
      default: '9531',
    },
  },
  '520042177': {
    CompanyName: 'הכשרה חברה לביטוח בע"מ',
    AgentKey: {
      default: 'TBD',
    },
  },
  '513611509': {
    CompanyName: 'ילין לפידות ניהול קופות גמל בע"מ',
    AgentKey: {
      default: '13991',
    },
  },
} as Formally.pensionCompaniesSettingsData;
