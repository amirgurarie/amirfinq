import { forwardRef, HttpModule, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LoggerService } from 'src/shared/middlewares/logger/logger.service';
import { AsyncEventEmitter } from 'src/shared/modules/flowGateway/utils/asyncEvent.util';
import { UserProfileModule } from 'src/users/userProfile/user-profile.module';
import { UserPensionRecommendationsFormally } from '../../../../entities/UserPensionRecommendationsFormally';
import { PensionFormallyController } from './pensionFormally.controller';
import { PensionFormallyService } from './pensionFormally.service';
import { PensionFormallyManager } from './pensionFormally.manager';
import { FormallyModule } from '../../../../shared/modules/formally/formally.module';
import { PensionRecommendationsModule } from '../portfolio/modules/recommendations/recommendations.module';
import { FormallyMapper } from './mappers/formally.mapper';
import { AddressService } from '../../../../address/address.service';
import { AddressModule } from '../../../../address/address.module';
import { RefCities, RefStreets } from '../../../../entities';
import { UserDocumentsModule } from '../../../../users/userDocuments/userDocuments.module';
import { PensionsModule } from '../../pensions.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([UserPensionRecommendationsFormally, RefCities, RefStreets]),
    UserDocumentsModule,
    PensionRecommendationsModule,
    UserProfileModule,
    AddressModule,
    HttpModule,
    FormallyModule,
    forwardRef(() => PensionsModule),
  ],
  providers: [
    PensionFormallyService,
    PensionFormallyManager,
    FormallyMapper,
    AsyncEventEmitter,
    LoggerService,
    AddressService,
  ],
  exports: [PensionFormallyService, PensionFormallyManager],
  controllers: [PensionFormallyController],
})
export class PensionFormallyModule {}
