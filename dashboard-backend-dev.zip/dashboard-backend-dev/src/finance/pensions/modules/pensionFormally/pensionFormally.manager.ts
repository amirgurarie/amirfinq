import { HttpService, Injectable } from '@nestjs/common';
import { UserProfileService } from '../../../../users/userProfile/user-profile.service';
import { FormallyMapper } from './mappers/formally.mapper';
import { PensionFormallyService } from './pensionFormally.service';
import { PensionRecommendationsManager } from '../portfolio/modules/recommendations/recommendations.manager';
import { FormallyManager } from '../../../../shared/modules/formally/formally.manager';
import { FormallyProcessDataMapper } from './mappers/formally.ProcessData.mapper';
import { Formally } from './types/formally.namespace';
import { DeepPartial } from 'typeorm';
import { FundPension, UserDetails, UserDocumentsDetails, Users } from 'src/entities';
import sharp from 'sharp';
import { UpdateUserFormDto } from './dtos/UpdateUserForm.dto';
import { v4 as uuidv4 } from 'uuid';
import { PensionPortfolio } from '../portfolio/portfolio.namespace';
import { PensionsService } from '../../pensions.service';
import { PensionCategoriesEnum } from '../../enum/pensionCategories.enum';
import { UserDocumentsService } from '../../../../users/userDocuments/userDocuments.service';
import { PensionRecommendationTypes } from '../portfolio/modules/recommendations/types/recommendations.namespace';
import PracticalActionsEnum = PensionRecommendationTypes.Holding.PracticalActionsEnum;
import EssentialActionsEnum = PensionRecommendationTypes.Holding.EssentialActionsEnum;
import { PensionFundFilterEnum } from '../../enum/pensionFundsFilter.enum';

@Injectable()
export class PensionFormallyManager {
  constructor(
    private readonly recommendationsManager: PensionRecommendationsManager,
    private readonly userProfileService: UserProfileService,
    private readonly httpService: HttpService,
    private readonly formallyManager: FormallyManager,
    private readonly formallyMapper: FormallyMapper,
    private readonly pensionFormallyService: PensionFormallyService,
    private readonly userDocumentsService: UserDocumentsService,
    private readonly pensionsService: PensionsService,
  ) {}

  /**
   * Builds simulations for different products/actions.
   * This method retrieves the user's profile, maps it to a static structure,
   * and processes specific categories to generate simulation results.
   * It filters companies and their funds based on the category and action,
   * and prepares the data for Formally processing.
   *
   * @param user - The user entity containing user details.
   * @returns A promise resolving to an array of simulation results.
   */
  async buildFormallySimulations(user: Users): Promise<any> {
    const userProfile = await this.userProfileService.getUserProfile(user.id);
    const mappedData = await this.getFormallyStaticStructure(userProfile);

    // Elements are stashed to temporarily exclude them from execution,
    return [
      //COMPERHENSIVE
      // {
      //   Category: PensionCategoriesEnum.COMPERHENSIVE + '-NEW',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.COMPERHENSIVE,
      //     mappedData,
      //     PracticalActionsEnum.NEW,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.COMPERHENSIVE + '-TRANSFER',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.COMPERHENSIVE,
      //     mappedData,
      //     PracticalActionsEnum.TRANSFER,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.COMPERHENSIVE + '-CHANGE',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.COMPERHENSIVE,
      //     mappedData,
      //     PracticalActionsEnum.CHANGE,
      //     EssentialActionsEnum.CHANGE_INVESTMENT_PLAN,
      //   ),
      // },

      // SUPPLEMENTARY
      // {
      //   Category: PensionCategoriesEnum.SUPPLEMENTARY + '-NEW',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.SUPPLEMENTARY,
      //     mappedData,
      //     PracticalActionsEnum.NEW,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.SUPPLEMENTARY + '-TRANSFER',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.SUPPLEMENTARY,
      //     mappedData,
      //     PracticalActionsEnum.TRANSFER,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.SUPPLEMENTARY + '-CHANGE',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.SUPPLEMENTARY,
      //     mappedData,
      //     PracticalActionsEnum.CHANGE,
      //     EssentialActionsEnum.CHANGE_INVESTMENT_PLAN,
      //   ),
      // },

      //EDUCATION
      // {
      //   Category: PensionCategoriesEnum.EDUCATION + '-NEW',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.EDUCATION,
      //     mappedData,
      //     PracticalActionsEnum.NEW,
      //   ),
      // },
      // {
      //   Action: PensionCategoriesEnum.EDUCATION + '-TRANSFER',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.EDUCATION,
      //     mappedData,
      //     PracticalActionsEnum.TRANSFER,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.EDUCATION + '-CHANGE',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.EDUCATION,
      //     mappedData,
      //     PracticalActionsEnum.CHANGE,
      //     EssentialActionsEnum.CHANGE_INVESTMENT_PLAN,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.EDUCATION + '-CHANGE-BENEFICIARIES',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.EDUCATION,
      //     mappedData,
      //     PracticalActionsEnum.CHANGE,
      //     EssentialActionsEnum.CHANGE_BENEFICIARIES,
      //   ),
      // },

      //PROVIDENT
      {
        Category: PensionCategoriesEnum.PROVIDENT + '-NEW',
        Result: await this.buildFormallyPerCategory(
          userProfile,
          PensionCategoriesEnum.PROVIDENT,
          mappedData,
          PracticalActionsEnum.NEW,
        ),
      },
      // {
      //   Category: PensionCategoriesEnum.PROVIDENT + '-TRANSFER',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.PROVIDENT,
      //     mappedData,
      //     PracticalActionsEnum.TRANSFER,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.PROVIDENT + '-CHANGE',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.PROVIDENT,
      //     mappedData,
      //     PracticalActionsEnum.CHANGE,
      //     EssentialActionsEnum.CHANGE_INVESTMENT_PLAN,
      //   ),
      // },

      //INVESTMENT
      // {
      //   Category: PensionCategoriesEnum.INVESTMENT + '-NEW',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.INVESTMENT,
      //     mappedData,
      //     PracticalActionsEnum.NEW,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.INVESTMENT + '-TRANSFER',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.INVESTMENT,
      //     mappedData,
      //     PracticalActionsEnum.TRANSFER,
      //   ),
      // },
      // {
      //   Category: PensionCategoriesEnum.INVESTMENT + '-CHANGE',
      //   Result: await this.buildFormallyPerCategory(
      //     userProfile,
      //     PensionCategoriesEnum.INVESTMENT,
      //     mappedData,
      //     PracticalActionsEnum.CHANGE,
      //     EssentialActionsEnum.CHANGE_INVESTMENT_PLAN,
      //   ),
      // },
    ];
  }

  async buildFormallyPerCategory(
    userProfile: DeepPartial<UserDetails>,
    category: PensionCategoriesEnum,
    mappedData: Formally.FormallyData,
    action: PracticalActionsEnum,
    changeAction?: EssentialActionsEnum,
  ): Promise<any> {
    const pensionCompanies = await this.pensionsService.findCompaniesByTargetPopulation('כלל האוכלוסיה');

    console.log('pensionCompanies', pensionCompanies);
    //get  companies funds
    const companyFundsArr = [];
    for (let i = 0; i < pensionCompanies.length; i++) {
      const funds = await this.getCompanyFunds(pensionCompanies[i]['companyid'], category);
      if (!funds || funds.length === 0) {
        continue;
      }
      console.log('funds-length', funds.length);
      console.log('funds', funds[0]);

      companyFundsArr.push({ Funds: funds, ...pensionCompanies[i] });
    }

    const arr = [];
    // const totalCompanies = companyFundsArr.length;
    // for (let i = 0; i < totalCompanies; i++) {
    //   const nextIndex = (i + 1) % totalCompanies;
    //   const fund = companyFundsArr[i].Funds[0];
    //
    //   const transferCompanyFund =
    //     action === PracticalActionsEnum.CHANGE && changeAction === EssentialActionsEnum.CHANGE_INVESTMENT_PLAN
    //       ? companyFundsArr[i].Funds[1]
    //       : action === PracticalActionsEnum.TRANSFER
    //       ? companyFundsArr[nextIndex].Funds[0]
    //       : fund;
    //
    //   if (action === PracticalActionsEnum.CHANGE && companyFundsArr[i].Funds.length < 2) {
    //     continue;
    //   }
    //
    //   const formallyProcessDataMapper = new FormallyProcessDataMapper(null, null, userProfile);
    //   const processData = formallyProcessDataMapper.getFormallyDataSimulation(
    //     fund,
    //     category,
    //     action,
    //     changeAction,
    //     transferCompanyFund,
    //   );
    //
    //   if (changeAction === EssentialActionsEnum.CHANGE_BENEFICIARIES) {
    //     mappedData.Beneficiaries = {
    //       Beneficiary: [
    //         {
    //           FirstNameMutav: 'FirstNameMutav',
    //           LastNameMutav: 'LastNameMutav',
    //           NameMutav: 'FirstNameMutav LastNameMutav',
    //           KirvaMutav: 'FATHER',
    //           ZeutMutav: '229963293',
    //           FullAddressMutav: 'test address field',
    //           MinMutav: 'זכר',
    //           BirthDateMutav: '01/01/1990',
    //           AhuzMutv: '100%',
    //           TypeIdent: TypeIdent.ID,
    //         },
    //       ],
    //     };
    //   }
    //
    //   const finalData = {
    //     ...mappedData,
    //     ProcessList: { ProcessData: processData },
    //   };
    //
    //   const response = await this.formallyManager.getFormsKit({ FormallyData: finalData });
    //   console.log('response-getFormsKit', JSON.stringify(response));
    //
    //   if (!response.includes('error')) {
    //     arr.push({
    //       companyId: fund.originalCompanyId,
    //       companyName: fund.companyName,
    //       ProcessUrl: response[0]?.ProcessUrl,
    //       // ErrDesc: response[0]?.ErrDesc,
    //       // ErrStatus: response[0]?.ErrStatus,
    //       // ProcessData: JSON.stringify(processData),
    //     });
    //   }
    // }
    //
    // const header = 'companyId\tcompanyName\tProcessUrl';
    // const rows = arr.map((r) => `${r.companyId}\t${r.companyName}\t${r.ProcessUrl}`);

    // return [header, ...rows].join('\n');
    return arr;
  }

  async sendRecommendationsToFormally(user: Users): Promise<any> {
    const userProfile = await this.userProfileService.getUserProfile(user.id);

    const userDocuments = await this.userDocumentsService.getUserDocuments(user, {
      group: 'PERSONAL',
      subGroup: 'PERSONALID',
    });

    // const base64Documents = await this.mergeImagesAndConvertToBase64(userDocuments[0].userDocumentsDetails);

    const mappedData = await this.getFormallyStaticStructure(userProfile);
    const processListArray = await this.processRecommendations(userProfile);

    const finalData = {
      ...mappedData,
      ProcessList: { ProcessData: processListArray },
      // ZeutAttachments: { ZeutAttachment: base64Documents },
    };

    const response = await this.formallyManager.getFormsKit({ FormallyData: finalData });
    console.log('response', JSON.stringify(response));

    await this.handleResponse(response, user.id, finalData);
  }

  private async processRecommendations(userProfile: DeepPartial<UserDetails>): Promise<Formally.ProcessData[]> {
    const userRecommendations = await this.recommendationsManager.getRecommendations(userProfile.id);
    const filteredData = userRecommendations.filter(
      (recommendation) =>
        recommendation.category !== PensionPortfolio.Categories.OTHER &&
        recommendation.category !== PensionPortfolio.Categories.INSURANCE,
    );

    const processListArray = [];
    for (const currentRecommendation of filteredData) {
      for (const currentTransaction of currentRecommendation.transactions) {
        const formallyProcessDataMapper = new FormallyProcessDataMapper(
          currentRecommendation.category,
          currentTransaction,
          userProfile,
        );
        processListArray.push(...formallyProcessDataMapper.getFormallyData());
      }
    }

    return processListArray;
  }

  private async getFormallyStaticStructure(userProfile: DeepPartial<UserDetails>): Promise<Formally.FormallyData> {
    return await this.formallyMapper.mapToFormallyData(userProfile);
  }

  private async handleResponse(response: any, userId: string, finalData: Formally.FormallyData): Promise<void> {
    if (!response.includes('error')) {
      const entryData = {
        userId,
        processGuid: finalData.ProcessGuid,
        payload: finalData,
        link: response[0].ProcessUrl,
        status: Formally.status.SENT as Formally.status,
        errorStatus: response[0].ErrStatus,
        errorDescription: response[0].ErrDesc,
      };
      await this.pensionFormallyService.save(entryData);
    }
  }

  async saveUserFormsKit(updateUserFormDto: UpdateUserFormDto): Promise<any> {
    const { idNumber, formLink } = updateUserFormDto;
    const userProfile = await this.userProfileService.getUserDetailsByIdNumber(idNumber);
    if (!userProfile) {
      throw new Error('An error occurred while processing the request');
    }
    await this.pensionFormallyService.save({
      id: uuidv4(),
      createdAt: new Date(),
      userId: userProfile.id,
      link: formLink,
    });

    return { status: 'success' };
  }

  private async mergeImagesAndConvertToBase64(userDocumentsDetails: UserDocumentsDetails[]) {
    const axios = this.httpService.axiosRef;

    // Load each image buffer and get dimensions
    const imageData = await Promise.all(
      userDocumentsDetails.map(async (documentDetail) => {
        const res = await axios.get(documentDetail.url, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(res.data);
        const metadata = await sharp(buffer).metadata();

        return {
          buffer,
          width: metadata.width || 0,
          height: metadata.height || 0,
        };
      }),
    );

    // Get max width and total height
    const totalHeight = imageData.reduce((sum, img) => sum + img.height, 0);
    const maxWidth = Math.max(...imageData.map((img) => img.width));

    // Prepare a composite list with correct top offset
    let currentTop = 0;
    const compositeImages = imageData.map(({ buffer, height }) => {
      const obj = { input: buffer, top: currentTop, left: 0 };
      currentTop += height;

      return obj;
    });

    // Create canvas and composite images
    const mergedBuffer = await sharp({
      create: {
        width: maxWidth,
        height: totalHeight,
        channels: 4,
        background: { r: 255, g: 255, b: 255, alpha: 1 },
      },
    })
      .composite(compositeImages)
      .jpeg()
      .toBuffer();

    return mergedBuffer.toString('base64');
  }

  private async getCompanyFunds(companyId: string, category: PensionCategoriesEnum): Promise<FundPension[]> {
    const [data] = await this.pensionsService.getFundsByFilter(
      PensionFundFilterEnum.ORIGINAL_COMPANY_ID,
      companyId,
      {
        riskLevel: 3,
        category: category,
        excludedCategories: ['11'],
      },
      0,
      20,
      true,
    );

    return data;
  }
}
