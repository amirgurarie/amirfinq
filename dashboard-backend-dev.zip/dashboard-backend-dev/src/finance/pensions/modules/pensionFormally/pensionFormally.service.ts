import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ServiceHelper } from 'src/shared/modules/service.helper';
import { UserPensionRecommendationsFormally } from '../../../../entities';

@Injectable()
export class PensionFormallyService extends ServiceHelper<UserPensionRecommendationsFormally> {
  constructor(
    @InjectRepository(UserPensionRecommendationsFormally)
    private readonly queriesRepository: Repository<UserPensionRecommendationsFormally>,
  ) {
    super(queriesRepository);
  }
}
