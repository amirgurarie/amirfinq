import { Injectable } from '@nestjs/common';
import { Funds } from 'src/entities/Funds';
import { RefAssetType } from 'src/entities/RefAssetType';
import { FundsService } from './funds/funds.service';
import { AssetsService } from './fundsCommon/assets.service';
import { FavoriteItemType, UnifiedAssets } from './portfolios/interfaces/asset.type';
import { AssetTypes } from './portfolios/interfaces/assetType.const';
import { StocksService } from './stocks/stocks.service';
import { isNullOrUndefined } from 'src/shared/helpers/utils';

const getAssetId = ({ assetId }) => assetId;
const concatArrayArgs = (...args: any[]) => (args?.length ? args.reduce((acc, curr) => acc.concat(curr), []) : []);
@Injectable()
export class AssetsHelper {
  constructor(
    protected readonly fundsService: FundsService,
    protected readonly assetsService: AssetsService,
    protected readonly stocksService: StocksService,
  ) {}

  /// Does not return portfolio selections assets
  public getAsset(
    assetType: RefAssetType | string,
    funds: Funds[],
    assets: UnifiedAssets[],
    assetId: string,
  ): FavoriteItemType {
    if (this.getAssetTypeId(assetType) === AssetTypes.Fund) {
      return funds.find((el) => {
        return el.id === assetId;
      });
    }

    return assets.find((el) => {
      // normal asset (stock for eg.)
      return this.getAssetId(el) === assetId;
    });
  }

  public getAssetTypeId(assetType: RefAssetType | string): string {
    return typeof assetType === 'string' ? assetType : assetType?.id;
  }

  public getAssetId(asset: FavoriteItemType): string | number {
    if ('id' in asset && !isNullOrUndefined(asset?.id)) {
      return asset.id;
    } else if ('assetId' in asset && !isNullOrUndefined(asset?.assetId)) {
      return asset.assetId;
    }

    return null;
  }

  public cleanPrefixedId(id: string): string {
    return id.includes('-') ? id.split('-')[1] : id;
  }

  private filterAssetsByType(
    assets: { assetType: RefAssetType | string; assetId: string }[],
    types: (RefAssetType | string)[],
    equals = true,
  ) {
    return assets.filter((item) => {
      const getId = this.getAssetTypeId(item.assetType);

      return equals ? types.includes(getId) : !types.includes(getId);
    });
  }

  public getFundsAssetsLists(
    allAssets: { assetType: RefAssetType | string; assetId: string }[],
  ): Promise<[Funds[], UnifiedAssets[]]> {
    const fundsList = this.filterAssetsByType(allAssets, [AssetTypes.Fund]).map(getAssetId);
    const stocksList = this.filterAssetsByType(allAssets, [AssetTypes.Stock]).map(getAssetId);
    const restOfAssetsList = this.filterAssetsByType(allAssets, [AssetTypes.Fund, AssetTypes.Stock], false).map(
      getAssetId,
    );

    // get both assets and stocks and concat them into one array

    const promises = Promise.all([
      this.fundsService.findFundsByArrayIds(fundsList), // get funds
      this.stocksService.findStocksByArrayIds(stocksList), // get stocks
      this.assetsService.findAssetsByArrayIds(restOfAssetsList), // get all assets except stocks and funds
    ]);

    return promises.then(([funds, ...assets]) => [funds, concatArrayArgs(...assets)]);
  }
}

export const StaticAssetsHelper = new AssetsHelper(null, null, null);
