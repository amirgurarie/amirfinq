import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Not, Repository } from 'typeorm';
import { FundsQueryParameters, getOrderByValues } from './dto/funds.dto';
import { ParametersHelper } from '../parameters.helper';
import { FundsSortTypesEnum } from './fundsSortTypes.enum';
import { IFundDividends } from './interfaces/fundDividends.interface';
import { FinanceHelper } from '../finance.helper';
import { IFundAssetType } from '../fundsCommon/fundAssetType.interface';
import { FUND_ASSET_TYPE } from '../portfolios/interfaces/assetType.const';
import { AssetType, getFinqRiskLevelFromObject } from '../portfolios/interfaces/asset.type';
import { FundsByClassificationDto } from './dto/fundByClassification';
import { InternalCategoriesListSubject } from './subject/fundCategories.subject';
import { FundCategoriesHelper } from './FundCategories.helper';
import {
  Funds,
  Users,
  RefFundType,
  RefFundHouse,
  RefFundSubType,
  RefFundSubCategory,
  UserFavorite,
} from 'src/entities';

@Injectable()
export class FundsService {
  constructor(
    @InjectRepository(Funds)
    private readonly fundsRepository: Repository<Funds>,
    @InjectRepository(RefFundHouse)
    private readonly fundsHousesRepository: Repository<RefFundHouse>,
    @InjectRepository(RefFundType)
    private readonly refFundTypeRepository: Repository<RefFundType>,
    @InjectRepository(RefFundSubType)
    private readonly refFundSubTypeRepository: Repository<RefFundSubType>,
    @InjectRepository(RefFundSubCategory)
    private readonly refFundSubCategoryRepository: Repository<RefFundSubCategory>,
  ) {}

  public async getFundSecondaries(type: 'category' | 'subtype' | 'type', forUi = true) {
    const RepoTypes: Record<string, Repository<any>> = {
      type: this.refFundTypeRepository,
      subtype: this.refFundSubTypeRepository,
      category: this.refFundSubCategoryRepository,
    };

    return RepoTypes[type].find({
      order: { uiOrder: 'ASC' },
      where: forUi ? { uiOrder: Not(0) } : {},
    });
  }

  public async getFundsHouses(filters: FundsByClassificationDto = null) {
    const fundQuery = this.fundsRepository
      .createQueryBuilder('funds')
      .addFrom(RefFundHouse, 'ref_fund_house')
      .select('distinct ref_fund_house.id AS "_houseId"')
      .addSelect(['funds.fundClassification AS "_fundClassification"', 'ref_fund_house.uiOrder AS "_houseUiOrder"'])
      .where('funds.fund_house = ref_fund_house.id')
      .orderBy('"_houseUiOrder"', 'DESC', 'NULLS LAST');

    if (filters.classification) {
      fundQuery.andWhere('funds.fundClassification = :classification', {
        classification: filters.classification,
      });
    }

    const [fundHouses, classificationOccurrences] = await Promise.all<
      RefFundHouse[],
      { _houseId: string; _fundClassification: string }[]
    >([this.findAllFundsHouses(), fundQuery.getRawMany()]);

    const classificationOccurrencesMap = classificationOccurrences.reduce((acc, { _houseId, _fundClassification }) => {
      acc[_houseId] = acc[_houseId] || [];
      _fundClassification && acc[_houseId].push(_fundClassification);

      return acc;
    }, {} as Record<string, string[]>);

    return fundHouses
      .map((fundHouse) => {
        return {
          ...fundHouse,
          classifications: classificationOccurrencesMap[fundHouse.id],
        };
      })
      .filter((category) => category.classifications?.length);
  }

  public async getFundsCategories(filters: FundsByClassificationDto = null) {
    const relatedSubCategoriesQuery = FundCategoriesHelper.getRelatedSubCategoriesQuery(this.fundsRepository);
    const relatedSecondaryClassificationsQuery = FundCategoriesHelper.getRelatedSecondaryClassificationsQuery(
      this.fundsRepository,
    );

    if (filters.classification) {
      relatedSubCategoriesQuery.andWhere('funds.fundClassification = :classification', {
        classification: filters.classification,
      });
      relatedSecondaryClassificationsQuery.andWhere('funds.fundClassification = :classification', {
        classification: filters.classification,
      });
    }

    const [categories, relatedSubCategories, relatedSecondaryClassifications] = await Promise.all<
      RefFundType[],
      InternalCategoriesListSubject[],
      any[]
    >([
      this.refFundTypeRepository.find({ order: { uiOrder: 'ASC' }, where: { uiOrder: Not(0) } }),
      relatedSubCategoriesQuery.getRawMany(),
      relatedSecondaryClassificationsQuery.getRawMany(),
    ]);

    const secClassesMap = FundCategoriesHelper.arrayToUniqueMap<InternalCategoriesListSubject>(
      relatedSecondaryClassifications,
      '_catId',
    );

    const subCategoriesMap = FundCategoriesHelper.arrayToUniqueMap<InternalCategoriesListSubject>(
      relatedSubCategories,
      '_catId',
      (subCategory) => ({ ...subCategory, secondaryClassifications: secClassesMap[subCategory.id] }),
    );

    return categories
      .map((category) => {
        const subCategories = subCategoriesMap[category.id] ?? [];

        return {
          ...category,
          subCategories,
          classifications: [...new Set(subCategories.map((subCat) => subCat._fundClassification))],
        };
      })
      .filter((category) => category.subCategories?.length);
  }

  public async getCashByFund(fundId: string): Promise<IFundAssetType> {
    const percentageRes = await this.fundsRepository
      .createQueryBuilder('funds')
      .select([`sum(funds.deposit_exposure/funds.fund_size) as percentage`])
      .where(`funds.id = :fundId`, {
        fundId,
      })
      .andWhere('funds.fund_size != 0')
      .getRawOne();

    return {
      id: 'cash',
      name_en: 'Cash',
      name_he: 'מזומן',
      percentage: Number(percentageRes.percentage),
    };
  }

  public findAllFunds(
    skip: number,
    take: number,
    user?: Users,
    filters: FundsQueryParameters = null,
  ): Promise<[Funds[], number]> {
    const [sortBy, orderBy] = getOrderByValues(filters?.sortBy, filters?.order);

    const query = this.fundsRepository
      .createQueryBuilder('funds')
      .leftJoinAndSelect('funds.fundHouse', 'fund_house')
      .leftJoinAndSelect('funds.fundType', 'fund_type', 'fund_type.id = funds.fundType')
      .leftJoinAndSelect('funds.fundSubCategory', 'fund_sub_category', 'fund_sub_category.id = funds.fundSubCategory')
      .innerJoinAndSelect(
        'funds.fundClassification',
        'fund_classification',
        'fund_classification.id = funds.fundClassification',
      )
      .innerJoinAndSelect(
        'funds.secondaryClassification',
        'secondary_classification',
        'secondary_classification.id = funds.secondaryClassification',
      )
      .orderBy(sortBy, orderBy, 'NULLS LAST');

    if (filters.fundHouse) {
      query.andWhere(
        '(fund_house.id in (:...fundHouse) OR fund_house.fund_house in (:...fundHouse) OR fund_house.fund_house_en in (:...fundHouse))',
        {
          fundHouse: ParametersHelper.getArrayParams(filters.fundHouse),
        },
      );
    }

    if (filters.classification) {
      query.andWhere('funds.fund_classification = :type', {
        type: filters.classification,
      });
    }

    if (filters.secondaryClassification) {
      query.andWhere('funds.secondaryClassification = :anotherType', {
        anotherType: filters.secondaryClassification,
      });
    }

    if (filters.fundType) {
      query.andWhere('funds.fund_type in (:...fundType)', {
        fundType: ParametersHelper.getArrayParams(filters.fundType),
      });
    }

    if (filters.fundSubType) {
      query.andWhere('funds.fund_type in (:...fundSubType)', {
        fundSubType: ParametersHelper.getArrayParams(filters.fundSubType),
      });
    }

    if (filters.fundSubCategory) {
      query.andWhere('funds.fund_sub_category in (:...fundSubCategory)', {
        fundSubCategory: ParametersHelper.getArrayParams(filters.fundSubCategory),
      });
    }

    if (filters.search) {
      query.andWhere(
        ...ParametersHelper.addSearch(filters.search, [
          'funds.description',
          'funds.descriptionEn',
          'fund_house.fundHouse',
          'fund_house.fundHouseEn',
        ]),
      );
    }

    return query.offset(skip).limit(take).getManyAndCount();
  }

  private oldSortByLogic(filters: any, query: any, user: Users) {
    switch (filters.sort) {
      case FundsSortTypesEnum.Highest1YearYield:
        query.orderBy('funds.yield_1_year', 'DESC', 'NULLS LAST');
        break;

      case FundsSortTypesEnum.Lowest1YearYield:
        query.orderBy('funds.yield_1_year', 'ASC', 'NULLS LAST');
        break;

      case FundsSortTypesEnum.Newest:
        query.orderBy('funds.foundation_date', 'DESC', 'NULLS LAST');
        break;

      case FundsSortTypesEnum.Oldest:
        query.orderBy('funds.foundation_date', 'ASC', 'NULLS LAST');
        break;

      case FundsSortTypesEnum.Rating:
        query.orderBy('funds.rating', 'DESC', 'NULLS LAST');
        break;

      case FundsSortTypesEnum.BestMatch:

      default:
        if (user) {
          const userfinqRiskLevel = user.finqRiskLevel === null ? 0 : user.finqRiskLevel;
          query.orderBy(`((1-abs(${userfinqRiskLevel}-funds.finq_risk_level)))`, 'DESC', 'NULLS LAST');
        } else {
          query.orderBy('funds.yield_1_year', 'DESC', 'NULLS LAST');
        }

        break;
    }
  }

  public addAdditionalData(
    assets: AssetType[],
    additionalData: { currency: string; user?: Users; batchRunDate: Date },
  ): Array<AssetType & { matchPercentage: number; currency: string }> {
    return assets.map((asset: AssetType) => {
      return Object.assign(asset, {
        matchPercentage: FinanceHelper.calculateFundMatchPercentage(
          additionalData?.user ? additionalData?.user?.finqRiskLevel : 0,
          getFinqRiskLevelFromObject(asset, 1),
        ),
        currency: additionalData.currency,
        batchRunDate: additionalData.batchRunDate,
      });
    });
  }

  public async findFundById(fundId: string): Promise<Funds> {
    return await this.fundsRepository.findOne(fundId, {
      relations: [
        'fundHouse',
        'fundSubCategory',
        'fundSubType',
        'benchmark',
        'fundClassification',
        'fundType',
        'fundDividends',
        'taxStatus',
        'secondaryClassification',
      ],
    });
  }

  public async findFundsByArrayIds(fundIds: string[]): Promise<Funds[]> {
    if (!fundIds.length) return Promise.resolve([]);

    return await this.fundsRepository.findByIds([...new Set(fundIds)], {
      relations: ['fundHouse', 'fundDividends', 'fundType'],
    });
  }

  public async getFavoriteFunds(user: Users, skip: number, take: number): Promise<[Funds[], number]> {
    const query = this.fundsRepository
      .createQueryBuilder('funds')
      .leftJoin(UserFavorite, 'favoriteAssets', 'favoriteAssets.asset_id=funds.id')
      .where('favoriteAssets.user_id = :userId', { userId: user.id })
      .andWhere('favoriteAssets.asset_type = :assetType', {
        assetType: FUND_ASSET_TYPE,
      })
      .orderBy('favoriteAssets.add_to_favorite_date', 'DESC');

    return await query.offset(skip).limit(take).getManyAndCount();
  }

  public findAllFundsHouses(): Promise<RefFundHouse[]> {
    return this.fundsHousesRepository.find({
      order: { uiOrder: 'ASC' },
      where: { uiOrder: Not(0) },
    });
  }

  public async findDividends(fundId: string): Promise<IFundDividends[]> {
    return await this.fundsRepository
      .createQueryBuilder('funds')
      .select([
        'fundDividends.dividend_date',
        'sum(fundDividends.rate) as dividend_rate',
        'sum(fundDividends.yield) as dividend_yield',
      ])
      .leftJoin('funds.fundDividends', 'fundDividends')
      .where('funds.id = :fundId', {
        fundId,
      })
      .andWhere('fundDividends.fund_id is not null')
      .groupBy('fundDividends.dividend_date')
      .getRawMany();
  }
}
