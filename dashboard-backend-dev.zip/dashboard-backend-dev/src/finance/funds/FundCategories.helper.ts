import { Funds, RefFundSecondaryClassification, RefFundSubCategory, RefFundType } from 'src/entities';
import { Repository } from 'typeorm';

export class FundCategoriesHelper {
  // --------------------------------- Methods ---------------------------------
  static arrayToUniqueMap<T = any>(arr: any[], idField = '_catId', mapItem = (v: T) => v) {
    const map = arr.reduce((acc, obj) => {
      if (!(idField in obj)) throw new Error(`Missing field ${idField} in object ${JSON.stringify(obj)}`);

      const id = obj[idField];
      delete obj[idField];

      if (obj && !acc[id]?.find((v) => v.id === obj.id)) {
        acc[id] = [...(acc[id] ?? []), mapItem(obj)];
      }

      return acc;
    }, {});

    return map as Record<string, T[]>;
  }

  // --------------------------------- Queries ---------------------------------
  static getRelatedSubCategoriesQuery(repository: Repository<Funds>) {
    const query = repository
      .createQueryBuilder('funds')
      .addFrom(RefFundType, 'ref_fund_type')
      .addFrom(RefFundSubCategory, 'ref_fund_sub_category')
      .select('distinct ref_fund_type.id AS "_catId"')
      .addSelect([
        // Internal use variables
        'funds.fundClassification AS "_fundClassification"',
        'ref_fund_type.uiOrder AS "_catUiOrder"',
        'count(*) AS "subCategoriesCount"',
        // Sub category fields
        'ref_fund_sub_category.id AS "id"',
        'ref_fund_sub_category.descriptionHe AS "descriptionHe"',
        'ref_fund_sub_category.descriptionEn AS "descriptionEn"',
      ])
      .where('funds.fund_type = ref_fund_type.id')
      .andWhere('funds.fund_sub_category = ref_fund_sub_category.id')
      .orderBy('"_catUiOrder"', 'DESC', 'NULLS LAST')
      .addOrderBy('"subCategoriesCount"', 'DESC', 'NULLS LAST')
      .groupBy(
        'ref_fund_type.id, ref_fund_sub_category.id, funds.fundClassification, ref_fund_sub_category.descriptionHe, ref_fund_sub_category.descriptionEn',
      );

    return query;
  }

  static getRelatedSecondaryClassificationsQuery(repository: Repository<Funds>) {
    const query = repository
      .createQueryBuilder('funds')
      .addFrom(RefFundSubCategory, 'ref_fund_sub_category')
      .addFrom(RefFundSecondaryClassification, 'ref_sec_class')
      .select('distinct ref_fund_sub_category.id AS "_catId"')
      .addSelect([
        // Internal use variables
        'funds.fundClassification AS "_fundClassification"',
        'funds.fundClassification',
        'count(*) AS "secondaryClassesCount"',
        // Sub category fields
        'ref_sec_class.id AS "id"',
        'ref_sec_class.descriptionHe AS "descriptionHe"',
        'ref_sec_class.descriptionEn AS "descriptionEn"',
      ])
      .where('funds.fund_sub_category = ref_fund_sub_category.id')
      .andWhere('funds.secondary_classification = ref_sec_class.id')
      .orderBy('"secondaryClassesCount"', 'DESC', 'NULLS LAST')
      .groupBy('ref_fund_sub_category.id, ref_sec_class.id, funds.fundClassification');

    return query;
  }
}
