import { applyDecorators } from '@nestjs/common';
import { IsOptional } from 'class-validator';
import { ApiQuery } from '@nestjs/swagger';
import { IsInInsensitive } from 'src/shared/validators/isInInsensitive';
import { FundsClassificationEnum } from '../fundsClassification.enum';

export class FundsByClassificationDto {
  @IsOptional()
  @IsInInsensitive(Object.values<string>(FundsClassificationEnum))
  public readonly classification?: FundsClassificationEnum = null; // FundsClassificationEnum.OPEN;
}

export function ApiFundsByClassificationQuery() {
  return applyDecorators(
    ApiQuery({
      name: 'classification',
      enum: FundsClassificationEnum,
      description: `One of: ${Object.values(FundsClassificationEnum)}`,
      required: false,
    }),
  );
}
