import { applyDecorators } from '@nestjs/common';
import { PaginationDto } from '../../../shared/dto/pagination.dto';
import { IsOptional, IsString } from 'class-validator';
import { IsListString } from '../../../shared/validators/isListString';
import { IsInInsensitive } from '../../../shared/validators/isInInsensitive';
import { ConstraintTypeEnum } from 'src/shared/validators/constraints/isListStringConstraint';
import { ApiQuery } from '@nestjs/swagger';
import { IsCaseSensitive } from 'src/shared/validators/isCaseSensitive';
import { OrderEnum } from 'src/shared/enums';
import { FundsClassificationEnum } from '../fundsClassification.enum';

export enum FundPricingSortByField {
  dailyPriceChange = 'dailyPriceChange',
  oneMonthYield = '1MonthYield',
  yearTdYield = 'yearTdYield',
  oneYearYield = 'oneYearYield',
  threeYearYield = '3YearYield',
  fiveYearYield = '5YearYield',
}

export enum FundsOtherSortBy {
  name = 'name',
  category = 'category',
  lastChangeDate = 'lastChangeDate',
  managementFee = 'managementFee',
}

export const FundsSortBy = { ...FundsOtherSortBy, ...FundPricingSortByField };

export type FundsSortBy = keyof typeof FundsSortBy;

export const FundsSortByMap = {
  [FundsSortBy.name]: 'fund_house.fundHouse',
  [FundsSortBy.category]: 'fund_type.descriptionHe',
  [FundsSortBy.lastChangeDate]: 'funds.lastChangeDate',
  [FundsSortBy.managementFee]: 'funds.managementFee',
  [FundsSortBy.dailyPriceChange]: 'funds.dailyPriceChange',
  [FundsSortBy.oneMonthYield]: 'funds.yield_1Month',
  [FundsSortBy.oneYearYield]: 'funds.yield_1Year',
  [FundsSortBy.threeYearYield]: 'funds.yield_3Years',
  [FundsSortBy.fiveYearYield]: 'funds.yield_5Years',
  [FundsSortBy.yearTdYield]: 'funds.yieldYtd',
};

/**
 * Because pricing fields are containing negative values, when sorting by them, we need to change the order
 * @param sortBy - the field to sort by
 * @param order - the order of the sort
 */
export const getOrderByValues = (
  sortBy: FundsSortBy,
  order: keyof typeof OrderEnum,
): [string, keyof typeof OrderEnum] => {
  const isPricingSortBy = Object.values(FundPricingSortByField).includes(sortBy as FundPricingSortByField);
  if (!isPricingSortBy) {
    return [FundsSortByMap[sortBy], order];
  }

  const oppositeOrder = order === OrderEnum.ASC ? OrderEnum.DESC : OrderEnum.ASC;

  return [FundsSortByMap[sortBy], oppositeOrder];
};

export class PaginatedWithSortByDto extends PaginationDto {
  @IsString()
  @IsOptional()
  @IsCaseSensitive(Object.values(FundsSortBy))
  public readonly sortBy?: FundsSortBy = FundsSortBy.dailyPriceChange;

  @IsOptional()
  @IsCaseSensitive(Object.values(OrderEnum))
  public readonly order?: OrderEnum = OrderEnum.ASC;
}

export type FundsQueryParameters = Omit<FundsDto, 'index' | 'size'>;

export class FundsDto extends PaginatedWithSortByDto {
  @IsOptional()
  public readonly fundHouse?: string;

  @IsOptional()
  @IsInInsensitive(Object.values<string>(FundsClassificationEnum))
  public readonly classification?: FundsClassificationEnum;

  @IsOptional()
  @IsListString(ConstraintTypeEnum.String)
  public readonly secondaryClassification?: string;

  @IsOptional()
  @IsListString(ConstraintTypeEnum.String)
  public readonly fundType?: string;

  @IsOptional()
  @IsListString(ConstraintTypeEnum.String)
  public readonly fundSubType?: string;

  @IsOptional()
  @IsListString(ConstraintTypeEnum.String)
  public readonly fundSubCategory?: string;

  @IsOptional()
  @IsString()
  public readonly search?: string;
}

export function ApiFundsSortBy() {
  return applyDecorators(
    ApiQuery({
      name: 'sortBy',
      enum: FundsSortBy,
      description: `One of: ${Object.values(FundsSortBy)}`,
      required: false,
    }),

    ApiQuery({
      name: 'order',
      enum: OrderEnum,
      description: `One of: ${Object.values(OrderEnum)}`,
      required: false,
    }),
  );
}

export function FundsApiQueryParameters() {
  return applyDecorators(
    ApiQuery({
      name: 'fundHouse',
      required: false,
      type: String,
      description:
        'Must be a comma-separated list of strings. Each of the strings will be used for strict comparison with fund houses names',
    }),

    ApiQuery({
      name: 'classification',
      enum: FundsClassificationEnum,
      description: `One of: ${Object.values(FundsClassificationEnum)}`,
      required: false,
    }),

    ApiQuery({
      name: 'secondaryClassification',
      required: false,
      type: String,
      description: 'Must be a comma-separated list of strings, can have several elements. Сan be empty.',
    }),

    ApiQuery({
      name: 'fundType',
      required: false,
      type: String,
      description: 'Must be a comma-separated list of strings, can have several elements. Сan be empty.',
    }),

    ApiQuery({
      name: 'fundSubType',
      required: false,
      type: String,
      description: 'Must be a comma-separated list of strings, can have several elements. Сan be empty.',
    }),

    ApiQuery({
      name: 'fundSubCategory',
      required: false,
      type: String,
      description: 'Must be a comma-separated list of strings, can have several elements. Сan be empty.',
    }),

    ApiQuery({
      name: 'managementFee',
      required: false,
      type: String,
      description: 'Must be above1.5, below1.5 or none. Сan be empty.',
    }),

    ApiQuery({
      name: 'classification',
      required: false,
      enum: FundsClassificationEnum,
      description: `One of: ${Object.values(FundsClassificationEnum)}. Сan be empty.`,
    }),

    ApiQuery({
      name: 'search',
      required: false,
      type: String,
      description: 'Search for funds by name',
    }),
  );
}
