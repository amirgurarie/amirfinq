export interface IFundDividends {
  dividend_date: string | number;
  dividend_rate: number;
  dividend_yield: number;
}
