export interface IFundSector {
  percentage: number;
  sector_id: string;
  sector_description_en: string;
  sector_description_he: string;
}
