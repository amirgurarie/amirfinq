export interface IFundCurrency {
  percentage: number;
  currency_id: string;
  currency_description: string;
  currency_description_en: string;
}
