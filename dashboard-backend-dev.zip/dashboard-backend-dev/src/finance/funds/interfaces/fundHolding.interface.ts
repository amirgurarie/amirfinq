export interface IFundHolding {
  fund_assets_asset_id: string;
  fund_assets_percentage: string;
  assets_description: string;
  fund_assets_turnover: string;
  assets_yield_month12: string;
}
