export interface IFundLocation {
  percentage: number;
  location_id: string;
  location_description_en: string;
  location_description_he: string;
}
