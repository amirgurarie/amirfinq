export enum FundsTypeEnum {
  M = 'M',
  S = 'S',
  B = 'B',
}
