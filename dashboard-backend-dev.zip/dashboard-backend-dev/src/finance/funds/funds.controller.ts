import { AbstractController } from '../../shared/controller';
import { ConfigService } from '@nestjs/config';
import { GeneralParametersService } from '../../shared/modules/generalParameters/generalParameters.service';
import { FundsService } from './funds.service';
import { ApiBearerAuth, ApiExtraModels, ApiOperation, ApiParam, ApiQuery, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Controller, Get, Param, Query, UseFilters, UseGuards, UseInterceptors } from '@nestjs/common';
import { NotFoundExceptionFilter } from '../../shared/filters/notFoundException.filter';
import { FundYieldsAdditionalDataSubject } from './subject/fundYieldsAdditionalData.subject';
import { FundYieldsYAxisSubject } from './subject/fundYieldsYAxis.subject';
import { FinanceHelper } from '../finance.helper';
import { ApiFailedHttpResponse } from '../../shared/decorators/apiFailedHttpResponse.decorator';
import { TransformInterceptor } from '../../shared/interceptors/transform.interceptor';
import { ApiChartsQuery } from '../../shared/decorators/apiChartsQuery.decorator';
import { errorSchemaResponse } from '../../shared/decorators/errorSchemaResponse';
import { DatasetsChartTransformInterceptor } from '../../shared/interceptors/datasetsChartTransform.interceptor';
import { dataChartSchemaResponse } from '../dataChartSchemaResponse';
import { FundAssetsService } from '../fundsCommon/fundAssets.service';
import { FundItemDistributionService } from '../fundsCommon/fundItemsDistribution.service';
import { PortfolioGraphResponseSubject } from '../../shared/subjects/charts/chartStatistics.subject';

import {
  ApiDataArrayResponse,
  ApiDataObjectResponse,
  ApiDataPaginatedResponse,
} from '../../shared/decorators/dataResponse.decorator';
import { FundHouseSubject } from './subject/fundHouse.subject';
import { ApiPaginationQuery } from '../../shared/decorators/apiPaginationQuery.decorator';
import { ApiFundsSortBy, FundsApiQueryParameters, FundsDto } from './dto/funds.dto';
import { FundResultSubject } from './subject/fundResult.subject';
import { PaginationTransformInterceptor } from '../../shared/interceptors/paginationTransform.interceptor';
import { BadRequestExceptionFilter } from '../../shared/filters/badRequestException.filter';
import { CurrentAuthUser } from '../../auth/currentAuthUser.decorator';
import { AuthenticatedUser } from '../../shared/types/authenticatedUser.interface';
import { FundAssetTypeSubject } from './subject/fundAssetType.subject';
import { FundSectorSubject } from './subject/fundSector.subject';
import { PaginationDto } from '../../shared/dto/pagination.dto';
import { FundHoldingSubject } from './subject/fundHolding.subject';
import { GeneralParameters } from '../../entities/GeneralParameters';
import { FundLocationSubject } from './subject/fundLocation.subject';
import { IFundHolding } from './interfaces/fundHolding.interface';
import { ApiFinanceAssetTypeDecorator } from '../../shared/decorators/apiFinanceAssetType.decorator';
import { YieldsService } from '../fundsCommon/yields.service';
import { FundDividendsSubject } from './subject/fundDividends.subject';
import { FundCurrencySubject } from './subject/fundCurrency.subject';
import { ExistedFundGuard } from './existedFund.guard';
import { ChartQueryDto } from '../portfolios/dto/chartQuery.dto';
import { AnonymousLocalJwtAuthGuard } from 'src/shared/guards/anonymousLocalJwtAuth.guard';
import { Funds } from 'src/entities/Funds';
import { NotFoundError } from 'src/shared/errors/notFound.error';
import { SharedRefListSubject } from 'src/shared/subjects/sharedRefList.subject';
import { FundCategoriesSubject } from './subject/fundCategories.subject';
import { ApiFundsByClassificationQuery, FundsByClassificationDto } from './dto/fundByClassification';

@ApiTags('Finance')
@Controller('v1/funds')
@UseFilters(NotFoundExceptionFilter, BadRequestExceptionFilter)
@ApiExtraModels(
  FundHouseSubject,
  FundResultSubject,
  FundAssetTypeSubject,
  FundHoldingSubject,
  FundLocationSubject,
  FundSectorSubject,
  FundDividendsSubject,
  FundCurrencySubject,
  SharedRefListSubject,
  FundCategoriesSubject,
)
export class FundsController extends AbstractController {
  constructor(
    private readonly yieldService: YieldsService,
    protected readonly configService: ConfigService,
    private readonly generalParametersService: GeneralParametersService,
    private readonly fundsService: FundsService,
    private readonly fundAssetsService: FundAssetsService,
    private readonly fundItemDistributionService: FundItemDistributionService,
  ) {
    super(configService);
  }

  @Get()
  @ApiOperation({ summary: 'Get Funds' })
  @ApiDataPaginatedResponse(FundResultSubject, 'Funds')
  @UseGuards(AnonymousLocalJwtAuthGuard)
  @ApiBearerAuth()
  @ApiFundsSortBy()
  @FundsApiQueryParameters()
  @ApiPaginationQuery()
  @ApiFailedHttpResponse()
  @UseInterceptors(PaginationTransformInterceptor)
  public async getFunds(@CurrentAuthUser() authUserPayload: AuthenticatedUser, @Query() query: FundsDto) {
    const { index, size, ...fundParameters } = query;
    const { skip, take } = this.pagination(index, size);

    const [rawFundsAndTotal, generalParameters] = await Promise.all<[Funds[], number], GeneralParameters>([
      this.fundsService.findAllFunds(skip, take, authUserPayload?.user, fundParameters),
      this.generalParametersService.findFirst(),
    ]);
    const [rawFunds, total] = rawFundsAndTotal;

    const currency = FinanceHelper.getCurrencySign(generalParameters.currency);

    const fundsResults = this.fundsService.addAdditionalData(rawFunds, {
      currency,
      user: authUserPayload?.user,
      batchRunDate: generalParameters.fundBatchRunDate,
    });

    const funds = this.transformToArray(fundsResults, FundResultSubject);

    return {
      data: funds,
      total,
      index: skip,
      size: funds.length,
    } as IPaginatedDataResponse<FundResultSubject>;
  }

  @Get('categories')
  @ApiOperation({ summary: 'Get Funds categories with sub categories data' })
  @ApiDataArrayResponse(FundCategoriesSubject, 'Funds')
  @ApiFailedHttpResponse()
  @ApiFundsByClassificationQuery()
  @UseInterceptors(TransformInterceptor)
  public async getFundCategories(@Query() query: FundsByClassificationDto) {
    const categories = await this.fundsService.getFundsCategories(query);

    return this.transformToArray(categories, FundCategoriesSubject);
  }

  @Get('houses')
  @ApiOperation({
    summary: 'Get funds houses',
  })
  @ApiDataArrayResponse(FundHouseSubject, 'Funds houses')
  @ApiFailedHttpResponse()
  @ApiFundsByClassificationQuery()
  @UseInterceptors(TransformInterceptor)
  public async getAllFundsHouses(@Query() query: FundsByClassificationDto) {
    const houses = await this.fundsService.getFundsHouses(query);

    return this.transformToArray(houses, FundHouseSubject);
  }

  @Get(':fundId')
  @ApiParam({
    name: 'fundId',
    required: true,
  })
  @ApiOperation({ summary: 'Get Fund by id' })
  @ApiDataObjectResponse(FundResultSubject, 'Fund data')
  @UseGuards(AnonymousLocalJwtAuthGuard)
  @ApiBearerAuth()
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async getFundById(
    @CurrentAuthUser()
    authUserPayload: AuthenticatedUser,
    @Param('fundId') fundId: string,
  ) {
    const rawFund = await this.fundsService.findFundById(fundId);

    if (!rawFund) {
      throw new NotFoundError(null, 'Fund not found');
    }

    const generalParameters = await this.generalParametersService.findFirst();
    const currency = FinanceHelper.getCurrencySign(generalParameters.currency);

    const fundResult = this.fundsService.addAdditionalData([rawFund], {
      currency,
      user: authUserPayload?.user,
      batchRunDate: generalParameters.fundBatchRunDate,
    });

    return this.transformToObject(fundResult[0], FundResultSubject);
  }

  @Get(':fundId/yields')
  @ApiOperation({
    summary: 'Retrieve all yields for specified fund',
  })
  @ApiFailedHttpResponse()
  @ApiChartsQuery()
  @ApiResponse({
    status: 200,
    description: 'Yields for specified fund',
    schema: dataChartSchemaResponse,
  })
  @ApiResponse({
    status: 404,
    description: 'Fund not found',
    schema: errorSchemaResponse,
  })
  @UseGuards(ExistedFundGuard)
  @UseInterceptors(DatasetsChartTransformInterceptor, TransformInterceptor)
  public async getFundsYields(@Param('fundId') fundId: string, @Query() query: ChartQueryDto) {
    await this.yieldService.retrieveGeneralParameters();
    const [rawData, yAxisData] = await Promise.all([
      this.yieldService.getFundYields(fundId, query),
      this.yieldService.getYAxis(),
    ]);

    const additionalData = this.transformToObject(rawData, FundYieldsAdditionalDataSubject, {
      strategy: 'exposeAll',
    });

    const yAxis = this.transformToObject(yAxisData, FundYieldsYAxisSubject);

    const data = {
      chart: { unit: 'price', datasets: additionalData, y_axis: yAxis },
    };

    return this.transformToObject(data, PortfolioGraphResponseSubject, {
      strategy: 'exposeAll',
    });
  }

  @Get(':fundId/assettypes')
  @ApiResponse({
    status: 404,
    description: 'Fund not found',
    schema: errorSchemaResponse,
  })
  @ApiDataArrayResponse(FundAssetTypeSubject, 'All asset types for specified fund')
  @UseGuards(ExistedFundGuard)
  @ApiFailedHttpResponse()
  @ApiOperation({ summary: 'Retrieve all asset types for specified fund' })
  @UseInterceptors(TransformInterceptor)
  public async getAssets(@Param('fundId') fundId: string) {
    const res = await this.fundItemDistributionService.getAssetTypesByFund(fundId);

    return this.transformToArray(res, FundAssetTypeSubject);
  }

  @Get(':fundId/sectors')
  @ApiResponse({
    status: 404,
    description: 'Fund not found',
    schema: errorSchemaResponse,
  })
  @ApiDataArrayResponse(FundSectorSubject, 'All sectors for specified fund')
  @UseGuards(ExistedFundGuard)
  @ApiFailedHttpResponse()
  @ApiOperation({ summary: 'Retrieve all sectors for specified fund' })
  @UseInterceptors(TransformInterceptor)
  public async getSectors(@Param('fundId') fundId: string) {
    const res = await this.fundItemDistributionService.getSectorsByFund(fundId);

    return this.transformToArray(res, FundSectorSubject);
  }

  @Get(':fundId/holdings')
  @ApiResponse({
    status: 404,
    description: 'Fund not found',
    schema: errorSchemaResponse,
  })
  @ApiFinanceAssetTypeDecorator()
  @ApiDataPaginatedResponse(FundHoldingSubject, 'All holdings for specified fund')
  @UseGuards(ExistedFundGuard)
  @ApiFailedHttpResponse()
  @ApiPaginationQuery()
  @ApiOperation({ summary: 'Retrieve all holdings for specified fund' })
  @UseInterceptors(PaginationTransformInterceptor)
  public async getHoldings(
    @Param('fundId') fundId: string,
    @Query() query: PaginationDto,
    @Query('assetType') assetType?: string,
  ) {
    const { skip, take } = this.pagination(query.index, query.size);

    const [rawHoldingsAndTotal, generalParameters] = await Promise.all<[IFundHolding[], number], GeneralParameters>([
      this.fundAssetsService.getHoldingsByFund(fundId, skip, take, assetType),
      this.generalParametersService.findFirst(),
    ]);
    const [rawHoldings, total] = rawHoldingsAndTotal;

    const currency = FinanceHelper.getCurrencySign(generalParameters.currency);

    const preparedHoldings = FinanceHelper.supplementByCurrency(rawHoldings, currency);

    const holdings = this.transformToArray(preparedHoldings, FundHoldingSubject);

    return {
      data: holdings,
      total,
      index: skip,
      size: holdings.length,
    } as IPaginatedDataResponse<FundHoldingSubject>;
  }

  @Get(':fundId/locations')
  @ApiResponse({
    status: 404,
    description: 'Fund not found',
    schema: errorSchemaResponse,
  })
  @ApiDataArrayResponse(FundLocationSubject, 'All locations for specified fund')
  @UseGuards(ExistedFundGuard)
  @ApiFailedHttpResponse()
  @ApiOperation({ summary: 'Retrieve all locations for specified fund' })
  @UseInterceptors(TransformInterceptor)
  public async getLocations(@Param('fundId') fundId: string) {
    const res = await this.fundItemDistributionService.getLocationsByFund(fundId);

    return this.transformToArray(res, FundLocationSubject);
  }

  @Get(':fundId/dividends')
  @ApiResponse({
    status: 404,
    description: 'Fund not found',
    schema: errorSchemaResponse,
  })
  @ApiDataArrayResponse(FundDividendsSubject, 'All dividends for specified fund')
  @UseGuards(ExistedFundGuard)
  @ApiFailedHttpResponse()
  @ApiOperation({ summary: 'Retrieve all dividends for specified fund' })
  @UseInterceptors(TransformInterceptor)
  public async getDividends(@Param('fundId') fundId: string) {
    const res = await this.fundsService.findDividends(fundId);

    return this.transformToArray(res, FundDividendsSubject);
  }

  @Get(':fundId/currencyexposure')
  @ApiResponse({
    status: 404,
    description: 'Fund not found',
    schema: errorSchemaResponse,
  })
  @ApiDataArrayResponse(FundCurrencySubject, 'All currency exposures for specified fund')
  @UseGuards(ExistedFundGuard)
  @ApiFailedHttpResponse()
  @ApiOperation({
    summary: 'Retrieve all currency exposures for specified fund',
  })
  @UseInterceptors(TransformInterceptor)
  public async getCurrencyExposure(@Param('fundId') fundId: string) {
    const res = await this.fundItemDistributionService.getCurrencyExposuresByFund(fundId);

    return this.transformToArray(res, FundCurrencySubject);
  }
}
