import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { NotFoundError } from '../../shared/errors/notFound.error';
import { Funds } from '../../entities/Funds';

export const CurrentFund = createParamDecorator((data: any, context: ExecutionContext): Record<'fund', Funds> => {
  const request = context.switchToHttp().getRequest();

  if (!request.fund) {
    throw new NotFoundError(null, 'Fund not found');
  }

  return {
    fund: request.fund,
  };
});
