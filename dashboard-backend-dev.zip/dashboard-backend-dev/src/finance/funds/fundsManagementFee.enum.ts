export enum FundsManagementFeeEnum {
  ABOVE = 'above1.5',
  BELOW = 'below1.5',
  NONE = 'none',
}
