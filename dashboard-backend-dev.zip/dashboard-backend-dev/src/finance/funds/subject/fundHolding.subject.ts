import { Expose, Transform } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class FundHoldingSubject {
  @Expose({ name: 'id', toPlainOnly: true })
  @ApiProperty({ name: 'id' })
  @Transform(
    (value) => {
      return value.value.trim();
    },
    { toPlainOnly: true },
  )
  fund_assets_asset_id: string;

  @Expose({ name: 'percentage', toPlainOnly: true })
  @ApiProperty({ name: 'percentage' })
  fund_assets_percentage: string;

  @Expose()
  @ApiProperty()
  currency: string;

  @Expose({ name: 'assetType', toPlainOnly: true })
  @ApiProperty({ name: 'assetType' })
  fund_asset_type: string;

  @Expose({ name: 'assetTypeDescriptionEn', toPlainOnly: true })
  @ApiProperty({ name: 'assetTypeDescriptionEn' })
  fund_asset_type_description_en: string;

  @Expose({ name: 'assetTypeDescriptionHe', toPlainOnly: true })
  @ApiProperty({ name: 'assetTypeDescriptionHe' })
  fund_asset_type_description_he: string;

  @Expose({ name: 'name', toPlainOnly: true })
  @ApiProperty({ name: 'name' })
  assets_description: string;

  @Expose({ name: 'nameEn', toPlainOnly: true })
  @ApiProperty({ name: 'nameEn' })
  fund_asset_description_en: string;

  @Expose({ name: 'isin', toPlainOnly: true })
  @ApiProperty({ name: 'isin' })
  fund_asset_isin: string;
}
