import { Expose, Transform } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class FundYieldsAdditionalDataSubject {
  @Expose()
  @ApiProperty()
  @Transform(
    (value) => {
      return {
        dailyPriceChange: value.obj.daily_price_change,
      };
    },
    { toPlainOnly: true },
  )
  additionalData: any;
}
