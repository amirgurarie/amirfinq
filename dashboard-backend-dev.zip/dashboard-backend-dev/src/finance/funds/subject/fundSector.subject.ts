import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class FundSectorSubject {
  @Expose({ name: 'id', toPlainOnly: true })
  @ApiProperty({ name: 'id' })
  sector_id: string;

  @Expose({ name: 'nameEn', toPlainOnly: true })
  @ApiProperty({ name: 'nameEn' })
  name_en: string;

  @Expose({ name: 'nameHe', toPlainOnly: true })
  @ApiProperty({ name: 'nameHe' })
  name_he: string;

  @Expose()
  @ApiProperty()
  percentage: number;
}
