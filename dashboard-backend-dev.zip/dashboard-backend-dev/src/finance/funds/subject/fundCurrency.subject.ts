import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IFundCurrency } from '../interfaces/fundCurrency.interface';

export class FundCurrencySubject implements IFundCurrency {
  @Expose({ name: 'id', toPlainOnly: true })
  @ApiProperty({ name: 'id' })
  currency_id: string;

  @Expose({ name: 'name', toPlainOnly: true })
  @ApiProperty({ name: 'name' })
  currency_description: string;

  @Expose({ name: 'nameEn', toPlainOnly: true })
  @ApiProperty({ name: 'nameEn' })
  currency_description_en: string;

  @Expose()
  @ApiProperty()
  percentage: number;
}
