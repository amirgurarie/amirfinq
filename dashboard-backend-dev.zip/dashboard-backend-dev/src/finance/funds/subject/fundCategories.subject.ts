import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform, Type } from 'class-transformer';
import { SharedRefListSubject } from 'src/shared/subjects/sharedRefList.subject';

export class InternalCategoriesListSubject extends SharedRefListSubject {
  // Not exposed to the client, but used to generate the other fields for the client
  _catId: string;
  _catUiOrder: string;

  @Expose({ name: 'classification', toPlainOnly: true })
  _fundClassification: string;

  @Expose()
  @ApiProperty({ type: InternalCategoriesListSubject, isArray: true })
  @Type(() => InternalCategoriesListSubject)
  secondaryClassifications: InternalCategoriesListSubject[] = [];
}

export class FundCategoriesSubject extends InternalCategoriesListSubject {
  @Expose()
  @ApiProperty()
  textHe: string;

  @Expose()
  @ApiProperty()
  textEn: string;

  @Expose()
  @ApiProperty()
  @Transform(({ value }) => value.filter(Boolean))
  classifications: string[];

  @Expose()
  @ApiProperty({ type: InternalCategoriesListSubject, isArray: true })
  @Type(() => InternalCategoriesListSubject)
  subCategories: InternalCategoriesListSubject[];
}
