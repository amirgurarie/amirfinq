import { ApiProperty } from '@nestjs/swagger';
import { Expose, Transform } from 'class-transformer';

export class FundHouseSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  fundHouse?: string;

  @Expose()
  @ApiProperty()
  fundHouseEn?: string;

  @Expose()
  @ApiProperty()
  logo?: string;

  @Expose()
  @ApiProperty()
  logo150?: string;

  @Expose()
  @ApiProperty()
  @Transform(({ value }) => value.filter(Boolean))
  classifications: string[];
}
