import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { FundSubject } from 'src/finance/portfolios/subject/fund.subject';

export class FundResultSubject extends FundSubject {
  @Expose()
  @ApiProperty()
  matchPercentage: number;
}
