import { Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { IFundDividends } from '../interfaces/fundDividends.interface';
import { DateToEpochTransform } from '../../../shared/decorators/subjects/dateToEpochTransform.decorator';

export class FundDividendsSubject implements IFundDividends {
  @Expose({ name: 'timestamp', toPlainOnly: true })
  @ApiProperty({ name: 'timestamp' })
  @DateToEpochTransform()
  dividend_date: number;

  @Expose({ name: 'dividend', toPlainOnly: true })
  @ApiProperty({ name: 'dividend' })
  dividend_rate: number;

  @Expose({ name: 'yield', toPlainOnly: true })
  @ApiProperty({ name: 'yield' })
  dividend_yield: number;
}
