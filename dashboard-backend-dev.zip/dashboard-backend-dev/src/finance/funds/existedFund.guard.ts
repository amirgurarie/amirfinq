import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { FundsService } from './funds.service';
import { NotFoundError } from '../../shared/errors/notFound.error';

@Injectable()
export class ExistedFundGuard implements CanActivate {
  constructor(private readonly fundsService: FundsService) {}

  public async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();

    const fundId = request.params?.fundId;

    const fund = await this.fundsService.findFundById(fundId);

    if (!fund) {
      throw new NotFoundError(null, 'Fund not found');
    }
    request.fund = fund;

    return true;
  }
}
