export enum FundsSortTypesEnum {
  BestMatch = 'bestMatch',
  Highest1YearYield = 'highest1YearYield',
  Lowest1YearYield = 'lowest1YearYield',
  Oldest = 'oldest',
  Newest = 'newest',
  Rating = 'rating',
}
