export enum FundsClassificationEnum {
  OPEN = 'OPEN',
  CLOSE = 'CLOSE',
  INDEX = 'INDEX',
}

export enum ClassificationToHebrew {
  OPEN = 'פתוחה',
  CLOSE = 'סגורה',
  INDEX = 'מחקה',
}
