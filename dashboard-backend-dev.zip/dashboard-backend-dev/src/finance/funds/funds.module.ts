import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Funds } from '../../entities/Funds';
import { FundsService } from './funds.service';
import { LoggerModule } from '../../shared/middlewares/logger/logger.module';
import { GeneralParametersModule } from '../../shared/modules/generalParameters/generalParameters.module';
import { FundsCommonModule } from '../fundsCommon/fundsCommon.module';
import { RefFundHouse } from 'src/entities/RefFundHouse';
import { FundsController } from './funds.controller';
import { AssetFavoritesModule } from '../assetFavorites/assetFavorites.module';
import { RefFundSubType } from 'src/entities/RefFundSubType';
import { RefFundSubCategory } from 'src/entities/RefFundSubCategory';
import { RefFundClassification, RefFundType, RefFundSecondaryClassification } from 'src/entities';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Funds,
      RefFundClassification,
      RefFundType,
      RefFundHouse,
      RefFundSubType,
      RefFundSubCategory,
      RefFundSecondaryClassification,
    ]),
    LoggerModule,
    GeneralParametersModule,
    forwardRef(() => FundsCommonModule),
    forwardRef(() => AssetFavoritesModule),
  ],
  providers: [FundsService],
  controllers: [FundsController],
  exports: [FundsService],
})
export class FundsModule {}
