import { GeneralParameters } from '../entities/GeneralParameters';
import { CurrencyHelper } from './currency.helper';
import { AssetType, isFund } from './portfolios/interfaces/asset.type';
import { RefCurrency } from 'src/entities/RefCurrency';
import { PortfolioSelectionsInterface } from './portfolios/selectedPortfolios/interfaces/portfolioSelections.interface';
import { PortfolioSelectionDetailsInterface } from './portfolios/selectedPortfolios/interfaces/portfolioSelectionDetails.interface';
import { UnifiedPortfolioStatusEnum } from './portfolios/interfaces/portfoliosStatus.enum';
import { PortfolioAssetsKeys } from './portfolios/subject/portfoliosSubject.helper';

enum CurrencySign {
  nis = '₪',
  dollar = '$',
  dolar = '$',
  usd = '$',
}

export class FinanceHelper {
  static addPortfolioStatus(portfolio: any, portfolioStatus: UnifiedPortfolioStatusEnum) {
    if (!portfolioStatus) return portfolio;

    const isArray = Array.isArray(portfolio);

    const newPortfolio = ((isArray ? portfolio : [portfolio]) ?? []).map((p) => ({ ...p, portfolioStatus }));

    return isArray ? newPortfolio : newPortfolio[0];
  }

  static getCurrencySign(currencyName: string) {
    return CurrencySign[currencyName?.toLowerCase()] || CurrencySign.nis;
  }

  public static supplementByCurrency(dataToBeUpdated: any[], currency: string) {
    return dataToBeUpdated.map((item) => {
      return Object.assign(item, { currency });
    });
  }

  public static calculateFundMatchPercentage(userFinqRiskLevel: number, fundFinqRiskLevel: number) {
    const percentage = 100 - Math.abs((userFinqRiskLevel - fundFinqRiskLevel) * 100);

    return percentage * 0.01;
  }

  public static getFundWithAdds(
    asset: AssetType,
    generalParameters: GeneralParameters,
  ): AssetType & { currency: string | RefCurrency; batchRunDate: Date } {
    const newAsset: any = {
      ...asset,
      batchRunDate: generalParameters.fundBatchRunDate,
    };

    if (isFund(asset)) {
      const currency = CurrencyHelper.getCurrencySign(generalParameters.currency);
      newAsset.currency = currency;
    }

    return newAsset;
  }

  public static getPortfolioSelectionDetailsWithFundCurrencies(
    portfolioSelectionDetails: PortfolioSelectionDetailsInterface[],
    generalParameters: GeneralParameters,
  ): PortfolioSelectionDetailsInterface[] {
    return portfolioSelectionDetails.map((details) => {
      const asset = FinanceHelper.getFundWithAdds(details.asset, generalParameters);

      return {
        ...details,
        ...{ asset },
      };
    });
  }

  /**
   * used to get the user proposal details with the fund currencies and the batch run date
   *
   * @param portfolio - portfolio to be updated
   * @param generalParameters - general parameters
   * @param assetsDetailsKey - key of the assets details array in the portfolio
   * @returns - portfolio with updated assets details and batchRunDate
   */
  public static addCurrencyAndBatchDate<T = any>(
    portfolio: T,
    generalParameters: GeneralParameters,
    assetsDetailsKey: PortfolioAssetsKeys,
  ): T & { batchRunDate: Date; currency: string; finqManagementFee: number } {
    portfolio[assetsDetailsKey] = (portfolio[assetsDetailsKey] ?? []).map((details) => {
      const fixedAsset = FinanceHelper.getFundWithAdds(details.asset, generalParameters);

      return { ...details, asset: fixedAsset };
    });

    return FinanceHelper.wrapWithGeneralParameters(portfolio, generalParameters);
  }

  public static getFullPortfolioSelectionWithSelectionDetails(
    portfolioSelection: PortfolioSelectionsInterface,
    generalParameters: GeneralParameters,
  ): PortfolioSelectionsInterface & { batchRunDate: Date; currency: string } {
    portfolioSelection.portfolioSelectionDetails = FinanceHelper.getPortfolioSelectionDetailsWithFundCurrencies(
      portfolioSelection.portfolioSelectionDetails,
      generalParameters,
    );

    return FinanceHelper.wrapWithGeneralParameters(portfolioSelection, generalParameters);
  }

  public static wrapWithGeneralParameters<T = any>(
    data: T,
    params: GeneralParameters,
  ): T & { batchRunDate: Date; currency: string; finqManagementFee: number } {
    return {
      ...data,
      finqManagementFee: params.fullManagementPrice,
      batchRunDate: params.fundBatchRunDate,
      currency: CurrencyHelper.getCurrencySign(params.currency),
    };
  }
}
