import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { APP_FILTER, APP_INTERCEPTOR } from '@nestjs/core';
import { ThrottlerModule } from '@nestjs/throttler';
import { TypeOrmModule } from '@nestjs/typeorm';
import { I18nSyncMiddleware } from 'src/shared/middlewares/i18nSync.middleware';
import { Connection } from 'typeorm';
import { AddressModule } from './address/address.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { CommonModule } from './common/common.module';
import { AssetFavoritesModule } from './finance/assetFavorites/assetFavorites.module';
import { PortfolioDocsModule } from './finance/docs/portfolioDocs.module';
import { FundsModule } from './finance/funds/funds.module';
import { FundsCommonModule } from './finance/fundsCommon/fundsCommon.module';
import { PensionsModule } from './finance/pensions/pensions.module';
import { PortfoliosModule } from './finance/portfolios/portfolios.module';
import { StocksModule } from './finance/stocks/stocks.module';
import { KYCOldModule } from './kyc-old/kyc.module';
import { KycModule } from './kyc/kyc.module';
import { TickerModule } from './news/ticker/ticker.module';
import { PaymentsModule } from './payments/payments.module';
import { AllExceptionFilter } from './shared/filters/allException.filter';
import { HttpLoggerInterceptor } from './shared/interceptors/httpLogger.interceptor';
import { LoggerMiddleware } from './shared/middlewares/logger.middleware';
import { LoggerModule } from './shared/middlewares/logger/logger.module';
import { AnalyticsModule } from './shared/modules/analytics/analytics.module';
import { UsersModule } from './users/users.module';
import { Auth0WebhookModule } from './webhooks/auth0Webhook/auth0Webhook.module';
import { FlowStageModule } from './flow-stages/flowStage.module';
import { FlowGatewayModule } from './shared/modules/flowGateway/flowGateway.module';
import { UserMigrationModule } from './user-migration/user-migration.module';
import { ProxyModule } from './proxy/proxy.module';
import { HoustonModule } from './houston/houston.module';
import { CalendlyModule } from './shared/modules/calendly/calendly.module';
import { validateEnv } from './env/schema';
import { FormallyDocumentModule } from './shared/modules/formally/modules/formally-document.module';
import { StaticDataModule } from './static-data-sync/static-data.module';
import { SentryModule } from '@sentry/nestjs/setup';
import './polyfill'; // KEEP THIS LAST

@Module({
  imports: [
    SentryModule.forRoot(),
    ConfigModule.forRoot({
      isGlobal: true,
      validate: validateEnv,
    }),
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (configService: ConfigService) => {
        return {
          type: 'postgres',
          url: `postgresql://${configService.get<string>('TYPEORM_USERNAME')}:${encodeURIComponent(
            configService.get<string>('TYPEORM_PASSWORD'),
          )}@${configService.get<string>('TYPEORM_HOST')}:${configService.get<number>(
            'TYPEORM_PORT',
          )}/${configService.get<string>('POSTGRES_DATABASE')}?application_name=FINKFrontEnd`,
          // host: configService.get<string>('TYPEORM_HOST'),
          // port: configService.get<number>('TYPEORM_PORT'),
          // username: configService.get<string>('TYPEORM_USERNAME'),
          entities: ['dist/**/*.entity{.ts,.js}', 'dist/entities/**/*{.ts,.js}'],
          // password: configService.get<string>('TYPEORM_PASSWORD'),
          // database: configService.get<string>('POSTGRES_DATABASE'),
          logging: process.env.TYPEORM_LOG_QUERIES === 'false' ? ['error', 'warn'] : 'all',
          debug: configService.get<boolean>('TYPEORM_DEBUG') || true,
          logger: 'simple-console',
          multipleStatements: configService.get<boolean>('TYPEORM_MULTIPLE_STATEMENTS') || false,
          cacheDisabled: {
            // change back to 'cache' to enable 'redis' cache
            type: 'redis',
            ignoreErrors: true,
            options: {
              host: configService.get<string>('REDIS_HOST', 'localhost'),
              port: configService.get<number>('REDIS_PORT', 6379),
              password: configService.get<string>('REDIS_PASSWORD', ''),
              tls: configService.get<number>('REDIS_PORT') === 6380,
            },
            duration: configService.get<number>('REDIS_CACHE_DURATION') || 7200000, // for 2 hours by default
          },
        };
      },
    }),
    ThrottlerModule.forRoot([
      {
        ttl: 60000,
        limit: 10,
      },
    ]),
    PortfoliosModule,
    UsersModule,
    PortfolioDocsModule,
    KycModule,
    FlowStageModule,
    KYCOldModule,
    LoggerModule,
    AddressModule,
    AuthModule,
    Auth0WebhookModule,
    TickerModule,
    FundsCommonModule,
    FundsModule,
    CommonModule,
    StocksModule,
    AssetFavoritesModule,
    PaymentsModule,
    PensionsModule,
    StaticDataModule,
    AnalyticsModule,
    FlowGatewayModule,
    UserMigrationModule,
    ProxyModule,
    HoustonModule,
    CalendlyModule,
    FormallyDocumentModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_INTERCEPTOR,
      useClass: HttpLoggerInterceptor,
    },
    {
      provide: APP_FILTER,
      useClass: AllExceptionFilter,
    },
  ],
})
export class AppModule implements NestModule {
  constructor(private connection: Connection) {}
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(LoggerMiddleware, I18nSyncMiddleware).forRoutes('*');
  }
}
