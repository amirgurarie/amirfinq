import { get } from 'lodash';
import { IsInCaseInsensitiveConstraint } from './../shared/validators/constraints/isInCaseInsensitiveConstraint';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, getConnection, Repository, SelectQueryBuilder } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { ServiceHelper } from '../shared/modules/service.helper';
import { RefAddress } from '../entities/RefAddress';
import { AddressByStreetDto } from './dto/addressByStreet.dto';
import { AddressByCityDto } from './dto/addressByCity.dto';
import { RefCities } from '../entities/RefCities';
import { RefStreets } from '../entities/RefStreets';

@Injectable()
export class AddressService {
  constructor(
    @InjectRepository(RefCities)
    private readonly refCitiesRepository: Repository<RefCities>,
    @InjectRepository(RefStreets)
    private readonly refStreetsRepository: Repository<RefStreets>,
  ) {}

  public async findAddressByCityId(id: number): Promise<RefCities> {
    return await this.refCitiesRepository.findOne({
      id,
    });
  }

  public async findStreetsByCityIdAndFilters(
    cityId: number,
    filters: AddressByStreetDto,
    skip: number,
    take: number,
  ): Promise<[RefStreets[], number]> {
    const query = this.refStreetsRepository
      .createQueryBuilder('ref_streets')
      .select()
      .leftJoinAndSelect('ref_streets.refCities', 'ref_cities')
      .where('ref_cities.id = :cityId', {
        cityId: cityId,
      });
    if (filters.street) {
      query
        .andWhere(
          new Brackets((qb) => {
            qb.where('ref_streets.description_he LIKE :streetStart', {
              streetStart: `${filters.street}%`,
            })
              .orWhere('ref_streets.description_he LIKE :streetContain', {
                streetContain: `%${filters.street}%`,
              })
              .orWhere('LOWER(ref_streets.description_en) LIKE LOWER(:streetStart)', {
                streetStart: `%${filters.street}%`,
              })
              .orWhere('LOWER(ref_streets.description_en) LIKE LOWER(:streetContain)', {
                streetContain: `%${filters.street}%`,
              });
          }),
        )
        .orderBy(
          `CASE WHEN (ref_streets.description_he LIKE '${filters.street}%') is true then ref_streets.description_he END ASC, 
           ref_streets.description_he ASC, 
           CASE WHEN (ref_streets.description_he LIKE '%${filters.street}%') is true then ref_streets.description_he END,
           CASE WHEN (LOWER(ref_streets.description_en) LIKE LOWER('${filters.street}%')) is true then ref_streets.description_en END ASC, 
           ref_streets.description_en ASC, 
           CASE WHEN (LOWER(ref_streets.description_en) LIKE LOWER('%${filters.street}%')) is true then ref_streets.description_en END`,
        );
    }
    const [listItems, count] = await query.skip(skip).cache(true).getManyAndCount();

    return [listItems, count];
  }

  public async mapCityOnStreets(cityId: number, streets: RefStreets[]) {
    const refCity = await this.refCitiesRepository.findOne(cityId);

    return streets.map((street) => {
      street.refCities = refCity;

      return street;
    });
  }

  public async findCity(filters: AddressByCityDto, skip: number, take: number): Promise<[{ count: number }, any[]]> {
    if (filters.city) {
      const countCities = this.refCitiesRepository
        .createQueryBuilder('ref_cities')
        .select('COUNT(DISTINCT "city_num") AS count')
        .where('description_he LIKE :cityStart', {
          cityStart: `${filters.city}%`,
        })
        .orWhere('description_he LIKE :cityContain', {
          cityContain: `%${filters.city}%`,
        })
        .orWhere('LOWER(description_en) LIKE LOWER(:cityStart)', {
          cityStart: `%${filters.city}%`,
        })
        .orWhere('LOWER(description_en) LIKE LOWER(:cityContain)', {
          cityContain: `%${filters.city}%`,
        })
        .cache(true)
        .getRawOne();

      const citiesData = this.refCitiesRepository
        .createQueryBuilder('ref_cities')
        .select([
          'DISTINCT ON (city_num) city_num as "cityNum"',
          'id as "id"',
          'description_he as "descriptionHe"',
          'description_en as "descriptionEn"',
          'index_reference as "indexReference"',
        ])
        .where('description_he LIKE :cityStart', {
          cityStart: `${filters.city}%`,
        })
        .orWhere('description_he LIKE :cityContain', {
          cityContain: `%${filters.city}%`,
        })
        .orWhere('LOWER(description_en) LIKE LOWER(:cityStart)', {
          cityStart: `%${filters.city}%`,
        })
        .orWhere('LOWER(description_en) LIKE LOWER(:cityContain)', {
          cityContain: `%${filters.city}%`,
        })
        .orderBy('city_num')
        .addOrderBy(
          `CASE WHEN ("ref_cities"."description_he" LIKE '${filters.city}%') is true then "ref_cities"."description_he" END ASC, 
          "ref_cities"."description_he" ASC, 
          CASE WHEN ("ref_cities"."description_he" LIKE '%${filters.city}%') is true then "ref_cities"."description_he" END,
          CASE WHEN (LOWER("ref_cities"."description_en") LIKE LOWER('${filters.city}%')) is true then "ref_cities"."description_en" END ASC, 
          "ref_cities"."description_en" ASC, 
          CASE WHEN (LOWER("ref_cities"."description_en") LIKE LOWER('%${filters.city}%')) is true then "ref_cities"."description_en" END
      `,
        )
        .skip(skip)
        .take(take)
        .cache(true)
        .getRawMany();

      return await Promise.all([countCities, citiesData]);
    }
    const allCities = this.refCitiesRepository
      .createQueryBuilder('refCities')
      .select([
        'DISTINCT ON (city_num) city_num as "cityId"',
        'description_he as "descriptionHe"',
        'description_en as "descriptionEn"',
        'index_reference as "indexReference"',
      ])
      .skip(skip)
      .take(take)
      .cache(true);

    return await Promise.all([{ count: await allCities.getCount() }, allCities.getRawMany()]);
  }

  public async findAddressesByStreet(
    filters: AddressByStreetDto,
    skip: number,
    take: number,
  ): Promise<[number, RefStreets[]]> {
    const query = this.refStreetsRepository
      .createQueryBuilder('ref_streets')
      .select()
      .leftJoinAndSelect('ref_streets.refCities', 'ref_cities');
    if (filters.street) {
      query
        .where('ref_streets.description_he LIKE :street', {
          street: `${filters.street}%`,
        })
        .orWhere('LOWER(ref_streets.description_en) LIKE LOWER(:street)', {
          street: `${filters.street}%`,
        });
    }

    return await Promise.all([
      await query.cache(true).getCount(),
      await query.skip(skip).take(take).cache(true).getMany(),
    ]);
  }

  public async findStreetById(id: number): Promise<RefStreets> {
    return await this.refStreetsRepository.findOne(id);
  }

  public async findStreetByIndexReference(indexReference: number): Promise<RefStreets> {
    return await this.refStreetsRepository
      .createQueryBuilder('ref_streets')
      .select()
      .leftJoinAndSelect('ref_streets.refCities', 'ref_cities')
      .where({
        indexReference,
      })
      .getOne();
  }
}
