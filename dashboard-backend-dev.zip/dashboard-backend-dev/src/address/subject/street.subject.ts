import { Exclude, Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';
import { TransformToProperty } from 'src/shared/decorators/subjects/transformToProperty.decorator';

export class StreetSubject {
  @Expose()
  @ApiProperty()
  id: number;

  @Expose()
  @ApiProperty()
  @TransformToProperty('refCities.cityNum')
  cityNum?: string;

  @Expose()
  @TransformToProperty('refCities.descriptionHe')
  cityName?: string;

  @Expose()
  @TransformToProperty('refCities.descriptionEn')
  cityNameEn?: string;

  @Expose({ name: 'streetName', toPlainOnly: true })
  @ApiProperty()
  descriptionHe?: string;

  @Expose({ name: 'streetNameEn', toPlainOnly: true })
  @ApiProperty()
  descriptionEn?: string;

  @Expose()
  @ApiProperty()
  indexReference?: string;
}
