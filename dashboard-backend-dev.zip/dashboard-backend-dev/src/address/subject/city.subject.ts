import { Exclude, Expose } from 'class-transformer';
import { ApiProperty } from '@nestjs/swagger';

export class CitySubject {
  @Expose()
  @ApiProperty()
  id?: number;

  @Expose()
  @ApiProperty()
  cityNum?: number;

  @Expose({ name: 'cityName', toPlainOnly: true })
  @ApiProperty()
  descriptionHe?: string;

  @Expose({ name: 'cityNameEn', toPlainOnly: true })
  @ApiProperty()
  descriptionEn?: string;

  @Expose()
  @ApiProperty()
  indexReference?: number;
}
