import { RefStreets } from './../entities/RefStreets';
import { Controller, Get, Param, Query, UseInterceptors } from '@nestjs/common';
import { ApiExtraModels, ApiOperation, ApiParam, ApiQuery, ApiTags } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config';
import { AddressService } from './address.service';
import { StreetSubject } from './subject/street.subject';
import { AddressSubject } from './subject/address.subject';
import { AbstractController } from '../shared/controller';
import { PaginationTransformInterceptor } from '../shared/interceptors/paginationTransform.interceptor';
import { TransformInterceptor } from '../shared/interceptors/transform.interceptor';
import { AddressByCityDto } from './dto/addressByCity.dto';
import { AddressByStreetDto } from './dto/addressByStreet.dto';
import { ApiFailedHttpResponse } from '../shared/decorators/apiFailedHttpResponse.decorator';
import { ApiPaginationQuery } from '../shared/decorators/apiPaginationQuery.decorator';
import { ApiDataObjectResponse, ApiDataPaginatedResponse } from '../shared/decorators/dataResponse.decorator';
import { PaginationSubject } from '../shared/subjects/pagination.subject';
import { CitySubject } from './subject/city.subject';

@ApiTags('Common')
@Controller('v1/address')
@ApiExtraModels(AddressSubject, PaginationSubject)
export class AddressController extends AbstractController {
  constructor(private readonly addressService: AddressService, protected readonly configService: ConfigService) {
    super(configService);
  }

  @Get('city')
  @ApiQuery({
    name: 'city',
    required: false,
    type: String,
    description: 'Filter cities with names that start with this prefix. Can be empty',
  })
  @ApiPaginationQuery()
  @UseInterceptors(PaginationTransformInterceptor)
  @ApiOperation({ summary: 'Get all addresses by given city criteria' })
  @ApiDataPaginatedResponse(AddressSubject, 'Get all addresses by given city criteria')
  @ApiFailedHttpResponse()
  public async findAddressesByCity(@Query() query: AddressByCityDto): Promise<any> {
    const { skip, take } = this.pagination(query.index, query.size);

    const [total, rawAddresses] = await this.addressService.findCity(query, skip, take);
    const addresses = this.transformToArray(rawAddresses, CitySubject);

    return {
      data: addresses,
      total: Number(total.count),
      index: skip,
      size: addresses.length,
    } as IPaginatedDataResponse<CitySubject>;
  }

  @Get('street')
  @ApiOperation({ summary: 'Get all addresses by given city criteria' })
  @ApiQuery({
    name: 'street',
    required: false,
    type: String,
    description: 'Filter cities with names that start with this prefix. Can be empty',
  })
  @ApiPaginationQuery()
  @ApiDataPaginatedResponse(AddressSubject, 'Get all addresses by given city criteria')
  @ApiFailedHttpResponse()
  @UseInterceptors(PaginationTransformInterceptor)
  public async findAddressesByStreet(@Query() query: AddressByStreetDto): Promise<any> {
    const { skip, take } = this.pagination(query.index, query.size);
    const [total, rawAddresses] = await this.addressService.findAddressesByStreet(query, skip, take);

    const addresses = this.transformToArray(rawAddresses, StreetSubject);

    return {
      data: addresses,
      total,
      index: skip,
      size: addresses.length,
    } as IPaginatedDataResponse<AddressSubject>;
  }

  @Get('city/:cityId')
  @ApiOperation({ summary: 'Get address by given cityId criteria' })
  @ApiDataObjectResponse(AddressSubject, 'Get address by given cityId criteria')
  @ApiParam({
    name: 'cityId',
    required: true,
    type: String,
  })
  @ApiFailedHttpResponse()
  @UseInterceptors(TransformInterceptor)
  public async findCityByNum(@Param('cityId') id: number): Promise<any> {
    const address = await this.addressService.findAddressByCityId(id);

    return this.transformToObject(address, CitySubject);
  }

  @Get('city/:cityId/street')
  @ApiPaginationQuery()
  @ApiQuery({
    name: 'street',
    required: false,
    type: String,
    description: 'Filter cities with names that start with this prefix. Can be empty',
  })
  @ApiOperation({
    summary: 'Get all addresses by given city and street criteria',
  })
  @ApiDataPaginatedResponse(AddressSubject, 'Get all addresses by given city and street criteria')
  @UseInterceptors(PaginationTransformInterceptor)
  @ApiFailedHttpResponse()
  public async findAddressesByStreetAndCityId(
    @Param('cityId') cityId: number,
    @Query() query: AddressByStreetDto,
  ): Promise<any> {
    const { skip, take } = this.pagination(query.index, query.size);
    const [rawAddresses, total] = await this.addressService.findStreetsByCityIdAndFilters(cityId, query, skip, take);
    const addresses = this.transformToArray(rawAddresses, StreetSubject);

    return {
      data: addresses,
      total,
      index: skip,
      size: addresses.length,
    } as IPaginatedDataResponse<AddressSubject>;
  }

  @Get(':addressId')
  @ApiOperation({ summary: 'Get address by given address id' })
  @ApiDataObjectResponse(AddressSubject, 'Get address by given address id')
  @UseInterceptors(TransformInterceptor)
  @ApiFailedHttpResponse()
  public async findById(@Param('addressId') addressId: number) {
    const address = await this.addressService.findStreetById(addressId);

    return this.transformToObject(address, StreetSubject);
  }
}
