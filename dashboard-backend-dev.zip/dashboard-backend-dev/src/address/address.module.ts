import { RefCities } from './../entities/RefCities';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AddressService } from './address.service';
import { AddressController } from './address.controller';
import { RefAddress } from '../entities/RefAddress';
import { RefStreets } from '../entities/RefStreets';

@Module({
  imports: [TypeOrmModule.forFeature([RefAddress, RefCities, RefStreets])],
  providers: [AddressService],
  controllers: [AddressController],
  exports: [AddressService, TypeOrmModule],
})
export class AddressModule {}
