import { PaginationDto } from '../../shared/dto/pagination.dto';
import { IsOptional } from 'class-validator';

export class AddressByCityDto extends PaginationDto {
  @IsOptional()
  public readonly city?: string;
}
