import { PaginationDto } from '../../shared/dto/pagination.dto';
import { IsOptional } from 'class-validator';

export class AddressByStreetDto extends PaginationDto {
  @IsOptional()
  public readonly street?: string;
}
